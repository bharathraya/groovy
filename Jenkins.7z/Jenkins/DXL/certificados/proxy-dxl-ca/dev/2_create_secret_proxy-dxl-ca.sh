oc create secret generic proxy-dxl-ca --from-file=server.truststor
