Estos certificados estan en la seccion secrets/<env>/proxy-dxl-ca, que son los que se utilizan para construir el secret
