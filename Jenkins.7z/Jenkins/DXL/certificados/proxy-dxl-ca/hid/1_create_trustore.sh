keytool -importcert -alias mongo-ca-root -storepass certificado%1 -trustcacerts \
        -file mongo_ca_root.cer -keystore server.truststor
keytool -importcert -alias otp-ca-root -storepass certificado%1 -trustcacerts \
        -file otp_ca_root.cer -keystore server.truststor
keytool -importcert -alias proxy-dxl-cert -storepass certificado%1 -trustcacerts \
        -file proxy_ca.crt -keystore server.truststor
