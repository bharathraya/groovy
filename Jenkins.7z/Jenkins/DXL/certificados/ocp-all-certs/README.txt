En esta carpeta estan los certificados de la consola asi como todos los csr solicitados para el resto de certificados, y sus correspondientes .key
Para los certificados *.apps-int de los micros, cuando sea necesaria renovacion, se tendra que realizar un certificado autogenerado con el wildcard *.apps-int ya que los certificados generados por vodafone no pueden ser generados con *
