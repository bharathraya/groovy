openssl req -new -sha256 -nodes -out assets-es-admin.dxldev.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-admin.dxldev.local.vodafone.es.key -config <(cat assets-es-admin.dxldev.local.vodafone.es.txt)

openssl req -new -sha256 -nodes -out assets-es-admin-sit1.dxlpreprod.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-admin-sit1.dxlpreprod.local.vodafone.es.key -config <(cat assets-es-admin-sit1.dxlpreprod.local.vodafone.es.txt)

openssl req -new -sha256 -nodes -out assets-es-admin-sit2.dxlpreprod.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-admin-sit2.dxlpreprod.local.vodafone.es.key -config <(cat assets-es-admin-sit2.dxlpreprod.local.vodafone.es.txt)

openssl req -new -sha256 -nodes -out assets-es-admin-pprd.dxlpreprod.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-admin-pprd.dxlpreprod.local.vodafone.es.key -config <(cat assets-es-admin-pprd.dxlpreprod.local.vodafone.es.txt)

openssl req -new -sha256 -nodes -out assets-es-admin-hidden.dxl.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-admin-hidden.dxl.local.vodafone.es.key -config <(cat assets-es-admin-hidden.dxl.local.vodafone.es.txt)

openssl req -new -sha256 -nodes -out assets-es-admin.dxl.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-admin.dxl.local.vodafone.es.key -config <(cat assets-es-admin.dxl.local.vodafone.es.txt)
