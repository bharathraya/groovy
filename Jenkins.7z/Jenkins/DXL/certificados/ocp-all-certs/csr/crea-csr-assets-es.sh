openssl req -new -sha256 -nodes -out assets-es-dev.dxldev.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-dev.dxldev.local.vodafone.es.key -config <(cat csr-assets-dev.txt)

openssl req -new -sha256 -nodes -out assets-es-sit1.dxlpreprod.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-sit1.dxlpreprod.local.vodafone.es.key -config <(cat csr-assets-sit1.txt)

openssl req -new -sha256 -nodes -out assets-es-sit2.dxlpreprod.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-sit2.dxlpreprod.local.vodafone.es.key -config <(cat csr-assets-sit2.txt)

openssl req -new -sha256 -nodes -out assets-es-pprd.dxlpreprod.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-pprd.dxlpreprod.local.vodafone.es.key -config <(cat csr-assets-pprd.txt)

openssl req -new -sha256 -nodes -out assets-es-hidden.dxl.local.vodafone.es.csr -newkey rsa:2048 -keyout assets-es-hidden.dxl.local.vodafone.es.key -config <(cat csr-assets-ocul.txt)
