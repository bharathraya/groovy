oc create secret tls myvdf-wildcard-cert --cert=./assets-es-hidden_dxl_local_vodafone_es.pem --key=./assets-es-hidden.dxl.local.vodafone.es.key
