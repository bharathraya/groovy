oc create secret tls myvdf-wildcard-cert --cert=./assets-es-dev_dxldev_local_vodafone_es.pem --key=./assets-es-dev.dxldev.local.vodafone.es.key
