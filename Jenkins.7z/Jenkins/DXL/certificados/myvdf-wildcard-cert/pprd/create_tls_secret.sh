oc create secret tls myvdf-wildcard-cert --cert=./assets-es-pprd_dxlpreprod_local_vodafone_es.pem --key=./assets-es-pprd.dxlpreprod.local.vodafone.es.key
