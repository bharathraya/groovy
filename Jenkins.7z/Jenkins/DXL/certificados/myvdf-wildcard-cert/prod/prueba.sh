oc create secret tls prueba-cert --cert=./assets-es_dxl_local_vodafone_es.pem --key=./assets-es.dxl.local.vodafone.es.key
