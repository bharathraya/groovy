# proxy_dxl.pem= proxy_ca.crt
oc create secret generic proxy-dxl-pem --from-file=proxy_dxl.pem
