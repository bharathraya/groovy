Estos certificados estan en la seccion secrets/<env>/proxy-dxl-pem, que son los que se utilizan para construir el secret
