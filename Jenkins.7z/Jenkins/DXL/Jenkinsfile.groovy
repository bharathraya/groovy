//
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat

// parametros de entrada:
// ${DeployEnv} -> Entorno [SIT1,SIT2,PPRD,HID,master]
// ${ALMS_ID} -> Paquete ALMS / CRQ  
// ${CommitID} -> Commit ID  


def templatePath = 'http://eswltbhr.es.sedc.internal.vodafone.com:8282/vodafone/PRUEBAS/upstream/tree/master/openshift/templates/nodejs-mongodb.json' 
def templateName = 'nodejs-mongodb-example' 
pipeline {
  agent { label 'eswltahr' }
    options {
        timeout(time: 20, unit: 'MINUTES') 
    }
    // variable para contener la configuracion por entorno
    def env_config=null
    def strTimeStamp=null
    def strDate=null
	def mergeMessage=null
    def gitCommitBefore=null
    def gitCommitAfter=null
    def onlyProperties=null    
    def gitFilesChanged=null
    def gitPropertiesChanged=null
    def version=null
    def artifact=null

  stages {
    stage('config_job'){
        // visualizar ALMS, Commit y Entorno
        echo "CommitID: ${CommitID}"
        echo "Entorno: ${DeployEnv}"
        echo "Delivery: ${Delivery}"
        echo "ProjectId: ${ProjectId}"

        currentBuild.displayName = "ALMS: ${ALMS_ID} Env: ${DeployEnv}"
        currentBuild.description = "ID_ALMS: ${ALMS_ID} Entorno: ${DeployEnv} Commit: ${CommitID}"
     
        def timeFormat = new SimpleDateFormat("yyyyMMddHHmmss")
        def dateFormat = new SimpleDateFormat("yyyyMMdd")
        def date = new Date()
        strTimeStamp=timeFormat.format(date)
        strDate=dateFormat.format(date)
        mergeMessage="[${ALMS_ID}][${strTimeStamp}][${DeployEnv}][${Delivery}][${ProjectId}]"

        
    }
    stage('clean'){
        deleteDir()
        sh "mkdir -p /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${DeployEnv}/.m2"
    }
    stage('checkout'){
        
        //checkout([$class: 'GitSCM', branches: [[name: '*/${DeployEnv}']], 
        //   doGenerateSubmoduleConfigurations: false, 
        //    extensions: [], submoduleCfg: [], 
        //    userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', 
        //    url: 'http://eswltbhr.es.sedc.internal.vodafone.com:8282/vodafone/MV-OW/MiVodafone-Angular.git']]])
        sh 'ls -ltra'    
            
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'vfjenkins-passwd',
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            sh '''
                git clone -b${DeployEnv} http://${USERNAME}:${PASSWORD}@eswltbhr:8282/vodafone/DXL/prueba.git project
                git clone http://${USERNAME}:${PASSWORD}@eswltbhr:8282/vodafone/CDM.git CDM
            '''
            }    


			def json = readJSON(file: "${WORKSPACE}/CDM/Jenkins/DXL/build/envs.json")
        env_config = json["${DeployEnv}"]

    }
    stage('merge changes'){
        
             
        dir('project'){
            gitCommitBefore = sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            echo "GitCommit Before MERGE: ${gitCommitBefore}"
	
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'vfjenkins-passwd',
                        usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                sh '''
                    git remote add entregas http://${USERNAME}:${PASSWORD}@eswltbhr:8282/entregas/DXL/prueba.git
                '''
                }  
            // git merge ${CommitID} --no-commit --no-ff
            sh """
                git status
                git fetch entregas"""
            try{
                sh "git merge --no-ff -m'${mergeMessage}' ${CommitID} "
                }
            catch(Exception){
                echo "There are following merge conflicts!"
                sh '''
                set -x
                git diff --name-only --diff-filter=U | while read f
                do
                echo $f
                git log --follow --oneline $f
                echo
                done
                '''
                error('Stopping the job, has merge conflicts!!!')

            }
            gitCommitAfter = sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            echo "GitCommit AFter MERGE: ${gitCommitAfter}"
            sh "git diff --name-only  ${gitCommitBefore}..${gitCommitAfter}"

            def xmlFile = getClass().getResourceAsStream("pom.xml")
            def projectinfo = new XmlParser().parse(xmlFile) 
            def version=projectinfo.version
            def artifact=projectinfo.artifactId
            //revisar si existe en nexus esa versión y ese artefacto
		}
    }

    stage('build'){
	
		//gitCommit = sh(returnStdout: true, script: 'git status | grep -E "modified:|deleted:|added:" | awk \'{print $2}\' | cut -f1 -d"/" > modified_changes').toString().trim()
		//echo "gitCommit=${gitCommit}"
		//sh "cp ../CDM/Jenkins/${JOB_NAME}/busca_pom ."
		//sh "chmod 750 busca_pom ."
		//sh "./busca_pom"
		//sh "cat mypoms"
        dir('project'){
            gitPropertiesChanged=sh(returnStdout: true, script: "git diff --name-only  ${gitCommitBefore}..${gitCommitAfter} | sed -n '/^WCS-[a-zA-Z0-9]*\\/properties\\//!p'").toString().trim()
            gitFilesChanged=sh(returnStdout: true, script: "git diff --name-only  ${gitCommitBefore}..${gitCommitAfter}").toString().trim()

            echo "gitPropertiesChanged: ${gitPropertiesChanged}"
            echo "gitFilesChanged: ${gitFilesChanged}"
            if (gitFilesChanged != ""){
                // there are changes involved !
                if (gitPropertiesChanged != ""){
                    onlyProperties=false
                }else
                {
                    onlyProperties=true
                }
            }else{
                //in case no changes involved , lets recompile all
                onlyProperties=false
            }
        }
        if (onlyProperties){
            echo "There are only property files modified, no need to build!!!"
        }
        else{
			echo "We start build as there are code changes involved in current merge..."
			echo "Copy settings.xml  to .m2 folder ... "
			sh "cp ${WORKSPACE}/CDM/Jenkins/${JOB_NAME}/m2/settings.xml /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${DeployEnv}/.m2"
			echo "Copy cm_build_script  to project folder ... "
			sh "cp ${WORKSPACE}/CDM/Jenkins/${JOB_NAME}/cm_build_script ${WORKSPACE}/project"
			sh "chmod 755 ${WORKSPACE}/project/cm_build_script"

			echo "BUILD ${DeployEnv}"
			sh "docker run -v ${WORKSPACE}/project:/home/platafor/project -v /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${DeployEnv}/.m2:/home/platafor/.m2 --rm --ulimit nofile=98304:98304  vfes_cdm_maven3:latest"
			//error('Stopping the job before rest of steps ...')
		}
    }
    
    stage('preamble') {
        steps {
            script {
               	openshift.withCluster(clusterName) {
               		openshift.withProject(projectName) {
                        echo "Using project: ${openshift.project()}"
                    }
                }
            }
        }
    }
    stage('cleanup') {
        steps {
            script {
                    withEnv(["PATH+OC=${tool 'occli-jenkins'}"]) {
	        	        openshift.withCluster(clusterName) {
	        	            openshift.verbose()
	        	            openshift.logLevel(3)
	                       	echo "Using Cluster: ${openshift.cluster()}"
        	        	    openshift.withProject(projectName) {
	                       	    echo "Using project: ${openshift.project()}"
	                       	    openshift.selector('all', [ app : templateName ]).exists()
	                    		if (openshift.selector('all', [ app : templateName ]).exists()) {
	                    		    openshift.selector('all', [ app : templateName ]).delete() 
                  			        echo "cleanup:all:${templateName} borrado"
	                    		}
	                    		echo "cleanup"
                  			    if (openshift.selector("secrets", templateName).exists()) { 
                    				openshift.selector("secrets", templateName).delete('--ignore-not-found=false')
                    				echo "cleanup:secrets:${templateName} borrado"
                    			}
                  		    }
               	 	    }
            	    }
            }
        }
    }
    stage('create') {
        steps {
            timeout(time:15, unit:'MINUTES') {
                input message: "Create to STAGE?", ok: "Create"
            }            
            script {
                    withEnv(["PATH+OC=${tool 'occli-jenkins'}"]) {
	        	        openshift.withCluster(clusterName) {
        			        openshift.withProject(projectName) {
                                withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'vfjenkins-passwd',
                                usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                                    sh '''
                                        rm -rf upstream
                                        git clone "http://${USERNAME}:${PASSWORD}@195.233.178.75:8282/vodafone/PRUEBAS/upstream.git"
                                        ssh origin@10.225.119.73 "cd ~ ; rm -rf upstream"
                                        scp -rp upstream origin@10.225.119.73:~/.
                                    '''
                                //openshift.exec(command: 'rm', arguments: ['-rf','upstream'])
                                //openshift.exec(command: 'git', arguments: ['clone', "http://${USERNAME}:${PASSWORD}@195.233.178.75:8282/vodafone/PRUEBAS/upstream.git"])
                                }
                                
                                withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'vfjenkins-passwd',
                                usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                                    //def result = openshift.raw( "set env", "bc/${templateName}","HTTP_PROXY=''" )
                                    //openshift.newApp("http://${USERNAME}:${PASSWORD}@195.233.178.75:8282/vodafone/PRUEBAS/upstream.git", "--name=${templateName}")
                                    openshift.newApp("-f upstream/openshift/templates/nodejs.json", "--name=${templateName}")
                                }
                		    }
            		    }
        	        }
            }
        }
    }
    stage('build') {
        steps {
            script {
                    withEnv(["PATH+OC=${tool 'occli-jenkins'}"]) {
		                openshift.withCluster(clusterName) {
                	        openshift.withProject(projectName) {
                  		        def builds = openshift.selector("bc", templateName).related('builds')
                  		        timeout(5) { 
                    		        builds.untilEach(1) {
                    			        return (it.object().status.phase == "Complete")
                    		        }
                  		        }
                	        }
            		    }
        	        }
            }
        }
    }
    stage('deploy') {
        steps {
            script {
                    withEnv(["PATH+OC=${tool 'occli-jenkins'}"]) {
		                openshift.withCluster(clusterName) {
                		    openshift.withProject(projectName) {
                  			    def rm = openshift.selector("dc", templateName).rollout()
                  			    timeout(5) { 
                    				openshift.selector("dc", templateName).related('pods').untilEach(1) {
                      					return (it.object().status.phase == "Running")
                    				}
                  			    }
                		    }
            		    }
            	    }
            }
        }
    }
    stage('tag') {
        steps {
            script {
	                withEnv(["PATH+OC=${tool 'occli-jenkins'}"]) {
        		        openshift.withCluster(clusterName) {
                		    openshift.withProject(projectName) {
                  			    openshift.tag("${templateName}:latest", "${templateName}-${projectName}:latest") 
                		    }
            		    }
        	        }
            }
        }
    }
  }
}