Los siguientes dos ficheros tienen la CA con el que se ha firmado el certificado del proxy. El contenido es el mismo con diferente nombre, ya que el proxy-dxl-pem se ha creado a partir del proxy_dxl.pem

proxy_ca.crt
proxy_dxl.pem

El siguiente fichero tiene el certificado que utiliza el proxy de la dxl. Este certificado se usa en el secret proxy-dxl pero transformado en pkcs12.pfx

proxy_dxl.cert

En parametros.cfg estan definidos los siguientes parametros pero la creacion de estos secrets se realiza a partir de los ficheros
PROXY_DXL_CA
JWT_PUBLIC_CERT
