//
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESJobConfig
// parametros de entrada:
// ${DeployEnv} -> Entorno [SIT1,SIT2,PPRD,HID,master]
// ${ALMS_ID} -> Paquete ALMS / CRQ  
// ${CommitID} -> Commit ID  


node("NTOL-${DeployEnv}"){
	
	// variable para contener la configuracion por entorno
    def ALMS_ID=""
    def CommitID=""
    def Delivery=""
    def ProjectId=""

    def jobConfig=null
       stage('filterIncomingTag'){
        echo sh(returnStdout: true, script: 'env')
        echo "gitlabBranch=${gitlabBranch} refs/tags/${DeployEnv}"
        if (gitlabBranch=="refs/tags/${DeployEnv}"){
            echo "OK!"
        }
        else
        {
            error "NO ${DeployEnv} Tag"
        }        
    }
    
    stage('clean'){
        deleteDir()
    }


    stage('config_job'){
        // visualizar ALMS, Commit y Entorno
        ALMS_ID="${ArtifactId}-${DeployEnv}"
        CommitID=""
        Delivery=""
        ProjectId=""        
        echo "ALMS_ID: ${ALMS_ID}"
        echo "CommitID: ${CommitID}"
        echo "Entorno: ${DeployEnv}"
        echo "Delivery: ${Delivery}"
        echo "ProjectId: ${ProjectId}"
        echo "Artifact: ${ArtifactId}"
        jobConfig=new VFESJobConfig(ALMS_ID,CommitID,DeployEnv,Delivery,ProjectId,
        "WCS-NTOL/${ArtifactId}","WCS-NTOL/BACK/${ArtifactId}.git",
        "${JOB_NAME}","${WORKSPACE}",this)
        jobConfig.jobName="AUX12/WCS-NTOL/BACK/build_back"

        currentBuild.displayName = jobConfig.jobDisplayName
        currentBuild.description = jobConfig.jobDescription
        
    }
    stage('clean'){
        deleteDir()
        
    }
    gitlabBuilds(builds: ['Checkout SCM', 'Build', 'Redeploy']) {
        stage('Checkout SCM')
        {
            gitlabCommitStatus("Checkout SCM") {
                // Usamos la tarea checkout para que en el Job de Jenkins quede constancia del commit origen
                checkout([$class: 'GitSCM', 
                    branches: [[name: "${gitlabBranch}"]], 
                    doGenerateSubmoduleConfigurations: false, 
                    extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${jobConfig.jobProjectFolder}"]], 
                    submoduleCfg: [], 
                    userRemoteConfigs: [[credentialsId: "vfjenkins-passwd", 
                                url: "${gitlabSourceRepoHttpUrl}"]]
                    ])
                // descargamos la parte de CDM donde tenemos los ficheros de configuracion (settings.xml, script build etc)
                checkout changelog: false, poll: false, 
                    scm: [$class: 'GitSCM', branches: [[name: '*/master']], 
                    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CheckoutOption'], 
                    [$class: 'RelativeTargetDirectory', relativeTargetDir: 'CDM']], 
                    submoduleCfg: [], 
                    userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', url: 'http://eswltbhr:8282/vodafone/CDM.git']]]
            }
        }

        stage('Read config'){
            jobConfig.jobReadConfig("${WORKSPACE}/CDM/Jenkins/${DeployEnv}/WCS-NTOL/BACK/build_back/envs.json")
        }
        stage('Build'){
            gitlabCommitStatus("Build") {
                jobConfig.simpleMavenDockerBuild('vfes_cdm_centos6_maven3_jdk8_065:latest',true)
            }
        }
        stage('Copy to release'){
            jobConfig.copyToRelease("WCS-NTOL/${ArtifactId}","","")
        }
        stage('Redeploy'){
            // Only redeploy in case of artifact 
            gitlabCommitStatus("Redeploy") {
                if (ArtifactId!="vf-back-common"){
                    jobConfig.wlAnsibleRedeploy("${WORKSPACE}/CDM/Ansible","WCS-NTOL/BACK/${ArtifactId}")
                }
            }
        }
    }
    stage('clean-when successfull'){
        deleteDir()
    }
}