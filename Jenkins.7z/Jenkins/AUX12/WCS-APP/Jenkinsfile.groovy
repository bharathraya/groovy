//
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

def deploymentEnv="AUX12"

node("WCS-APP-${deploymentEnv}"){
	
	// variable para contener la configuracion por entorno
    def jobConfig=null
    def filterTag="AUX12"
    
    def artifactId="WCS-APP"
    def projectFolder="${WORKSPACE}/${artifactId}"
    
    stage('filterIncomingTag'){
        echo sh(returnStdout: true, script: 'env')
        if (gitlabBranch.equals('refs/tags/'+filterTag)){
            echo "OK!"
        }
        else
        {
            currentBuild.result = 'ABORTED'
            error "NO ${filterTag} Branch"
        }        
    }
    
    stage('config_job'){
        // visualizar ALMS, Commit y Entorno
        echo "Artifact: ${artifactId}"
    }
    stage('clean'){
        deleteDir()
        
    }
    stage('checkout'){
        
        // Usamos la tarea checkout para que en el Job de Jenkins quede constancia del commit origen
        checkout([$class: 'GitSCM', 
            branches: [[name: "refs/tags/${filterTag}"]], 
            doGenerateSubmoduleConfigurations: false, 
            extensions: [
                [$class: 'RelativeTargetDirectory', relativeTargetDir: "${projectFolder}"]], 
            submoduleCfg: [], 
            userRemoteConfigs: [[credentialsId: "vfjenkins-passwd", 
                        url: "${gitlabSourceRepoHttpUrl}"]]
            ])
        // descargamos la parte de CDM donde tenemos los ficheros de configuracion (settings.xml, script build etc)
        checkout changelog: false, poll: false, 
            scm: [$class: 'GitSCM', branches: [[name: '*/master']], 
            doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CheckoutOption'], 
            [$class: 'RelativeTargetDirectory', relativeTargetDir: 'CDM']], 
            submoduleCfg: [], 
            userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', url: 'http://eswltbhr:8282/vodafone/CDM.git']]]

     
    }


    stage('build'){
        mavenDockerBuilder('vfes_cdm_centos6_maven3_jdk8_065:latest',"${projectFolder}",false,"${deploymentEnv}")
    }
    stage('copy to release'){
        echo "TODO"
    }

    stage('Redeploy'){
        wlAnsibleRestart deploymentEnv,WORKSPACE+"/CDM/Ansible","ch:cas:coa:dw:ft:lg:mvf:wb","true","true"
    }
    
 
}