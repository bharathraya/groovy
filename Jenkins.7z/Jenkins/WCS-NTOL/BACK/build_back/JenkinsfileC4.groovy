//
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESJobConfig
// parametros de entrada:
// ${DeployEnv} -> Entorno [SIT1,SIT2,PPRD,HID,master]
// ${ALMS_ID} -> Paquete ALMS / CRQ  
// ${CommitID} -> Commit ID  

def jobConfig=null
def vodafoneRepoUrl=null
node("NTOL-${DeployEnv}"){
	
	// variable para contener la configuracion por entorno
    
    
    def entregasRepoUrl=null
    stage('config_job'){
        // visualizar ALMS, Commit y Entorno
        echo "ALMS_ID: ${ALMS_ID}"
        echo "CommitID: ${CommitID}"
        echo "Entorno: ${DeployEnv}"
        echo "Delivery: ${Delivery}"
        echo "ProjectId: ${ProjectId}"
        echo "Artifact: ${ArtifactId}"
        
        vodafoneRepoUrl="https://bitbucket.agile.vodafone.com/scm/c4destiny/${ArtifactId}.git"
        entregasRepoUrl="http://eswltbhr:8282/entregas/WCS-NTOL/BACK/${ArtifactId}.git"
        jobConfig=new VFESJobConfig(ALMS_ID,CommitID,DeployEnv,Delivery,ProjectId,
        "WCS-NTOL/${ArtifactId}","WCS-NTOL/BACK/${ArtifactId}.git",
        "WCS-NTOL/BACK/build_back","${WORKSPACE}",this)

        currentBuild.displayName = jobConfig.jobDisplayName
        currentBuild.description = jobConfig.jobDescription
    }
    stage('clean'){
        deleteDir()
        
    }
}
node("maven-eswltbhr"){
    stage('checkoutAPP'){
        
        // Usamos la tarea checkout para que en el Job de Jenkins quede constancia del commit origen
        checkout([$class: 'GitSCM', 
            branches: [[name: "vodafone/${jobConfig.jobDeployEnv}"]], 
            doGenerateSubmoduleConfigurations: false, 
            extensions: [
                [$class: 'LocalBranch', localBranch: "${jobConfig.jobDeployEnv}"], 
                [$class: 'RelativeTargetDirectory', relativeTargetDir: "${jobConfig.jobProjectFolder}"]], 
            submoduleCfg: [], 
            userRemoteConfigs: [[credentialsId: "essvc.essvc-devops-Bitbucket", 
                        url: "${vodafoneRepoUrl}"]]
            ])
        stash includes: "${jobConfig.jobProjectFolder}/**/*", name: 'app', useDefaultExcludes: false
    }
}
node("NTOL-${DeployEnv}"){
    stage('checkoutCDM'){
        unstash 'app'
        // descargamos la parte de CDM donde tenemos los ficheros de configuracion (settings.xml, script build etc)
        checkout changelog: false, poll: false, 
            scm: [$class: 'GitSCM', branches: [[name: '*/master']], 
            doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CheckoutOption'], 
            [$class: 'RelativeTargetDirectory', relativeTargetDir: 'CDM']], 
            submoduleCfg: [], 
            userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', url: 'http://eswltbhr:8282/vodafone/CDM.git']]]

     
    }
    stage('read config'){
        jobConfig.jobReadConfig("${WORKSPACE}/CDM/Jenkins/WCS-NTOL/BACK/build_back/envs.json")
    }

    stage('merge changes'){
        jobConfig.mergeCommitBitBucket()
        currentBuild.description = currentBuild.description +jobConfig.getJobChanges()

    }

    stage('build'){
        jobConfig.mavenDockerBuild('vfes_cdm_centos6_maven3_jdk8_065:latest','^WCS-NTOL\\/[a-zA-Z0-9]*\\/properties\\/',true)
    }
    stage('copy to release'){
        jobConfig.copyToRelease("WCS-NTOL/${ArtifactId}","","","${ArtifactId}")
    }

    stage('Redeploy'){
        // Only redeploy in case of artifact 
        if (DeployEnv!="master"&&DeployEnv!="masterCI"&&DeployEnv!="HID1"&&DeployEnv!="HID1CI"){
            if (ArtifactId!="vf-back-common"){
                jobConfig.wlAnsibleRedeploy("${WORKSPACE}/CDM/Ansible","WCS-NTOL/BACK/${ArtifactId}")
            }
        }
    }
    stage('Tag&Push'){
        jobConfig.pushAndTagBitbucket("bitbucket.agile.vodafone.com/scm/c4destiny/${ArtifactId}.git")

    }
    stage('clean-when successfull'){
        deleteDir()
    }
}