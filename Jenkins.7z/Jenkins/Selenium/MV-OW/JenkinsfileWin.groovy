def ret=""
pipeline{
    agent{
        label 'es1117yw'
    }
    parameters { choice(name: 'ENTORNO', choices: ['SIT1', 'SIT2', 'PPRD1'], description: '') }
    stages{
        stage('Set build description'){
            steps {
                script {
                    bat "del /f *.png *.txt"
                    currentBuild.displayName = "Env: ${params.ENTORNO}"
                }
            }
        }
        
        stage('Selenium Test'){
            steps{
                script{
                    ret=bat(returnStdout:true , script:"python Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${params.ENTORNO} ${BUILD_ID}")
                }
            }   
        }
        
    }
    post {
        always {
            script{
                currentBuild.description="""Env: ${params.ENTORNO}
${ret}"""
                archiveArtifacts artifacts: '*.png', fingerprint: true
            }
        }
    }
}