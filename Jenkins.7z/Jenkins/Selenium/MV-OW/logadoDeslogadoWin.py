from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from datetime import datetime
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
import time
import sys
import json


def currentTime():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
def currentStamp():
    return datetime.now().strftime('%Y%m%d%H%M%S')
def printBrowserLog(mydriver):
    for lg in mydriver.get_log('browser'):
        print ("      "+lg["message"])


if len(sys.argv) != 3 :
    print ("")
    print ("prueba.py <ENV> <buildId>")
    print ("")
    sys.exit(2)

myenv=sys.argv[1]
buildid=sys.argv[2]
print ("ARG:"+myenv)

user = "22622415Y@nuevomivf.es"
#user = "52799350K@nuevomivf.es"
#pwd = "Prueba2468"
pwd = "Prueba2468"
timeout = 120

env_server = { 'SIT1' : 'vodlta08', 'SIT2' : 'vodlow02' , 'PPRD1':'vodlta25','PPRD':'vodlta25','SIT1CI' : 'vodlta08', 'SIT2CI' : 'vodlow02' , 'PPRD1CI':'vodlta25',}
server=env_server[myenv]
url="http://"+server+":25283/c/particulares/es/acceso-area-privada/"
#tst=currentStamp()
tst=buildid

print (currentTime()+" init")
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--window-size=1920,1080")
chrome_options.add_argument('headless')
chrome_options.add_argument('--proxy-server=10.13.51.112:8080')
chrome_options.add_argument('--proxy-bypass-list=vodlta08;10.225.239.228;vodlta25;10.225.122.241;vodlow02;10.225.122.249')
capabilities = chrome_options.to_capabilities()

print (currentTime()+" webDriver remote")

driver= webdriver.Chrome(executable_path=r"C:\chromedriver\chromedriver.exe",desired_capabilities=capabilities)
driver.set_network_conditions(
    offline=False,
    latency=350,  # additional latency (ms)
    download_throughput=500 * 1024,  # maximal throughput
    upload_throughput=500 * 1024)
#driver = webdriver.Remote(
#   command_executor='http://127.0.0.1:4444/wd/hub',
#   desired_capabilities=capabilities)


print (currentTime()+" Set implicit Wait  to "+str(timeout)+" secs")
driver.implicitly_wait(timeout)

print (currentTime()+" Get login page "+url)
driver.get(url)

print (currentTime()+" Loaded:"+driver.title)
driver.save_screenshot("01.login_page."+myenv+"."+tst+".png")

assert "Acceso MiVodafone" in driver.title

print (currentTime()+" Waiting for 'enter' input  to load ...")
element = WebDriverWait(driver, timeout).until(
EC.visibility_of_element_located((By.XPATH, ".//input[@id='enter']")))

elem = driver.find_element_by_id("userid")
elem.send_keys(user)
elem = driver.find_element_by_id("password")
elem.send_keys(pwd)
print (currentTime()+" Trying login doing password submit ...")
elem.submit()
#printBrowserLog(driver)


#elem = driver.find_element_by_id("enter")
#print currentTime()+" Login button text:"+elem.get_attribute('value')
#if elem.get_attribute('value')=='Acceder':
#    print currentTime()+" Trying login clicking Acceder button..."
#    elem.click()
#else:
#    print currentTime()+" Trying login clicking RETURN in password input box ..."
#    #elem1=driver.find_element_by_id("password")
#    elem.send_keys(Keys.ENTER)

#print currentTime()+" sleep 30 secs"
#time.sleep(30)
driver.save_screenshot("02.after_login."+myenv+"."+tst+".png")


print (currentTime()+" Wait for 'Te Cuesta'")
#element = WebDriverWait(driver, 600).until(
#EC.element_to_be_clickable((By.XPATH, ".//*[text()='Te cuesta']")))
try:
    element = WebDriverWait(driver, timeout).until(
    EC.visibility_of_element_located((By.XPATH, ".//*[text()='Te cuesta']")))
    #element = driver.find_element_by_xpath(".//*[text()='Te cuesta']")
except TimeoutException as e:
    print (currentTime()+" ERROR: Could not find 'Te cuesta' after "+str(timeout)+" secs timeout")
    printBrowserLog(driver)
    print (currentTime()+" Take screenshot")
    driver.save_screenshot("03.error_not_login."+myenv+"."+tst+".png")
    print (currentTime()+" driver close")
    driver.close()
    print (currentTime()+" end")
    sys.exit(1)

time.sleep(10)
print (currentTime()+" Take screenshot")
driver.save_screenshot("03.login_screenshot."+sys.argv[1]+"."+tst+".png")

print (currentTime()+" logout")
element = driver.find_element_by_xpath(".//*[@title='Desconectar']")
element.click()

print (currentTime()+" driver close")
driver.close()
print (currentTime()+" end")
