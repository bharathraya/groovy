def ret=""
pipeline{
    agent{
        label 'es1149yr-platafor'
    }
    parameters { choice(name: 'ENTORNO', choices: ['SIT1', 'SIT2', 'PPRD1'], description: '') }
    stages{
        stage('Set build description'){
            steps {
                script {
                    sh "rm -f *.png *.txt"
                    currentBuild.displayName = "Env: ${params.ENTORNO}"
                }
            }
        }
        
        stage('Start Selenium Docker'){
            steps{
                sh """
                    docker run -d --add-host vodlta08:10.225.239.228 \
                    --add-host vodlta25:10.225.122.241 \
                    --add-host vodlow02:10.225.122.249 \
                    --name=selenium-mvow.${BUILD_ID} \
                    -p4444:4444 selenium/standalone-chrome:latest
                """
            }
        }
        stage('Selenium Test'){
            steps{
                timeout(5) {
                    waitUntil {
                       script {
                         def r = sh script: 'wget -q http://127.0.0.1:4444 -O /dev/null', returnStatus: true
                         return (r == 0);
                       }
                    }
                }
                script{
                    sh "python Jenkins/Selenium/MV-OW/logadoDeslogado.py ${params.ENTORNO} ${BUILD_ID}> result.txt 2>&1 "
                }        
            }            
        }
        
    }
    post {
        always {
            script{
                sh """
                        docker stop selenium-mvow.${BUILD_ID}
                        docker rm selenium-mvow.${BUILD_ID}                        
                    """
                ret=readFile("result.txt").trim()
                currentBuild.description = "Env: "+params.ENTORNO+""" 
${ret}"""
                archiveArtifacts artifacts: '*.png', fingerprint: true
            }
        }
    }
}