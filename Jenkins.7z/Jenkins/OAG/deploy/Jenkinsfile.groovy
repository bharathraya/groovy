def envConfig = null
def gitCDMJobFolder='Jenkins/OAG/deploy'
def envFile="${gitCDMJobFolder}/envs.json"
def cdmCheckoutFolder='CDM'
def gitCDMRepo='http://eswltbhr:8282/vodafone/CDM.git'
def gitCDMCred='vfjenkins-passwd'



pipeline {
    /* insert Declarative Pipeline here */
    agent {
        label "OAG"
    }
    parameters {
        choice(choices: ['SIT1','SIT2'], description: '', name: 'Environment')
        string(name:'CommitId')
        string(name:'ALMS_ID')
        string(name:'ProjectId')
        string(name:'Delivery')
    }

    stages {
        stage('Read Env Config') {
            steps {
                checkout scm: [$class: 'GitSCM', branches: [[name: '*/master']], 
                    doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CheckoutOption'], 
                    [$class: 'RelativeTargetDirectory', relativeTargetDir: "${cdmCheckoutFolder}"]], 
                    submoduleCfg: [], 
                    userRemoteConfigs: [[credentialsId: "${gitCDMCred}", url: "${gitCDMRepo}"]]]
                
                def myEnvConfig=readJSON file: "${cdmCheckoutFolder}/${gitCDMJobFolder}/${envFile}"
                envConfig=myEnvConfig[""]
                    

                
            }
        }

        stage('Checkout') {
            steps {
                checkout scm: [
                        branches: [[name: "${params.Environment}"]], 
                    doGenerateSubmoduleConfigurations: false, 
                    extensions: [
                        [$class: 'LocalBranch', localBranch: "${params.Environment}"], 
                        [$class: 'RelativeTargetDirectory', relativeTargetDir: "${jobConfig.jobProjectFolder}"]], 
                    submoduleCfg: [], 
                    userRemoteConfigs: [[credentialsId: "vfjenkins-passwd", 
                                url: "${vodafoneRepoUrl}"]]
                    ]


            }
        }
        stage('Backup'){
            steps{
                //BACKUP
                // Por cada nodo
                // BACKUP de /home/${path}/OAG-11.1.2.${version}.0/apigateway/groups/deployments.json
                for (nodo in envConfig.nodes) {
                    sh "scp ${nodo.username}@${nodo.server}:${nodo.path}/"
                }
                // BACKUP de /home/${path}/OAG-11.1.2.${version}.0/apigateway/groups/${grupoId}/${V_inst}/conf/envSettings.props
                // Backup de .fed .pol .env
                // ./run.sh migrate/archive.py -g ${grupo} -n ${gateway_01} -d https://${admin}:${port_Admin}/api -u ${policyUser} -p ${pass} -b ${PATH_PAQUETE_BACKUP}/${V_nodo};

            }
        }


        // DESPLIEGUE
        // por cada nodo
        // copiar el .pol a /home/${path}/OAG-11.1.2.${version}.0/apigateway/samples/scripts/migrate/polPackage.pol	
        // Copiar el .env a /home/${path}/OAG-11.1.2.${version}.0/apigateway/samples/scripts/migrate/environmentPackage.env
        // copiar el envSettings.props.${ENTORNO} a /home/${path}/OAG-11.1.2.${version}.0/apigateway/groups/${grupoId}/${V_inst}/conf/envSettings.props

        // Crear el .fed:
        // ./run.sh migrate/createDeploymentPackage.py -g ${grupo} -n ${V_gateway} -d https://${admin}:${port_Admin}/api -u ${policyUser} -p ${pass}		"

        // REINICIO
        // por cada nodo 
        //   parar GW
        //     ./startinstance -n $V_gateway -g $grupo -k;
        //   parar Nodemanager
        //     ./nodemanager -k;
        // por cada nodo
        //   arrancar Nodemanager
        //     ./nodemanager >/dev/null 2>&1 
        //   arrancar GW
        //     ./startinstance -n $V_gateway -g $grupo >/dev/null 2>&1 &;



        stage('Example Build') {
            steps {
                echo "Building $ALMS_ID "
            }
        }
    }
}