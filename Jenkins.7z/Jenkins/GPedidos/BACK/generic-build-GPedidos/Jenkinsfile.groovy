//
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat

// parametros de entrada:
// ${DeployEnv} -> Entorno [SIT1,SIT2,PPRD,HID,master]
// ${ALMS_ID} -> Paquete ALMS / CRQ  
// ${CommitID} -> Commit ID  


node("GPedidos-${DeployEnv}"){
	
	// variable para contener la configuracion por entorno
    def env_config=null
    def strTimeStamp=null
    def strDate=null
    def releaseServer=null
    def releaseUser=null
	def mergeMessage=null

    stage('config_job'){
        
        def timeFormat = new SimpleDateFormat("yyyyMMddHHmmss")
        def dateFormat = new SimpleDateFormat("yyyyMMdd")
        def date = new Date()
        strTimeStamp=timeFormat.format(date)
        strDate=dateFormat.format(date)
        currentBuild.displayName = "ALMS: ${ALMS_ID} Env: ${DeployEnv} Artifact:${ArtifactID}"
        currentBuild.description = "ID_ALMS: ${ALMS_ID} Entorno: ${DeployEnv} Commit: ${CommitID} Artifact:${ArtifactID}"

        mergeMessage="[${ALMS_ID}][${strTimeStamp}][${DeployEnv}][${Delivery}][${ProjectId}]"
        
    }
    stage('clean'){
        sh "rm -rf WCS-GPedidos CDM * .g* .b*"
        sh "mkdir -p /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${DeployEnv}/.m2"
    }
    stage('checkout'){
        
        //checkout([$class: 'GitSCM', branches: [[name: '*/${DeployEnv}']], 
        //   doGenerateSubmoduleConfigurations: false, 
        //    extensions: [], submoduleCfg: [], 
        //    userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', 
        //    url: 'http://eswltbhr.es.sedc.internal.vodafone.com:8282/vodafone/MV-OW/MiVodafone-Angular.git']]])
        sh 'ls -ltra'    
            
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'vfjenkins-passwd',
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            sh '''
                git clone -b${DeployEnv} http://${USERNAME}:${PASSWORD}@eswltbhr.es.sedc.internal.vodafone.com:8282/vodafone/MV-OW-BACK/WCS-GPedidos/${ArtifactID}.git WCS-GPedidos/${ArtifactID}
                git clone http://${USERNAME}:${PASSWORD}@eswltbhr.es.sedc.internal.vodafone.com:8282/vodafone/CDM.git CDM
            '''
            }    
    }
    stage('read env config'){
        def json = readJSON(file: "${WORKSPACE}/CDM/Jenkins/GPedidos/BACK/generic-build-GPedidos/envs.json")
        env_config = json["${DeployEnv}"]
    }
    stage('merge changes'){
        dir("WCS-GPedidos/${ArtifactID}"){
            gitCommitBefore = sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            echo "GitCommit Before MERGE: ${gitCommitBefore}"
	
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'vfjenkins-passwd',
                        usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                sh '''
                    git remote add entregas http://${USERNAME}:${PASSWORD}@eswltbhr:8282/entregas/MV-OW-BACK/WCS-GPedidos/${ArtifactID}.git
                '''
                }  
            // git merge ${CommitID} --no-commit --no-ff
            sh """
                git status
                git fetch entregas"""
            try{
                sh "git merge --no-ff -m'${mergeMessage}' ${CommitID} "
                }
            catch(Exception){
                echo "There are following merge conflicts!"
                sh '''
                set -x
                git diff --name-only --diff-filter=U | while read f
                do
                echo $f
                git log --follow --oneline $f
                echo
                done
                '''
                error('Stopping the job, has merge conflicts!!!')

            }
            gitCommitAfter = sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            echo "GitCommit AFter MERGE: ${gitCommitAfter}"
            sh "git diff --name-only  ${gitCommitBefore}..${gitCommitAfter}"
        }
    }
    stage('build'){
        echo "Copy cp settings.xml  to .m2 folder ... "
        sh "cp ${WORKSPACE}/CDM/Jenkins/GPedidos/BACK/generic-build-GPedidos/m2/settings.xml /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${DeployEnv}/.m2"
        echo "Copy cm_build_script  to project folder ... "
        sh "cp ${WORKSPACE}/CDM/Jenkins/GPedidos/BACK/generic-build-GPedidos/cm_build_script ${WORKSPACE}/WCS-GPedidos/${ArtifactID}"
        sh "chmod 755 ${WORKSPACE}/WCS-GPedidos/${ArtifactID}/cm_build_script"

        echo "BUILD ${DeployEnv}"
        //sh "docker run -v ${WORKSPACE}/WEB-Bajas/BACK/${ArtifactID}:/home/plataforma/project -v /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${DeployEnv}/.m2:/home/plataforma/.m2 --rm --ulimit nofile=98304:98304  prueba_maven:1.0"
        sh """ 
            docker run --user=\$(id -u):\$(id -g) --ulimit nofile=98304:98304 \
            -v ${WORKSPACE}/WCS-GPedidos/${ArtifactID}/:/home/plataforma/project \
            -v /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${DeployEnv}/.m2:/home/plataforma/.m2 \
            vfes_cdm_centos6_maven3_jdk8_065:latest /home/plataforma/project/cm_build_script
            """
     }

    stage('Copy-to-release'){
        def plataforpath=""
        
        sh """
            find WCS-GPedidos/${ArtifactID} -type f |  zip -r ${ALMS_ID}-${DeployEnv}-${strTimeStamp}.zip -@;
            """
    
        if (DeployEnv != 'master' && DeployEnv != 'HID1' && DeployEnv != 'masterCI' && DeployEnv != 'HID1CI'  ) {
            
            env_config.release.each { item ->
                echo "Deploying up on ${item.server} ..."
                sh """
                   ssh -o StrictHostKeyChecking=no  ${item.server} "mkdir -p /home/plataforma/jenkins/tmp/job-${ALMS_ID}-${DeployEnv}-${strTimeStamp}/"
                   """
                sh "scp ${ALMS_ID}-${DeployEnv}-${strTimeStamp}.zip ${item.server}:/home/plataforma/jenkins/tmp/job-${ALMS_ID}-${DeployEnv}-${strTimeStamp}/ 2>/dev/null"
                sh """
                   ssh -o StrictHostKeyChecking=no -l ${item.username}  ${item.server} \
                   'cd ${item.path}; \
                   rm backup-jenkins-*-${DeployEnv}-*.zip
                   zipinfo -1 /home/plataforma/jenkins/tmp/job-${ALMS_ID}-${DeployEnv}-${strTimeStamp}/${ALMS_ID}-${DeployEnv}-${strTimeStamp}.zip | zip backup-jenkins-${ALMS_ID}-${DeployEnv}-${strTimeStamp}.zip -@;\
                   unzip -o /home/plataforma/jenkins/tmp/job-${ALMS_ID}-${DeployEnv}-${strTimeStamp}/${ALMS_ID}-${DeployEnv}-${strTimeStamp}.zip; '
                   """
                sh """
                   ssh -o StrictHostKeyChecking=no  ${item.server} "rm /home/plataforma/jenkins/tmp/job-${ALMS_ID}-${DeployEnv}-${strTimeStamp}/*.zip"
                   """
            }
        }
        else{
			
            def zipname=""
            if (DeployEnv == 'HID1CI' || DeployEnv == 'masterCI')   {
                def myenvd=""   
                switch  (DeployEnv){
                    case 'HID1CI':
                        myenvd='HID1'
                        break
                    case 'masterCI':
                        myenvd='PROD'
                        break
                    case 'HID1':
                        myenvd='HID1'
                        break
                    case 'master':
                        myenvd='PROD'
                        break

                }
                plataforpath="/home/plataforma/plausr/data/temporal/${strDate}/anexo/${ALMS_ID}/${myenvd}"
                zipname="${ALMS_ID}-GPedidos"
            }else{
                plataforpath="/home/plataforma/plausr/data/temporal/${strDate}/anexos/${ALMS_ID}"
                zipname="${ALMS_ID}-${DeployEnv}-${strTimeStamp}"
            }
            env_config.release.each { item ->
                echo "Preparing for ${item.server} ..."
                echo "create .env file for deployment ..."
                sh "echo export REL_ROOT=${item.path} >> ${ALMS_ID}-${DeployEnv}-${strTimeStamp}.${item.server}.env"
                sh "echo export USER_REL=${item.username} >> ${ALMS_ID}-${DeployEnv}-${strTimeStamp}.${item.server}.env"
                echo "create path in remote server"
                sh "ssh platafor@${item.server} 'mkdir -p ${plataforpath}'"
                echo "upload .sh, .zip and .env files"
                sh "scp ${ALMS_ID}-${DeployEnv}-${strTimeStamp}.${item.server}.env platafor@${item.server}:${plataforpath}/${zipname}.env"
                sh "scp ${ALMS_ID}-${DeployEnv}-${strTimeStamp}.zip platafor@${item.server}:${plataforpath}/${zipname}.zip"
                sh "scp ${WORKSPACE}/CDM/CommonTools/scripts/ROLLBACK_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.bak.sh"
                sh "scp ${WORKSPACE}/CDM/CommonTools/scripts/DEPLOY_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.sh"
				sh "ssh platafor@${item.server} 'chmod 777 ${plataforpath}; chmod 755 ${plataforpath}/*.sh'"
            }
			echo ""
            echo ""
            echo "************************************************************************"
            echo "************************************************************************"
            echo "Execute:"
            currentBuild.description = currentBuild.description+"\n\r\n\rExecute:"
            env_config.release.each { item ->
                echo "${item.username}@${item.server}:${plataforpath}/${zipname}.sh"
                currentBuild.description = currentBuild.description+"\n\r${item.username}@${item.server}:${plataforpath}/${ALMS_ID}-${DeployEnv}-${strTimeStamp}.sh"
			}
			echo "************************************************************************"
			echo "************************************************************************"
			echo ""
			echo ""
		}
    }
    stage('Re-deploy'){
        if (DeployEnv != 'master' && DeployEnv != 'HID1'  && DeployEnv != 'HID1CI'  && DeployEnv != 'masterCI'  ) 
        {
               sh "cd ${WORKSPACE}/CDM/Ansible;ansible-playbook -i inventories/${DeployEnv}/hosts redeploy.yml --extra-vars \"deployment_env=${DeployEnv} deployment_artifact=GPedidos/BACK/${ArtifactID}\""
        }
    }
    stage('Tag&Push'){
        echo "PUSH"
        def t=""
        def n=""
        dir("WCS-GPedidos/${ArtifactID}"){
            if (Delivery!=''){
                t=t+"-${Delivery}"
                n=n+":${Delivery}"
            }
            if (ProjectId!=''){
                t=t+"-${ProjectId}"
                n=n+":${ProjectId}"
            }

        sh "git tag -a ${ALMS_ID}-${DeployEnv}-${strTimeStamp}${t} -m '${ALMS_ID}:${DeployEnv}:${strTimeStamp}${n}'"
        
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'vfjenkins-passwd',
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            if (gitCommitAfter!=gitCommitBefore){
                sh "git push http://${USERNAME}:${PASSWORD}@eswltbhr.es.sedc.internal.vodafone.com:8282/vodafone/MV-OW-BACK/WCS-GPedidos/${ArtifactID}.git ${DeployEnv}"
            }
            sh "git push http://${USERNAME}:${PASSWORD}@eswltbhr.es.sedc.internal.vodafone.com:8282/vodafone/MV-OW-BACK/WCS-GPedidos/${ArtifactID}.git ${ALMS_ID}-${DeployEnv}-${strTimeStamp}${t}"                        
            }
        }
    }


}