
//
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat

// parametros de entrada:
// ${DeployEnv} -> Entorno [SIT1,SIT2,PPRD,HID,master]
// ${ALMS_ID} -> Paquete ALMS / CRQ  
// ${CommitID} -> Commit ID  


node("WORKBENCH"){
	
	// variable para contener la configuracion por entorno
    def env_config=null
    def strTimeStamp=null
    def strDate=null
    def releaseServer=null
    def releaseUser=null
	def mergeMessage=null

    stage('config_job'){
        
       echo "Commit: ${CommitID}"
       echo "ALMS_ID: ${ALMS_ID}"
       echo "DeployEnv: ${DeployEnv}"
       echo "ArtifactID: ${ArtifactID}"
       echo "Delivery: ${Delivery}"
       echo "ProjectId: ${ProjectId}"
        
    }


}