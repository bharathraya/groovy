import groovy.json.JsonSlurper
import groovy.json.JsonSlurperClassic
import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import java.net.URL
import java.net.HttpURLConnection
import java.io.ByteArrayOutputStream
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _


@NonCPS
private static def readJson(String text){

    def jsonSlurper = new JsonSlurperClassic ()
    return jsonSlurper.parseText(text)
}

/*
private static def readJSONURL(String jsonUrl){
    def result=[:]
	try{
		def json=sh (label: "Get JSON ${jsonUrl}", returnStdout: true, script: "curl --noproxy '*' ${jsonUrl}")
		//echo "json : ${json}"
		result=readJSON text:json
	}catch(Exception){
        echo("Error when reading JSON from URL")
	}
	return result
}
*/


pipeline{
    agent{
        label 'eswltahr-platafor'
    }
    stages{
        //Stage para coger JSON anexo al JOB de Validate
        stage('prueba'){
            steps{
                script{
                    echo "RolloutInfo ${Rollout}"
                }
            }
        }
        stage('IdsExtraction')
        {
            steps{
                script{
                    def JsonData = new JsonSlurper()
                    def contenido = JsonData.parseText("${Rollout}")

                    echo "Production Id: ${contenido.ProductionDeploymentId}"
                    echo "Rollout Id: ${contenido.RolloutId}"

                    env.BUILD_id = "${contenido.ProductionDeploymentId}"
                    env.BUILD_rolloutId = "${contenido.RolloutId}"
                }
            }
        }
        stage('Check Validate Result'){
            //Bajar attachment de WB con el JSON de prepare
            steps{
                script{
                    //Llamamos a la API para recoger el ID:
                    node('es1117yw'){
                        checkout scm
                        dir('CDM/CommonTools/WorkBenchClient/'){
                            try{
                                def result = bat(returnStdout:true, script: "python send_jenkins_id.py -p ${env.BUILD_id} -r ${env.BUILD_rolloutId} -k jobPrepareId -t get")
                                echo "${result}"

                                def partesString = result.split(":")
                                def valor = partesString[2].trim()
                                env.BUILD_valor = "${valor}"
                                echo "${valor}"
                                
                                /*
                                def jsonString = data.find{it.startsWith("[{")}
                                
                                def jsonSlurper = new JsonSlurper()
                                def jsonData = jsonSlurper.parseText(jsonString)
                                echo "${jsonData}"
                                */
                            }
                            catch(Exception e)
                            {
                                echo "Error al procesar el ValueID"
                            }
                        }
                    }
                    def jobUrlPrepare = "http://195.233.178.75:8283/job/WORKBENCH/job/_pruebas/job/pruebaRolloutPrepare/${env.BUILD_valor}/artifact/ResultPrepare.json"
                    
                    //Leemos el JSON anexado
                    def result=[:]
                    try{
                        def json=sh (label: "Get JSON ${jobUrlPrepare}", returnStdout: true, script: "curl --noproxy '*' ${jobUrlPrepare}")
                        echo "json : ${json}"
                        result=readJSON text:json
                        env.BUILD_json = result
                    }catch(Exception){
                        echo "Error when reading JSON from URL"
                    }
                    //def resultJson = readJSONURL(jobUrlValidate)
                    echo "${env.BUILD_json}"
                    def jsonData = readJSON text: env.BUILD_json
                    def statusValue = jsonData[0].StatusPrepare
                    echo "${statusValue}"
                    if(statusValue == "OK")
                    {
                        def ruta = jsonData[1].Ruta
                        echo "${ruta}"
                        env.BUILD_statusPrepareValue = "OK"
                        env.BUILD_ruta = "${ruta}"
                        def deployData = jsonData[2].Deploy
                        env.BUILD_deployData = "${deployData}"
                    }
                    else
                    {
                        env.BUILD_statusPrepareValue = "KO"
                    }
                }
            }
        }
        stage('Script Execution')
        {
            steps{
                script{
                    if(env.BUILD_statusPrepareValue == "OK")
                    {
                        env.BUILD_errorExecDeploy = 'false'
                        node('eswltahr')
                        {
                            def data = readJSON text: env.BUILD_deployData
                            def ruta = env.BUILD_ruta.toString()
                            def listaErrorConexion = []
                            env.BUILD_errorUserConexion = 'false'
                            data.each{ key->
                                echo "${key.server}"
                                echo "${key.usuario}"
                                //Nos conectamos a las máquinas
                                try
                                {
                                    sh "ssh ${key.usuario}@${key.server} '${ruta}'"
                                }
                                catch(Exception e)
                                {
                                    echo "Error desplegando: ${ruta} en la maquina: ${key.server} con usuario: ${key.usuario}"
                                    elemento = [usuario: "${key.usuario}", server: "${key.server}"]
                                    listaErrorConexion.add(elemento)
                                    env.BUILD_errorUserConexion = 'true'
                                }
                            }
                            env.BUILD_listaErrorConexion = listaErrorConexion
                        }
                    }
                    else
                    {
                        env.BUILD_errorExecDeploy = 'true'
                    }
                }
            }
        }
        stage('Error Validation')
        {
            steps{
                script{
                    def errorExecDeploy = (env.BUILD_errorExecDeploy == 'true') ? true : false
                    def listaErrorConexion = env.BUILD_listaErrorConexion
                    def userConexion = (env.BUILD_errorUserConexion == 'true') ? true : false
                    def mensajeFinal = "Deploy KO: "
                    error=false
                    if(errorExecDeploy == true)
                    {
                        error("ERROR: Etapa de Prepare Fallida")
                    }
                    if(userConexion)
                    {
                        mensajeFinal = mensajeFinal + "Conexion "
                        echo "Errores Conexion: ${listaErrorConexion}"
                        error=true
                    }
                    if(error==true)
                    {
                        mensajeFinal = mensajeFinal + "|Errores"
                        error(mensajeFinal)
                    }
                }
            }
        }
    }
}