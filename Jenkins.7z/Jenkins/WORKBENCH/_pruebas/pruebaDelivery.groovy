
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _


_Delivery=params.DELIVERY

 node ("es036tvr") {   
   stage ("getUser"){
     wrap([$class: 'BuildUser']) {
          _User=env.BUILD_USER_ID
            }
       echo "Exec user: ${_User}"
   
        (_pass,_User)=findpassword(_User)
        currentBuild.displayName = "Delivery: ${_Delivery} ejecutado por ${_User} "
        currentBuild.description = "Delivery: ${_Delivery} "
   }
}

node ("es1117yw") {     
    stage ("getEnvName"){
        dir("D:\\Plataforma\\Get_Delivery_Environment"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                result = bat(returnStdout: true, script: "python get_deliveryEnvironment.py -u ${_User} -c ${_pass} -d ${_Delivery}").toString().trim()
                envName = result.readLines().drop(1).join(" ") 
                echo "El entorno para ${_Delivery} es : ...${envName}..."
            }
        }
    }
}