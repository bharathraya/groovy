import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

pipeline{
    agent {
        label 'es1117yw'
    }
  triggers {
    GenericTrigger(
     genericVariables: [
      [key: 'ISSUE', value: 'issue', defaultValue: 'null']
     ]
    )
  }
    stages {
        stage('echo') {
            steps {
                script {
                    echo "Cambio"
                    echo "Contenido de issue: ${issue}"
                    
                    def parsedIssue = readJSON text: issue
                    
                    def body = parsedIssue.body
                    def title = parsedIssue.title
                    def number = parsedIssue.number
                    def repositoryName = "idg-itdevops-requests"

                    echo "Valor de body: ${body}"
                    echo "Valor de title: ${title}"
                    currentBuild.displayName =  "usuario:${title}    issue:${number}"
                    checkout scm
                    dir("CDM/CommonTools/WorkBenchClient/New_Scripts") {
                        bat "python createWBUser.py -j \"${body}\" -r \"${repositoryName}\" -i \"${number}\""
                    }
                }
            }
        }
    }
}