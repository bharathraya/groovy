
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _


myalms_id=params.PAQUETE
mensaje=params.MENSAJE
id=params.ID


node ("eswltbhr") {     
    stage ("Reject"){
        createReject(myalms_id,mensaje,id)
    }
}