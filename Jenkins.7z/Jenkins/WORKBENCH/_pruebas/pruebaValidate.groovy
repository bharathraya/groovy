import groovy.json.JsonSlurper
import groovy.json.JsonSlurperClassic
import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import java.net.URL
import java.net.HttpURLConnection
import java.io.ByteArrayOutputStream
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _


@NonCPS
private static def readJson(String text){

    def jsonSlurper = new JsonSlurperClassic ()
    return jsonSlurper.parseText(text)
}



pipeline{
    environment{
        def existsPVCS = false
        def existsCommit = false
        def hoy=new Date().format( 'yyyyMMdd' )
    }
    agent{
        label 'eswltahr-platafor'
    } 
    stages{
        stage('prueba'){
            steps{
                script{
                    echo "RolloutInfo ${Rollout}"
                }
            }
        }
        stage('IdsExtraction')
        {
            steps{
                script{
                    def JsonData = new JsonSlurper()
                    def contenido = JsonData.parseText("${Rollout}")

                    echo "Production Id: ${contenido.ProductionDeploymentId}"
                    echo "Rollout Id: ${contenido.RolloutId}"

                    env.BUILD_id = "${contenido.ProductionDeploymentId}"
                    env.BUILD_rolloutId = "${contenido.RolloutId}"
                }
            }
        }
        stage('Data Validation')
        {
            steps{
                script{
                    node("es1117yw")
                    {
                        def errorPCK = 'false'
                        checkout scm
                        dir("CDM/CommonTools/WorkBenchClient/"){
                            try{
                                def resultadoData = bat(returnStdout: true, script: "python get_pck_status_validation.py -p ${env.BUILD_id} -r ${env.BUILD_rolloutId}").toString().trim()
                                data = resultadoData.readLines()
                                def jsonString = data.find{it.startsWith("[{")}
                                echo "Response: ${jsonString}"

                                def slurper = new JsonSlurper()
                                def json = slurper.parseText(jsonString)

                                def pckInfo = json.collect{ item -> 
                                    [   PackageId: item['PackageId: '],
                                        Application: item['Application: '],
                                        StatusPackage: item['StatusPackage: '],
                                        Environment: item['Environment: '],
                                        ResponseValidation: item['Response Validation: ']
                                    ]
                                }
                                def listaPaquetes = pckInfo.collect { it.PackageId }.join(' ')
                                env.BUILD_listaPaquetes = "${listaPaquetes}"
                                
                                def valorApp = null
                                for (item in pckInfo)
                                {
                                    if(valorApp == null)
                                    {
                                        valorApp = item.Application
                                    }
                                    if(item.Application != valorApp)
                                    {
                                        //Si hay mínimo un paquete con una aplicación distinta sacamos mensaje
                                        echo "el paquete: ${item.PackageId}, es de la aplicación: ${item.Application}, no corresponde a la aplicación del rollout"
                                        break
                                    }
                                }

                                //Filtramos el JSON de validación de paquetes para que solo devuelva los que tienen un error de validación:
                                def newJson = []
                                for (item in pckInfo)
                                {
                                    if(item.ResponseValidation == "KO")
                                    {
                                        newJson << item
                                    }
                                }

                                def jsonPckFinal = JsonOutput.toJson(newJson)
                                env.BUILD_pckErrorsJson = jsonPckFinal

                                echo "Validation Info: ${jsonPckFinal}"
                                if(json.toString().contains("KO"))
                                {
                                    errorPCK = 'true'
                                }
                                env.BUILD_errorPCK = errorPCK
                                env.BUILD_valorApp = valorApp
                                echo "Aplicacion: ${env.BUILD_valorApp}"
                            }
                            catch(Exception e)
                            {
                                echo "ERROR: ${e}"
                                errorPCK = 'true'
                                env.BUILD_errorPCK = errorPCK
                                //error('Validación KO')
                            }
                        }
                    }
                }
            }
        }
        stage('Application Checking')
        {
            steps{
                script{
                    checkout scm
                    def data = readJSON file: "${WORKSPACE}/CDM/Jenkins/WORKBENCH/_pruebas/pruebaDatosJSON.json"
                    def errorAPP = 'false'
                    def errorRepo = 'false'
                    def errorbranchDestino = 'false'
                    def errorbranchNoProd = 'false'
                    def mensajeError = "Validacion KO: "
                    //Comprobamos que la aplicación está en el JSON de configuración
                    if(env.BUILD_valorApp.toString() in data)
                    {
                        echo "la aplicacion ${env.BUILD_valorApp} se encuentra en el JSON de la release"
                    }
                    else
                    {
                        errorAPP = 'true'
                        env.BUILD_errorAPP = errorAPP
                        error("Validacion KO: la aplicacion ${env.BUILD_valorApp} no se encuentra en el JSON de la release")
                    }
                }
            }
        }
        stage('Data Extraction')
        {
            steps{
                script{
                    //Seleccionamos los datos del JSON para hacer comprobaciones:
                    checkout scm
                    def data = readJSON file: "${WORKSPACE}/CDM/Jenkins/WORKBENCH/_pruebas/pruebaDatosJSON.json"
                    def nombreAPP = env.BUILD_valorApp.toString()

                    existsPVCS = false
                    existsCommit = false
                    data.each{key, value ->
                        if(key.toString() == env.BUILD_valorApp)
                        {
                            echo "${value.repo}"
                            //Cogemos los datos del bloque commit del JSON de la release
                            if(value.pvcs)
                            {
                                echo "Entro en PVCS"
                                existsPVCS = true
                            }
                            else if(value.commit)
                            {
                                echo "Entro en Commit"
                                existsCommit = true
                                env.BUILD_commitBlock = true
                                value.commit.each{ dataCommit ->
                                    env.BUILD_commitRepository = "${dataCommit.repository}"
                                    env.BUILD_commitDestinyBranch = "${dataCommit.destinyBranch}"
                                    env.BUILD_commitBranchNP = "${dataCommit.branchNoProd}"
                                }
                            } 
                        }
                    }
                    echo "El valor de existsPVCS: ${existsPVCS}"
                    echo "El valor de existsCommit: ${existsCommit}"
                    env.BUILD_existsCommit = "${existsCommit}"
                    env.BUILD_existsPVCS = "${existsPVCS}"
                }
            }
        }
        stage('User Validation')
        {
            steps{
                script{
                    node("eswltahr")
                    {
                        checkout scm
                        def data = readJSON file: "${WORKSPACE}/CDM/Jenkins/WORKBENCH/_pruebas/pruebaDatosJSON.json"

                        def errorUSER = 'false'
                        def listaErrores = []
                        def listaErroresUserDeploy = []
                        def release = false
                        def sppr = false
                        def appConfig = 'false'
                        data.each { key, value ->
                            if(key.toString() == env.BUILD_valorApp.toString())
                            {
                                if(value.release)
                                {
                                    value.release.each { rel ->
                                        def userDeploy = "${rel.userDeploy}"
                                        echo "${userDeploy}"
                                        def server = "${rel.server}"
                                        if(rel.username){
                                            if(rel.username instanceof List)
                                            {
                                                rel.username.each { user ->
                                                echo "Usuario: ${user}"
                                                    //Hacemos la validación de los usuarios de la release:
                                                    try
                                                    {
                                                        sh "ssh -q ${user}@${server}"
                                                    }
                                                    catch(Exception e)
                                                    {
                                                        echo "el usuario: ${user}, no funciona en la máquina: ${server}"
                                                        errorUSER = 'true'
                                                        def elemento = [usuario: "${user}", server: "${server}"]
                                                        listaErrores.add(elemento)
                                                    }
                                                }
                                                if(rel.userDeploy)
                                                {
                                                    def found = rel.username.find {it == userDeploy}
                                                    if(found)
                                                    {
                                                        echo "${userDeploy} se encuentra en la lista de usuarios de la release"
                                                    }
                                                    else
                                                    {
                                                        echo "${userDeploy} no se encuentra en la lista de usuarios de la release"
                                                        def elemento = [usuario: "${userDeploy}", server: "${server}"]
                                                        listaErroresUserDeploy.add(elemento)
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                def usernamerel = "${rel.username}"
                                                echo "Usuario: ${usernamerel}"
                                                try
                                                {
                                                    sh "ssh -q ${usernamerel}@${server}"
                                                }
                                                catch(Exception e)
                                                {
                                                    echo "el usuario: ${usernamerel}, no funciona en la máquina: ${server}"
                                                    errorUSER = 'true'
                                                    def elemento = [usuario: "${usernamerel}", server: "${server}"]
                                                    listaErrores.add(elemento)
                                                }
                                                def errorDeploy
                                                if(rel.userDeploy)
                                                {
                                                    if(usernamerel == userDeploy)
                                                    {
                                                        echo "el usuario ${userDeploy} es válido"
                                                        
                                                    }
                                                    else
                                                    {
                                                        def elemento = [usuario: "${userDeploy}", server: "${server}"]
                                                        listaErroresUserDeploy.add(elemento)
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            echo "No hay bloque de usuarios en la release"
                                        }
                                    }
                                }
                                else{
                                    echo "No se puede realizar validación de la release en esta ${key} ya que no hay bloque en el fichero de datos"
                                }
                                if(value.sppr)
                                {
                                    value.sppr.each { sp ->
                                        def serversppr = "${sp.server}"

                                        if(sp.username)
                                        {
                                            if(sp.username instanceof List)
                                            {
                                                sp.username.each { user ->
                                                    //Hacemos la validación de los usuarios de sppr:
                                                    try{
                                                        sh "ssh -q ${user}@${serversppr}"
                                                    }
                                                    catch(Exception e)
                                                    {
                                                        echo "el usuario: ${user}, no funciona en la máquina: ${serversppr}"
                                                        errorUSER = 'true'
                                                        def elemento = [usuario: "${user}", server: "${server}"]
                                                        listaErrores.add(elemento)
                                                        /*
                                                        listaErroresUsers.call{
                                                            datosErrorSPPR {
                                                                usuario "${username}"
                                                                server "${server}"
                                                            }
                                                        }
                                                        */
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                //Hacemos la validación de los usuarios de sppr:
                                                def usernamesppr = "${sp.username}"
                                                try{
                                                    sh "ssh -q ${usernamesppr}@${serversppr}"
                                                }
                                                catch(Exception e)
                                                {
                                                    echo "el usuario: ${usernamesppr}, no funciona en la máquina: ${serversppr}"
                                                    errorUSER = 'true'
                                                    def elemento = [usuario: "${usernamesppr}", server: "${server}"]
                                                    listaErrores.add(elemento)
                                                    /*
                                                    listaErroresUsers.call{
                                                        datosErrorSPPR {
                                                            usuario "${username}"
                                                            server "${server}"
                                                        }
                                                    }
                                                    */
                                                }
                                            }
                                        }
                                        else
                                        {
                                            echo "No hay bloque de usuarios en el bloque de SPPR"
                                        }
                                    }
                                }
                                else{
                                    echo "No hay bloque de sppr en el fichero de datos para la aplicacion ${env.BUILD_valorApp}"
                                }
                                //env.BUILD_listaErroresUsers = "${listaErroresUsers}".toString()
                                def listaDeploy = listaErroresUserDeploy
                                def errorDeploy
                                echo "${listaDeploy}"
                                if(listaDeploy == null || listaDeploy.size() == 0)
                                {
                                    echo "lista deploy vacia"
                                    errorDeploy = 'false'
                                }
                                else
                                {
                                    echo "lista deploy con datos"
                                    errorDeploy = 'true'
                                    listaFinalErrorUserDeploy = listaDeploy[0]
                                    env.BUILD_listaErrorUserDeploy = listaFinalErrorUserDeploy
                                }
                                env.BUILD_errorUSER = errorUSER
                                env.BUILD_errorDeploy = errorDeploy
                                echo "${env.BUILD_errorDeploy}"
                                def erroresUser = JsonOutput.toJson(listaErrores)
                                env.BUILD_listaUsers = listaErrores
                            }
                        }
                    }
                }
            }
        }
        stage('Commit Data Extraction')
        {
            when{ expression { existsCommit } }
            steps{
                script{
                    node('es1117yw')
                    {
                        checkout scm
                        def data = readJSON file: "${WORKSPACE}/CDM/Jenkins/WORKBENCH/_pruebas/pruebaDatosJSON.json"
                        def commit = 'false'
                        
                        data.each{ key, value ->
                            dir("CDM/CommonTools/WorkBenchClient/"){
                                def error = 'false'
                                if(env.BUILD_commitBlock)
                                {
                                    if(key.toString() == env.BUILD_valorApp.toString())
                                    {
                                        def response = bat(returnStdout: true, script: "python get_commit_rollout_info.py -p ${env.BUILD_id} -r ${env.BUILD_rolloutId} -b ${env.BUILD_branchNoProd}").toString().trim()
                                        data = response.readLines()
                                        def jsonString = data.find{it.startsWith("[{")}

                                        def slurper = new JsonSlurper()
                                        def json = slurper.parseText(jsonString)
                                        echo "JSON Prueba: ${json}"

                                        if(json.isEmpty())
                                        {
                                            error = 'true'
                                            env.BUILD_commitError = error
                                        }
                                        else
                                        {
                                            def commitInfo = json.collect{ item -> 
                                                [   PackageId: item.PackageId,
                                                    CreatedAt: item.CreatedAt,
                                                    Branch: item.Branch,
                                                    Commit: item.Commit,
                                                    RepositoryHash: item.RepositoryHash,
                                                    RepositoryProject: item.RepositoryProject
                                                ]
                                            }
                                            def jsonFinalCommit = JsonOutput.toJson(commitInfo)
                                            echo "Commit Info: ${commitInfo}"
                                            env.BUILD_infoCommit = jsonFinalCommit

                                            echo "JSON Commits: ${jsonFinalCommit}"

                                        }
                                    }
                                }
                                else
                                {
                                    env.BUILD_commitJSONBlock = 'true'
                                }
                            }
                        }
                    }
                }
            }
        }
        stage('PVCS Data Validation')
        {
            when{ expression { existsPVCS } }
            steps{
                script{
                    try{
                        txeker("",env.BUILD_valorApp,"PROD","prueba",env.BUILD_listaPaquetes)
                        env.BUILD_txekerError = false
                    } 
                    catch(Exception e){
                        env.BUILD_txekerError = true
                    }
                }
            }
        }
        stage('Commit Data Validation'){
            when{ expression { existsCommit } }
            steps{
                script{
                    node('es1117yw')
                    {
                        wrap([$class: 'BuildUser']) {
                            _User=env.BUILD_USER_ID
                        }

                        (_pass,_User)=findpassword(_User)


                        
                        def errorValidateCommit = 'false'
                        def commitError = (env.BUILD_commitError == 'true') ? true : false
                        def commitJSONError = (env.BUILD_commitJSONBlock == 'true') ? true : false
                        if(commitJSONError)
                        {
                            echo "No hay información de commit para poder validar"
                            errorValidateCommit = 'true'
                            env.BUILD_errorValidateCommit = errorValidateCommit
                        }
                        else
                        {
                            def dataCommits = env.BUILD_infoCommit.toString()
                            //def jsonSlurper = new JsonSlurper()
                            def parsedJson = readJson(dataCommits)

                            //Cogemos la info del JSON del commit:+
                            def commit = parsedJson[0].Commit
                            def branch = parsedJson[0].Branch
                            def repository = parsedJson[0].RepositoryHash
                            def project = parsedJson[0].RepositoryProject

                            def check = "true"

                            if("${commit}" == "" || "${branch}" == "" || "${repository}" == "" || "${project}" == "")
                            {
                                check = "false"
                            }

                            if(check == "true"){
                                dir("CDM/CommonTools/WorkBenchClient/New_Scripts")
                                {
                                    def errorTest1 = 'false'
                                    def errorTest2 = 'false'
                                    def errorFaltaDatos = "false"

                                    //Comprobamos si el repositorio proporcionado es BitBucket, GitHub, etc.
                                    if(env.BUILD_commitRepository == "bitbucket"){
                                        //Llamamos a test-bitbucket1.py para comprobar si 
                                        echo "Lanzamos test-bitbucket1.py:"
                                        try{
                                            ansiColor('xterm') {
                                                //bat "python test-bitbucket1.py -r ${repository} -p ${project} -o ${branch} -d ${env.BUILD_commitDestinyBranch} -c ${commit} -u ${_User} -x ${_pass}"
                                            }
                                            env.BUILD_errorTest1 = errorTest1
                                        }
                                        catch(Exception e)
                                        {
                                            echo "Fallo por error"
                                            errorTest1 = 'true'
                                            env.BUILD_errorTest1 = errorTest1
                                        }

                                        echo "***************************************************************************\n"
                                        echo "Lanzamos test-bitbucket2.py"
                                        //Llamamos a test-bitbucket2.py para comprobar si hay conflictos
                                        try{
                                            ansiColor('xterm') {                                            
                                                //bat "python test-bitbucket2.py -d ${env.BUILD_commitDestinyBranch} -p ${project} -r ${repository} -c ${commit} -x ${_pass} -u ${_User}"
                                            }
                                            env.BUILD_errorTest2 = errorTest2
                                        }
                                        catch(Exception e)
                                        {
                                            echo "Error de test bitbucket2: KO"
                                            errorTest2 = 'true'
                                            env.BUILD_errorTest2 = errorTest2
                                        }
                                    }
                                    else if(env.BUILD_repository == "github"){
                                        //Llamamos a test-bitbucket1.py para comprobar si 
                                        echo "Lanzamos test-bitbucket1.py:"
                                        try{
                                            ansiColor('xterm') {
                                                bat "python test-bitbucket1.py -r ${repository} -p ${project} -o ${branch} -d ${env.BUILD_commitDestinyBranch} -c ${commit} -u ${_User} -x ${_pass}"
                                            }
                                            env.BUILD_errorTest1 = errorTest1
                                        }
                                        catch(Exception e)
                                        {
                                            echo "Fallo por error"
                                            errorTest1 = 'true'
                                            env.BUILD_errorTest1 = errorTest1
                                        }

                                        echo "***************************************************************************\n"
                                        echo "Lanzamos test-bitbucket2.py"
                                        //Llamamos a test-bitbucket2.py para comprobar si hay conflictos
                                        try{
                                            ansiColor('xterm') {                                            
                                                bat "python test-bitbucket2.py -d ${env.BUILD_commitDestinyBranch} -p ${project} -r ${repository} -c ${commit} -x ${_pass} -u ${_User}"
                                            }
                                            env.BUILD_errorTest2 = errorTest2
                                        }
                                        catch(Exception e)
                                        {
                                            echo "Error de test bitbucket2: KO"
                                            errorTest2 = 'true'
                                            env.BUILD_errorTest2 = errorTest2
                                        }
                                    }
                                }
                            }
                            else
                            {
                                echo "Faltan alguno de los siguientes datos para validar el commit: (BranchDestino, Proyecto, Repositorio, Commit, BranchOrigen)"
                                errorFaltaDatos = "true"
                                env.BUILD_errorFaltaDatosCommit = errorFaltaDatos
                            }
                        }
                    }
                }
            }
        }
        stage('Error Validation')
        {
            steps{
                script{
                    //Resumen general del JOB y comprobación de errores:

                    def PackageErrors = (env.BUILD_errorPCK == 'true') ? true : false
                    def UsersErrors = (env.BUILD_errorUSER == 'true') ? true : false
                    def bloqueCommitVacio = (env.BUILD_commitError == 'true') ? true : false
                    def faltaDatosCommit = (env.BUILD_errorFaltaDatosCommit == 'true') ? true : false
                    def errorDeploy = (env.BUILD_errorDeploy == 'true') ? true : false
                    echo "${errorDeploy}"

                    //JSONs de información de errores
                    def pckJson = env.BUILD_pckErrorsJson
                    def userJson = env.BUILD_listaUsers
                    def listaDeploy = env.BUILD_listaErrorUserDeploy
                    env.BUILD_errorUserDeploy = errorDeploy

                    def errorTest1py = (env.BUILD_errorTest1 == 'true') ? true : false
                    def errorTest2py = (env.BUILD_errorTest2 == 'true') ? true : false

                    def pvcsError = env.BUILD_txekerError

                    //Comprobamos si hay variables con errores y Montamos el mensaje:
                    def variablesError = [PackageErrors, UsersErrors, errorDeploy, bloqueCommitVacio, faltaDatosCommit, pvcsError]
                    def contador = 0
                    def listaJsonFinal = []
                    variablesError.eachWithIndex{ value, index ->
                        if(value)
                        {
                            contador = contador + 1
                        }
                    }

                    if(contador > 0)
                    {
                        def mensajeFinal = "Validacion KO: "
                        echo "SUMMARY: \n"
                        echo "*********************************************************************\n"
                        if(PackageErrors)
                        {
                            echo "Package Errors: ${pckJson}"
                            mensajeFinal = mensajeFinal + " Package"
                        }
                        if(UsersErrors)
                        {
                            echo "Users Errors: ${userJson}"
                            mensajeFinal = mensajeFinal + " Users"
                        }
                        if(errorDeploy)
                        {
                            echo "User Deploy Errors: ${listaDeploy}"
                            mensajeFinal = mensajeFinal + " User Deploy"
                        }
                        if(bloqueCommitVacio)
                        {
                            echo "No hay bloque de commit en este rollout para validar"
                            mensajeFinal = mensajeFinal + " No commit data"
                        }
                        if(faltaDatosCommit)
                        {
                            echo "Hay datos del commit que están vacíos"
                            mensajeFinal = mensajeFinal + " Variables sin informacion en los datos del commit|"
                        }
                        if(errorTest1py)
                        {  
                            echo "Merge Error: No se puede mergear el commit a master"
                            mensajeFinal = mensajeFinal + " Merge"
                        }
                        if(errorTest2py)
                        {
                            echo "Commit Error: Faltan commits de master en el commit"
                            mensajeFinal = mensajeFinal + " Commit"
                        }
                        if(pvcsError)
                        {
                            echo "Txeker Error: \n"
                            sh """ ssh -q es036tvr "cat /home/plataforma/plausr/data/paquetes/"${hoy}"/prueba/prueba.txt" """
                            mensajeFinal = mensajeFinal + " PVCS"
                        }
                        mensajeFinal = mensajeFinal + " | Errors"
                        //Montamos JSON para anexar al JOB solo con la parte de Status
                        elemento = [StatusValidate: "KO"]
                        listaJsonFinal.add(elemento)
                        def jsonFinal = JsonOutput.prettyPrint(JsonOutput.toJson(listaJsonFinal))


                        //Dejamos anexado el JSON al JOB
                        writeJSON file:'ResultValidate.json' , json:jsonFinal
                        archiveArtifacts artifacts: '*.json', fingerprint: true

                        def executionId = currentBuild.id
                        echo "ID JOB: ${executionId}"

                        //Bloque de Parameter:
                        node('es1117yw')
                        {
                            dir('CDM/CommonTools/WorkBenchClient/'){
                                def key = "jobValidateId"
                                try{
                                    bat "python send_jenkins_id.py -p ${env.BUILD_Id} -r ${env.BUILD_rolloutId} -k ${key} -v ${executionId} -t send"
                                }
                                catch(Exception e)
                                {
                                    echo "Error sending Jenkins Execution ID"
                                }
                            }
                        }
                        error(mensajeFinal)
                    }
                    else
                    {
                        echo "Validacion OK"
                        //Montar JSON con parametro StatusValidate -> OK y resto de información(Status, ApplicationName, Paquetes)
                        elemento = [StatusValidate: "OK"]
                        listaJsonFinal.add(elemento)
                        echo "EXISTS COMMIT: ${env.BUILD_existsCommit}"
                        echo "PVCS COMMIT: ${env.BUILD_existsPVCS}"
                        def existsCommit = (env.BUILD_existsCommit == "true") ? true : false
                        def existsPVCS = (env.BUILD_existsPVCS == "true") ? true : false
                        //Añadimos los paquetes y usuarios
                        if(existsCommit)
                        {
                             //Sacamos el paquete
                            def jsonCommit = env.BUILD_infoCommit.toString()
                            echo "${jsonCommit}"
                            def slurper = new JsonSlurper()
                            def jsondata = slurper.parseText(jsonCommit)
                            if(jsondata != null)
                            {
                                def packageId = jsondata[0].PackageId
                                def commitId = jsondata[0].Commit
                                def application = env.BUILD_valorApp.toString()
                                elementoPackage = [PackageId: "${packageId}", ApplicationName: "${application}", CommitId: "${commitId}"]
                                listaJsonFinal.add(elementoPackage)
                            }
                            
                        }
                        if(existsPVCS)
                        {
                            //Añadimos todos los paquetes al JSON:
                            def application = env.BUILD_valorApp.toString()
                            elementoPackage = [PackageId: "${env.BUILD_listaPaquetes}", ApplicationName: "${application}"]
                            listaJsonFinal.add(elementoPackage)
                        }
                        //listaJsonFinal.add(pckJson.toString())
                        //listaJsonFinal.add(userJson.toString())
                        
                        def jsonCombined = JsonOutput.prettyPrint(JsonOutput.toJson(listaJsonFinal))
                        echo "${jsonCombined}"

                        writeJSON file:'ResultValidate.json' , json:jsonCombined
                        archiveArtifacts artifacts: '*.json', fingerprint: true

                        def executionId = currentBuild.id
                        env.BUILD_currentBuild = "${executionId}"
                        echo "ID JOB: ${executionId}"

                        //Llamamos a la API para almacenar el ID del JOB de Jenkins como Parameter:
                        node('es1117yw')
                        {
                            dir('CDM/CommonTools/WorkBenchClient/'){
                                def key = "jobValidateId"
                                try{
                                    bat "python send_jenkins_id.py -p ${env.BUILD_Id} -r ${env.BUILD_rolloutId} -k ${key} -v ${env.BUILD_currentBuild} -t send"
                                }
                                catch(Exception e)
                                {
                                    echo "Error sending Jenkins Execution ID"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}