import groovy.json.JsonSlurper
import groovy.json.JsonSlurperClassic
import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import java.net.URL
import java.net.HttpURLConnection
import java.io.ByteArrayOutputStream
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _


@NonCPS
private static def readJson(String text){

    def jsonSlurper = new JsonSlurperClassic ()
    return jsonSlurper.parseText(text)
}

/*
private static def readJSONURL(String jsonUrl){
    def result=[:]
	try{
		def json=sh (label: "Get JSON ${jsonUrl}", returnStdout: true, script: "curl --noproxy '*' ${jsonUrl}")
		//echo "json : ${json}"
		result=readJSON text:json
	}catch(Exception){
        echo("Error when reading JSON from URL")
	}
	return result
}
*/


pipeline{
    agent{
        label 'eswltahr-platafor'
    }
    stages{
        //Stage para coger JSON anexo al JOB de Validate
        stage('prueba'){
            steps{
                script{
                    echo "RolloutInfo ${Rollout}"
                }
            }
        }
        stage('IdsExtraction')
        {
            steps{
                script{
                    def JsonData = new JsonSlurper()
                    def contenido = JsonData.parseText("${Rollout}")

                    echo "Production Id: ${contenido.ProductionDeploymentId}"
                    echo "Rollout Id: ${contenido.RolloutId}"

                    env.BUILD_id = "${contenido.ProductionDeploymentId}"
                    env.BUILD_rolloutId = "${contenido.RolloutId}"
                }
            }
        }
        stage('Check Validate Result'){
            //Bajar attachment de WB con el JSON de prepare
            steps{
                script{
                    //Llamamos a la API para recoger el ID:
                    node('es1117yw'){
                        checkout scm
                        dir('CDM/CommonTools/WorkBenchClient/'){
                            try{
                                def result = bat(returnStdout:true, script: "python send_jenkins_id.py -p ${env.BUILD_id} -r ${env.BUILD_rolloutId} -k jobValidateId -t get")

                                def partesString = result.split(":")
                                def valor = partesString[2].trim()
                                env.BUILD_valor = "${valor}"
                                
                                /*
                                def jsonString = data.find{it.startsWith("[{")}
                                
                                def jsonSlurper = new JsonSlurper()
                                def jsonData = jsonSlurper.parseText(jsonString)
                                echo "${jsonData}"
                                */
                            }
                            catch(Exception e)
                            {
                                echo "Error al procesar el ValueID"
                            }
                        }
                    }
                    def jobUrlValidate = "http://195.233.178.75:8283/job/WORKBENCH/job/_pruebas/job/pruebaRolloutValidate/${env.BUILD_valor}/artifact/ResultValidate.json"
                    
                    //Leemos el JSON anexado
                    def result=[:]
                    try{
                        def json=sh (label: "Get JSON ${jobUrlValidate}", returnStdout: true, script: "curl --noproxy '*' ${jobUrlValidate}")
                        echo "json : ${json}"
                        result=readJSON text:json
                        env.BUILD_json = result
                    }catch(Exception){
                        echo "Error when reading JSON from URL"
                    }
                    //def resultJson = readJSONURL(jobUrlValidate)
                    def jsonData = readJSON text: env.BUILD_json
                    def statusValue = jsonData[0].StatusValidate
                    if(statusValue == "OK")
                    {
                        def packageId = jsonData[1].PackageId
                        def applicationName = jsonData[1].ApplicationName
                        if(jsonData[1].CommitId){
                            def commitId = jsonData[1].CommitId
                            env.BUILD_commitId = commitId
                        }
                        echo "${packageId}"
                        echo "${applicationName}"
                        env.BUILD_statusValidateValue = "OK"
                        env.BUILD_valorApp = "${applicationName}"
                        env.BUILD_valorPackage = "${packageId}"
                    }
                    else
                    {
                        env.BUILD_statusValidateValue = "KO"
                    }
                }
            }
        }
        stage('Job Execution')
        {
            steps{
                script{
                    //Lanzamos el JOB:
                    if(env.BUILD_statusValidateValue == "OK")
                    {
                        env.BUILD_errorValidate = 'false'
                        echo "Prepare se lanza"
                        def data = readJSON file: "${WORKSPACE}/CDM/Jenkins/WORKBENCH/_pruebas/pruebaDatosJSONPrepare.json"
                        def listaUserDeploy = []
                        def valoresParametros = []
                        data.each{ key, value ->
                            if(key.toString() == env.BUILD_valorApp.toString()){
                                env.BUILD_existsPVCS = 'false'
                                env.BUILD_existsCommit = 'false'
                                if(value.pvcs)
                                {
                                    env.BUILD_existsPVCS = 'true'
                                    env.BUILD_environment = 'PROD'
                                }
                                if(value.commit)
                                {
                                    value.commit.each{ valueCommit->
                                        env.BUILD_environment = "${valueCommit.destinyBranch}"
                                    }
                                    env.BUILD_existsCommit = 'true'
                                }
                                if(value.jenkins){
                                    value.jenkins.each{ val ->
                                        def jobName = "${val.job}"
                                        def serverName = "${val.server}"
                                        if(val.Parameters)
                                        {
                                            env.BUILD_datosParameters = 'false'
                                            val.Parameters.each{ item->
                                                item.each{ key1, value1->
                                                    if(value1[0] == "" || value1[0] == null)
                                                    {
                                                        env.BUILD_datosVaciosParameters = 'true'
                                                    }
                                                    else
                                                    {
                                                        env.BUILD_datosVaciosParameters = 'false'
                                                        valoresParametros.add(value1)
                                                    }
                                                }
                                            }
                                            env.BUILD_listaParameters = valoresParametros
                                            echo "Parametros: ${env.BUILD_listaParameters}"
                                        }
                                        else{
                                            echo "No hay bloque de Parameters en el bloque de datos Jenkins"
                                            env.BUILD_datosParameters = 'true'
                                        }
                                        def urlServer = "${val.urlServer}"
                                        env.BUILD_jobJenkins = "${jobName}"
                                        env.BUILD_serverName = "${serverName}"
                                        //env.BUILD_blockParameters = "${jsonObj}"
                                        env.BUILD_urlServer = "${urlServer}"
                                    }
                                }
                                if(value.release)
                                {
                                    value.release.each{ rel->
                                        if(rel.userDeploy)
                                        {
                                            def elemento = [usuario: "${rel.userDeploy}", server: "${rel.server}"]
                                            listaUserDeploy.add(elemento)
                                        }
                                    }
                                }
                                env.BUILD_listaUserDeploy = JsonOutput.toJson(listaUserDeploy)
                            }
                        }
                        def jobName = env.BUILD_jobJenkins.toString()
                        //Llamamos a las APIs para sacar la info del JenkinsServer:
                        node('es1117yw')
                        {
                            dir('CDM/CommonTools/WorkBenchClient/'){
                                try{
                                    def response = bat(returnStdout:true, script: "python get_info_jenkins_server.py -s ${env.BUILD_serverName}")
                                    data = response.readLines()
                                    def jsonString = data.find{it.startsWith("[")}
                                    env.BUILD_jsonServer = "${jsonString}"
                                    env.BUILD_errorDatoServer = 'false'
                                }
                                catch(Exception e)
                                {
                                    env.BUILD_errorDatoServer = 'true'
                                }
                            }
                        }
                        def dataPY = new JsonSlurper().parseText(env.BUILD_jsonServer)
                        if(dataPY.isEmpty())
                        {
                            env.BUILD_erroresDataPy = 'true'
                            echo "${env.BUILD_serverName} no existe en los servers de WB ya que no hay datos relacionados"
                        }
                        else{
                            def usuario = dataPY[0]
                            def token = dataPY[1]
                            //Bloque para lanzar el JOB
                            //.py para lanzar el JOB
                            node('es1117yw')
                            {
                                dir('CDM/CommonTools/WorkBenchClient/')
                                {
                                    def dataParameters = env.BUILD_blockParameters
                                    def existsPVCS = (env.BUILD_existsPVCS == 'true') ? true : false
                                    def existsCommit = (env.BUILD_existsCommit == 'true') ? true : false
                                    echo "Exist Commit: ${existsCommit}"
                                    echo "Exist PVCS: ${existsPVCS}"
                                    echo "Lista Parametros: ${env.BUILD_listaParameters}"
                                    if(existsCommit)
                                    {
                                        def response = bat(returnStdout:true, script: "python exec_job.py -s ${env.BUILD_urlServer} -u ${usuario} -p ${token} -w ${env.BUILD_valorPackage} -d ${env.BUILD_environment} -a ${env.BUILD_valorApp} -c ${env.BUILD_commitId} -l ${listaSinCorchetes}")
                                        def dataResponse = response.readLines().toString()
                                        env.BUILD_dataResponse = "${dataResponse}"
                                        
                                    }
                                    if(existsPVCS)
                                    {
                                        def wbid = "prueba"
                                        def response = bat(returnStdout:true, script: "python exec_job.py -s ${env.BUILD_urlServer} -u ${usuario} -p ${token} -w ${wbid} -b ${env.BUILD_valorPackage} -e ${env.BUILD_environment} -a ${env.BUILD_valorApp} -l ${listaSinCorchetes}")
                                        def dataResponse = response.readLines().toString()
                                        env.BUILD_dataResponse = "${dataResponse}"
                                    }
                                    def cadenaRuta = env.BUILD_dataResponse.split("@")[1][0..-2]
                                    def nuevaCadenaRuta = cadenaRuta.substring(cadenaRuta.indexOf("/h"))
                                    env.BUILD_description = "${nuevaCadenaRuta}"
                                }
                            }
                        }
                    }
                    else{
                        env.BUILD_errorValidate = 'true'
                    }
                }
            }
        }
        stage('Error Validation')
        {
            steps{
                script{
                    def errorValidate = (env.BUILD_errorValidate == 'true') ? true : false
                    def errorServer = (env.BUILD_errorDatoServer == 'true') ? true : false
                    def errorDataPy = (env.BUILD_erroresDataPy == 'true') ? true : false
                    def datosParameters = (env.BUILD_datosParameters == 'true') ? true : false
                    def datosVaciosParameters = (env.BUILD_datosVaciosParameters == 'true') ? true : false
                    def variablesError = [errorValidate, errorServer, errorDataPy, datosParameters, datosVaciosParameters]
                    def contador = 0
                    variablesError.eachWithIndex{ value, index ->
                        if(value)
                        {
                            contador = contador + 1
                        }
                    }
                    def listaJsonFinal = []

                    
                    if(contador > 0)
                    {
                        elemento = [StatusPrepare: "KO"]
                        listaJsonFinal.add(elemento)

                        writeJSON file:'ResultPrepare.json' , json:listaJsonFinal
                        archiveArtifacts artifacts: 'ResultPrepare.json', fingerprint: true

                        def jobId = currentBuild.id
                        env.BUILD_idJob = "${jobId}"

                        node('es1117yw')
                        {
                            dir('CDM/CommonTools/WorkBenchClient/'){
                                def key = "jobPrepareId"
                                try{
                                    bat "python send_jenkins_id.py -p ${env.BUILD_id} -r ${env.BUILD_rolloutId} -k ${key} -v ${env.BUILD_idJob} -t send"
                                }
                                catch(Exception e)
                                {
                                    echo "Error sending Jenkins Execution ID"
                                }
                            }
                        }
                        error("ERROR: Prepare KO")
                    }
                    else
                    {
                        elemento = [StatusPrepare: "OK"]
                        listaJsonFinal.add(elemento)

                        def jobId = currentBuild.id
                        env.BUILD_idJob = "${jobId}"

                        elementoRuta = [Ruta: "${env.BUILD_description}"]
                        listaJsonFinal.add(elementoRuta)

                        elementoDeploy = [Deploy: "${env.BUILD_listaUserDeploy}"]
                        listaJsonFinal.add(elementoDeploy)

                        def jsonFinal = JsonOutput.prettyPrint(JsonOutput.toJson(listaJsonFinal))
                        writeJSON file:'ResultPrepare.json' , json:jsonFinal
                        archiveArtifacts artifacts: 'ResultPrepare.json', fingerprint: true

                        node('es1117yw')
                        {
                            dir('CDM/CommonTools/WorkBenchClient/'){
                                def key = "jobPrepareId"
                                try{
                                    bat "python send_jenkins_id.py -p ${env.BUILD_Id} -r ${env.BUILD_rolloutId} -k ${key} -v ${env.BUILD_idJob} -t send"
                                }
                                catch(Exception e)
                                {
                                    echo "Error sending Jenkins Execution ID"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
