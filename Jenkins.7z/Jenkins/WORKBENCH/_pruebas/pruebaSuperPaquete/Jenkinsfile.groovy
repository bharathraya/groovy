#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

def set_wb_credentials(){
    dir ("CDM/CommonTools/WorkBenchClient/"){

        bat "del wbcredentials.py"
        cred='''urltoken="https://webpre-adm.es.sedc.internal.vodafone.com:42510/WorkBenchTest/Token"
urlpackageinfo="https://webpre-adm.es.sedc.internal.vodafone.com:42510/WorkBenchTest/api/Construction/Package/{}/Model?filters.base=true&filters.references=true&filters.dependences=true&filters.dataModules=true&filters.annexes=true&filters.history=true&filters.contents=true"
username="Admin"
password="WorkBench_2018"
host="webpre-adm.es.sedc.internal.vodafone.com:42510"'''
        writeFile(file: 'wbcredentials.py', text: cred)
        
    }
}

def get_wb_package_json(String _package){
    ret=[]
    set_wb_credentials()
    dir ("CDM/CommonTools/WorkBenchClient/"){
        bat "pip install -r requirements.txt"
        bat "python get_package_info.py ${_package} result.json"
        ret=readJSON file:"result.json"
    }
    
    return ret
}
pipeline{
    agent {
        label 'es1117yw'
    }
    stages{
        stage('get json'){
            steps{
                script{
                    jsoninfo=get_workbench_package_info2(package)
                    echo "JsonInfo:${jsoninfo}"
                }

            }
            
        }
    }
}