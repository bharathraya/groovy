
void prueba(String prueba){
    echo "${prueba}"
}

return this