#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDeployment
//import groovy.json.JsonOutput
//import vfes.utils.VFESJobConfig
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

def getFromAnnexes(String _Alms,String _Env,String _remoteServer,String _date){
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    export ruta_temp=\$DIR_BASE_TEMPORAL/${_date}/anexo/${_Alms}

    if [ ! -d \${ruta_temp} ]
    then
        mkdir -p \${ruta_temp}
    fi
    
    cd \${ruta_temp}
    scp -qr es036tvr:/home/plataforma/plausr/data/temporal/${_date}/${_Alms}/${_Env}/Annexes/* .
    """
    
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}

def apigw_migrador(String _env,String _package,String _remoteServer, String _domain){
    
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_package}
    apigw_migrador.sh -d ${_domain} -e ${_env} -p ${_package} 
    
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}

// Parametros entrada
def callFromWB=true
def _Domain=""
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _Aplicacion=""
def _dataModules=""
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _Pvcs=""
def hoy=new Date().format( 'yyyyMMdd' )

print "La fecha de hoy es ......${hoy}......"

if (PackageInfo==""){
    callFromWB=false  
}

def pckInfo=null
if (callFromWB){
    pckInfo=readJSON(text: "${PackageInfo}")
    _DeployEnv=pckInfo['DeployEnvironment'].Name
    _Domain=pckInfo['AppDomain'].Name	
    _ALMS_ID=pckInfo.Id.toString()
    _server=pckInfo['AppHost'].Host
    _Aplicacion=pckInfo['ApplicationName']
    _Pvcs=pckInfo['Pvcs']
    _HayModulosPVCS=pckInfo['Pvcs'].Archive[0]
    _dataModules=pckInfo['Modules']
    _HayModulosDatos=pckInfo['Modules'].FileName[0]
    _dominioAPIGW=_Aplicacion
    

	print "DEBUG: parameter PackageInfo =${PackageInfo}"
	print "_dominio: ${_dominioAPIGW}"
 	
    }


//node("${_Domain}-${_DeployEnv}"){
//Se han de indicar en el agente la etiqueta del _Domain para saber qu� agente vamos a utilizar
node("${_Domain}"){
    
    stage ("configure"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Aplicacion}"
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_DeployEnv} Aplicaci�n: ${_Aplicacion}"
    }

    stage("comprobaciones"){
        
        print "COMPROBACIONES"
        print "_HayModulosPVCS ${_HayModulosPVCS} "
        print "_HayModulosDatos ${_HayModulosDatos} "
        //print "NODE_NAME ${env.NODE_NAME}"
        //print "_server ${_server}"
        
        if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
	        error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
         }
         
        if( _HayModulosPVCS == null){
            error("No hay modulos de pvcs")
         }

        //if( _HayModulosDatos == null){
        //    error("No hay modulos de datos")
        // }

        if ("${env.NODE_NAME}" == "${_server}")
         {
            _server =""
             //print "DEBUG server ${_server} "
        }
    }

    stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        //Descomentar cuando FW abierto
        cleanDirPaquete "${_ALMS_ID}","${_server}","${hoy}"
        print "CLEAN"
    }
    
    stage ("checkoutAnexos"){
		//Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        //No utilizar - getFromAnexosCat "${_ALMS_ID}","${_DeployEnv}","${_server}","${hoy}"
        //Descomentar cuando FW abierto
        print "_dominio: ${_dominioAPIGW}"
        if ( _dominioAPIGW=="APIGW_REEMPLAZO" || _dominioAPIGW=="APIGW_SUSTITUCION" ){
          print "ANEXOS"
          //getFromAnnexes "${_ALMS_ID}","${_DeployEnv}","${_server}","${hoy}"
        }
        
    }    
       
    stage ("checkoutPVCS"){
		//Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        //Descomentar cuando FW abierto
        getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_server}"
        print "PVCS"
    }
    
    stage ("deploy"){
        print "DEPLOY STAGE"
        //apigw_migrador "${_DeployEnv}","${_ALMS_ID}","${_server}","${_dominioAPIGW}_DXL"
        apigw_migrador "${_DeployEnv}","${_ALMS_ID}","${_server}","${_dominioAPIGW}"
    }
}