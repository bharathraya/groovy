#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-EDC-JAVA/pipelineConfig.yml'])
mavenPipelineTemplateSAML([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ISA-MOBILITY/ISA-MOBILITY-JAVA/pipelineConfig.yml',
     artifactChoices:["samlwrapper-averias","samlwrapper-instalaciones"],
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","master"]])



