#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

myalms_id=params.WB_ID
   
      node ("eswltahr-platafor") {     
    stage ("Obtener JSON"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${myalms_id}"
        currentBuild.description = "ID_WB: ${myalms_id}"
        wbpckinfo=get_workbench_package_info(myalms_id)
        //print "DEBUG: parameter PackageInfo =${PackageInfo}"
        print wbpckinfo
    }
}
