#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

Agrupapipeline([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/BIZTALK/pipelineConfigUpgrade.yml',
environmentChoices:["SIT1","SIT2","SIT3","PPRD","PROD"],
OptionChoices:["1","2","3"]])
