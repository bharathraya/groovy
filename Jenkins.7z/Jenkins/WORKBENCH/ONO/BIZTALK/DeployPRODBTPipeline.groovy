#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

DeployPRODBT([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/BIZTALK/pipelineConfig.yml',
EnviromentChoices:["SIT1", "SIT2", "SIT3", "PPRD", "PROD"]])

