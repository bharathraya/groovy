#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/BIZTALK/pipelineConfigUpgrade.yml',
    applicationChoices:["BIZTALK2020-BBDD", "BIZTALK2020-BINDINGS" ,"BIZTALK2020-CONFIG" ,"BIZTALK2020-IIS" ,"BIZTALK2020-OBSOLETOS","BIZTALK2020-SQLSERVER","BIZTALK2020-TEST"],
	 environmentChoices:["SIT1","SIT2","SIT3","PPRD","PROD"]])