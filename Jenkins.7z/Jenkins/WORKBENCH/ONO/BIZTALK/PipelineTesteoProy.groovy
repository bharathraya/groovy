#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _Domain=""
def _DeployEnv=""
def _LabelName=""
def _ALMS_ID=""
def _server=""
def _Aplicacion=""
def _dataModules=""
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _Pvcs=""
def _domain=""
def _env=""

def hoy=new Date().format( 'yyyyMMdd' )
def pckInfo=null

if (PackageInfo==""){
    callFromWB=false  
    //print "llamada manual"
}
else{
    //print "llamada WB"
}


print "La fecha de hoy es ......${hoy}......"


node("eswltbhr"){
    stage("ObtenerDatos"){
        if (callFromWB){
            //print "llamada WB"
            pckInfo=readJSON(text: "${PackageInfo}")
            _DeployEnv=pckInfo['EnvironmentName']
            _LabelName=pckInfo['EnvironmentLabel']
            _ALMS_ID=pckInfo.Id.toString()
            _CodProy=pckInfo['ProjectId']
            _domain=pckInfo['ApplicationName'] 
        }
        else
        {
            //print "llamada manual"
            _ALMS_ID=params.WB_ID  
            wbpckinfo=get_workbench_package_info(_ALMS_ID)
            _DeployEnv=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
            _LabelName=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
            _CodProy=wbpckinfo.Data.Model.Model.Base.Project.CodProject
            _domain=wbpckinfo.Data.Model.Model.Base.Application.Description
        }
        
         print "WB ID ${_ALMS_ID}"
         print "Codigo Proyecto ${_CodProy}"
         
         print "Enviroment ${_DeployEnv}"
         print "Label ${_LabelName}"
         print "Domain ID ${_domain}"
        
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Codigo Proyecto ${_CodProy} "
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_DeployEnv} "
    }

    stage("BuscarEstado"){
        if(_CodProy=="" ) { 
    	    error("El código Proyecto viene vacío [${_CodProy}]")
        }
       if(_CodProy ==~ /Mantenimiento-ES[0-9]{4}DL/ || _CodProy ==~ /Mantenimiento ES[0-9]{4}DL/ ) { 
           print "Proyecto de Mantenimiento ${_CodProy}"
        }
       else{
            exec="""
                  . \$HOME/.profile >/dev/null 2>&1
                  cd /home/plataforma/release/scripts
                 ./revisa_proy.sh -p ${_CodProy} 
                """
            sh "ssh -q ken-to3-c '${exec}'"
           }
        }
        
     stage("Txeker"){
        if ((_domain=="BIZTALK-IIS" || _domain=="BIZTALK2020-IIS") && ( _LabelName=="PPRDCI" || _LabelName=="SIT1CI" || _LabelName=="SIT2CI" || _LabelName=="SIT3CI" ) )
        {
             if (_LabelName == "PPRDCI")
               {
                   _env="PPRD"
               }
               else if (_LabelName == "SIT1CI")
               {
                   _env="SIT1"
               } 
               else if (_LabelName == "SIT2CI")
               {
                   _env="SIT2"
               }
               else if (_LabelName == "SIT3CI")
               {
                   _env="SIT3"
               }
             print "Lanzamos el txeker para ${_domain} y paquete WB ${_ALMS_ID} en el entorno ${_env} "  
    	     txeker("",_domain,_env,_ALMS_ID,_ALMS_ID)
       
        }    
     }//stage lanzar txeker   
 
}
