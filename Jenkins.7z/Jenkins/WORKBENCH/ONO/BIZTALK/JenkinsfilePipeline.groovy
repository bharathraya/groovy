#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/BIZTALK/pipelineConfig.yml',
    applicationChoices:["BIZTALK-BBDD", "BIZTALK-BINDINGS" ,"BIZTALK-CONFIG" ,"BIZTALK-IIS" ,"BIZTALK-OBSOLETOS","BIZTALK-SQLSERVER","BIZTALK-TEST"],
	 environmentChoices:["SIT1","SIT2","SIT3","PPRD","PROD"]])
