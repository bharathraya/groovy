#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

SVNPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/CRAMER/pipelineConfig_PromoSVN.yml'])

//PVCSPipelineTemplate_pruebarferna72.groovy([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/CRAMER/pipelineConfig_PromoSVN.yml'])
