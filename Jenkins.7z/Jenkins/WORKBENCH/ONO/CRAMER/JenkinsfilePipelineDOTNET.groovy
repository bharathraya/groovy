#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

PVCSPipelineWindowsTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/CRAMER/pipelineConfig.yml'])
