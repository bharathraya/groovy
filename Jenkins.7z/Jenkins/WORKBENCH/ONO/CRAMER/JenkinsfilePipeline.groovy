#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/CRAMER/pipelineConfig.yml'])

PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/CRAMER/pipelineConfig.yml',
    applicationChoices:["CRAMER-UNIX","CRAMER-LoadJAVA","CRAMER-BBDD","CRAMER-DOTNET","CRAMER-METADATA","CRAMER-J2EE","MQ_SIRO_V8","MQ_SIRO_V8-BBDD"],
	 environmentChoices:["SIT1","SIT2","PPRD","PPRD1","EBU","PROD"]])

