#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _Domain=""
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def hoy=new Date().format( 'yyyyMMdd' )
def pckInfo=null
def _Aplicacion=""
def _dataModules=""
def _HayModulosPVCS=""
def _HayModulosDatos=""


print "La fecha de hoy es ......${hoy}......"

if (PackageInfo==""){
    callFromWB=false  
}

if (callFromWB){
    pckInfo=readJSON(text: "${PackageInfo}")
    _DeployEnv=pckInfo['DeployEnvironment'].Name
    _Domain=pckInfo['AppDomain'].Name	
    _ALMS_ID=pckInfo.Id.toString()
    _server=pckInfo['AppHost'].Host
    _dataModules=pckInfo['Modules']
    _Aplicacion=pckInfo['ApplicationName']
    _Pvcs=pckInfo['Pvcs']
    _HayModulosDatos=pckInfo['Modules'].FileName[0]
    _HayModulosPVCS=pckInfo['Pvcs'].Archive[0]
    
    print "DEBUG: parameter PackageInfo =${PackageInfo}"
    print "DEBUG: hay modulos de datos ${_HayModulosDatos}"
    print "DEBUG: hay modulos pvcs ${_HayModulosPVCS}"
    }



node("${_Domain}-${_DeployEnv}"){
    
    stage ("configure"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Aplicacion}"
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_DeployEnv} Aplicación: ${_Aplicacion}"
    }
    
    stage("comprobaciones"){
        if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
    	    error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
        }
    
        if(_HayModulosDatos == null && _HayModulosPVCS == null)
        {
            error("No hay modulos de datos ni de pvcs")
        }
    
    }
	stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        cleanDirPaquete "${_ALMS_ID}","${_server}","${hoy}"
    }
    
    stage ("checkoutModulosDatos"){
        if(_HayModulosDatos!= null)
        {
		    //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
            getFromAnexos "${_ALMS_ID}","${_DeployEnv}","${_server}","${hoy}"
        }    
    }

    stage ("Ejecutar gestdata"){
        if(_HayModulosDatos!= null)
        {
            // Ejecutamos el gestadata para cada modulo de datos
            // la llamada (String _Alms,String _Env,String _remoteServer,String _date)
            gestData "${_ALMS_ID}",_dataModules,"${_server}","${hoy}","${_DeployEnv}"
        }
    }
}
