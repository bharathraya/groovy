#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _ALMS_ID=""
def _Aplicacion=""
def _dataModules=""
def _myParamsTotal=""
def _myHayParametros=""
def wbpckinfo=""
def _env=""
def _BBDD=""
def posi=0
def _Value=""
def _descripcion=""
def _key=""
def exec=""
def _domain=""
def iIsPrepro=0

def hoy=new Date().format( 'yyyyMMdd' )
def pckInfo=null

if (PackageInfo==""){
    callFromWB=false  
}


print "Today's date is ......${hoy}......"

node ("es036tvr") {     
    stage ("GetUser"){
        wrap([$class: 'BuildUser']) {
        _usuario=env.BUILD_USER_ID
        }
      _usuario="cm_bot"
    (_pass,_usuario)=findpassword(_usuario)
    }
}



node("AMDOCS-PARCHE"){
    stage("ObtenerDatos"){
        if (callFromWB){
            pckInfo=readJSON(text: "${PackageInfo}")
            _ALMS_ID=pckInfo.Id.toString()
            _domain=pckInfo['ApplicationName'] 
        }
        else
        {
            _ALMS_ID=params.WB_ID  
         }

        wbpckinfo=get_workbench_package_info(_ALMS_ID)
        _env=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
        _myParamsTotal=wbpckinfo.Data.Model.Model.Params
        _domain=wbpckinfo.Data.Model.Model.Base.Application.Description
        
        if(_myParamsTotal == "null"  || ! _myParamsTotal ){
            _myHayParametros=0
            _myParams=0
        }
        else
        {
            _myHayParametros=_myParamsTotal.size()
            _myParams=_myParamsTotal
        }

        print "ALMS ID ${_ALMS_ID}"
        print "Environment ${_env}"
        print "Domain ${_domain}"
        iIsPrepro=0
         
        if (_env=="SIT1")
        {
            _BBDD="TST2"
            iIsPrepro=1
        }
        else if (_env=="PPRD")
        {
            _BBDD="TST3"
            iIsPrepro=1
        }
        else if (_env=="SIT2")
        {
            _BBDD="TST5"
            iIsPrepro=1

        }

        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_env} BBDD: ${_BBDD} "
        currentBuild.description = "ID_WB: ${_ALMS_ID} Environment: ${_env} BBDD: ${_BBDD}"
    
        } //stage
}//nodo

node("es1117yw"){
    stage("Promote dependencies"){
    if(_myHayParametros != 0 && _domain == "AMDOCS-BBDD" && iIsPrepro == 1 ){        
            print "There are parameters in the package ${_myHayParametros}"
            print "Parameters: ${_myParams}"
            print "IS Prepro: ${iIsPrepro}"
            
             for (posi = 0; posi < _myParams.size(); posi++) {
                _key = _myParams[posi].Key; //Key
                _Value = _myParams[posi].Value; //Valor
                _descripcion = _myParams[posi].Description ; //descripción
                            
                if (_key=="ISWINDOW" && (_Value=="Y" ||_Value=="YES"))
                {
                    print "${_ALMS_ID}"
                    print "${_usuario}"
                    checkout scm
                        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
                         wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                                bat "promte_package_dependencies_for_window.py -u ${_usuario} -c ${_pass} -p  ${_ALMS_ID}"
                          }//wrap
                        }
                }
                 
             }//for
             
              //sh "${exec}"
            
        }//Hay parametros

        
    } //stage
}//nodo
