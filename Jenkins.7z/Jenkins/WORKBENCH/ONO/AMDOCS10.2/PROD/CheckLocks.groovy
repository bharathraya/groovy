#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def mycrq=params.CRQ
def mypass=params.PASS_PPP

    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Check: ${mycrq}"
    currentBuild.description = "Check: ${mycrq}"
    
//Comprobacion conectividad
node ("devopsprdtools01") {       
   stage ("DB_LOCK_CHECK"){
       print "*****************************************************"
       print " Checking DB locks and invalids objects for ${mycrq} "
       print "*****************************************************"
       exec_check_locks="""
       . \$HOME/.profile >/dev/null 2>&1
       cd /home/plataforma/release/scripts
       ./check_locks_PGA1.sh -C ${mycrq} -P ${mypass}
       """
       sh "${exec_check_locks}" //platafor
   } //stage
} //node
