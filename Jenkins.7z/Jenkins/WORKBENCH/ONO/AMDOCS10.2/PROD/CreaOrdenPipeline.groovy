#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def mybuilduser=""
def _CRQ=""
def _Orden=""
def _OrdenPost=""
def _OrdenPre=""

def hoy=new Date().format( 'yyyyMMdd' )


node("AMDOCS-PARCHE"){
    stage("Prepare"){
                //Saco el ejecutor
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
                }
            
            print "Today's date is ......${hoy}......"
    
            // Parametros entrada
            _CRQ=params.CRQ_ID
            _Orden=params.ORDEN
            _OrdenPost=params.ORDEN_POST
            _OrdenPre=params.ORDEN_PRE
    
            currentBuild.displayName = "Order to upload to bitbucket for the CRQ: ${_CRQ}" 
            currentBuild.description = "Order to upload to bitbucket for the CRQ: ${_CRQ}" 

      }//stage
    
    stage("SubirOrden"){
        
        if (_Orden != "" && _OrdenPost != "" && _OrdenPre != "")
        {
            error("Database or Schema orders are uploaded, not both.")
            
        }
        else if (_Orden != "" && _OrdenPost != "" && _OrdenPre == "")
        {
            error("Database or Schema orders are uploaded, not both.")
            
        }
         else if (_Orden != "" && _OrdenPre && _OrdenPost == "")
        {
            error("Database or Schema orders are uploaded, not both.")
            
        }
        
        if (_Orden != "")
        {
            print "Database Order is uploaded"
             execOrden="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_CRQ} PROD_o_no
                rm -Rf *
                touch -f orden.txt
                echo '${_Orden}' >> orden.txt
                SubidaGIT.sh -a -p ${_CRQ}
            """            
            
            sh "${execOrden}"
        }
        else if (_OrdenPost != "" && _OrdenPre != "")
        {
            print "PRE and POST order is uploaded"
            execOrdenES="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_CRQ} PROD_o_no
                rm -Rf *
                touch -f orden_post.txt orden_pre.txt
                echo '${_OrdenPost}' >> orden_post.txt
                echo '${_OrdenPre}' >> orden_pre.txt
                SubidaGIT.sh -a -p ${_CRQ}
            """            
            
            sh "${execOrdenES}"
        }
        else if (_OrdenPost != "" && _OrdenPre == "")
        {
            print "POST Order is uploaded"
            execOrdenES="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_CRQ} PROD_o_no
                rm -Rf *
                touch -f orden_post.txt
                echo '${_OrdenPost}' >> orden_post.txt
                SubidaGIT.sh -a -p ${_CRQ}
            """            
            
            sh "${execOrdenES}"
        }
        else if (_OrdenPost == "" && _OrdenPre != "")
        {
            print "PRE Order is uploaded"
            execOrdenES="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_CRQ} PROD_o_no
                rm -Rf *
                touch -f orden_pre.txt
                echo '${_OrdenPre}' >> orden_pre.txt
                SubidaGIT.sh -a -p ${_CRQ}
            """            
            
            sh "${execOrdenES}"
        }
            
    }//Stage   
    
}//Nodo
