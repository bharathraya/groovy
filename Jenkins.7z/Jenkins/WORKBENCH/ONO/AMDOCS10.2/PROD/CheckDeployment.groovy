#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def _listapaquete=""
def _NomVista=""
def _CRQ_ID=""
def _View
def mybuilduser=""
def RutaTemp=""
def RutaPaquete=""
def hoy=new Date().format( 'yyyyMMdd' )
def _Ventana
def NumTipos=""
def TiposApp=""
def _listpackages=""

_Ventana = false
_upgrade="S"


node("AMDOCS-DEPLOY"){
    stage("Prepare"){
                //Saco el ejecutor
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
                }
            
            print "Today's date is ......${hoy}......"
    
            // Parametros entrada
            _CRQ_ID=params.CRQ_ID.trim()    
            _domain=params.App
    
            currentBuild.displayName = "Application to review: ${_domain} Dia: ${hoy} "        
     
            print "Input parameters"
            print "Chosen application ${_domain}"
            
            if (CRQ_ID == "" & (_domain =="AMDOCS-UPSD" || _domain =="AMDOCS-RULEMANAGER" || _domain =="AMDOCS-CLARIFY" ))
            {
                error("It is necessary to put the package name to check.")
            }
           
            if (_CRQ_ID != "")
            {
                 print "Name of package ${_CRQ_ID}"
                    currentBuild.description = "Application to review: ${_domain} NAME: ${_CRQ_ID} "
            }
            else
            {
                currentBuild.description = "Application to review: ${_domain} "
            }

      }//stage
      

    stage("Check"){
         if (_domain =="AMDOCS-UPSD" || _domain =="AMDOCS-RULEMANAGER" || _domain =="AMDOCS-CLARIFY" )
         {
          execCheck="""
            . \$HOME/.profile >/dev/null 2>&1
            check_deployment_package.sh -d ${_domain} -e PROD -p ${_CRQ_ID}
            """
         }
         else
         {
             execCheck="""
            . \$HOME/.profile >/dev/null 2>&1
            check_deployment.sh -d ${_domain} 
            """
         }
         
         print "*********************************************************************"
         print "******WE LAUNCH THE REVIEW*******************************************"
         sh "${execCheck}"

    }//stage
}//Nodo
  
