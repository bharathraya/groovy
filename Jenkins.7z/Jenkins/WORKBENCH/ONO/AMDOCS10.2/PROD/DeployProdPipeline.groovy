#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

DeployAmdocsProdPipeline([pipelineDeployConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/PROD/DeployAppConfig.yml',
TypesChoices:["AMDOCS-AIF","AMDOCS-BBDD","AMDOCS-BusinessRules","AMDOCS-CAB","AMDOCS-CLARIFY","AMDOCS-CONTRATOS","AMDOCS-ESQUEMA","AMDOCS-UPSD","AMDOCS-RULEMANAGER","AMDOCS-SMS","AMDOCS-SPM","AMDOCS-CLIENT","AMDOCS-SERVER","AMDOCS-BPM_APM","AMDOCS-IntegracionTOA","MQ_NEPTUNO"]])






   
