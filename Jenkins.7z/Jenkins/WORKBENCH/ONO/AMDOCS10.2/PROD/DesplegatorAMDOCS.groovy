#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros necesarios
def _packageName=params.CRQ_ID.trim()
def _AppToDeploy=params.Application
def _Env=params.Enviroment
def _Date=params.Date
def _Scripts=params.Scripts
def _sshTest=params.SSH_Check
//def _checkAppStopped=params.Check_App_stopped
def maquina=""

if(_AppToDeploy=="" || _Env=="" || _packageName=="") { 
	error("Parameters --> Application [${_AppToDeploy}] Enviroment [${_Env}] CRQ_ID [${_packageName}] are mandatory.")
}

if(_Date==""){
	print "parameter Date is empty, we get the current date"
	_Date=new Date().format( 'yyyyMMdd' )
}

_Domain=_AppToDeploy
maquina="devopsprdtools01"

print "Package name: ${_packageName}"
print "Application: ${_AppToDeploy}"
print "Domain: ${_Domain}"
print "Environment: ${_Env}"
print "Date: ${_Date}"
print "SSHtest: ${_sshTest}"
//print "checkAppStopped: ${_checkAppStopped}"

//Configuramos el nombre del build y su descripcion
currentBuild.displayName = "WB_ID: ${_packageName} Domain: ${_AppToDeploy} Entorno: ${_Env}"
if(_Scripts==""){
	currentBuild.description = "Scripts: ${_packageName}-${_Domain}.sh"
	_Scripts="${_packageName}-${_Domain}.sh"
}
else{
	currentBuild.description = "Scripts: ${_Scripts}"
}

print "Scripts to execute: ${_Scripts}"

/*
if(_checkAppStopped=="YES"){
        node ("eswltbhr-platafor") {       
    	stage ("checkAppStopped"){
    		print "*****************************************"
    		print "Doing ps -fu weblogic in PROD machines:"
    		print "*****************************************"
    		
    		try{
    				exec_checkAppStopped="""
    				cd /home/plataforma/plausr
    				. ./.profile 2>/dev/null
    				cd /home/plataforma/release/scripts
    				./check_proc_prod.sh -d ${_Domain} -e ${_Env}
    				 """
    				
    				sh "ssh -q platafor@${maquina} '${exec_checkAppStopped}'"
    		} 
    		catch(Exception e){
    			error("The check if App is stopped in production machines has failed with error: ${e}")
    		}
       } //stage
    } //node
}
*/

if(_sshTest=="YES")
{
    node ("devopsprdtools01") {       
    	stage ("checkSSH"){
    		print "*****************************************"
    		print "Checking the correct SSH in the machines:"
    		print "*****************************************"
    		
    		try{
    				exec_checkSSH="""
    				cd /home/plataforma/plausr
    				. ./.profile 2>/dev/null
    				cd /home/plataforma/release/scripts
    				./check_ssh_prod_upgrade.sh -d ${_Domain}
    				 """
    				 
    				//sh "ssh -q platafor@${maquina} '${exec_checkSSH}'"
					sh "${exec_checkSSH}"
    		} 
    		catch(Exception e){
    			error("The SSH to some production machine has failed with error: ${e}")
    		}
       } //stage
    } //node
}

node ("devopsprdtools01") {       
	stage ("DeployScript"){
		print "************************************************"
		print "Executing the Script in each production machine:"
		print "************************************************"
		
		try{
			exec_desplegator="""
			cd /home/plataforma/plausr
			. ./.profile 2>/dev/null
			cd /home/plataforma/release/scripts
			./desplegator -d ${_Domain} -e ${_Env} -f ${_Date} -p ${_packageName} ${_Scripts}
			"""
			//sh "ssh -q platafor@${maquina} '${exec_desplegator}'"
			sh "${exec_desplegator}"
		} 
		catch(Exception e){
			error("The deployment of ${_Scripts} in some production machine has failed with error: ${e}")
		}
   } //stage
} //node

node ("devopsprdtools01") {       
	stage ("DeployScript"){
		print "************************************************"
		print "Checking the changes in each production machine:"
		print "************************************************"
		
		try{
			exec_checkDeploy="""
			cd /home/plataforma/plausr
			. ./.profile 2>/dev/null
			cd /home/plataforma/release/scripts
			./check_deployment.sh -d ${_Domain} -e ${_Env}
			"""

			//sh "ssh -q platafor@${maquina} '${exec_checkDeploy}'"
			sh "${exec_checkDeploy}"
		} 
		catch(Exception e){
			error("There is some diference between SPPR and some PROD machine. error: ${e}")
		}
   } //stage
} //node
