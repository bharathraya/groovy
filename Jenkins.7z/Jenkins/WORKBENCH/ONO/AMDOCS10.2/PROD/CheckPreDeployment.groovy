#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def mycrq=params.CRQ

    //Configuramos el nombre del build y su descripcion    
currentBuild.displayName = "Check ssh for ${mycrq}"
    currentBuild.description = "Check ssh for ${mycrq}"
    
//Comprobacion conectividad
node ("devopsprdtools01") {       
   stage ("CRQ_UNIX_CONECTIONS"){
       print "*************************************************"
       print " Checking UNIX connections for CRM PROD machines "
       print "*************************************************"
       exec_check_ssh="""
		. $HOME/.profile >/dev/null 2>&1
		cd /home/plataforma/release/scripts
		./check_ssh_prod_upgrade.sh -d ALL
       """
       sh "${exec_check_ssh}" //platafor
   } //stage
} //node
