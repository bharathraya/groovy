#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def _listapaquete=""
def _NomVista=""
def _CRQ_ID=""
def _View
def mybuilduser=""
def RutaTemp=""
def RutaPaquete=""
def hoy=new Date().format( 'yyyyMMdd' )
def hoy_minutos=new Date().format( 'yyyyMMddmmss' )
def _Ventana
def NumTipos=""
def TiposApp=""
def _listpackages=""

_Ventana = false
_upgrade="S"


node("AMDOCS-PARCHE"){
    stage("Prepare"){
                //Saco el ejecutor
                wrap([$class: 'BuildUser']) {
                    echo "Exec user: ${env.BUILD_USER_ID}"
                    mybuilduser=env.BUILD_USER_ID
                    }
            (_pass,mybuilduser)=findpassword(mybuilduser)
            
        print "Today's date is ......${hoy}......"

        // Parametros entrada
        _CRQ_ID=params.CRQ_ID.trim()    
        _listapaquetes=params.List_Packages.trim()
        _NomVista=params.Vista.trim()  
        
        if (_CRQ_ID =="")
        {
            error("It is necessary to put the package name to create")
        }
      else
       {
       	  if ( !_CRQ_ID.contains("COMPROBACIONES"))
                { 
                  _CRQ_ID="${_CRQ_ID}_COMPROBACIONES"
                  print "Change the patch name to ${_CRQ_ID}"
                 }
       }
                         
        if (_listapaquetes == "" && _NomVista == "" )
        {
            error("It is mandatory to enter the name of the view or the list of packages")
        }
        else if (_listapaquetes != "" && _NomVista != "" )
        {
            error("There can be no view and list of packages")
        }
        print "Input parameters"
        print "Name of  ${_CRQ_ID}"
        
        RutaTemp="/home/plataforma/plausr/tmp"
        RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
        sh "if [ -d ${RutaPaquete} ] ; then rm -rf ${RutaPaquete} ; fi ; mkdir -p ${RutaPaquete} "
        if (_NomVista !="")
         {
            _View = true
            print "Name for view: ${_NomVista}"
            currentBuild.displayName = "NAME: ${_CRQ_ID} Date: ${hoy} View: ${_NomVista} "
            currentBuild.description = "NAME: ${_CRQ_ID} View: ${_NomVista} "
          }
          else
          {
            _View = false
            print "List of packages: ${_listapaquetes}"
            currentBuild.displayName = "NAME: ${_CRQ_ID} Date: ${hoy} List of packages: ${_listapaquetes} "
            currentBuild.description = "NAME: ${_CRQ_ID} List of packages: ${_listapaquetes} "
           
            sh "echo ${_listapaquetes} >> ${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt"
            
            sh "cat ${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt | tr '\n' ' ' >> ${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt_tmp"
            sh "mv ${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt_tmp ${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt"
          }
                                
        print "Execute function to separate"
       // print "Lanzo SeparaPaquete2 ${_CRQ_ID} , ${_View} , ${_Ventana}, ${_NomVista} , ${mybuilduser} , ${_pass} , ${_upgrade}"
        
        SeparaPaquete2 "${_CRQ_ID}" , _View , _Ventana, "${_NomVista}" , mybuilduser , _pass , _upgrade
        
        TiposApp = readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")                       
       // sh "echo ${RutaPaquete}/${_CRQ_ID}_tipos |wc -l >> ${RutaPaquete}/${_CRQ_ID}_Numtipos"
        if  (!TiposApp.contains("AMDOCS-COMPROBACIONES"))
        {
            error("There is not AMDOCS-COMPROBACIONES")
        }
        //NumTipos = readFile(file: "${RutaPaquete}/${_CRQ_ID}_Numtipos")
        Tipos=TiposApp.split("\n")
        NumTipos = Tipos.size()
        print "NumTipos-> ${NumTipos}"
        
        if (Tipos.size() != 1)
        {
            print "There are packages that not are from AMDOCS-COMPROBACIONES"
        }

      }//stage
      

    stage("Copy"){
         _listpackages=readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-COMPROBACIONES")
          replica_datos("","AMDOCS-COMPROBACIONES","PROD",_CRQ_ID,_listpackages)
          execCopy="""
            . \$HOME/.profile >/dev/null 2>&1
            export ruta_temp=\$DIR_BASE_TEMPORAL/${hoy}/${_CRQ_ID}/PROD/DataModules
            . paquete
            mv ${_CRQ_ID} ${_CRQ_ID}_${hoy_minutos}
            . paquete ${_CRQ_ID} PROD_o_no
            mkdir -p BBDD/SA/
            scp -qr es036tvr:\$ruta_temp/*sql BBDD/SA/
            find BBDD/SA/ -type f > orden.txt
            cd
            SubidaGIT.sh -a -p ${_CRQ_ID}
            """
            print "We copy the files "
            sh "${execCopy}"
            
            print "************************************************************************************************ "  
            print "EXECUTE on devopsprdtools01 "  
            print "SIMULATION->   nohup carga_bbdd_PROD_upgrade.sh -p ${_CRQ_ID} -P <Password> -CS & "  
            print "PRODUCTION->  nohup carga_bbdd_PROD_upgrade.sh -p ${_CRQ_ID} -P <Password> -C &  "  
            print "************************************************************************************************ "  

    }//stage
}//Nodo
  
