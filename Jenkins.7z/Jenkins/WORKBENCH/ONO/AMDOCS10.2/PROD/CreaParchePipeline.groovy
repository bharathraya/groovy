#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

CreaParchepipelineUpgrade([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/pipelineConfig.yml',
pipelineAppFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/PROD/AppConfig.yml',
EnvChoices:["SIT2","SIT1","PPRD","PET"],
OptionChoices:["1","2","3","4"],
TypesChoices:["ALL","AMDOCS-AIF","AMDOCS-BBDD","AMDOCS-COMPROBACIONES","AMDOCS-BusinessRules","AMDOCS-CAB","AMDOCS-CLARIFY","AMDOCS-CONTRATOS","AMDOCS-ESQUEMA","AMDOCS-PlantillasPDF","AMDOCS-PlantillasTOA","AMDOCS-UPSD","AMDOCS-RULEMANAGER","AMDOCS-SMS","AMDOCS-SPM","AMDOCS-VISTAS","AMDOCS-CLIENT","AMDOCS-SERVER","CRMSmart","AMDOCS-BPM_APM","AMDOCS-IntegracionTOA","AMDOCS-IntegracionPermanencias","AMDOCS-IntegracionOferta","AMDOCS-SCRIPTS-BUILD","MQ_NEPTUNO","AMDOCS-SCRIPTS-BPM","ALL except BBDD"]])


