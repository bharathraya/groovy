#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _env=""
def _ALMS_ID=""

def hoy=new Date().format( 'yyyyMMdd' )
def _dateLog=new Date().format( 'yyyyMMddHHmmss' )
def pckInfo=null

if (PackageInfo==""){
    callFromWB=false  
    //print "llamada manual"
}else
{
  //  print "llamada desde WB"
   //  print "Info enviada -> ${PackageInfo}"
}


print "Today's date is ......${hoy}......"


node("COMMON"){
    stage("ObtenerDatos"){
        if (callFromWB){
          //  print "PacakgeInfo -> ${PackageInfo}"
            pckInfo=readJSON(text: "${PackageInfo}")
            _ALMS_ID=pckInfo.Id.toString()
        }
        else
        {
            _ALMS_ID=params.WB_ID  
         }

        wbpckinfo=get_workbench_package_info(_ALMS_ID)
        _env=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
         print "ALMS ID ${_ALMS_ID}"
         print "Environment ${_env}"

        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_env}  "
        currentBuild.description = "ID_WB: ${_ALMS_ID} Environment: ${_env} "
    }
    
    stage("Revisar"){
        execRe="""
        export DIR_BASE_TEMPORAL=/home/plataforma/plausr/data/temporal
        export DIR_BASE_PAQUETE=/home/plataforma/plausr/data/paquetes
        cd \$DIR_BASE_PAQUETE/${hoy}/${_ALMS_ID}
        find . -type d > /home/plataforma/plausr/tmp/Chequeo_${_ALMS_ID}.${_env}.${_dateLog}.txt

        NUM=\$(cat /home/plataforma/plausr/tmp/Chequeo_${_ALMS_ID}.${_env}.${_dateLog}.txt  | grep DATA_CONFIGURATION |wc -l)
        echo "Number for data_configuration .... \${NUM} ...."
           
           if [ \${NUM} -ne 0 ]
           then
                if [  ! -d \$DIR_BASE_TEMPORAL/${hoy}/${_ALMS_ID}/${_env}/DataModules/ ]  && [ ! -d \$DIR_BASE_TEMPORAL/${hoy}/${_ALMS_ID}/${_env}/Annexes/ ]
                then
                    echo "ERROR There are DATA_CONFIGURATION and there is not ROLLBACK"
                    exit 1
                else 
                   if [ -d \$DIR_BASE_TEMPORAL/${hoy}/${_ALMS_ID}/${_env}/DataModules/ ]
                   then
                        find \$DIR_BASE_TEMPORAL/${hoy}//${_ALMS_ID}/${_env}/DataModules/ -name "*.sql"  > /home/plataforma/plausr/tmp/ChequeoRollback_${_ALMS_ID}.${_env}.${_dateLog}.txt
                        NUMR=\$(cat /home/plataforma/plausr/tmp/ChequeoRollback_${_ALMS_ID}.${_env}.${_dateLog}.txt | wc -l)
                        echo "Number for rollback in date modules.... \${NUMR} ...."
                        
                         if   [ \${NUMR} -eq 0 ] 
                         then
                               if [ -d \$DIR_BASE_TEMPORAL/${hoy}/${_ALMS_ID}/${_env}/Annexes/ ]
                               then
                                    find \$DIR_BASE_TEMPORAL/${hoy}/${_ALMS_ID}/${_env}/Annexes/ -name "*.sql"  > /home/plataforma/plausr/tmp/ChequeoRollbackAn_${_ALMS_ID}.${_env}.${_dateLog}.txt
                                    NUMRA=\$(cat /home/plataforma/plausr/tmp/ChequeoRollbackAn_${_ALMS_ID}.${_env}.${_dateLog}.txt | wc -l)
                                    echo "Number for rollback in annexes.... \${NUMRA} ...."
                                    if   [ \${NUMRA} -eq 0 ] 
                                    then
                                        echo "ERROR There are DATA_CONFIGURATION and there is not ROLLBACK"
                                        exit 5
                                    fi
                                else 
                                    echo "ERROR There are DATA_CONFIGURATION and there is not ROLLBACK"
                                    exit 5
                                fi
                         fi
                    else
                     if [ -d \$DIR_BASE_TEMPORAL/${hoy}/${_ALMS_ID}/${_env}/Annexes/ ]
                        then
                            find \$DIR_BASE_TEMPORAL/${hoy}/${_ALMS_ID}/${_env}/Annexes/ -name "*.sql"  > /home/plataforma/plausr/tmp/ChequeoRollbackAn_${_ALMS_ID}.${_env}.${_dateLog}.txt
                            NUMRA=\$(cat /home/plataforma/plausr/tmp/ChequeoRollbackAn_${_ALMS_ID}.${_env}.${_dateLog}.txt | wc -l)
                            echo "Number for rollback in annexes.... \${NUMRA} ...."
                             if   [ \${NUMRA} -eq 0 ] 
                             then
                                    echo "ERROR There are DATA_CONFIGURATION and there is not ROLLBACK"
                                    exit 5
                             fi
                      fi
                   fi
                fi
            fi
        """
       
      try{
        // sh "ssh -q es036tvr '${execRe}'"
         sh "${execRe}"
      } catch(Exception e){
          //  echo "Fallo al ejecutar el execRe error: ${e}" 
            createReject (_ALMS_ID , "ERROR There are files DATA_CONFIGURATION and there is not ROLLBACK file","5")
            error ("ERROR There are files  DATA_CONFIGURATION and there is not ROLLBACK file")
      }
       
    }//Stage Revisar

    
}//nodo
    
