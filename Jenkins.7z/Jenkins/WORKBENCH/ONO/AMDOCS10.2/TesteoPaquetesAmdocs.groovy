#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def callFromWB=true
def pckInfo=null
_Entorno=""

if (PackageInfo==""){
    callFromWB=false  
}else{
    print(PackageInfo)
}

node ("es036tvr") {     
    stage ("GetUser"){
        wrap([$class: 'BuildUser']) {
        _usuario=env.BUILD_USER_ID
        }
    (_pass,_usuario)=findpassword(_usuario)
node("eswltbhr"){
    stage("ObtenerDatos"){
        if (callFromWB){
            pckInfo=readJSON(text: "${PackageInfo}")
            _Entorno=pckInfo['EnvironmentLabel'] 
        }
        else
        {
            _Entorno=params.ENTORNO
         }

node ("es1117yw"){
    stage ("Test"){
            wrap([$class: 'BuildUser']) {
                _User=env.BUILD_USER_ID
                }
        echo "Exec user: ${_User}"
        

        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
                bat "testAmdocsPackagesByEnvironment.py -u ${_usuario} -c ${_pass} -e  ${_Entorno}"
        }
    }
}
    }
}
    
    }//stage
} //nodo

