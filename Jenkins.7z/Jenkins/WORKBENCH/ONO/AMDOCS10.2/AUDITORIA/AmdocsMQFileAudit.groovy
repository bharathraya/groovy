#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def _ent=""
def _app=""
def _formatoHora=""

def hoy=new Date().format( 'yyyyMMdd' )


node("AMDOCS-DEPLOY"){
    stage("Prepare"){
                //Saco el ejecutor
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
                }
            
            print "La fecha de hoy es ......${hoy}......"
    
            // Parametros entrada
            _ent="SIT1"
            _app=params.APP
    
            currentBuild.displayName = "Aplicación a revisar: ${_app} Entorno: ${_ent} vs PROD " 
            currentBuild.description = "Aplicación a revisar: ${_app} Entorno: ${_ent} vs PROD " 
     
            print "Aplicación Elegida : ${_app}"
            print "Entorno contra el que se revisa: ${_ent}"
            
      }//stage
    
    stage("Auditoria"){
    
        print "Descargamos de pvcs versiones de PROD y SIT1 en es036tvr para compararlas y posteriormetne comparar PVCS de PROD con release de PROD" 
        print "  "
        
            execAudit="""
                . \$HOME/.profile >/dev/null 2>&1
                auditoria_versiones_upg_MQ.sh -d ${_app} -e ${_ent} 
                """            
            sh "${execAudit}"
            if    (iError==1)  
             {
                 error("No está igual en los entornos comparados revisar el fichero errores_MQ_NEPTUNO_SIT1_PROD.txt y errores_MQ_NEPTUNO_PRODREAL_PROD.txt")
             }
        }//Stage   
    
}//Nodo
  
