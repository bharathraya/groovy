#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def ENV1=""
def ENV2=""
def DELIVERY=""
def exec_preview=""

def hoy=new Date().format( 'yyyyMMdd' )

node("AMDOCS-PARCHE"){
    stage("Prepare"){

    //Saco el ejecutor
    wrap([$class: 'BuildUser']) {
          echo "Exec user: ${env.BUILD_USER_ID}"
          mybuilduser=env.BUILD_USER_ID
        }
            
    print "La fecha de hoy es ......${hoy}......"
    
    // Parametros entrada
    ENV1=params.ENV1
    ENV2=params.ENV2
    DELIVERY=params.DELIVERY.trim()

    currentBuild.displayName = "PREVIEW: ${ENV1} vs ${ENV2} " 
    currentBuild.description = "PREVIEW: ${ENV1} vs ${ENV2} " 
    print "Entorno 1: ${ENV1}"
    print "Entorno 2: ${ENV2}"
    
    if (ENV1 == ENV2)
        {
           error("No se puede elegir el mismo entorno.")
        }

}//Stage
   
   stage ("ESQUEMA-AUDIT"){
       print "*******************************************"
       print " Ejecutamos preview para ${ENV1} y ${ENV2} "
       print "*******************************************"
       
       execAudit="""
                . \$HOME/.profile_audit >/dev/null 2>&1
                install_schema_WB_audit -D ${DELIVERY} -o ${ENV1} -d ${ENV2} 
                """            
            sh "${execAudit}"

   } //stage
} //node
