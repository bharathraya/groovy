#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

_Fecha=params.DATE
_Commit=params.COMMIT

//final String REGEX_DATE= /d{4}-(0?[1-9]|1[1-2])-(3[01]|[12][0-9]|0?[1-9])/
final String REGEX_DATE= /\d{4}\-\d{2}\-\d{2}/

if (_Fecha == "" && _Commit == "")
{
  error ("Hay que pasar alguna de las opcion [ Fecha | Commit ]")
}

if (_Fecha != "" && _Commit != "")
{
  error ("Hay que pasar SOLO una de las opcion [ Fecha | Commit ]")
}

/*if(_Fecha ==~ REGEX_DATE)
{
  error ("${_Fecha} NO cumple el formato YYYY-MM-DD")
}*/
node ("es036tvr") {   
  stage ("extractPVCS"){
    wrap([$class: 'BuildUser']) {
      _User=env.BUILD_USER_ID
    }
    echo "Exec user: ${_User}"
   
    (_pass,_User)=findpassword(_User)
    currentBuild.displayName = "Ejecutado por ${_User} "

    sh ". \$HOME/.profile_ >/dev/null 2>&1;extractBBDD_PROD"
    }
} //nodo es036tvr

node ("eswltahr") {
  stage("extractLEGACY"){
    checkout scm
    if (_Fecha != "")
    {
        param="-f ${_Fecha}"
    }
    if (_Commit != "")
    {
        param="-c ${_Commit}"
    }
    dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
          try {
            bat "python3 get_BbCommitByDataOrCommit.py ${param}"
          }
          catch (Exception e){
            echo "ERROR: ${e}"
            error ("Fallo en la creacion del repositorio ${param}")
          }
    }
  }//stage createCDM
}//node eswltahr-DXL

     

