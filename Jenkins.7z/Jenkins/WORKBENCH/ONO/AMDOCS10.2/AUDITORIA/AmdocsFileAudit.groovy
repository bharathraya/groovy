#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def _ent=""
def _app=""
def _formatoHora=""

def hoy=new Date().format( 'yyyyMMdd' )


node("AMDOCS-DEPLOY"){
    stage("Prepare"){
                //Saco el ejecutor
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
                }
            
            print "La fecha de hoy es ......${hoy}......"
    
            // Parametros entrada
            _app=params.APP
            if (_app != "AMDOCS-UPSD" && _app != "AMDOCS-RULEMANAGER" && _app != "AMDOCS-CLARIFY" )    
            {
                _ent="SIT1"
            }
            else{
                _ent="PVCS"
            }

            currentBuild.displayName = "Aplicación a revisar: ${_app} Entorno: ${_ent} vs PROD " 
            currentBuild.description = "Aplicación a revisar: ${_app} Entorno: ${_ent} vs PROD " 
     
            print "Aplicación Elegida : ${_app}"
            print "Entorno contra el que se revisa: ${_ent}"
            
      }//stage
    
    stage("Auditoria"){
    
    
    if (_app != "AMDOCS-UPSD" && _app != "AMDOCS-RULEMANAGER" && _app != "AMDOCS-CLARIFY" )    
    {
       iError=0
            execCheck="""
            . \$HOME/.profile >/dev/null 2>&1
            check_deployment.sh -d ${_app} 
            """
        
        print "Revisamos que este igual en SPPR y PROD"
        try{
            sh "${execCheck}"
            } catch(Exception e){
                print "El artefacto en PROD está diferente que en SPPR"
                iError=1
            }
          print "Revisamos que este igual en SPPR y ${_ent}"
    }
    else
    {     iError=0
          print "Revisamos que este igual en PROD y ${_ent}"
    }
     
            execAudit="""
                . \$HOME/.profile >/dev/null 2>&1
                auditoria_versiones_upg.sh -d ${_app} -e ${_ent} 
                """            
            sh "${execAudit}"
            if    (iError==1)  
             {
                 error("No está SPPR como PROD")
             }
        }//Stage   
    
}//Nodo
  
