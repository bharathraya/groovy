#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def _ent1=""
def _ent2=""
def _serverPROD=""
def _formatoHora=""

def hoy=new Date().format( 'yyyyMMdd' )

_formatoHora = new Date().format("yyyyMMddHHmmss")
print "FormatoHora: ${_formatoHora}"
    

_serverPROD="devopsprdtools01"

node("AMDOCS-PARCHE"){
    stage("Prepare"){
                //Saco el ejecutor
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
                }
            
            print "La fecha de hoy es ......${hoy}......"
    
            // Parametros entrada
            _ent1=params.Ent1
            _ent2=params.Ent2
    
            currentBuild.displayName = "Entornos a revisar: ${_ent1} vs: ${_ent2} " 
            currentBuild.description = "Entornos a revisar: ${_ent1} vs: ${_ent2} " 
     
            print "Entorno 1: ${_ent1}"
            print "Entorno 2: ${_ent2}"
            
            if (_ent1 == _ent2)
            {
                error("No se puede elegir el mismo entorno.")
            }

      }//stage
    
    stage("ObtenerObjetos${_ent1}"){
            execCopy="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_ent1} 
                cd ..
                scp -r ${_serverPROD}:/home/plataforma/plausr/data/paquetes/${hoy}/${_ent1} .
                . paquete ${_ent1}_VISTAS
                cd ..
                scp -r ${_serverPROD}:/home/plataforma/plausr/data/paquetes/${hoy}/${_ent1}_VISTAS .
                """            
     
             
            print "Se va a obtener los datos de BBDD del primer entorno: ${_ent1}"
             
            execBBDD="""
                    . \$HOME/.profile >/dev/null 2>&1
                    get_PLv3 ${_ent1}
                    """
            execVistas="""
                    . \$HOME/.profile >/dev/null 2>&1
                    getVistas ${_ent1}
                    """    
                        
             if (_ent1 != "PGA1_BAS"  )
             {
                  sh "${execBBDD}"
                  sh "${execVistas}"
             }
             else
             {
                 sh "ssh -q ${_serverPROD} '${execBBDD}'"
                 sh "ssh -q ${_serverPROD} '${execVistas}'"
                 print "Se va a obtener los datos de la BBDD ${_ent1} a la máquina devopststtools01 "
                 sh "${execCopy}"
             }
        }//Stage 1   
    stage("ObtenerObjetos${_ent2}"){
            execCopy2="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_ent1} 
                cd ..
                scp -r ${_serverPROD}:/home/plataforma/plausr/data/paquetes/${hoy}/${_ent1} .
                . paquete ${_ent1}_VISTAS
                cd ..
                scp -r ${_serverPROD}:/home/plataforma/plausr/data/paquetes/${hoy}/${_ent1}_VISTAS .
                """          
                
            print "Se va a obtener los datos de BBDD del segundo entorno: ${_ent2}"
             
            execBBDD2="""
                    . \$HOME/.profile >/dev/null 2>&1
                    get_PLv3 ${_ent2}
                    """
            execVistas2="""
                    . \$HOME/.profile >/dev/null 2>&1
                    getVistas ${_ent2}
                    """    
                            
             if (_ent2 != "PGA1_BAS"  )
             {
               sh "${execBBDD2}"
               sh "${execVistas2}"
             }
             else
             {
                sh "ssh -q ${_serverPROD} '${execBBDD2}'"
                sh "ssh -q ${_serverPROD} '${execVistas2}'"
                 
                print "Se va a obtener los datos de la BBDD ${_ent2} a la máquina devopststtools01 "
                sh "${execCopy2}"
                 
             }
        }//stage
        
    
    stage("ComparacionBBDD"){
        
         execComp="""
            . \$HOME/.profile >/dev/null 2>&1
            . paquete Comparar_${ent1}_${ent2}_${_formatoHora}
            cd ..
            scp -r ${ent1}/* Comparar_${ent1}_${ent2}_${_formatoHora}
            scp -r ${ent2}/* Comparar_${ent1}_${ent2}_${_formatoHora}
            scp -r ${ent1}_VISTAS/* Comparar_${ent1}_${ent2}_${_formatoHora}
            scp -r ${ent2}_VISTAS/* Comparar_${ent1}_${ent2}_${_formatoHora}
            """
                
         sh "${execComp}"  
         
         Lista="SA BTS DW HISTORICO INTERNET MQM RECOBROS USR_CONSULTA_RED"
         ListaS=Lista.split(" ")
         for (pos = 0; pos < ListaS.size(); pos++) {
            esq=ListaS[pos]
            print "Esquema a analizar ${esq}"
            execDiff=""
            execDiff="""
            . \$HOME/.profile >/dev/null 2>&1
            . paquete Comparar_${ent1}_${ent2}_${_formatoHora}
                diff_folders ${esq}_${ent1}  ${esq}_${ent2}  ${esq}
                diff_folders ${esq}_${ent2}  ${esq}_${ent1}  ${esq}
                diff_folders ${esq}_${ent2}_VISTAS  ${esq}_${ent1}_VISTAS ${esq}
                diff_folders ${esq}_${ent1}_VISTAS  ${esq}_${ent2}_VISTAS ${esq}
                if [ -f errores_${esq}_${ent1}_${esq}_${ent2}.txt -a -f errores_${esq}_${ent2}_${esq}_${ent1}.txt ]
                then
                    getErrors errores_${esq}_${ent1}_${esq}_${ent2}.txt errores_${esq}_${ent2}_${esq}_${ent1}.txt O
                fi 
                if [ -f errores_${esq}_${ent1}_VISTAS_${esq}_${ent2}_VISTAS.txt -a -f errores_${esq}_${ent2}_VISTAS_${esq}_${ent1}_VISTAS.txt ]
                then
                    getErrors errores_${esq}_${ent1}_VISTAS_${esq}_${ent2}_VISTAS.txt errores_${esq}_${ent2}_VISTAS_${esq}_${ent1}_VISTAS.txt V
                fi   
            """
            sh "${execDiff}"  
         }
         
          
    }//stage
}//Nodo
  
