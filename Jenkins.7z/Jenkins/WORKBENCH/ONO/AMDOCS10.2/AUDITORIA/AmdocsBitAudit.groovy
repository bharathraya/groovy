#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def _ent=""
def _app=""
def _formatoHora=""

def hoy=new Date().format( 'yyyyMMdd' )

node("AMDOCS-DEPLOY"){
    stage("Prepare"){
                //Saco el ejecutor
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
                }
            (_pass,mybuilduser)=findpassword(mybuilduser)
            print "La fecha de hoy es ......${hoy}......"
    
            // Parametros entrada
            _ent="SIT1"
            _app=params.APP
           // _commit=params.COMMIT
            currentBuild.displayName = "Aplicación a revisar: ${_app} Entorno: ${_ent} vs PROD " 
            currentBuild.description = "Aplicación a revisar: ${_app} Entorno: ${_ent} vs PROD " 
     
            print "Aplicación Elegida : ${_app}"
            print "Entorno contra el que se revisa: ${_ent}"
            
      }//stage
    
    stage("Auditoria"){
        iError=0
            execCheck="""
            . \$HOME/.profile >/dev/null 2>&1
            check_deployment.sh -d ${_app} 
            """
        
        print "Revisamos que este igual en sppr y PROD"
        try{
            sh "${execCheck}"
            } catch(Exception e){
                print "El artefacto en PROD está diferente que en SPPR"
                iError=1
            }
                          
        print "Revisamos que contenido de SIT1 esta en master"
        
       if (_app == "AMDOCS-SERVER")
       {
            _repo="ISA-AMDOCS-java-smartserver"
       }
       else if (_app =="AMDOCS-CLIENT")
       {
            _repo="ISA-AMDOCS-java-smartclient"
       }
       else if (_app =="AMDOCS-BPM_APM")
       {
            _repo="ISA-AMDOCS-apm-bpm"
       }
       else if (_app =="AMDOCS-IntegracionTOA")
       {
            _repo="ISA-AMDOCS-java-integracionTOA"
       }
       else if (_app =="AMDOCS-SCRIPTS-BPM")
       {
            _repo="ISA-AMDOCS-scripts-bpm"
       }
       else if (_app =="AMDOCS-IntegracionPermanencias")
       {
            _repo="ISA-AMDOCS-java-integracionPermanencias"
       }
       
        _proyect="ISA-AMDOCS"
        _SourceDest="master"
        _SourceOri="vodafone/SIT1"

        print "Proyecto: ${_proyect}"
        print "Repo: ${_repo}"
        print "Rama Origen: ${_SourceOri}"
        print "Rama Destino: ${_SourceDest}"
       _nombreCarpeta ="_app"
       print "lanzamos checkContent checkContent(${_repo},${_proyect},${_SourceDest},'',${_SourceOri},${_app}),mybuilduser,_pass"
    try{
             wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                checkContent(_repo,"ISA-AMDOCS",_SourceDest,"",_SourceOri,_app,mybuilduser,_pass)
             }
      } catch(Exception e){
                            print "No está el contenido de master en SIT1"
                           if (iError==1)
                            {
                                iError=3
                            }
                            else
                            {
                                iError=2
                            }
                        
                          }
                          
     print "lanzamos checkContent checkContent(${_repo},${_proyect},${_SourceOri},'',${_SourceDest},${_app}),mybuilduser,_pass"
      try{
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                checkContent(_repo,"ISA-AMDOCS",_SourceOri,"",_SourceDest,_app,mybuilduser,_pass)
            }
      } catch(Exception e){
                            print "No está el contenido de SIT1 en master"
                           if (iError==1)
                            {
                                iError=4
                            }
                            else if (iError==3)
                            {
                                iError=5
                            }
                            else
                             {
                                iError=6
                            }
                        
                          }
        
        
         execComparar="""
            . \$HOME/.profile >/dev/null 2>&1
            compara_ramas_upgrade.sh  -e master -o SIT1 -d ${_app}
            """

       // sh "ssh -q devopststtools01 '${execComparar}'"
         sh "${execComparar}"
         
         RutaPaquete="/home/plataforma/plausr/data/paquetes/${hoy}/${_app}_master_SIT1"
         sh "touch -f ${RutaPaquete}/errores_master_SIT1.txt"
         sh "touch -f ${RutaPaquete}/get_diff_master_SIT1.txt"
         _Errores = readFile(file: "${RutaPaquete}/errores_master_SIT1.txt")
         _Diferencias = readFile(file: "${RutaPaquete}/get_diff_master_SIT1.txt")
         
         if ( _Errores != "")
         {
             print "***************************************"
             print "Hay diferencias entre master y SIT1"
             print "${_Errores}"
             print "***************************************"
             print "Estas son las diferencias"
             print "${_Diferencias}"
             print "***************************************"
         }

        if (iError == 1)
        {
                error("El artefacto no está igual en SPPR que en PROD")
        }
        else if (iError == 2)
        {
                error("El contenido de master no está en SIT1")
        }
        else if (iError == 3)
        {
                error("El contenido de master no está en SIT1 y el artefacto está diferente en PROD y SPPR")
        }
        else if (iError == 4)
        {
                error("El artefacto no está igual en SPPR que en PROD y el contenido de SIT1  no está en master")
        }
        else if (iError == 5)
        {
                error("El artefacto no está igual en SPPR que en PROD y el contenido de SIT1  no está en master ni el de master en SIT1")
        }
        else if (iError == 6)
        {
                error("El contenido de SIT1  no está en master")
        }
            
      }//Stage   
    
}//Nodo
  

