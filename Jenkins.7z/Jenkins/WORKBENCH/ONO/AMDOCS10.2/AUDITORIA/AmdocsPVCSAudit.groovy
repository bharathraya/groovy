#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def _ent1=""
def _ent2=""
def _app=""
def exec=""

def hoy=new Date().format( 'yyyyMMdd' )

node("es036tvr"){
    stage("Prepare"){
                //Saco el ejecutor
                 wrap([$class: 'BuildUser']) {
                    echo "Exec user: ${env.BUILD_USER_ID}"
                    mybuilduser=env.BUILD_USER_ID
                }
            
            print "La fecha de hoy es ......${hoy}......"
    
            // Parametros entrada
            _ent1=params.Ent1
            _ent2=params.Ent2
            _app=params.APP
    
            currentBuild.displayName = "Entornos a revisar: ${_ent1} vs: ${_ent2} en la aplicación ${_app}" 
            currentBuild.description = "Entornos a revisar: ${_ent1} vs: ${_ent2} en la aplicación ${_app}" 
     
            print "Aplicación a revisar: ${_app}"
            print "Entorno 1: ${_ent1}"
            print "Entorno 2: ${_ent2}"
            
            if (_ent1 == _ent2)
            {
                error("No se puede elegir el mismo entorno.")
            }

      }//stage
    
    stage("SacarDatosPVCS"){
            exec="""
                . \$HOME/.profile_jenkins >/dev/null 2>&1  
                InformeVersiones2 -o ${_ent1} -d ${_ent2} -a ${_app}
            """            
          
          if (_app != "BIZTALK-IIS")
          {
              sh "${exec}"
          }     
         //   getAmdocs102ModulePackageDelivery(mybuilduser, _ent1 , _ent2,_app)
        }//stage 
}//Nodo
