import vfes.utils.VFESALMSDataRetriever

def execute(VFESALMSDataRetriever alms){
        
    def _HayModulosPvcs=alms.myHayPvcs
    def _domain=alms.mydomain
    def _HayModulosDatos=alms.mydataModules.size()
    def _env=alms.mydeployEnv
    def _ALMS_ID=alms.myalmsID
    def _server=alms.myserver
    def _WBCalled=alms.mywbCalled
    def _paquete=alms.mylistapaquetes
    _date=new Date().format( 'yyyyMMdd' )
    
     if(_HayModulosPvcs != "0"){
        echo "Hay módulos de pvcs ${_HayModulosPvcs}"
        echo "entorno ${_env}"
        echo "WB_ID ${_ALMS_ID}"
        echo "Aplicacion ${_domain}"
        
        if(_HayModulosDatos!= 0)
            {        
                echo "Hay módulos de datos ${_HayModulosDatos}"   
                if (_WBCalled == false)
                {    print "Es manual, lanzo el replica_datos para los nombres"
                    // print "${_WBCalled} valor de WB"
                     replica_datos("-o",_domain,_env,_ALMS_ID,_paquete)
                }
                
                 
                execMo="""
                . \$HOME/.profile >/dev/null 2>&1

                export ruta_temp=\$DIR_BASE_TEMPORAL/${_date}/${_ALMS_ID}/${_env}
                export ruta_nueva=\$DIR_BASE_TMP_COMP/${_date}/${_ALMS_ID}
                if [ -d \${ruta_nueva} ] 
                then
                    rmdir  \${ruta_nueva}
                fi
                mkdir -p \${ruta_nueva}
                
                if [ -f \${ruta_temp}/DataModules/orden_pre.txt ] 
                then
                    cp \${ruta_temp}/DataModules/orden_pre.txt \${ruta_nueva}/orden_pre.txt 
                fi
                if [ -f \${ruta_temp}/DataModules/orden_post.txt ] 
                then
                    cp \${ruta_temp}/DataModules/orden_post.txt \${ruta_nueva}/orden_post.txt 
                fi
                if [ -f \${ruta_temp}/DataModules/orden.txt ] 
                then
                    cp \${ruta_temp}/DataModules/orden.txt \${ruta_nueva}/orden.txt 
                fi
                
                """
                
                sh "ssh -q es036tvr '${execMo}'"
                
            }//Fin de modulos de datos

            exec="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_ALMS_ID}
                install_schema_WB -W -d ${_domain} -e  ${_env} -p ${_ALMS_ID} ${_ALMS_ID} 

                """
              //  install_schema_WB -W -d ${_domain} -e  ${_env} -p ${_ALMS_ID} ${_ALMS_ID} 
            if (_server !="")
            {
                    sh "ssh -q ${_server} '${exec}'"
            }
            else
            {
                    sh "${exec}"
            }

    

      }//if de si existen modulos
}//execute


return this
