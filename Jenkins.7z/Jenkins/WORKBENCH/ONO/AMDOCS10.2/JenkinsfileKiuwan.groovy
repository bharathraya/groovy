#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _


PVCSPipelineTemplateKiuwan([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml',kiuwanConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/kiuwanConfig.yml',
    applicationChoices:["AMDOCS-BBDD","AMDOCS-CAB","AMDOCS-AIF","MQ_NEPTUNO","AMDOCS-CLIENT","AMDOCS-SERVER","AMDOCS-MAESTRAS","AMDOCS-BPM_APM","AMDOCS-UPSD","AMDOCS-ESQUEMA","AMDOCS-PREVIEW","AMDOCS-CLARIFY","AMDOCS-ProcessManager","APM","APM-SMS_Resumen_Compra","AMDOCS-SPM","AMDOCS-PM","AMDOCS-FORMS","AMDOCS-CBS","AMDOCS-PROCESOS","MQ_BRK","MQ-BBDD-BROKER"],
	 environmentChoices:["KIUWAN","TST","TST1","SIT1","SIT2","PPRD","PPRD1","PROD"]])
