#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

VentanaOnoPipelineUpgrade([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/pipelineConfig.yml', 
environmentChoices:["SIT1","PPRD"] , Optionvista:["YES","NO"], OptionPaquetes:["YES","NO"]])

