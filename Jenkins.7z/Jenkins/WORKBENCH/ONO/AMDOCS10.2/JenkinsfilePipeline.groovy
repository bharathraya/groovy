#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/pipelineConfig.yml',
    applicationChoices:["AMDOCS-AIF","AMDOCS-BBDD","AMDOCS-BusinessRules","AMDOCS-CAB","AMDOCS-CONTRATOS","AMDOCS-PlantillasPDF","AMDOCS-PlantillasTOA","MQ_NEPTUNO","AMDOCS-UPSD","AMDOCS-ESQUEMA","AMDOCS-PREVIEW","AMDOCS-CLARIFY","AMDOCS-RULEMANAGER","AMDOCS-SMS","AMDOCS-SPM"],
	 environmentChoices:["TST","TST1","SIT1","SIT2","SIT3","PPRD","PPRD1","PROD"]])
