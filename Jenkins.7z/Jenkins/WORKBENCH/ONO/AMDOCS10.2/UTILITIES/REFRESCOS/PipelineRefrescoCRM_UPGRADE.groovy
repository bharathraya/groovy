#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def _date1=new Date().format( 'yyyyMMdd' )
def myenv=params.ENV
def myenv2=params.ENV2
def myapp=params.APP
def mybbdd=params.BBDD
def SPPR="/home/amdocs_sppr/opt/amdocs/crm"    
def VariableSCPBoolean = true
def VariableALL = false
def VariableALL_EXCEPT = false
def act_pvcs_svn = false
def act_pvcs_bit = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Refresh: ${myapp} ${myenv}"
    currentBuild.description = "Refresh: ${myapp} ${myenv}"

if ( "${myenv}" == "${myenv2}" ) {
    println("ENV OK")
} else {
    println("ERROR, REVIEW, ENV and ENV2 are not the same")
    return 33;
}

if ( "${myapp}" == "ALL" ) {
VariableALL = "true"
}

if ( "${myenv}" == "TST" ) {
  myenv = "TST4"
}

if ( "${myenv}" == "SIT1" ) {
  myenv = "TST2"
}

if ( "${myenv}" == "SIT2" ) {
  myenv = "TST5"
}

if ( "${myenv}" == "PPRD" ) {
  myenv = "TST3"
}

if ( "${myenv}" == "SIT3" ) {
  myenv = "TST6"
}

if ( "${myenv}" == "FOR" ) {
  myenv = "TST7"
}

if ( "${myenv}" == "PET" ) {
  myenv = "PET"
}

if ( "${myapp}" == "ACT_PVCS_BIT" || "${myapp}" == "ALL" ) {
        if ( "${myenv}" == "TST1" || "${myenv}" == "TST2" || "${myenv}" == "TST3" || "${myenv}" == "TST4" || "${myenv}" == "TST5" || "${myenv}" == "TST6" || "${myenv}" == "PET" ) {
                    act_pvcs_bit = "true"
        } //if
    else
        {
        act_pvcs_bit = "false"
        }
}

// ********************* for post refresh  bbdd activity" ***************************
if ( "${mybbdd}" == "YES" ) {
node ("devopststtools01") {       
   stage ("PostRefresco_BBDD"){
        print "*************************************************"
        print " PostRefrescoBBDD_${myenv} "
        print "*************************************************"
        exec_PostRefreshBBDD="""
        if [ -f /home/plataforma/plausr/refresh/despues_refresco.sh ]
        then  
            /home/plataforma/plausr/refresh/despues_refresco.sh MANMTO_CM MANMTO_CM77 ${myenv}  
        	SUCCESS=`grep "Post-refresh acitivity finished OK" /home/plataforma/plausr/refresh/${myenv}/log/post_refresh_${myenv}_${_date1}.log`
            if [ ! -z "\${SUCCESS}" ]
	        then
        	    echo "Post activity BBDD task finished OK"
            else
        	    echo "Post activity BBDD task finished ERROR"
                exit 56
	        fi            
        else
            echo "Script to do post activity refresh BBDD not found"
            exit 57
        fi    
        """
        sh "ssh -q platafor@crm50tst02 '${exec_PostRefreshBBDD}'" 
} //stage
} //node
}
// ********************* END for post refresh  bbdd activity" ***************************

if ( "${myapp}" == "SMS" || "${myapp}" == "ALL" ) {
myapp = "SMS"

  node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage
} //node
  
if ( "${myapp}" == "SMS" ){

node ("devopststtools01") {       
   stage ("Refesco_SMS"){

        print "*****************************************************************************"
        print " Backup for UploadWSDocumentum.java y class for environment ${myenv} "
        print "*****************************************************************************"
        exec_backup_SMS="""
        if [ -f ${Path_ENV}/java/UploadWSDocumentum.java ]
        then
            mv ${Path_ENV}/java/UploadWSDocumentum.java ${Path_ENV}/java/UploadWSDocumentum.java_${_date}
                    if [ -f ${Path_ENV}/java/UploadWSDocumentum.java_${_date} ]
        			then
            			echo "Backup java OK"
        			else
            			echo "Error in backup of java"
            			exit 55
        			fi
        else
            echo "There is not ${Path_ENV}/java/UploadWSDocumentum.java we don´t do backup"
        fi     
        
        if [ -f ${Path_ENV}/java/UploadWSDocumentum.class ]
        then
            mv ${Path_ENV}/java/UploadWSDocumentum.class ${Path_ENV}/java/UploadWSDocumentum.class_${_date}
                    if [ -f ${Path_ENV}/java/UploadWSDocumentum.class_${_date} ]
        			then
            			echo "Backup class OK"
        			else
            			echo "Error in backup of class"
            			exit 55
        			fi    
        else
            echo "There is not ${Path_ENV}/java/UploadWSDocumentum.class we don´t do backup"
        fi
        """
        sh "ssh -q weblogic@${Machine_ENV} '${exec_backup_SMS}'" //weblogic


		print "*********************************************************************"
        print "We copy  UploadWSDocumentum.java and class for environment ${myenv} "
        print "*********************************************************************"
        exec_copia_SMS="""
        scp platafor@crm50tst07:/home/amdocs_sppr/release/APM/SMS_Resumen_Compra/project/src/UploadWSDocumentum.java ${Path_ENV}/java
        if [ -f ${Path_ENV}/java/UploadWSDocumentum.java ]
        then
            echo "Copy OK"
        else
            echo "Error in the copy of jar of UploadWSDocumentum.java"
            exit 56
        fi
        scp platafor@crm50tst07:/home/amdocs_sppr/release/APM/SMS_Resumen_Compra/compiled/classes/UploadWSDocumentum.class ${Path_ENV}/java
        if [ -f ${Path_ENV}/java/UploadWSDocumentum.class ]
        then
            echo "Copy OK"
        else
            echo "Error in the copy of jar for UploadWSDocumentum.class"
            exit 56
        fi  
        """
        sh "ssh -q weblogic@${Machine_ENV} '${exec_copia_SMS}'" //weblogic

} //stage
} //node

} //if
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

} //if

if ( "${myapp}" == "CONTRATOS" || "${myapp}" == "ALL" ) {
myapp = "CONTRATOS"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node

if ( "${myapp}" == "CONTRATOS" ){

node ("devopststtools01") {       
   stage ("Refesco_CONTRATOS"){

        print "********************************************************************"
        print " Backup for  impresionContratos.jar for Environment ${myenv} "
        print "********************************************************************"
        exec_backup_CONTRATOS="""
        if [ -f ${Path_ENV}/impresionContratos.jar ]
        then
        	mv ${Path_ENV}/impresionContratos.jar ${Path_ENV}/impresionContratos.jar_${_date}
                    if [ -f ${Path_ENV}/impresionContratos.jar_${_date} ]
        			then
            			echo "Backup OK"
        			else
            			echo "Error in backup"
            			exit 55
        			fi    
        else
            echo "There is not ${Path_ENV}/impresionContratos.jar, we don´t do backup"
        fi
        """
        sh "ssh -q apmadm@${Machine_ENV} '${exec_backup_CONTRATOS}'" //apmadm


		print "************************************************************"
        print "Copy  impresionContratos.jar for Environment ${myenv} "
        print "************************************************************"
        exec_copia_CONTRATOS="""
        scp platafor@crm50tst07:/home/amdocs_sppr/release/APM/impresionContratos/compiled/jar/impresionContratos.jar ${Path_ENV}
        if [ -f ${Path_ENV}/impresionContratos.jar ]
        then
            echo "Copy OK"
        else
            echo "Error in copy for jar of impresionContratos"
            exit 56
        fi    
        """
        sh "ssh -q apmadm@${Machine_ENV} '${exec_copia_CONTRATOS}'" //apmadm

} //stage
} //node

} //if
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

} //if

if ( "${myapp}" == "AIF" || "${myapp}" == "ALL" ) {
myapp = "AIF"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node

if ( "${myapp}" == "AIF" ){

node ("devopststtools01") {       
   stage ("Refesco_AIF"){

        print "*******************************************************************************************************"
        print " Backup CustInterfacesAIF.sar, CustProcesses.par y CustScripts.par for environment ${myenv} "
        print "*******************************************************************************************************"
        exec_backup_AIF_PAR="""
        if [ -f ${Path_ENV}/sar/cust/CustInterfacesAIF.sar ]
        then
            mv ${Path_ENV}/sar/cust/CustInterfacesAIF.sar ${Path_ENV}/sar/cust/CustInterfacesAIF.sar_${_date}
                    if [ -f ${Path_ENV}/sar/cust/CustInterfacesAIF.sar_${_date} ]
        			then
            			echo "Backup OK"
        			else
            			echo "Error in backup de CustInterfacesAIF.sar"
            			exit 55
          			fi    
        else
            echo "There is not ${Path_ENV}/sar/cust/CustInterfacesAIF.sar we don´t do"
        fi
        
        if [ -f ${Path_ENV}/par/CustProcesses.par ]
        then
            mv ${Path_ENV}/par/CustProcesses.par ${Path_ENV}/par/CustProcesses.par_${_date}
                    if [ -f ${Path_ENV}/par/CustProcesses.par_${_date} ]
        			then
            			echo "Backup OK"
        			else
            			echo "Error in backup for CustProcesses.par"
            			exit 55
          			fi    
        else
            echo "There is not ${Path_ENV}/par/CustProcesses.par we don´t do"
        fi        
        
         if [ -f ${Path_ENV}/par/CustScripts.par ]
        then
            mv ${Path_ENV}/par/CustScripts.par ${Path_ENV}/par/CustScripts.par_${_date}
                    if [ -f ${Path_ENV}/par/CustScripts.par_${_date} ]
        			then
            			echo "Backup OK"
        			else
            			echo "Error in backup for CustScripts.par"
            			exit 55
          			fi    
        else
            echo "There is not ${Path_ENV}/par/CustScripts.par we don´t do"
        fi          
        
        """
        sh "ssh -q srvadm@${Machine_ENV} '${exec_backup_AIF_PAR}'" //srvadm


		print "***************************************************************************************************"
        print "We copy CustInterfacesAIF.sar, CustInterfacesAIF.par y CustProcesses.par for environment ${myenv} "
        print "***************************************************************************************************"
        exec_copia_AIF_PAR="""
        scp platafor@crm50tst07:/home/amdocs_sppr/opt/amdocs/crm/sar/cust/CustInterfacesAIF.sar ${Path_ENV}/sar/cust
        scp platafor@crm50tst07:/home/amdocs_sppr/opt/amdocs/crm/par/CustScripts.par ${Path_ENV}/par
     	scp platafor@crm50tst07:/home/amdocs_sppr/opt/amdocs/crm/par/CustProcesses.par ${Path_ENV}/par
        if [ -f ${Path_ENV}/sar/cust/CustInterfacesAIF.sar ]
        then
            echo "Copy OK"
        else
            echo "Error copying sar of AIF"
            exit 56
        fi        
        if [ -f ${Path_ENV}/par/CustScripts.par ]
        then
            echo "Copy OK"
        else
            echo "Error copying  par CustScripts.par"
            exit 56
        fi        
        if [ -f ${Path_ENV}/par/CustProcesses.par ]
        then
            echo "Copy OK"
        else
            echo "Error copying par CustProcesses.par"
            exit 56
        fi
        
        """
        sh "ssh -q srvadm@${Machine_ENV} '${exec_copia_AIF_PAR}'" //srvadm
} //stage
} //node

} //if
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

} //if

if ( "${myapp}" == "CAB" || "${myapp}" == "ALL" ) {
myapp = "CAB"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node

if ( "${myapp}" == "CAB" ){
node ("devopststtools01") {       
stage ("Parada_PM_1"){

        print "*****************************************"
        print " We sotp APM de ${myenv}                 "
        print "*****************************************"
        exec_parar_PM_1="""
        cd ${Path_ENV_RS}
        ./Parar_APM.sh 2>/dev/null
        """
        print (exec_parar_PM_1)
        sh "ssh -q apmadm@${Machine_ENV} '${exec_parar_PM_1}'" //apmadm

    } //stage
} //node
node ("devopststtools01") {       
   stage ("Refesco_CAB"){

        print "*************************************************"
        print " Backup del CAB for environment ${myenv} "
        print "*************************************************"
        exec_backup_CAB="""
        if [ -f ${Path_ENV}/CrmCustLibrary.ear ]
        then
            mv ${Path_ENV}/CrmCustLibrary.ear ${Path_ENV}/CrmCustLibrary.ear_${_date}
                    if [ -f ${Path_ENV}/CrmCustLibrary.ear_${_date} ]
        			then
            			echo "Backup OK"
        			else
            			echo "Error in backup"
            			exit 55
        			fi    
        else
            echo "There is not ${Path_ENV}/CrmCustLibrary.ear,we don´t do"
        fi    
        """
        sh "ssh -q srvadm@${Machine_ENV} '${exec_backup_CAB}'" //srvadm


		print "****************************************"
        print "Copy CAB for environment ${myenv} "
        print "****************************************"
        exec_copia_CAB="""
        scp platafor@crm50tst07:${SPPR}/shared_libraries/CrmCustLibrary.ear ${Path_ENV}
        if [ -f ${Path_ENV}/CrmCustLibrary.ear ]
        then
            echo "Copy OK"
        else
            echo "Error copying jar CAB"
            exit 56
        fi    
        """
        sh "ssh -q srvadm@${Machine_ENV} '${exec_copia_CAB}'" //srvadm

} //stage
} //node

node ("devopststtools01") {       
   stage ("Arranque_PM_1"){

        print "*************************************************"
        print " Start PM de ${myenv}                       "
        print "*************************************************"
        exec_arrancar_PM_1="""
        cd ${Path_ENV_RS}
        ./Arranca_APM.sh 2>/dev/null
        """
        print (exec_arrancar_PM_1)
        sh "ssh -q apmadm@${Machine_ENV} '${exec_arrancar_PM_1}'" //apmadm

    } //stage
} //node
} //if
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

} //if


if ( "${myapp}" == "SERVER" || "${myapp}" == "ALL" ) {
myapp = "SERVER"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node


if ( "${myapp}" == "SERVER" ) {

node ("devopststtools01") {       
    stage ("Parada_SERVER_0_1"){

        print "*************************************************"
        print " Stop SERVER de ${myenv}                      "
        print "*************************************************"
        exec_parar_SERVER_0_1="""
        . ./.profile 2>/dev/null
        cd ${Path_ENV_RS}
        ./stop_Server.sh 2>/dev/null
        """
        print (exec_parar_SERVER_0_1)
        sh "ssh -q srvadm@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //srvadm
    } //stage

} //node

node ("devopststtools01"){

    stage ("Refresco_SERVER"){

        print "*********************************************************"
        print "Copying CrmCustLibrary.ear of SMART SERVER for ${myenv}"
        print "*********************************************************"
        exec_copia_SERVER_0="""
            echo "Doing backup of CrmCustLibrary.ear"
            cd ${Path_ENV}
            cp CrmCustLibrary.ear CrmCustLibrary.ear_${_date}
            if [ -f CrmCustLibrary.ear_${_date} ]
            then
                    echo "Backup OK"
            else
                    echo "Backup KO"
                    exit 3
            fi
            echo "Copying from crm50tst07 CrmCustLibrary.ear"
            scp platafor@crm50tst07:/home/amdocs_sppr/opt/amdocs/crm/shared_libraries/CrmCustLibrary.ear ${Path_ENV}
            if [ -f ${Path_ENV}/CrmCustLibrary.ear ]
                then
                    echo "Copy OK"
                else
                    echo "Error copying , check"
                    exit 56
            fi
        """
        sh "ssh -q srvadm@${Machine_ENV} '${exec_copia_SERVER_0}'" //srvadm
} //stage
} //node
// Arranque SERVER
node ("devopststtools01") {       
    stage ("Arranque_SERVER_0_1"){

        print "*************************************************"
        print " Start SERVER for ${myenv}                   "
        print "*************************************************"
        exec_arrancar_SERVER_0_1="""
        . ./.profile 2>/dev/null
        cd ${Path_ENV_RS}
        ./start_Server.sh 2>/dev/null
        """
        print (exec_arrancar_SERVER_0_1)
        sh "ssh -q srvadm@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //srvadm
    } //stage

} //node
} //if

if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

} //if

/*
if ( "${myapp}" == "TOA" || "${myapp}" == "ALL" ) {
myapp = "TOA"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node

if ( "${myapp}" == "TOA" ){

node ("devopststtools01") {       
   stage ("Refesco_TOA"){

        print "****************************************************************"
        print " Backup for  IntegracionTOA.ear for environment ${myenv} "
        print "****************************************************************"
        exec_backup_TOA="""
        if [ -f ${Path_ENV}/IntegracionTOA.ear ]
        then
        	mv ${Path_ENV}/IntegracionTOA.ear ${Path_ENV}/IntegracionTOA.ear_${_date}
        	if [ -f ${Path_ENV}/IntegracionTOA.ear_${_date} ]
        		then
            			echo "Backup OK"
        		else
            		echo "Error in backup"
            		exit 55
        		fi    
        else
            echo "There is not ${Path_ENV}/IntegracionTOA.ear we don´t do backup"
        fi
        """
        sh "ssh -q srvadm@${Machine_ENV} '${exec_backup_TOA}'" //srvadm


		print "********************************************************"
        print "Copy  IntegracionTOA.ear for environment ${myenv} "
        print "********************************************************"
        exec_copia_TOA="""
        scp platafor@crm50tst07:/home/amdocs_sppr/opt/amdocs/crm/shared_libraries/IntegracionTOA.ear ${Path_ENV}
        if [ -f ${Path_ENV}/IntegracionTOA.ear ]
        then
            echo "Copy OK"
        else
            echo "Error copying the ear of TOA"
            exit 56
        fi    
        """
        sh "ssh -q srvadm@${Machine_ENV} '${exec_copia_TOA}'" //srvadm

} //stage
} //node

} //if

if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

} //if
*/

if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
myapp = "CLIENT"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node

node ("devopststtools01") {       
    stage ("Parada_CLIENT_0_1"){

        print "*************************************************"
        print " Stop CLIENT de ${myenv}                      "
        print "*************************************************"
        exec_parar_CLIENT_0_1="""
        . ./.profile 2>/dev/null
        cd ${Path_ENV_RS}
        ./stop_JNLP.sh 2>/dev/null
        """
        print (exec_parar_CLIENT_0_1)
        sh "ssh -q uifadm@${Machine_ENV} '${exec_parar_CLIENT_0_1}'" //uifadm
    } //stage

} //node

node ("devopststtools01"){

    stage ("Refresco_CLIENT"){

        print "****************************************************"
        print "Copy AmdocsCRM.ear of SMART CLIENT for ${myenv}"
        print "****************************************************"
        exec_copia_CLIENT_0="""
            echo "Doing backup of AmdocsCRM.ear"
            cd ${Path_ENV}
            cp AmdocsCRM.ear AmdocsCRM.ear_${_date}
            if [ -f AmdocsCRM.ear_${_date} ]
            then
                    echo "Backup OK"
            else
                    echo "Backup KO"
                    exit 3
            fi
            echo "Copying from crm50tst07 AmdocsCRM.ear"
            scp platafor@crm50tst07:/home/amdocs_sppr/opt/amdocs/crm/client/AmdocsCRM.ear ${Path_ENV}
            if [ -f ${Path_ENV}/AmdocsCRM.ear ]
                then
                    echo "Copy OK"
                else
                    echo "Error copying, check"
                    exit 56
            fi
        """
        sh "ssh -q uifadm@${Machine_ENV} '${exec_copia_CLIENT_0}'" //uifadm
} //stage
} //node
// Arranque CLIENT
node ("devopststtools01") {       
    stage ("Arranque_CLIENT_0_1"){

        print "*************************************************"
        print " Start CLIENT de ${myenv}                   "
        print "*************************************************"
        exec_arrancar_CLIENT_0_1="""
        . ./.profile 2>/dev/null
        cd ${Path_ENV_RS}
        ./start_JNLP.sh 2>/dev/null
        """
        print (exec_arrancar_CLIENT_0_1)
        sh "ssh -q uifadm@${Machine_ENV} '${exec_arrancar_CLIENT_0_1}'" //uifadm
    } //stage

} //node

}//if

if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

if (( "${myapp}" == "ALL" ) || ( "${myapp}" == "ACT_PVCS_BIT" )) {

myapp = "CLIENT" // solo para revisar si es 1 o 0, da igual la app

node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node  
 
if ( "${myenv}" == "TST1" ) {
myenv = "TST1" 
} //if
if ( "${myenv}" == "TST4" ) {
myenv = "TST" 
} //if
if ( "${myenv}" == "TST5" ) {
myenv = "SIT2" 
} //if
if ( "${myenv}" == "TST3" ) {
myenv = "PPRD" 
} //if
if ( "${myenv}" == "TST2" ) {
myenv = "SIT1" 
} //if
if ( "${myenv}" == "TST6" ) {
myenv = "SIT3" 
} //if
if ( "${myenv}" == "PET" ) {
myenv = "PET" 
} //if

if ( "${act_pvcs_bit}" == "true" && "${Cm_0_1}" == "1" ) {
node ("crm50tst01.ono.es"){
   stage ("ACT_PVCS_BIT"){
        print "**********************************************"
        print "Executing act_pvcs_upgrade for  ${myenv}  on machine crm50tst01  "
        print "**********************************************"
        exec_ACT_PVCS_BIT="""
        . /home/plataforma/plausr/.profile_refresco 2>/dev/null
        cd /home/plataforma/release/scripts
        ./act_pvcs_upgrade -pb -e ${myenv}
        """
        sh "${exec_ACT_PVCS_BIT}" //platafor
   } //stage
   } //node
} //if
} //if
