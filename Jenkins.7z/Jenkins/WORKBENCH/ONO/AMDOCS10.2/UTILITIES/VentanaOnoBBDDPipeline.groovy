#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

VentanaOnoPipelineBBDDUpgrade([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/pipelineConfig.yml', 
environmentChoices:["SIT1","PPRD"]])

