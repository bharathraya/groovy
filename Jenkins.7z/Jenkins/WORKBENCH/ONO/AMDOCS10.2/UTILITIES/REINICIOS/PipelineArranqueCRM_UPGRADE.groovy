#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def myclient=params.PCK
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Arranque: ${myapp} ${myenv}"
    currentBuild.description = "Arranque: ${myapp} ${myenv}"
     
 node ("devopststtools01") {    
        stage ("Ejecutor"){
            wrap([$class: 'BuildUser']) {
                    echo "Exec user: ${env.BUILD_USER_ID}"
                    mybuilduser=env.BUILD_USER_ID
                    }

        }
    }
     
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true_ALL"
}

if ( "${myapp}" == "ALL_MAESTRAS" ) {
VariableALL = "true_MAESTRAS"
}

if ( "${myapp}" == "PM"  || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) {
    myapp = "PM"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

    if ( "${myapp}" == "PM" ) {
        // Arranque PM
        node ("devopststtools01") {       
            stage ("Parar_PM"){
        
                print "**********************************************"
                print " Paramos el PM de ${myenv}                    "
                print "**********************************************"
                exec_parar_PM_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./Parar_APM.sh 2>/dev/null
                """
                print (exec_parar_PM_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_PM_0}'" //weblogic
            } //stage
          
            stage ("DelCache_PM_0_1"){
            print "**********************************************"
            print " Borramos Cache APM de ${myenv}                   "
            print "**********************************************"
            exec_cache_PM_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./DeleteCacheServer.sh 2>/dev/null
            """
            print (exec_cache_PM_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_cache_PM_0_1}'" //weblogic        
            } //stage
          
            stage ("Arranca_PM"){
        
                print "******************************"
                print " Arrancamos el PM de ${myenv} "
                print "******************************"
                exec_arrancar_PM_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./Arranca_APM.sh 2>/dev/null
                """
                print (exec_arrancar_PM_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_PM_0}'" //weblogic
            } //stage        
        } //node
    } // if
} //if

if ( "${myapp}" == "SERVER"  || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) {
    myapp = "SERVER"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    node ("devopststtools01") { 
        stage ("Paramos_SERVER_0_1"){
            print "**********************************************"
            print " Paramos SERVER de ${myenv}                   "
            print "**********************************************"
            exec_parar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_Server.sh 2>/dev/null
            """
            print (exec_parar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic        
        } //stage
        
       stage ("DelCache_SERVER_0_1"){
            print "**********************************************"
            print " Borramos Cache SERVER de ${myenv}                   "
            print "**********************************************"
            exec_cache_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./DeleteCacheServer.sh 2>/dev/null
            """
            print (exec_cache_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_cache_SERVER_0_1}'" //weblogic        
        } //stage
        
        stage ("Arranque_SERVER_0_1"){
            print "*************************************************"
            print " Arrancamos SERVER de ${myenv}                   "
            print "*************************************************"
            exec_arrancar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_Server.sh 2>/dev/null
            """
            print (exec_arrancar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic        
        } //stage
    } //node
} //if

if ( "${myapp}" == "CLIENT" || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) {
    myapp = "CLIENT"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    } //node
    // Arranque CLIENT
    node ("devopststtools01") { 
       stage ("Parar_CLIENT_0_1"){
            print "*******************************************"
            print "Paramos CLIENT en ${myenv}                 "
            print "*******************************************"
            exec_parar_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_JNLP.sh 2>/dev/null
            """
            print (exec_parar_CLIENT_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_CLIENT_0_1}'" //weblogic
       } //stage
       
       stage ("DelCache_CLIENT_0_1"){
            print "**********************************************"
            print " Borramos Cache CLIENT de ${myenv}                   "
            print "**********************************************"
            exec_cache_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./DeleteCacheServer.sh 2>/dev/null
            """
            print (exec_cache_CLIENT_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_cache_CLIENT_0_1}'" //weblogic        
        } //stage
      
      
       stage ("Arrancar_CLIENT_0_1"){
            print "**********************************************"
            print "Arrancamos CLIENT en ${myenv}                 "
            print "**********************************************"
            exec_arrancar_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_JNLP.sh 2>/dev/null
            """
            print (exec_arrancar_CLIENT_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_CLIENT_0_1}'" //weblogic
       } //stage
    } //node
} //if


//ARRANQUE RULEMANAGER
if ( "${myapp}" == "RULEMANAGER" || "${myapp}" == "ALL" || "${VariableALL}" == "true_ALL") {
    myapp = "RULEMANAGER"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_rulemanager = Opciones[3]
        } //stage
    } //node
    
    // Parada RULEMANAGER
    if ( "${existe_rulemanager}" == "1" ) {
        node ("devopststtools01") {       
            stage ("Parada_RULEMANAGER"){
                print "*********************************"
                print " PARAMOS RULEMANAGER de ${myenv} "
                print "*********************************"
                exec_parar_RULEMANAGER="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./stop_rulemanager.sh 2>/dev/null
                """
                print (exec_parar_RULEMANAGER)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_RULEMANAGER}'" 
            } //stage
            stage ("Arranque_RULEMANAGER"){
                print "*************************************************"
                print " ARRANCAMOS RULEMANAGER de ${myenv}                      "
                print "*************************************************"
                exec_arrancar_RULEMANAGER="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./start_rulemanager.sh 2>/dev/null
                """
                print (exec_arrancar_RULEMANAGER)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_RULEMANAGER}'" 
            } //stage
        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
} //if
    //ARRANQUE MQ 
    if ( "${myapp}" == "MQ" || "${myapp}" == "ALL" || "${VariableALL}" == "true_ALL") {
    myapp = "MQ"
    if (( "${myenv}" == "SIT1" ) || ( "${myenv}" == "SIT2" ) || ( "${myenv}" == "PPRD" )) {
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_mq = Opciones[3]
            } //stage
    } //node
    if ( "${existe_mq}" == "1" ) {
        node ("devopststtools01") {       
            stage ("Parada_MQ"){
                print "**************************"
                print " Paramos MQ de ${myenv}   "
                print "**************************"
                exec_parar_MQ="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./paramq -g ${Machine_ENV}
                ./kill_all.sh
                ./arrancamq -g ${Machine_ENV}
                """
                print (exec_parar_MQ)
                sh "ssh -q mqm@${Machine_ENV} '${exec_parar_MQ}'" 
            } //stage
            
            stage ("Arranque_MQ"){
                print "*************************************************"
                print " Arrancamos MQ de ${myenv}                      "
                print "*************************************************"
                exec_arrancar_MQ="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./arrancamq -g ${Machine_ENV}
                """
                print (exec_arrancar_MQ)
                sh "ssh -q mqm@${Machine_ENV} '${exec_arrancar_MQ}'" 
            } //stage
        } //node
    } // if
    } //if
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
    } // if
