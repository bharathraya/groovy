#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def VariableSCPBoolean = true
def VariableALL = false
def VariableMQ = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Parada: ${myapp} ${myenv}"
    currentBuild.description = "Parada: ${myapp} ${myenv}"
    
    node ("devopststtools01") {    
        stage ("Ejecutor"){
            wrap([$class: 'BuildUser']) {
                    echo "Exec user: ${env.BUILD_USER_ID}"
                    mybuilduser=env.BUILD_USER_ID
                    }

        }
    }
if ( "${myapp}" == "ALL" ) {
    VariableALL = "true"
}


if ( "${myapp}" == "PM" || "${myapp}" == "ALL" ) {
    myapp = "PM"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm  
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]       
        } //stage

    } //node

    if ( "${myapp}" == "PM" ) {
    //Parada PM
        node ("devopststtools01") {       
            stage ("Parada_PM"){

               print "*************************************************"
               print " Paramos el PM de ${myenv}                       "
               print "*************************************************"
               exec_parar_PM_0="""
               . ./.profile 2>/dev/null
               cd ${Path_ENV}
               ./Parar_APM.sh 2>/dev/null
               """
               print (exec_parar_PM_0)
               sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_PM_0}'" //weblogic
               
               print "****************************************"
               print "Comprobamos la parada del APM de ${myenv}"
               print "****************************************"
               exec_comp_apm="""
               if [ \$(ps -fu weblogic | grep -i ${myenv} | grep -v grep | wc -l) -ne 0 ]
                   then
                       echo ""
                       echo "Algo no se ha parado"
                       ps -fu weblogic | grep -i ${myenv} | grep -v grep
                   exit 3
               else
                       echo ""
                       echo "Parada corecta"
               fi
               """
             //sh "ssh -q weblogic@${Machine_ENV} '${exec_comp_apm}'" //weblogic
               print " ejecucion ${exec_comp_apm}"        
           } //stage

        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if

if ( "${myapp}" == "SERVER" || "${myapp}" == "ALL" ) {
    myapp = "SERVER"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    // Parada SERVER
    node ("devopststtools01") {       
        stage ("Parada_SERVER_0_1"){
    
            print "*************************************************"
            print " Paramos SERVER de ${myenv}                      "
            print "*************************************************"
            exec_parar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_Server.sh 2>/dev/null
            """
            print " ejecucion ${exec_parar_SERVER_0_1}"
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
        } //stage
    
       //METER BORRADO DE TMPS?
    } //node
    
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}


if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
    myapp = "CLIENT"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm  

            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
        } //stage

    } //node
    // Parada CLIENT
    node ("devopststtools01") {       
        stage ("Parada_CLIENT_0_1"){
    
            print "*************************************************"
            print " Paramos CLIENT de ${myenv}                      "
            print "*************************************************"
            exec_parar_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_JNLP.sh 2>/dev/null
            """
            print " ejecucion ${exec_parar_CLIENT_0_1}"
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_CLIENT_0_1}'" //weblogic
        } //stage
    }

    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    }
} //if

//PARADA RULEMANAGER
if ( "${myapp}" == "RULEMANAGER" || "${myapp}" == "ALL" ) {
    myapp = "RULEMANAGER"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_rulemanager = Opciones[3]
            } //stage
    } //node
    
    // Parada RULEMANAGER
    if ( "${existe_rulemanager}" == "1" ) {
        node ("devopststtools01") {       
            stage ("Parada_RULEMANAGER"){
    
                print "*************************************************"
                print " Paramos RULEMANAGER de ${myenv}                      "
                print "*************************************************"
                exec_parar_RULEMANAGER="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./stop_rulemanager.sh 2>/dev/null
                """
                print " ejecucion ${exec_parar_RULEMANAGER}"
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_RULEMANAGER}'" 
            } //stage
        } //node
    } // 
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
} //if   
    
    //PARADA MQ 
    if ( "${myapp}" == "MQ" || "${myapp}" == "ALL" ) {
    myapp = "MQ"
    if ( "${myenv}" == "SIT1" || "${myenv}" == "SIT2" || "${myenv}" == "PPRD" ) {
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig = readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones = ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_mq = Opciones[3]
            } //stage
    } //node
    if ( "${existe_mq}" == "1" ) {
        node ("devopststtools01") {       
            stage ("Parada_MQ"){
                print "*************************************************"
                print " Paramos MQ de ${myenv}                      "
                print "*************************************************"
                exec_parar_MQ="""
                cd ${Path_ENV}
                ./paramq -g ${Machine_ENV}
                ./kill_all.sh
                """
                print " ejecucion ${exec_parar_MQ}"
                sh "ssh -q mqm@${Machine_ENV} '${exec_parar_MQ}'" 
                
            } //stage
        } //node
    } //if
    } //if
    } //if
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } // if
    
if (( "${myenv}" == "TST" ) || ( "${myenv}" == "TST1" ) || ( "${myenv}" == "SIT1" ) || ( "${myenv}" == "PPRD" )) {
if ( "${myapp}" == "KILL" || "${myapp}" == "ALL" ) {
node ("devopststtools01") {       
    stage ("Kill_connections"){

        print "*************************************************"
        print " Ejecutamos kill_connections para ${myenv}       "
        print "*************************************************"
        exec_kill_connections_0_1="""
        . /home/plataforma/plausr/.profile 2>/dev/null
        cd /home/plataforma/plausr/KILL_CONNECTIONS
        ./cancel_connections_tga_jenkins.sh ${myenv}
        """
        print (exec_kill_connections_0_1)
        sh "${exec_kill_connections_0_1}" //platafor
    } //stage
} //node
} //if
} //if
