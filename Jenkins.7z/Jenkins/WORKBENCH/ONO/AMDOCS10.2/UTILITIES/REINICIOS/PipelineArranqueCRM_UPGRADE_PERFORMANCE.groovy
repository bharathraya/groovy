#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def myclient=params.PCK
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Restart: ${myapp} ${myenv}"
    currentBuild.description = "Restart: ${myapp} ${myenv}"
     
 node ("devopststtools01") {    
        stage ("Ejecutor"){
            wrap([$class: 'BuildUser']) {
                    echo "Exec user: ${env.BUILD_USER_ID}"
                    mybuilduser=env.BUILD_USER_ID
                    }

        }
    }
     
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true_ALL"
}

if ( "${myapp}" == "SERVER"  || "${VariableALL}" == "true_ALL" ) {
    myapp = "SERVER"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    node ("devopststtools01") { 
        stage ("Paramos_SERVER_0_1"){
            print "**********************************************"
            print " Paramos SERVER de ${myenv}                   "
            print "**********************************************"
            exec_parar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_Server.sh 2>/dev/null
            """
            print (exec_parar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic        
        } //stage
        
        stage ("Arranque_SERVER_0_1"){
            print "*************************************************"
            print " Arrancamos SERVER de ${myenv}                   "
            print "*************************************************"
            exec_arrancar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_Server.sh 2>/dev/null
            """
            print (exec_arrancar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic        
        } //stage
    } //node
} //if

if ( "${myapp}" == "CLIENT" || "${VariableALL}" == "true_ALL" ) {
    myapp = "CLIENT"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    } //node
    // Arranque CLIENT
    node ("devopststtools01") { 
       stage ("Parar_CLIENT_0_1"){
            print "*******************************************"
            print "Paramos CLIENT en ${myenv}                 "
            print "*******************************************"
            exec_parar_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_JNLP.sh 2>/dev/null
            """
            print (exec_parar_CLIENT_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_CLIENT_0_1}'" //weblogic
       } //stage
       
       stage ("Arrancar_CLIENT_0_1"){
            print "**********************************************"
            print "Arrancamos CLIENT en ${myenv}                 "
            print "**********************************************"
            exec_arrancar_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_JNLP.sh 2>/dev/null
            """
            print (exec_arrancar_CLIENT_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_CLIENT_0_1}'" //weblogic
       } //stage
    } //node
} //if


if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
} //if
