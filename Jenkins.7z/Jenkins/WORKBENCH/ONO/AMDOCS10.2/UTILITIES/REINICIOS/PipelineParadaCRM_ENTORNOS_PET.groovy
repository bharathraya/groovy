#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def VariableSCPBoolean = true
def VariableALL = false
//def VariableMQ = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Parada: ${myapp} ${myenv}"
    currentBuild.description = "Parada: ${myapp} ${myenv}"

if ( "${myapp}" == "ALL" ) {
    VariableALL = "true"
}


if ( "${myapp}" == "APM" || "${myapp}" == "ALL" ) {
    myapp = "APM"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm  
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]       
        } //stage

    } //node

    if ( "${myapp}" == "APM" ) {
    //Parada APM
        node ("devopststtools01") {       
            stage ("Parada_APM"){

               print "*************************************************"
               print " Paramos el weblogic APM de ${myenv}                       "
               print "*************************************************"
               exec_parar_APM_0="""
               . ./.profile 2>/dev/null
               cd ${Path_ENV}
               ./stop_cluster_apm_1.sh 2>/dev/null
               """
               print (exec_parar_APM_0)
               sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_APM_0}'" //weblogic
               
            //   print "****************************************"
            //   print "Comprobamos la parada del APM de ${myenv}"
            //   print "****************************************"
            //   exec_comp_apm="""
            //   if [ \$(ps -fu weblogic | grep -i ${myenv} | grep -v grep | wc -l) -ne 0 ]
            //       then
            //           echo ""
            //           echo "Algo no se ha parado"
            //           ps -fu weblogic | grep -i ${myenv} | grep -v grep
            //       exit 3
            //   else
            //           echo ""
            //           echo "Parada corecta"
            //   fi
            //   """
            // //sh "ssh -q weblogic@${Machine_ENV} '${exec_comp_apm}'" //weblogic
            //   print " ejecucion ${exec_comp_apm}"        
           } //stage

        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if

if ( "${myapp}" == "APMAsinc" || "${myapp}" == "ALL" ) {
    myapp = "APMAsinc"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm  
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]       
        } //stage

    } //node

    if ( "${myapp}" == "APMAsinc" ) {
    //Parada APMAsinc
        node ("devopststtools01") {       
            stage ("Parada_APMAsinc"){

               print "*************************************************"
               print " Paramos los procesos de APM Asincronos, Automaticos, etc de ${myenv}                       "
               print "*************************************************"
               exec_parar_APMAsinc_0="""
               . ./.profile 2>/dev/null
               cd ${Path_ENV}
               ./Parada_APM_asinc.sh 2>/dev/null
               """
               print (exec_parar_APMAsinc_0)
               sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_APMAsinc_0}'" //procesos
           } //stage

        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if

if ( "${myapp}" == "SERVER" || "${myapp}" == "ALL" ) {
    myapp = "SERVER"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    // Parada SERVER
    node ("devopststtools01") {       
        stage ("Parada_SERVER_0_1"){
    
            print "*************************************************"
            print " Paramos SERVER de ${myenv}                      "
            print "*************************************************"
            exec_parar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_cluster_app_1.sh 2>/dev/null
            """
            print (exec_parar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
        } //stage
    
       //METER BORRADO DE TMPS?
    } //node
    
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}


if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
    myapp = "CLIENT"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm  

            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
        } //stage

    } //node
    // Parada CLIENT
    node ("devopststtools01") {       
        stage ("Parada_CLIENT_0_1"){
    
            print "*************************************************"
            print " Paramos CLIENT de ${myenv}                      "
            print "*************************************************"
            exec_parar_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_cluster_uif_1.sh 2>/dev/null
            """
            print (exec_parar_CLIENT_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_CLIENT_0_1}'" //weblogic
        } //stage
    }

    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    }
} //if

//PARADA RULEMANAGER
if ( "${myapp}" == "RULEMANAGER" || "${myapp}" == "ALL" ) {
    myapp = "RULEMANAGER"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_rulemanager = Opciones[3]
            } //stage
    } //node
    
    // Parada RULEMANAGER
    if ( "${existe_rulemanager}" == "1" ) {
        node ("devopststtools01") {       
            stage ("Parada_RULEMANAGER"){
    
                print "*************************************************"
                print " Paramos RULEMANAGER de ${myenv}                      "
                print "*************************************************"
                exec_parar_RULEMANAGER="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./stop_rulemanager.sh  2>/dev/null
                """
                print (exec_parar_RULEMANAGER)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_RULEMANAGER}'" 
            } //stage
        } //node
    } // 
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } 
    
} //if

////    //PARADA MQ 
////    if ( "${myapp}" == "MQ" || "${myapp}" == "ALL" ) {
////
////    myapp = "MQ"
////
////    // cuando tengamos MQ de SIT3 if (( "${myenv}" == "SIT1" ) || ( "${myenv}" == "SIT2" ) || ( "${myenv}" == "PPRD" ) || ( "${myenv}" == "SIT3" )) {
////    if (( "${myenv}" == "SIT1" ) || ( "${myenv}" == "SIT2" ) || ( "${myenv}" == "PPRD" )) {
////    node ("devopststtools01") {     
////        stage ("Opciones"){
////            checkout scm 
////            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
////            
////            print "cual es el valor de myenv_myapp ${myenv}_${myapp}"
////            Opciones=ENVConfig["${myenv}_${myapp}"]
////            Path_ENV = Opciones[0]
////            Machine_ENV = Opciones[1]
////            User_ENV = Opciones[2]
////            existe_mq = Opciones[3]
////
////            } //stage
////    } //node
////    if ( "${existe_mq}" == "1" ) {
////       // node ("devopststtools01") {       
////       node ("devopststtools01") {  
////            stage ("Parada_MQ"){
////                print "*************************************************"
////                print " Paramos MQ de ${myenv}                      "
////                print "*************************************************"
////                exec_parar_MQ="""
////                cd ${Path_ENV}
////                ./paramq -g ${Machine_ENV}
////                """
////                print (exec_parar_MQ)
////                sh "ssh -q mqm@${Machine_ENV} '${exec_parar_MQ}'" 
////                
////            } //stage
////        } //node
////    } // if
////    } // if
////    if ( "${VariableALL}" == "true" ) {
////        myapp = "ALL"
////    }
////    
//// }//if

//Stop Admin nodes of weblogic if it is down (reboot server) 
if ( "${myapp}" == "AdminW" ) {
    myapp = "AdminW"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm  
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]       
        } //stage

    } //node

    if ( "${myapp}" == "AdminW" ) {
    //Parada AdminW
        node ("devopststtools01") {       
            stage ("Parada_AdminW"){

               print "*************************************************"
               print " Paramos los Admin de los Weblogics en ${myenv}                "
               print "*************************************************"
               exec_parar_AdminW_0="""
               . ./.profile 2>/dev/null
               cd ${Path_ENV}
               ./stopAdmin_WeblogicsPET.sh 2>/dev/null
               """
               print (exec_parar_AdminW_0)
               sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_AdminW_0}'" //procesos
           } //stage

        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if


 //Stop NodeManagers of weblogic if it is down (reboot server)  
if ( "${myapp}" == "NodeManager" ) {
    myapp = "NodeManager"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm  
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]       
        } //stage

    } //node

    if ( "${myapp}" == "NodeManager" ) {
    //Parada NodeManager
        node ("devopststtools01") {       
            stage ("Parada_NodeManager"){

               print "*************************************************"
               print " Paramos los NodeMangare de los Weblogics en ${myenv}           "
               print "*************************************************"
               exec_parar_NodeManager_0="""
               . ./.profile 2>/dev/null
               cd ${Path_ENV}
               ./stopNodeManager_WeblogicsPET.sh 2>/dev/null
               """
               print (exec_parar_NodeManager_0)
               sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_NodeManager_0}'" //procesos
           } //stage

        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if


 //ARRANQUE APACHE if it is down (reboot server) 
if ( "${myapp}" == "APACHE" || "${myapp}" == "ALL" ) {
    myapp = "APACHE"
    if (( "${myenv}" == "PET" )) {
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

    if ( "${myapp}" == "APACHE" ) {
        // Arranque APACHE
        node ("devopststtools01") {       
            stage ("Arranca_APACHE"){
        
                print "*************************************************"
                print " Arrancamos el APACHE de ${myenv}                    "
                print "*************************************************"
                exec_PARADA_APACHE="""
        		. ./.profile 2>/dev/null
       		 	cd ${Path_ENV}
       		 	./apachectl stop               
        		sleep 10
        		"""
        		print (exec_PARADA_APACHE)
        		sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_PARADA_APACHE}'" //apache
            } //stage
        
        } //node
    } // if
    } //if
     if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if
