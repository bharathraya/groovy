#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Arranque: APACHE ${myenv}"
    currentBuild.description = "Arranque: APACHE ${myenv}"
     
 node ("devopststtools01") {    
        stage ("Ejecutor"){
            wrap([$class: 'BuildUser']) {
                    echo "Exec user: ${env.BUILD_USER_ID}"
                    mybuilduser=env.BUILD_USER_ID
                    }

        }
    }
    
node ("devopststtools01") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                    Opciones=ENVConfig["${myenv}_APACHE"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    User_ENV = Opciones[2]
    } //stage
    
} //node

node ("devopststtools01") {  
    stage ("Parada_APACHE"){
        print "******************************************"
        print " Paramos el APACHE de ${myenv}            "
        print "******************************************"
        exec_PARADA_APACHE="""
        . ./.profile 2>/dev/null
        cd ${Path_ENV}/bin
        ./httpd -k stop -d ${Path_ENV}
        sleep 30
        """
        print (exec_PARADA_APACHE)
        sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_PARADA_APACHE}'" //webadm
    } //stage
    
    stage ("Arranque_APACHE"){
        print "*********************************************"
        print " Arrancamos el APACHE de ${myenv}            "
        print "*********************************************"
        exec_ARRANQUE_APACHE="""
        . ./.profile 2>/dev/null
        cd ${Path_ENV}/bin
        ./httpd -k start -d ${Path_ENV}
        """
        print (exec_ARRANQUE_APACHE)
        sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_ARRANQUE_APACHE}'" //webadm
    } //stage
} //node
