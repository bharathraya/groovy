#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def myclient=params.PCK
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Arranque: ${myapp} ${myenv}"
    currentBuild.description = "Arranque: ${myapp} ${myenv}"
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true"
}

 //ARRANQUE APACHE if it is down (reboot server) 
if ( "${myapp}" == "APACHE" || "${myapp}" == "ALL" ) {
    myapp = "APACHE"
    if (( "${myenv}" == "SIT1" ) || ( "${myenv}" == "SIT2" ) || ( "${myenv}" == "PPRD" )) {
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

   if ( "${myapp}" == "APACHE" ) {
        // Arranque APACHE
        node ("devopststtools01") {       
            stage ("Arranca_APACHE"){
        
                print "*************************************************"
                print " Arrancamos el APACHE de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_PM_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}/bin
                ./httpd -k start -d ${Path_ENV} 2>/dev/null
                """
                print (exec_arrancar_PM_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_PM_0}'" //apache
            } //stage
        } //node
    } // if
    } //if
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if


if ( "${myapp}" == "PM"  || "${myapp}" == "ALL" ) {
    myapp = "PM"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

    if ( "${myapp}" == "PM" ) {
        // Arranque PM
        node ("devopststtools01") {       
            stage ("Arranca_PM"){
        
                print "*************************************************"
                print " Arrancamos el PM de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_PM_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./Arranca_APM.sh 2>/dev/null
                """
                print (exec_arrancar_PM_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_PM_0}'" //weblogic
            } //stage
        
        } //node
    } // if
     if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if

if ( "${myapp}" == "SERVER"  || "${myapp}" == "ALL" ) {
    myapp = "SERVER"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    node ("devopststtools01") { 
        stage ("Arranque_SERVER_0_1"){
            print "*************************************************"
            print " Arrancamos SERVER de ${myenv}                   "
            print "*************************************************"
            exec_arrancar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_Server.sh 2>/dev/null
            """
            print (exec_arrancar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic        
        } //stage
    } //node
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}

if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
    myapp = "CLIENT"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    } //node
    // Arranque CLIENT
    node ("devopststtools01") { 
       stage ("Arrancar_CLIENT_0_1"){
            print "**********************************************"
            print "Arrancamos CLIENT en ${myenv}                 "
            print "**********************************************"
            exec_arrancar_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_JNLP.sh 2>/dev/null
            """
            print (exec_arrancar_CLIENT_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_CLIENT_0_1}'" //weblogic
       } //stage
   }
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    }
} //if


//ARRANQUE RULEMANAGER
if ( "${myapp}" == "RULEMANAGER" || "${myapp}" == "ALL" ) {
    myapp = "RULEMANAGER"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_rulemanager = Opciones[3]
        } //stage
    } //node
    
    // Parada RULEMANAGER
    if ( "${existe_rulemanager}" == "1" ) {
        node ("devopststtools01") {       
            stage ("Arranque_RULEMANAGER"){
    
                print "*************************************************"
                print " ARRANCAMOS RULEMANAGER de ${myenv}                      "
                print "*************************************************"
                exec_arrancar_RULEMANAGER="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./start_rulemanager.sh 2>/dev/null
                """
                print (exec_arrancar_RULEMANAGER)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_RULEMANAGER}'" 
            } //stage
        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
} //if
    
//ARRANQUE MQ 
if ( "${myapp}" == "MQ" || "${myapp}" == "ALL" ) {
    myapp = "MQ"
    if (( "${myenv}" == "SIT1" ) || ( "${myenv}" == "SIT2" ) || ( "${myenv}" == "PPRD" )) {
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
             print "cual es el valor de myenv_myapp ${myenv}_${myapp}"
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            existe_mq = Opciones[3]
            } //stage
    } //node
    if ( "${existe_mq}" == "1" ) {
        node ("devopststtools01") {       
            stage ("Arranque_MQ"){
                print "*************************************************"
                print " Arrancamos MQ de ${myenv}                      "
                print "*************************************************"
                exec_arrancar_MQ="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./arrancamq -g ${Machine_ENV}
                """
                print (exec_arrancar_MQ)
                sh "ssh -q mqm@${Machine_ENV} '${exec_arrancar_MQ}'" 
            } //stage
        } //node
    } // if

    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
    } // if
    
}//if
