#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def myclient=params.PCK
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Arranque: ${myapp} ${myenv}"
    currentBuild.description = "Arranque: ${myapp} ${myenv}"
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true"
}

 //ARRANQUE APACHE if it is down (reboot server) 
if ( "${myapp}" == "APACHE" || "${myapp}" == "ALL" ) {
    myapp = "APACHE"
    if ( "${myenv}" == "PET" ) {
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

   if ( "${myapp}" == "APACHE" ) {
        // Arranque APACHE
        node ("devopststtools01") {       
            stage ("Arranca_APACHE") {
        
                print "*************************************************"
                print " Arrancamos el APACHE de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_PM_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./apachectl start
                """
                print (exec_arrancar_PM_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_PM_0}'" //apache
            } //stage
        } //node
    } // if
    } //if
        
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if

 //ARRANQUE CONSUL Agents if it is down (reboot server) 
if ( "${myapp}" == "CONSUL") {
    myapp = "CONSUL"
    if ( "${myenv}" == "PET" ) {
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

   if ( "${myapp}" == "CONSUL" ) {
        // Arranque CONSUL
        node ("devopststtools01") {       
            stage ("Arranca_CONSUL") {
        
                print "*************************************************"
                print " Arrancamos el CONSUL de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_CNSL_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./startAgent_consulPET.sh 2>/dev/null
                """
                print (exec_arrancar_CNSL_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_CNSL_0}'" //consul
            } //stage
        } //node
    } // if
    } //if
        
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if


 //ARRANQUE Admin nodes of weblogic if it is down (reboot server) 
if ( "${myapp}" == "AdminW" ) {
    myapp = "AdminW"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

    if ( "${myapp}" == "AdminW" ) {
        // Arranque AdminW
        node ("devopststtools01") {       
            stage ("Arranca_AdminW") {
        
                print "*************************************************"
                print " Arrancamos los Adim de los weblogics de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_AdminW_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./startAdmin_WeblogicsPET.sh 2>/dev/null
                """
                print (exec_arrancar_AdminW_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_AdminW_0}'" //weblogic
            } //stage
        
        } //node
    } // if
     if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if


 //ARRANQUE NodeManagers of weblogic if it is down (reboot server) 
if ( "${myapp}" == "NodeManager") {
    myapp = "NodeManager"
    if ( "${myenv}" == "PET" ) {
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

   if ( "${myapp}" == "NodeManager" ) {
        // Arranque NodeManager
        node ("devopststtools01") {       
            stage ("Arranca_NodeManager") {
        
                print "*************************************************"
                print " Arrancamos los NodeManager de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_NodeManager_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./startNodeManager_WeblogicsPET.sh 2>/dev/null
                """
                print (exec_arrancar_NodeManager_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_NodeManager_0}'" //consul
            } //stage
        } //node
    } // if
    } //if
        
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if


if ( "${myapp}" == "APM"  || "${myapp}" == "ALL" ) {
    myapp = "APM"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

    if ( "${myapp}" == "APM" ) {
        // Arranque APM
        node ("devopststtools01") {       
            stage ("Arranca_APM") {
        
                print "*************************************************"
                print " Arrancamos el weblogic del APM de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_APM_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./start_cluster_apm_1.sh 2>/dev/null
                """
                print (exec_arrancar_APM_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_APM_0}'" //weblogic
            } //stage
        
        } //node
    } // if
     if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if

if ( "${myapp}" == "APMAsinc"  || "${myapp}" == "ALL" ) {
    myapp = "APMAsinc"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

    if ( "${myapp}" == "APMAsinc" ) {
        // Arranque APMAsinc
        node ("devopststtools01") {       
            stage ("Arranca_APMAsinc") {
        
                print "*************************************************"
                print " Arrancamos los procesos del APM Asincronos, Automaticos, etc de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_APMAsinc_0="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./Arranca_APM_asinc.sh 2>/dev/null
                """
                print (exec_arrancar_APMAsinc_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_APMAsinc_0}'" //weblogic
            } //stage
        
        } //node
    } // if
     if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if


if ( "${myapp}" == "SERVER"  || "${myapp}" == "ALL" ) {
    myapp = "SERVER"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    node ("devopststtools01") { 
        stage ("Arranque_SERVER_0_1") {
            print "*************************************************"
            print " Arrancamos SERVER de ${myenv}                   "
            print "*************************************************"
            exec_arrancar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_cluster_app_1.sh 2>/dev/null
            """
            print (exec_arrancar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic        
        } //stage
    } //node
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}

if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
    myapp = "CLIENT"
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    } //node
    // Arranque CLIENT
    node ("devopststtools01") { 
       stage ("Arrancar_CLIENT_0_1"){
            print "**********************************************"
            print "Arrancamos CLIENT en ${myenv}                 "
            print "**********************************************"
            exec_arrancar_CLIENT_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_cluster_uif_1.sh 2>/dev/null
            """
            print (exec_arrancar_CLIENT_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_CLIENT_0_1}'" //weblogic
       } //stage
   }
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    }
} //if


//ARRANQUE RULEMANAGER
if ( "${myapp}" == "RULEMANAGER" || "${myapp}" == "ALL" ) {
    myapp = "RULEMANAGER"
    node ("devopststtools01") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_PET.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_rulemanager = Opciones[3]
        } //stage
    } //node
    
    // ARRANQUE RULEMANAGER
    if ( "${existe_rulemanager}" == "1" ) {
        node ("devopststtools01") {       
            stage ("Arranque_RULEMANAGER"){
    
                print "*************************************************"
                print " ARRANCAMOS RULEMANAGER de ${myenv}                      "
                print "*************************************************"
                exec_arrancar_RULEMANAGER="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./start_rulemanager.sh 2>/dev/null
                """
                print (exec_arrancar_RULEMANAGER)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_RULEMANAGER}'" 
            } //stage
        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
} //if
    
//ARRANQUE MQ 
////if ( "${myapp}" == "MQ" || "${myapp}" == "ALL" ) {
////    myapp = "MQ"
////    if (( "${myenv}" == "SIT1" ) || ( "${myenv}" == "SIT2" ) || ( "${myenv}" == "PPRD" )) {
////    node ("devopststtools01") {     
////        stage ("Opciones"){
////            checkout scm 
////            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
////             print "cual es el valor de myenv_myapp ${myenv}_${myapp}"
////            Opciones=ENVConfig["${myenv}_${myapp}"]
////            Path_ENV = Opciones[0]
////            Machine_ENV = Opciones[1]
////            existe_mq = Opciones[3]
////            } //stage
////    } //node
////    if ( "${existe_mq}" == "1" ) {
////        node ("devopststtools01") {       
////            stage ("Arranque_MQ"){
////                print "*************************************************"
////                print " Arrancamos MQ de ${myenv}                      "
////                print "*************************************************"
////                exec_arrancar_MQ="""
////                . ./.profile 2>/dev/null
////                cd ${Path_ENV}
////                ./arrancamq -g ${Machine_ENV}
////                """
////                print (exec_arrancar_MQ)
////                sh "ssh -q mqm@${Machine_ENV} '${exec_arrancar_MQ}'" 
////            } //stage
////        } //node
////    } // if
////
////    if ( "${VariableALL}" == "true" ) {
////        myapp = "ALL"
////    } //if
////    } // if    
////}//if
