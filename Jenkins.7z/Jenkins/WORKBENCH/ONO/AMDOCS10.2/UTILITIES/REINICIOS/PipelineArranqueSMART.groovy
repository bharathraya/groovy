#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def myclient=params.PCK
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Reinicio: ${myapp} ${myenv}"
    currentBuild.description = "Reinicio: ${myapp} ${myenv}"
     
 node ("devopststtools01") {    
        stage ("Ejecutor"){
            wrap([$class: 'BuildUser']) {
                    echo "Exec user: ${env.BUILD_USER_ID}"
                    mybuilduser=env.BUILD_USER_ID
                    }

        }
    }
     
if ( "${myapp}" == "SERVER" ) {
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_SMART_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                        Node1 = Opciones[3]
                        Node2 = Opciones[4]
                        Node3 = Opciones[5]
                        Node4 = Opciones[6]
                    } //stage
    
    } //node

node ("devopststtools01") {
        stage ("Reinicio_SERVER"){
            print "********************************************************"
            print " Reiniciamos SERVER de ${myenv} sin perdida de servicio "
            print "********************************************************"
            exec_reiniciar_SERVER="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./restartNode.sh ${Node1} 2>/dev/null
            ./restartNode.sh ${Node2} 2>/dev/null
            ./restartNode.sh ${Node3} 2>/dev/null
            ./restartNode.sh ${Node4} 2>/dev/null
            """
            print (exec_reiniciar_SERVER)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_reiniciar_SERVER}'" //srvadm        
        } //stage

} //node
} //if

if ( "${myapp}" == "CLIENT" ) {
    node ("devopststtools01") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/REINICIOS/REINICIOS_SMART_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                        Node1 = Opciones[3]
                        Node2 = Opciones[4]
                    } //stage
    
    } //node

node ("devopststtools01") {
        stage ("Reinicio_CLIENT"){
            print "********************************************************"
            print " Reiniciamos CLIENT de ${myenv} sin perdida de servicio "
            print "********************************************************"
            exec_reiniciar_CLIENT="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./restartNode.sh ${Node1} 2>/dev/null
            ./restartNode.sh ${Node2} 2>/dev/null
            """
            print (exec_reiniciar_CLIENT)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_reiniciar_CLIENT}'" //uifadm        
        } //stage

} //node
} //if