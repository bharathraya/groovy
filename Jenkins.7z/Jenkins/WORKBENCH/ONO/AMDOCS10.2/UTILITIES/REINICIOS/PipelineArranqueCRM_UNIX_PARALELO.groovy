#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def VariableSCPBoolean = true

    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Ejecucion: ${myenv}"
    currentBuild.description = "Ejecucion: ${myenv}"



node ("devopststtools01") {     
   stage ("REINICIO_PARALELO_UNIX"){
       
       wrap([$class: 'BuildUser']) {
                    echo "Exec user: ${env.BUILD_USER_ID}"
                    mybuilduser=env.BUILD_USER_ID
                    }

       print "******************************************"
       print "      Lanzamos arranque para ${myenv}     "
       print "******************************************"
       exec_reinicio_paralelo="""
       cd /home/plataforma/release/scripts
       ./arranque_J3nk1ns -e ${myenv}
       """
       print (exec_reinicio_paralelo)
       sh "${exec_reinicio_paralelo}" //platafor      
   } //stage
} //node
