#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Recompile: ${myapp} ${myenv}"
    currentBuild.description = "Recompile: ${myapp} ${myenv}"


node ("crm50tst01.ono.es") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/RECOMPILACION/Recompilacion.yml")
                    Opciones=ENVConfig["${myenv}"]
                    Machine_ENV = Opciones[0]
                } //stage
}

if (( "${myapp}" == "CONSULTA" ) || ( "${myapp}" == "ALL" )) {
node ("${Machine_ENV}") {
    stage ("Consulta_ENV") {
    print "*******************************************************"
    print "          We check invallids for ${myenv}            "
    print "*******************************************************"
    exec_consulta_ENV="""
    cd /home/plataforma/plausr
    . ./.profile_jenkins 2>/dev/null
    cd /home/plataforma/release/scripts
    ./all_invalid_jenkins.sh -e ${myenv}
    """
    print (exec_consulta_ENV)
    sh "${exec_consulta_ENV}" //platafor
    }
}
}

if (( "${myapp}" == "RECOMPILE" ) || ( "${myapp}" == "ALL" )) {
node ("${Machine_ENV}") {
    stage ("Recompile_ENV") {
    print "*******************************************************"
    print "             Recompile ${myenv}                     "
    print "*******************************************************"
    exec_recompila_ENV="""
    cd /home/plataforma/plausr
    . ./.profile_jenkins 2>/dev/null
    cd /home/plataforma/release/scripts
    ./all_invalid_jenkins.sh -e ${myenv} -r
    """
    print (exec_recompila_ENV)
    sh "${exec_recompila_ENV}" //platafor
    }
}
}
