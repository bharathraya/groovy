#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myapp=params.APP
def myenv=params.ENV
def VariableSCPBoolean = true
def myBBDD=""

     //Cual es la bbdd
    if (myenv == "PPRD")
    {
        myBBDD="TST3"
    }
    else if (myenv == "SIT1")
    {
        myBBDD="TST2"
    }
    else if (myenv == "TST1")
    {
        myBBDD="TST1"
    }
    else if (myenv == "TST")
    {
        myBBDD="TST4"
    }
    else if (myenv == "SIT2")
    {
        myBBDD="TST5"
    }
    else if (myenv == "SIT3")
    {
        myBBDD="TST6"
    }

   //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Execution: ${myapp} ${myenv} ${myBBDD}"
    currentBuild.description = "Execution: ${myapp} ${myenv} ${myBBDD}"
    


node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS10.2/UTILITIES/MAESTRAS/MAESTRAS.yml")
                    Opciones=ENVConfig["${myenv}"]
                    Machine_ENV = Opciones[0]
                } //stage

} //node

	
if ( "${myapp}" == "MAESTRAS-CORTO" ) {
myapp = "MAESTRAS-CORTO"
node ("${Machine_ENV}") {     
   stage ("MAESTRAS-CORTO"){
       print "*****************************************"
       print " We run SHORT MAESTRAS for ${myenv} "
       print "*****************************************"
       exec_maestras_corto="""
       cd /home/plataforma/release/scripts
       ./arranque_maestras -e ${myBBDD} -C
       """
       print (exec_maestras_corto)
       sh "${exec_maestras_corto}" //platafor      
   } //stage
} //node
} //if


if ( "${myapp}" == "MAESTRAS-LARGO" ) {
myapp = "MAESTRAS-LARGO"
node ("${Machine_ENV}") {     
   stage ("MAESTRAS-LARGO"){
       print "*****************************************"
       print " We run FULL MAESTRAS for ${myenv} "
       print "*****************************************"
       exec_maestras_largo="""
       cd /home/plataforma/release/scripts
       ./arranque_maestras -e ${myBBDD} -L
       """
       print (exec_maestras_largo)
       sh "${exec_maestras_largo}" //platafor      
   } //stage
} //node
} //if
