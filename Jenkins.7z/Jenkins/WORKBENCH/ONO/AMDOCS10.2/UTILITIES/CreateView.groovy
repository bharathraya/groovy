#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def hoy=new Date().format( 'yyyyMMdd' )

_Entorno=params.Entorno
_Vista=params.Vista
_FechaSanity=params.FechaSanity
_Sistema="CRM AMDOCS 10.2"

print "Environment ${_Entorno}"
print "View ${_Vista}"
print "Sanity Date ${_FechaSanity}"



node ("es036tvr") {     
    stage ("GetUser"){
        wrap([$class: 'BuildUser']) {
        _usuario=env.BUILD_USER_ID
        }
    (_pass,_usuario)=findpassword(_usuario)
      
      //Configuramos el nombre del build y su descripcion
      currentBuild.displayName = "View: ${_Vista} Env: ${_Entorno}  "
      currentBuild.description = "View: ${_Vista} Env: ${_Entorno}  "
      
    }
}
print "Today's date is ......${hoy}......"
print "User ${_usuario}"
createView(_usuario,_Vista,_Sistema,_pass,_Entorno,_FechaSanity)
