#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

SVNPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/PORTABILIDAD/pipelineConfig.yml'])
