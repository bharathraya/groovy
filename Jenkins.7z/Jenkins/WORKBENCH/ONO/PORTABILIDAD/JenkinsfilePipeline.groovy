#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _


PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/PORTABILIDAD/pipelineConfig.yml',
    applicationChoices:["IPORTA" , "IPORTA-BBDD" , "SGP" , "SGP-BBDD" ,  "WEB-SGP" ,"SGPMC" , "SGPMC-UNIX" , "SGPMC-BBDD" ,"MQ_SGP" ],
	environmentChoices:["SIT1","SIT2","PPRD","SIT3","PPRD1","PROD"]])

