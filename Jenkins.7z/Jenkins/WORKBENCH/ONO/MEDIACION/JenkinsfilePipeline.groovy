#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/MEDIACION/pipelineConfig.yml',
    applicationChoices:["MTV", "MTV-UNIX" ,"MTV-BBDD" ],
	 environmentChoices:["SIT1","SIT2","PPRD","PROD"]])
