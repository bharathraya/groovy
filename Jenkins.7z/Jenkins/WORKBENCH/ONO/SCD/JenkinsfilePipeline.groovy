#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/SCD/pipelineConfig.yml'])
PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/SCD/pipelineConfig.yml',
    applicationChoices:["SCD-BBDD","SCD-SCRIPTS","MQ_SCD"],
	 environmentChoices:["SIT1","SIT2","PPRD1","SIT3","PROD"]])
