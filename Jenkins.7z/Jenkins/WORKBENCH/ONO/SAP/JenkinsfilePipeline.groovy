#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/SAP/pipelineConfig.yml'])
PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/SAP/pipelineConfig.yml',
    applicationChoices:["SAP-ONO","MQ_SAP"],
	 environmentChoices:["SIT1","SIT2","SIT3","PPRD","PPRD1","PROD"]])

