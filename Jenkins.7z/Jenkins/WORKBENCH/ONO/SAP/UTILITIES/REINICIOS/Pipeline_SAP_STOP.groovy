#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myenv2=params.ENV2
def myapp=params.APP 
 
currentBuild.displayName = "Stop: ${myapp} ${myenv}"
currentBuild.description = "Stop: ${myapp} ${myenv}"

if ( "${myenv}" == "${myenv2}" ) {
    println("ENV OK")
} else {
    println("ERROR, REVIEW, ENV and ENV2 are not the same")
    return 33;
}

node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/SAP/UTILITIES/REINICIOS/REINICIOS.yml")
                    Opciones=ENVConfig["${myapp}-${myenv}"]
                    sidadm = Opciones[0]
                    Machine_ENV = Opciones[1]
      				Instance_ENV = Opciones[2]
                } //stage
} //node
  

node ("fwapptst01") {       
   stage ("StopSap"){
        print "*****************************************************************************"
        print " Stop SAP and clean IPC "
        print "*****************************************************************************"
     	print " Stopping SAP"
        exec_stopsap="""
              stopsap
              setenv count_process `ps -ef |grep dw.sap${Instance_ENV} |grep -v grep | wc -l`
              if   ( \$count_process > 0 ) then
                 echo "SAP stop ERROR will kill with kill -9 -1" 
                 kill -9 -1 
              endif
              """
         print " Cleaning resources"
         exec_cleanipc="""
              cleanipc 02 remove
              if ( \$status == 0 ) then
                  echo "cleanipc executed OK"
              else
                  echo "cleanipc ERROR"
              endif
          """
        Machine_ENV.split( '\\|' ).any {
		Machine_splited=it
          sh "ssh -q ${sidadm}@${it}   '${exec_stopsap}'" //Stop SAP
          sh "ssh -q ${sidadm}@${it}  '${exec_cleanipc}'" //Clean IPC
     }

} //stage
} //node

