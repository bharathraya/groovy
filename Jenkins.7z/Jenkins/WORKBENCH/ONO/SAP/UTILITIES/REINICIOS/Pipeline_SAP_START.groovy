#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myenv2=params.ENV2
def myapp=params.APP 
def resultCode=""
string Machine=""
 
currentBuild.displayName = "Start: ${myapp} ${myenv}"
currentBuild.description = "Start: ${myapp} ${myenv}"

if ( "${myenv}" == "${myenv2}" ) {
    println("ENV OK")
} else {
    println("ERROR, REVIEW, ENV and ENV2 are not the same")
    return 33;
}

node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/SAP/UTILITIES/REINICIOS/REINICIOS.yml")
                    Opciones=ENVConfig["${myapp}-${myenv}"]
                    sidadm = Opciones[0]
                    Machine_ENV = Opciones[1]
      				Instance_ENV = Opciones[2]
                    Machine_ENV_REVERSE=Machine_ENV.split( '\\|' ).reverse()
                } //stage
} //node
  

node ("fwapptst01") {       
   stage ("StartSap"){
        print "*****************************************************************************"
        print " Start SAP "
        print "*****************************************************************************"
     	print " Starting SAP"
        exec_startsap="""
              setenv count_process `ps -ef |grep dw.sap${Instance_ENV} |grep -v grep | wc -l`
              setenv host `hostname`
              if   ( \$count_process > 0 ) then
                   echo " ****** SAP ${Instance_ENV} IN MACHINE \${host} IS NOT FULLY STOPPED, SO WILL NOT EXECUTE START SAP ******"
              else
              	 startsap
                 if ( \${status} == 0) then
                 	echo  "SAP ${Instance_ENV} IN MACHINE \${host} STARTED OK"
                 else
                 	echo  "ERROR --> SAP ${Instance_ENV} IN MACHINE \${host} HAS NOT STARTED OK" 
                 endif
              endif
              """             
        Machine_ENV_REVERSE.any{
            Machine=it
            //sh "ssh -q ${sidadm}@${Machine}   '${exec_startsap}'" //Start SAP
            SALIDA=sh returnStdout: true, script: "ssh -q ${sidadm}@${Machine} '${exec_startsap}'"
            if ( SALIDA.contains("IS NOT FULLY STOPPED") || SALIDA.contains("NOT STARTED OK"))  {
              	resultCode=1
                error (SALIDA)
				return true 
             } 
            print SALIDA
          }
} //stage
} //node

