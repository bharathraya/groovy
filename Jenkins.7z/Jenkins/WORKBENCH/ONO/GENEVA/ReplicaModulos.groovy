#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

PipelineReplicaModulos([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/GENEVA/pipelineConfig.yml'])
