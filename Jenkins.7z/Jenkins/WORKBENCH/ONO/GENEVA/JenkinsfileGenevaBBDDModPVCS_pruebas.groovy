#!groovy
import net.sf.json.JSONObject
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDataRetriever


//This method is to compile geneva BBDD packages with PVCS modules
//Reads a JSON method wich have modules order and executes them
VFESALMSDataRetriever almsdata=new VFESALMSDataRetriever(PackageInfo)

def dateFormat = new SimpleDateFormat("yyyyMMdd")
def date = new Date()
strDate = dateFormat.format(date)

node("${almsdata._Domain}-${almsdata._DeployEnv}"){
	stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        cleanDirPaquete "${almsdata._ALMS_ID}","${almsdata._server}","${strDate}"
    }
    stage ("checkoutPVCS"){
		//Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        getFromPVCS "${almsdata._ALMS_ID}","${almsdata._DeployEnv}","${almsdata._server}"
    }
    stage ("crearFicheroTemp"){
        //Crea en la ruta tmp un fichero con la ruta completa de los modulos PVCS para pasarselo a carga_bbdd_geneva.sh
        createFileTempPVCS "${almsdata._ALMS_ID}","${almsdata._DeployEnv}","${almsdata._PVCSModules}","${almsdata._server}","${strDate}"
    }
    stage ("ejecucionPVCS"){
        carga_bbdd_geneva "${almsdata._ALMS_ID}","${almsdata._DeployEnv}","${almsdata._Domain}","${almsdata._server}"
    }
}
