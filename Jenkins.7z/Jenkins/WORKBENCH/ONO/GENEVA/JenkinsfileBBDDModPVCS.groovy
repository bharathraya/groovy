#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _Domain=""
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _Aplicacion=""
def _dataModules=""
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _Pvcs=""

def hoy=new Date().format( 'yyyyMMdd' )
def pckInfo=null



print "La fecha de hoy es ......${hoy}......"

if (PackageInfo==""){
    //LLamada desde WB
    callFromWB=false  
}

if (callFromWB){
    pckInfo=readJSON(text: "${PackageInfo}")
    _DeployEnv=pckInfo['DeployEnvironment'].Name
    _Domain=pckInfo['AppDomain'].Name	
    _ALMS_ID=pckInfo.Id.toString()
    _server=pckInfo['AppHost'].Host
    _serverGestdata=pckInfo['AppHost'].Host //Necesitamos guardar esta variable para el gestdatda
    _Aplicacion=pckInfo['ApplicationName']
    
    _dataModules=pckInfo['Modules']
    _Pvcs=pckInfo['Pvcs']
    _HayModulosDatos=pckInfo['Modules'].FileName[0]
    _HayModulosPVCS=pckInfo['Pvcs'].Archive[0]
    
    print "DEBUG: parameter PackageInfo =${PackageInfo}"
    //print "DEBUG: hay modulos de datos ${_HayModulosDatos}"
    //print "DEBUG: hay modulos pvcs ${_HayModulosPVCS}"

    }

node("${_Domain}-${_DeployEnv}"){
    
    stage ("configure"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Aplicacion}"
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_DeployEnv} Aplicación: ${_Aplicacion}"
    }

    stage("comprobaciones"){
        if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
    	    error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
        }
    
        if(_HayModulosDatos == null && _HayModulosPVCS == null)
        {
            error("No hay modulos de datos ni de pvcs")
        }
        
        if ("${env.NODE_NAME}" == "${_server}")
        {
           _server =""
           //  borramos el server para no hacer ssh
        }
       
    }

	stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        //Borrado del directorio temporal de anexo si existe por haberse promocionado otra vez este dia
        cleanDirPaquete "${_ALMS_ID}","${_server}","${hoy}"
    }
    
    stage ("checkoutModulosDatos"){
        if(_HayModulosDatos!= null){
            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
            getFromAnexos "${_ALMS_ID}","${_DeployEnv}","${_server}","${hoy}"
        }
    }
    stage ("checkoutPVCS"){
         if(_HayModulosPVCS!= null){
		 //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
            getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_server}"
         }
    }


    stage ("Ejecutar gestdata"){
        if(_HayModulosDatos!= null){
            
        // Ejecutamos el gestdata para cada modulo de datos
        gestData "${_ALMS_ID}",_dataModules,"${_serverGestdata}","${hoy}","${_DeployEnv}"
        
        //Creamos fichero con los modulos de datos ejecutados en el directorio logs para el gestdata
        //Y los copiamos al .paquete
        createFileDates "${_ALMS_ID}",_dataModules,"${_server}","${hoy}","${_DeployEnv}"
        }
    }
    
    stage ("Creamos fichero temporal"){
          if(_HayModulosPVCS!= null){
         //Ejecutamos el script carga_bbdd_geneva siempre, creamos el fichero si hay pvcs
          createFileTmp "${_ALMS_ID}","${_DeployEnv}","${_server}","${hoy}"
         }
    }
    stage ("ejecucionPVCS"){
         //Ejecutamos el script carga_bbdd_geneva siempre
          carga_bbdd_geneva "${_ALMS_ID}","${_DeployEnv}","${_Domain}","${_server}"
        
    }

}
