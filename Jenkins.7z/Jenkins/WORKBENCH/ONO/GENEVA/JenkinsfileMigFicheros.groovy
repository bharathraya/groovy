#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


// Parametros necesario
def callFromWB=true
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _dataModules=""
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _Pvcs=""
def _Anexos=""

def hoy=new Date().format( 'yyyyMMdd' )
def pckInfo=null


if (PackageInfo==""){
    //LLamada manual
        print "Llamada manual"
        callFromWB=false  
        _DeployEnv=params.Enviroment  
        _ALMS_ID=params.WB_ID  
        _Domain=params.Application
                
    }
    else{
        print "Llamada desde WB "
        callFromWB=true  
        pckInfo=readJSON(text: "${PackageInfo}")
        _DeployEnv=pckInfo['EnvironmentName']
        _Domain=pckInfo['ApplicationName']  

    }

node("${_Domain}-${_DeployEnv}"){
    
    stage ("leer contenido"){
          print "La fecha de hoy es ......${hoy}......"
            
        if (callFromWB){
            //Se llama desde WB
            
            pckInfo=readJSON(text: "${PackageInfo}")
            echo "PackageInfo: ${PackageInfo}"
            
            // Llamo a la función que trae el superpaquete
            (_DeployEnv,_Domain,_ALMS_ID,_server,_Pvcs,_dataModules,_Anexos)=parsePckInfoPVCS(PackageInfo)
            print "Paquete WB ${_ALMS_ID}"
            print "Entorno ${_DeployEnv}"
            print "Dominio ${_Domain}"
            print "Server ${_server}"
            print "Módulos pvcs ${_Pvcs}"
            print "Módulos de datos ${_dataModules}"
            print "Anexos ${_Anexos}"
            
            }else{
                //Se llama de forma manual, leemos los parametros de entrada
                _DeployEnv=params.Enviroment  
                _ALMS_ID=params.WB_ID  
                _Domain=params.Application
                
                print "Paquete WB ${_ALMS_ID}"
                print "Entorno ${_DeployEnv}"
                print "Dominio ${_Domain}"
                
                //Llamo a la funcion que obtiene los datos de WB
                wbpckinfo=get_workbench_package_info(_ALMS_ID)
                
                _server=wbpckinfo.Data.Model.Model.Base.Application.Name
                _Pvcs=wbpckinfo.Data.Model.Model.Contents.PVCS
                _dataModules=wbpckinfo.Data.Model.Model.Modules.Modules
                _Anexos=wbpckinfo.Data.Model.Model.Annexes
                
                print "Server ${_server}"
                print "Módulos pvcs ${_Pvcs}"
                print "Módulos de datos ${_dataModules}"
                print "Anexos ${_Anexos}"
                
            }
            
            //Miramos si hay modulos de datos y de pvcs
            _HayModulosPVCS=_Pvcs.size()
            _HayModulosDatos=_dataModules.size()
            print "Hay módulos de datos  ${_HayModulosDatos}"
            print "Hay módulos de pvcs  ${_HayModulosPVCS}"
        }


    stage ("configure"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Aplicacion}"
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_DeployEnv} Aplicación: ${_Aplicacion}"
        print "NODE_NAME = ${env.NODE_NAME}"

    }
    stage("comprobaciones"){
        
        if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
	        error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
         }
         if( _HayModulosPVCS == 0){
            error("No hay modulos de pvcs")
         }

         if ("${env.NODE_NAME}" == "${_server}")
         {
            _server =""
             //print "DEBUG server ${_server} "
         }
          _server =""
             //print "DEBUG server ${_server} "
    }
	stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        cleanDirPaquete "${_ALMS_ID}","${_server}","${hoy}"
    }
       
	stage ("checkoutPVCS"){
		//Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_server}"
    }
    
	stage ("deploy"){
        //Llamada al mig
        mig "${_Aplicacion}" ,"","${_DeployEnv}","${_ALMS_ID}","${_server}","-Wc"
    }
}
