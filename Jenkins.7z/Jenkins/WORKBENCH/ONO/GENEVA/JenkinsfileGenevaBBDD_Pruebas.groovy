import net.sf.json.JSONObject
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDataRetriever
//import vfes.utils.VFESALMSDModulesRetriever lo hemos eliminado
//import vars.createOrder

//This method is to compile geneva BBDD packages
//Reads a JSON method wich have modules order and executes them
VFESALMSDataRetriever almsdata=new VFESALMSDataRetriever(PackageInfo)

/*def call(String _Alms,String _FileName,String _DbBdName,String _ManagerName,String _DbBdUser,String _DbBdPassword){
    
    def dateFormat = new SimpleDateFormat("yyyyMMdd")
    def date = new Date()
    strDate = dateFormat.format(date)

    exec="""
    . \$HOME/.profile
    . paquete ${_Alms}
    gestdata_2.sh "${DIR_PAQUETE}/${strDate}/${_Alms}" "${_FileName}" "${_DbBdName}" "_${ManagerName}" "${_DbBdUser}" "${_DbBdPassword}"
    """
}*/

def dateFormat = new SimpleDateFormat("yyyyMMdd")
def date = new Date()
strDate = dateFormat.format(date)

node("${almsdata._Domain}-${almsdata._DeployEnv}"){
	stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        cleanDirPaquete "${almsdata._ALMS_ID}","${almsdata._server}","${strDate}"
    }
   stage("TraerModulos"){
    //Nos traemos los modulos que ha dejado WB en es200ahr
    //def call(String _Alms,String _Env,String _remoteServer,String _date){
        getFromAnexos "${almsdata._ALMS_ID}","${almsdata._DeployEnv}","${almsdata._server}","${strDate}"
    }
    stage ("ejecucionDatos"){
        VFESALMSDataRetriever dataModules=new VFESALMSDataRetriever(PackageInfo)
        dataModules.pckInfo.Modules.each { module->
             exec="""
            . \$HOME/.profile
            . paquete 
            gestdata_2.sh "\${DIR_PAQUETE}/${strDate}/anexo/${almsdata._ALMS_ID}/${module.FileName}" "${module.DbBdName}" "${module.ManagerName}" "${module.DbBdUser}" "${module.DbBdPassword}"
            """
            if (_remoteServer!="")
                {
                    sh "ssh -q ${_remoteServer} '${exec}'"
                }
            else
                {
                    sh "${exec}"
                }
        }
    }
    stage ("checkoutPVCS"){
        //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        getFromPVCS "${almsdata._ALMS_ID}","${almsdata._DeployEnv}","${almsdata._server}"
    }
    stage ("crearFicheroTemp"){
        //Crea en la ruta tmp un fichero con la ruta completa de los modulos PVCS para pasarselo a carga_bbdd_geneva.sh
        createFileTempPVCS "${almsdata._ALMS_ID}","${almsdata._DeployEnv}","${almsdata._PVCSModules}","${almsdata._server}","${strDate}"
    }
    stage ("ejecucionPVCS"){
        carga_bbdd_geneva "${almsdata._ALMS_ID}","${almsdata._DeployEnv}","${almsdata._Domain}","${almsdata._server}"
    }
}