#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

PipelineGeneraOrden([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/GENEVA/pipelineConfig.yml'])
