#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/GENEVA/pipelineConfig.yml'])
PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/GENEVA/pipelineConfig.yml',
    applicationChoices:["GENEVA-ONO-FICHEROS","GENEVA-ONO-BBDD","GENEVA-ONO-BILLING","GENEVA-ONO-MAPEOS-BILLING","GENEVA-ONO-RATING","GENEVA-ONO-MAPEOS-RATING","GENEVA-ONO-C","GENEVA-ONO-JAVA","MQ_FACT","MQ_FACT-BBDD"],
	environmentChoices:["SIT1","SIT2","PPRD","PPRD1","SIT3","PROD"]])
