#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _Domain=""
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _dataModules=""
def _Aplicacion =""
def _HayModulosDatos=null

def pckInfo=null
def hoy=new Date().format( 'yyyyMMdd' )

print "La fecha de hoy es ......${hoy}......"

if (PackageInfo==""){
    callFromWB=false  
}


if (callFromWB){
    pckInfo=readJSON(text: "${PackageInfo}")
    _DeployEnv=pckInfo['DeployEnvironment'].Name
    _Domain=pckInfo['AppDomain'].Name	
    _ALMS_ID=pckInfo.Id.toString()
    _server=pckInfo['AppHost'].Host
    _dataModules=pckInfo['Modules']
    _Aplicacion=pckInfo['ApplicationName']
    _HayModulosDatos=pckInfo['Modules'].FileName[0]

    
    //print "DEBUG: parameter PackageInfo =${PackageInfo}"
 	
}


node("${_Domain}-${_DeployEnv}"){
    stage ("configure"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Aplicacion}"
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_DeployEnv} Aplicación: ${_Aplicacion}"
    }
    stage("comprobaciones"){
        if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
    	    error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
        }
    
        if(_HayModulosDatos == null)
        {
            error("No hay modulos de datos")
        }
        
        if ("${env.NODE_NAME}" == "${_server}")
        {
           _server =""
           //  borramos el server para no hacer ssh
        }
    }    

	stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        cleanDirPaquete "${_ALMS_ID}","${_server}","${hoy}"
    }
    stage ("checkoutModulosDatos"){
		//Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        getFromAnexosCat "${_ALMS_ID}","${_DeployEnv}","${_server}","${hoy}"
    }
	stage ("createOrder"){
		//Crear el fichero de orden en la ruta de modulos de datos de la maquina destino
		//Parametros (String _Alms,_dataModules,String _remoteServer,String _date)
		createOrder "${_ALMS_ID}",_dataModules,"${_server}","${hoy}"
    }
    stage ("CheckMapeos"){
		//Llamada al check_mapeos.sh
		//check_mapeos.sh <alms_pck> GENEVA-ONO-MAPEOS-BILLING <environment>
		//Parametros _package,String _env,String _remoteServer,String _Aplicacion
		CheckMapeos "${_ALMS_ID}","${_DeployEnv}","${_server}", "${_Aplicacion}"
    }
	stage ("deploy"){
        //Llamada al sql_gnv.sh
        //sql_gnv.sh -d GENEVA-ONO-MAPEOS-BILLING -e <environment> -p <alms_pck>  
        sql_gnv "${_ALMS_ID}","${_DeployEnv}","${_server}" , "${_Aplicacion}"
    }
}
