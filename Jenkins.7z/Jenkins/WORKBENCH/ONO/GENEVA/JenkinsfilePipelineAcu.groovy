#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/GENEVA/pipelineConfig.yml'])
PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/GENEVA/pipelineConfig.yml',
    applicationChoices:["ACUMULADORES-BBDD","ACUMULADORES-SCRIPTS","ACUMULADORES-CONFIG","ACUMULADORES-JAVA"],
	environmentChoices:["SIT1","SIT2","PPRD","PROD"]])
