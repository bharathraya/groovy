#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _env=""
def WB_ID=""
def _type=""

def hoy=new Date().format( 'yyyyMMdd' )
def _dateLog=new Date().format( 'yyyyMMddHHmmss' )



print "La fecha de hoy es ......${hoy}......"


node("es036tvr"){
    stage("ObtenerDatos"){
        WB_ID=params.WB_ID  
        _env=params.ENV  
        _type=params.TYPE
    
       print "WB ID ${WB_ID}"
       print "Enviroment ${_env}"
       print "Type of package ${_type}"

        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${WB_ID} Env: ${_env} Type: ${_type} "
        currentBuild.description = "WB: ${WB_ID} Env: ${_env} Type: ${_type} "
        
        if (_env =="SONAR1")
        {
            Maquinaremota="smartapptst01"    
        }
        else  if (_env =="SONAR")
        {
            Maquinaremota="smartapptst04"    
        }
         else  if (_env =="SONAR2")
        {
            Maquinaremota="smartapptst03"    
        }
        
        if ( _type == "AMDOCS-SERVER")
        {
            TypeSmart = "ONOServer"
        }
        else
        { 
            TypeSmart  = "ONOClient"
        }
    }
   
    stage("ObtenerDatos"){
         _nombreCarpeta="${WB_ID}_OBS"
         _domain="${_type}-OBSOLETO"
         
         print "nombre de la carpea ${_nombreCarpeta}"
         print "Dominio ${_domain}"
         print "Ejecutamos el txeker"
         txeker("-x",_domain,_env,_nombreCarpeta,WB_ID)
         
    }
}
 node("eswltbhr-amdocs"){
    stage("ObtenerDatos"){
                       
            print "Copiamos el fichero a la máquina ${Maquinaremota} y ejecutamos el obs"                   
            print "Se ejecuta : obs -d CRMSmart -e ${_env} -p ${_nombreCarpeta} -f e"
            print "Se ejecuta: obs_sonar -a ${TypeSmart} -p ${_nombreCarpeta}"
             exec="""
               . \$HOME/.profile >/dev/null 2>&1
                 . paquete  ${_nombreCarpeta}
                 scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${_nombreCarpeta}.${_env}.deploy e
                 obs -d CRMSmart -e ${_env} -p ${_nombreCarpeta} -f e
                 obs_sonar -a ${TypeSmart} -p ${_nombreCarpeta}
               """
            sh "ssh -q ${Maquinaremota} '${exec}'"
            
            print "******************************************************************************************************************"
            print "Revisar que no se quedan directorios vacios!!!"
            print "******************************************************************************************************************"
   }//OBS
                    
}

         

