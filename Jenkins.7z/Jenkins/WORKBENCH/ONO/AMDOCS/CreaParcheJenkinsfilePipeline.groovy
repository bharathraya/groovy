#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

CreaParchepipeline([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml',
OptionChoices:["1","2","3","4"],
TypesChoices:["ALL","AMDOCS-BBDD","AMDOCS-CLIENT","AMDOCS-SERVER", "CRMSmart", "AMDOCS-BPM_APM", "AMDOCS-UPSD", "AMDOCS-CustActionBeans", "AMDOCS-PROCESOS", "AMDOCS-CLARIFY","MQ_NEPTUNO", "AMDOCS-AIF_APM", "APM", "AMDOCS-ESQUEMA","AMDOCS-VISTAS","AMDOCS-IntegracionTOA","ALL except SVN"]])








