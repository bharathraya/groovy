#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


def mybuilduser=""
def _CRQ=""
def _Orden=""
def _OrdenPost=""
def _OrdenPre=""

def hoy=new Date().format( 'yyyyMMdd' )


node("eswltahr"){
    stage("Prepare"){
                //Saco el ejecutor
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
                }
            
            print "La fecha de hoy es ......${hoy}......"
    
            // Parametros entrada
            _CRQ=params.CRQ_ID
            _Orden=params.ORDEN
            _OrdenPost=params.ORDEN_POST
            _OrdenPre=params.ORDEN_PRE
    
            currentBuild.displayName = "Orden a subir a bitbucket para el CRQ: ${_CRQ}" 
            currentBuild.description = "Orden a subir a bitbucket para el CRQ: ${_CRQ}" 

      }//stage
    
    stage("SubirOrden"){
        
        if (_Orden != "" && _OrdenPost != "" && _OrdenPre != "")
        {
            error("Se suben ordenes de  BBDD o de Esquema")
            
        }
        else if (_Orden != "" && _OrdenPost != "" && _OrdenPre == "")
        {
            error("Se suben ordenes de  BBDD o de Esquema")
            
        }
         else if (_Orden != "" && _OrdenPre && _OrdenPost == "")
        {
            error("Se suben ordenes de  BBDD o de Esquema")
            
        }
        
        if (_Orden != "")
        {
            print "Se sube Orden de BBDD"
             execOrden="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_CRQ} PROD_o_no
                rm -Rf *
                touch -f orden.txt
                echo '${_Orden}' >> orden.txt
                SubidaBitBucket.sh -a -p ${_CRQ}
            """            
            
            sh "${execOrden}"
        }
        else if (_OrdenPost != "" && _OrdenPre != "")
        {
            print "Se sube Orden de PRE y POST"
            execOrdenES="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_CRQ} PROD_o_no
                rm -Rf *
                touch -f orden_post.txt orden_pre.txt
                echo '${_OrdenPost}' >> orden_post.txt
                echo '${_OrdenPre}' >> orden_pre.txt
                SubidaBitBucket.sh -a -p ${_CRQ}
            """            
            
            sh "${execOrdenES}"
        }
        else if (_OrdenPost != "" && _OrdenPre == "")
        {
            print "Se sube Orden de POST"
            execOrdenES="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_CRQ} PROD_o_no
                rm -Rf *
                touch -f orden_post.txt
                echo '${_OrdenPost}' >> orden_post.txt
                SubidaBitBucket.sh -a -p ${_CRQ}
            """            
            
            sh "${execOrdenES}"
        }
        else if (_OrdenPost == "" && _OrdenPre != "")
        {
            print "Se sube Orden de PRE"
            execOrdenES="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete ${_CRQ} PROD_o_no
                rm -Rf *
                touch -f orden_pre.txt
                echo '${_OrdenPre}' >> orden_pre.txt
                SubidaBitBucket.sh -a -p ${_CRQ}
            """            
            
            sh "${execOrdenES}"
        }
            
    }//Stage   
    
}//Nodo
