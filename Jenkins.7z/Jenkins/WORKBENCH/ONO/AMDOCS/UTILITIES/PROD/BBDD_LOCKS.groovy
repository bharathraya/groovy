#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def mymodule=params.MODULES
def myenv=params.ENV
def mypass=params.PASS
def VariableSCPBoolean = true
def VariableALL = false
def hoy=new Date().format( 'yyyyMMdd' )

    dateTotal=new Date().format( 'yyyyMMddHHmmss' )


//Configuramos el nombre del build y su descripcion    
currentBuild.displayName = "Checking locks in ${myenv}"
currentBuild.description = "${mymodule}"


if ( "${myenv}" != "PROD" ) {

node ("opetst75-platafor") {       
    
FICHERO="locks.${myenv}.${dateTotal}.txt"    
print "We create file: ${FICHERO}"

stage ("BBDD_LOCKS"){

print "**************************************************"
print " We will check the locks for the selected modules "
print "**************************************************"
exec_BBDD_LOCKS="""
    . ./.profile_refresco >>/dev/null
    cd /home/plataforma/plausr/locks
    if [ -f ${FICHERO} ]
        then
        echo "${FICHERO} exists, we delete and recreate it"
        rm ${FICHERO}
        touch ${FICHERO}
        echo "${mymodule}" >> ${FICHERO}
    else
        echo "We create ${FICHERO}"
        touch ${FICHERO}
        echo "${mymodule}" >> ${FICHERO}
    fi
    /home/plataforma/release/scripts/bbdd_locks -e ${myenv} -f ${FICHERO}
    """
    sh "ssh -q platafor@opetst75 '${exec_BBDD_LOCKS}'" //platafor
    } //stage
} //node

} //if

if ( "${myenv}" == "PROD" ) {

node ("opetst75-platafor") {       
    
FICHERO="locks.${dateTotal}.txt"    
print "We create file: ${FICHERO}"

stage ("BBDD_LOCKS"){

print "**************************************************"
print " We will check the locks for the selected modules "
print "**************************************************"
exec_BBDD_LOCKS="""
    . ./.profile_locks >>/dev/null
    cd /home/plataforma/plausr/locks
    if [ -f ${FICHERO} ]
        then
        echo "${FICHERO} exists, we delete and recreate it"
        rm ${FICHERO}
        touch ${FICHERO}
        echo "${mymodule}" >> ${FICHERO}
    else
        echo "We create ${FICHERO}"
        touch ${FICHERO}
        echo "${mymodule}" >> ${FICHERO}
    fi
    /home/plataforma/release/scripts/bbdd_locks -e ${myenv} -p ${mypass} -f ${FICHERO}
    """
    sh "ssh -q platafor@appcrm01 '${exec_BBDD_LOCKS}'" //platafor
    } //stage
} //node

} //if
