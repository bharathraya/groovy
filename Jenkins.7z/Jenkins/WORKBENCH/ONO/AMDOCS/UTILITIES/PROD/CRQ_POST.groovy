#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myapp=params.COMPROBACION
def mypass=params.PASS
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "${myapp}"
    currentBuild.description = "${myapp}"
    
if ( "${myapp}" == "CHECK_SERVER" || "${myapp}" == "COMPROBAR_TODO" ){
//Comprobacion server
node ("eswltbhr-platafor") {       
   stage ("CHECK_SERVER"){
       print "************************************************"
       print " Comprobramos que se ha hecho SERVER OK en PROD "
       print "************************************************"
       exec_COMP_SERVER="""
       cd /home/plataforma/plausr
       . ./.profile 2>/dev/null
       cd /home/plataforma/release/scripts
       ./check_deploy_smartserver.sh
       """
       sh "ssh -q platafor@smartapptst05 '${exec_COMP_SERVER}'" //platafor
   } //stage
} //node
} //if

if ( "${myapp}" == "CHECK_CAB" || "${myapp}" == "COMPROBAR_TODO" ){
//Comprobacion CAB
node ("eswltbhr-platafor") {       
   stage ("CHECK_CAB"){
       print "*********************************************"
       print " Comprobramos que se ha hecho CAB OK en PROD "
       print "*********************************************"
       exec_COMP_CAB="""
       cd /home/plataforma/plausr
       . ./.profile 2>/dev/null
       cd /home/plataforma/release/scripts
       ./check_CAB.sh
       """
       sh "ssh -q platafor@opetst75 '${exec_COMP_CAB}'" //platafor
   } //stage
} //node
} //if
