#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myapp=params.COMPROBACION
def mypass=params.PASS
def VariableSCPBoolean = true
def VariableALL = false
def Path_Script_pla="E:\\platafor_scripts"
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Comprobacion: ${myapp}"
    currentBuild.description = "Comprobacion: ${myapp}"
    
if ( "${myapp}" == "CRQ_UNIX_CONECTIONS" || "${myapp}" == "COMPROBAR_TODO" ){
//Comprobacion conectividad
node ("eswltbhr-platafor") {       
   stage ("CRQ_UNIX_CONECTIONS"){
       print "*****************************************************************"
       print " Comprobramos las conectividades de SMART necesarias para el CRQ "
       print "*****************************************************************"
       exec_COMP_CONECT_SMART="""
       cd /home/plataforma/release/scripts
       ./check_conections_prod -d CRMSmart
       """
       sh "ssh -q platafor@smartapptst05 '${exec_COMP_CONECT_SMART}'" //platafor
       print "****************************************************************"
       print " Comprobramos las conectividades de CRM necesarias para el CRQ  "
       print "****************************************************************"
       exec_COMP_CONECT_CRM="""
       cd /home/plataforma/release/scripts
       ./check_conections_prod -d AMDOCS
       """
       sh "ssh -q platafor@smartapptst05 '${exec_COMP_CONECT_CRM}'" //platafor
   } //stage
} //node
} //if

if ( "${myapp}" == "CRQ_BBDD_PROCESS" || "${myapp}" == "COMPROBAR_TODO" ){
//Comprobacion conectividad
node ("vwd-descver01"){
stage ("CRQ_BBDD_PROCESS"){
        print "******************************************"
        print " Comprobamos los procesos de la BBDD PGA1 "
        print "******************************************"
            dir ("${Path_Script_pla}"){
                bat("PGA1_PROCESS.bat ${mypass}")
                }
} //stage
} //node
} //if

if ( "${myapp}" == "CRQ_WEBLOGIC_PROCESS" || "${myapp}" == "COMPROBAR_TODO" ){
//Comprobacion conectividad
node ("vwd-descver01"){
stage ("CRQ_WEBLOGIC_PROCESS"){
        print "******************************************************"
        print " Comprobamos los procesos de weblogic de la BBDD PGA1 "
        print "******************************************************"
            dir ("${Path_Script_pla}"){
                bat("PGA1_WEBLOGIC_PROCESS.bat ${mypass}")
                }
} //stage
} //node
} //if
