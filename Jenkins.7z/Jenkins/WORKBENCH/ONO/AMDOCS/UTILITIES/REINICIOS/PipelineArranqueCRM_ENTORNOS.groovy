#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def myclient=params.PCK
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Arranque: ${myapp} ${myenv}"
    currentBuild.description = "Arranque: ${myapp} ${myenv}"
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true_ALL"
}

if ( "${myapp}" == "ALL_MAESTRAS" ) {
VariableALL = "true_MAESTRAS"
}

if ( "${myapp}" == "ALL" || "${myapp}" == "ALL_MAESTRAS" ) {
    
    if (( "${myenv}" == "TGA1" ) || ( "${myenv}" == "TGA2" ) || ( "${myenv}" == "TGA3" ) || ( "${myenv}" == "TGA4" ) || ( "${myenv}" == "TGA21" ) || ( "${myenv}" == "TGA6" )) {
        node ("opetst71-platafor") {
            stage ("Bloqueos_descompilados") {
               print "*******************************************************"
               print " Terminamos bloqueo de ${myenv}                        "
               print "*******************************************************"
               exec_bloqueo_entorno="""
               cd /home/plataforma/release/scripts
               ./end_env_lock ${myenv}
               """
               print (exec_bloqueo_entorno)
               sh "${exec_bloqueo_entorno}" //platafor        
        
               print "**********************************************************************"
               print " Sacamos numero de descompilados de ${myenv} y compilamos si procede "
               print "**********************************************************************"
               exec_recomp_entorno="""
               cd /home/plataforma/release/scripts
               ./check_invalids ${myenv}
               """
               print (exec_recomp_entorno)
               sh "${exec_recomp_entorno}" //platafor    
            } //stage
    
        } //node
    } //if
} //if

if ( "${myapp}" == "PM"  || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) {
    myapp = "PM"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        Cm_0_1 = Opciones[2]
                    } //stage
    
    } //node

    if ( "${myapp}" == "PM" && "${Cm_0_1}" == "0" ) {
        // Arranque PM
        node ("eswltbhr-platafor") {       
            stage ("Arranca_PM_0"){
        
                print "*************************************************"
                print " Arrancamos el PM de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_PM_0="""
                cd ${Path_ENV}
                ./Arrancar_PM_${myenv}.sh 2>/dev/null
                """
                print (exec_arrancar_PM_0)
                sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_PM_0}'" //weblogic
            } //stage
        
        } //node
    } // if

    if ( "${myapp}" == "PM" && "${Cm_0_1}" == "1" ) {
        node ("eswltbhr-platafor") {       
           stage ("Arranque_PM_1"){
        
                print "*************************************************"
                print " Arrancamos PM de ${myenv}                       "
                print "*************************************************"
                exec_arrancar_PM_1="""
                cd ${Path_ENV}
                ./Arranca_PM_${myenv}.sh 2>/dev/null
                """
                print (exec_arrancar_PM_1)
                sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_PM_1}'" //weblogic
                if ( "${myenv}" != "FGA1" ) {
                    print "*************************************************"
                    print " Arrancamos PM_NEW de ${myenv}                   "
                    print "*************************************************"
                    exec_arrancar_APM_1="""
                    cd ${Path_ENV}
                    ./Arranca_APM_NEW_${myenv}.sh 2>/dev/null
                    """
                    print (exec_arrancar_APM_1)
                    sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_APM_1}'" //weblogic
                } // 
            } //stage
        } //node
    } //if
} //if

if ( "${myapp}" == "SERVER"  || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) {
    myapp = "SERVER"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        Cm_0_1 = Opciones[2]
                    } //stage
    
    } //node
    // Parada y arranque SERVER
    node ("eswltbhr-platafor") {       
        stage ("Parada_SERVER_0_1"){
            print "*************************************************"
            print " Paramos SERVER de ${myenv}                      "
            print "*************************************************"
            exec_parar_SERVER_0_1="""
            cd ${Path_ENV}/bin
            ./stopALL.sh 2>/dev/null
            ./kill_weblogic_process.sh 2>/dev/null
            """
            print (exec_parar_SERVER_0_1)
            sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
        } //stage
        stage ("Borrado_SERVER_0_1"){
            print "*************************************************"
            print " Borramos temporales de SERVER en ${myenv}       "
            print "*************************************************"
            exec_borrar_SERVER_0_1="""
            cd ${Path_ENV}
            ./del_tmp
            """
            print (exec_borrar_SERVER_0_1)
            sh "ssh -q weblogic@${Machine_ENV} '${exec_borrar_SERVER_0_1}'" //weblogic
        } //stage
    } //node
    node ("eswltbhr-platafor") { 
        stage ("Arranque_SERVER_0_1"){
            print "*************************************************"
            print " Arrancamos SERVER de ${myenv}                   "
            print "*************************************************"
            exec_arrancar_SERVER_0_1="""
            cd /home/weblogic
            . ./.profile 2>/dev/null
            cd ${Path_ENV}/bin
            ./startAll.sh 2>/dev/null
            """
            print (exec_arrancar_SERVER_0_1)
            sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic        
        } //stage
    } //node
} //if

if (( "${myapp}" == "CLIENT" || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) && ( "${myclient}" == "0" )) {
    myapp = "CLIENT"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        Cm_0_1 = Opciones[2]
                    } //stage
    
    } //node
    // Arranque CLIENT
    node ("VWT-WEBSERVER01"){
       stage ("Arrancar_CLIENT_0_1"){
            print "**********************************************"
            print "Arrancamos CLIENT en ${myenv}                 "
            print "**********************************************"
                dir ("${Path_ENV}"){
        	        bat("Start_Weblogic.bat")
                    }
       } //stage
    } //node
} //if

if (( "${myapp}" == "CLIENT" || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) && ( "${myclient}" == "1" )) {
    myapp = "CLIENT"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        Cm_0_1 = Opciones[2]
                    } //stage
    
    } //node
    // Arranque CLIENT
    node ("VWT-WEBSERVER01"){
       stage ("Arrancar_CLIENT_0_1"){
            print "**********************************************"
            print "Arrancamos CLIENT en ${myenv}                 "
            print "**********************************************"
                dir ("${Path_ENV}"){
        	        bat("Start_Weblogic.bat")
                    }
       } //stage
    } //node
} //if

if ( "${myapp}" == "TUXEDO" || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ){
    myapp = "TUXEDO"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        Cm_0_1 = Opciones[2]
                        Tuxedo_user = Opciones[3]
                    } //stage
    
    } //node

    if ( "${myapp}" == "TUXEDO" ){
        //Arranque TUXEDO
        node ("opedes71-platafor") {       
           stage ("Arranque_TUXEDO"){
               print "*******************************************************"
               print " Arrancamos los tuxedo de ${myenv} en la ${Machine_ENV}"
               print "*******************************************************"
               exec_arrancar_TUXEDO="""
               cd ${Path_ENV}
               . ./.profile_hudson
               cd ${Path_ENV}/AmdocsCRM7.5/FlexibleDeployment/scripts
               ./start_tuxedo.sh
               """
               print (exec_arrancar_TUXEDO)
               sh "ssh -q ${Tuxedo_user}@${Machine_ENV} '${exec_arrancar_TUXEDO}'" //tuxedo
        
               print "**********************************************************************"
               print "Comprobamos el arranque de los tuxedo de ${myenv} en la ${Machine_ENV}"
               print "**********************************************************************"
               exec_comp_TUXEDO="""
               cd ${Path_ENV}
               . ./.profile_hudson
               cd ${Path_ENV}/AmdocsCRM7.5/FlexibleDeployment
               ./checkservers | egrep -v "GROUP2|Faltan|encontrando"
               """
               print (exec_comp_TUXEDO)
               sh "ssh -q ${Tuxedo_user}@${Machine_ENV} '${exec_comp_TUXEDO}'" //tuxedo      
        
           } //stage
        } //node
        if (( "${myenv}" != "TGA4" ) && ( "${myenv}" != "TGA9" ) && ( "${myenv}" != "TGA8" ) && ( "${myenv}" != "TGA7" ) && ( "${myenv}" != "TGA6" )){
            myapp = "TUXEDO2"
            node ("eswldahr") {     
                stage ("Opciones"){
                        checkout scm  
            
                                ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                                Opciones=ENVConfig["${myenv}_${myapp}"]
                                Path_ENV = Opciones[0]
                                Machine_ENV = Opciones[1]
                                Cm_0_1 = Opciones[2]
                                Tuxedo_user = Opciones[3]
                            } //stage
            
            } //node
            node ("opedes71-platafor") {       
               stage ("Arranque_TUXEDO2_0"){
                   print "*******************************************************"
                   print " Arrancamos los tuxedo de ${myenv} en la ${Machine_ENV}"
                   print "*******************************************************"
                   exec_arranca_TUXEDO2="""
                   cd ${Path_ENV}
                   . ./.profile_hudson
                   cd ${Path_ENV}/scripts
                   ./start_tuxedo.sh
                   """
                   print (exec_arranca_TUXEDO2)
                   sh "ssh -q ${Tuxedo_user}@${Machine_ENV} '${exec_arranca_TUXEDO2}'" //tuxedo
            
                   print "**********************************************************************"
                   print "Comprobamos el arranque de los tuxedo de ${myenv} en la ${Machine_ENV}"
                   print "**********************************************************************"
                   exec_comp_TUXEDO2="""
                   cd ${Path_ENV}
                   . ./.profile_hudson
                   cd ${Path_ENV}
                   ./checkservers | egrep -v "GROUP2|Faltan|encontrando"
                   """
                   print (exec_comp_TUXEDO2)
                   sh "ssh -q ${Tuxedo_user}@${Machine_ENV} '${exec_comp_TUXEDO2}'" //tuxedo  
            
               } //stage
            } //node
        } //if
    } //if
} //if

//ARRANQUE RULEMANAGER
if ( "${myapp}" == "RULEMANAGER" || "${myapp}" == "ALL" || "${VariableALL}" == "true_ALL") {
    myapp = "RULEMANAGER"
    node ("eswldahr") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            existe_rulemanager = Opciones[2]
        } //stage
    } //node
    
    // Parada RULEMANAGER
    if ( "${existe_rulemanager}" == "1" ) {
        node ("eswltbhr-platafor") {       
            stage ("Arranque_RULEMANAGER"){
    
                print "*************************************************"
                print " ARRANCAMOS RULEMANAGER de ${myenv}                      "
                print "*************************************************"
                exec_arrancar_RULEMANAGER="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./start_rulemgr 2>/dev/null
                """
                print (exec_arrancar_RULEMANAGER)
                sh "ssh -q clarify@${Machine_ENV} '${exec_arrancar_RULEMANAGER}'" 
            } //stage
        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}

//ARRANQUE MQ
if ( "${myapp}" == "MQ" || "${myapp}" == "ALL" || "${VariableALL}" == "true_ALL") {
    myapp = "MQ"
    node ("eswldahr") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            existe_mq = Opciones[2]
            } //stage
    } //node
    if ( "${existe_mq}" == "1" ) {
        node ("eswltbhr-platafor") {       
            stage ("Parada_MQ"){
                print "*************************************************"
                print " Paramos MQ de ${myenv}                      "
                print "*************************************************"
                exec_arrancar_MQ="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./arrancamq -g ${Machine_ENV}
                """
                print (exec_arrancar_MQ)
                sh "ssh -q mqm@${Machine_ENV} '${exec_arrancar_MQ}'" 
            } //stage
        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
} // if
