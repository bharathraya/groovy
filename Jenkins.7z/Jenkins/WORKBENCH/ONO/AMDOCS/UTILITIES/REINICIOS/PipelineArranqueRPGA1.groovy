#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Arranque: ${myapp} ${myenv}"
    currentBuild.description = "Arranque: ${myapp} ${myenv}"
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true_ALL"
}

if ( "${myapp}" == "PM"  || "${VariableALL}" == "true_ALL" ) {
myapp = "PM"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                } //stage

} //node

if ( "${myapp}" == "PM" ) {
node ("opetst75-platafor") {       
   stage ("Arranque_PM_1"){

        print "*************************************************"
        print " Arrancamos PM de ${myenv}                       "
        print "*************************************************"
        exec_arrancar_PM_1="""
        cd ${Path_ENV}
        ./Arranca_PM_${myenv}.sh 2>/dev/null
        """
        print (exec_arrancar_PM_1)
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_arrancar_PM_1}'" //weblogic

        print "*************************************************"
        print " Arrancamos PM_NEW de ${myenv}                   "
        print "*************************************************"
        exec_arrancar_APM_1="""
        cd ${Path_ENV}
        ./Arranca_APM_NEW_${myenv}.sh 2>/dev/null
        """
        print (exec_arrancar_APM_1)
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_arrancar_APM_1}'" //weblogic
    } //stage
} //node
} //if
} //if

if ( "${myapp}" == "SERVER"  || "${VariableALL}" == "true_ALL" ) {
myapp = "SERVER"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                } //stage

} //node
// Parada y arranque SERVER
node ("opetst75-platafor") {       
    stage ("Parada_SERVER_0_1"){
        print "*************************************************"
        print " Paramos SERVER de ${myenv}                      "
        print "*************************************************"
        exec_parar_SERVER_0_1="""
        cd ${Path_ENV}/bin
        ./stopAll.sh 2>/dev/null
        ./kill_weblogic_process.sh 2>/dev/null
        """
        print (exec_parar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
    } //stage
    stage ("Borrado_SERVER_0_1"){
        print "*************************************************"
        print " Borramos temporales de SERVER en ${myenv}       "
        print "*************************************************"
        exec_borrar_SERVER_0_1="""
        cd ${Path_ENV}
        ./del_tmp
        """
        print (exec_borrar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_borrar_SERVER_0_1}'" //weblogic
    } //stage
} //node
node ("opetst75-platafor") { 
    stage ("Arranque_SERVER_0_1"){
        print "*************************************************"
        print " Arrancamos SERVER de ${myenv}                   "
        print "*************************************************"
        exec_arrancar_SERVER_0_1="""
        cd /home/weblogic
        . ./.profile 2>/dev/null
        cd ${Path_ENV}/bin
        ./startAll.sh 2>/dev/null
        """
        print (exec_arrancar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic        
    } //stage
} //node
} //if

if ( "${myapp}" == "CLIENT" || "${VariableALL}" == "true_ALL" ) {
myapp = "CLIENT"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                } //stage

} //node
// Arranque CLIENT
node ("VWT-WEBSERVER01"){
   stage ("Parar_CLIENT_0_1"){
        print "**********************************************"
        print "Paramos CLIENT en ${myenv}                    "
        print "**********************************************"
            dir ("${Path_ENV}"){
    	        bat("Stop_Weblogic.bat")
                }
   } //stage
   stage ("Arrancar_CLIENT_0_1"){
        print "**********************************************"
        print "Arrancamos CLIENT en ${myenv}                 "
        print "**********************************************"
            dir ("${Path_ENV}"){
    	        bat("Start_Weblogic.bat")
                }
   } //stage
} //node
} //if
