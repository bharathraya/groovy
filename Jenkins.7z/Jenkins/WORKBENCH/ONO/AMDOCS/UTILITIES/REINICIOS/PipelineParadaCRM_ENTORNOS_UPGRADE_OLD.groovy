#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Parada: ${myapp} ${myenv}"
    currentBuild.description = "Parada: ${myapp} ${myenv}"
    
if ( "${myapp}" == "ALL" ) {
    VariableALL = "true"
}


if ( "${myapp}" == "PM" || "${myapp}" == "ALL" ) {
    myapp = "PM"
    node ("eswldahr") {     
        stage ("Opciones"){
            checkout scm  
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]       
        } //stage

    } //node

    if ( "${myapp}" == "PM" ) {
    //Parada PM
        node ("eswltbhr-platafor") {       
            stage ("Parada_PM"){

               print "*************************************************"
               print " Paramos el PM de ${myenv}                       "
               print "*************************************************"
               exec_parar_PM_0="""
               cd ${Path_ENV}
               ./Parar_APM.sh 2>/dev/null
               """
               print (exec_parar_PM_0)
               sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_PM_0}'" //weblogic
               
               print "****************************************"
               print "Comprobamos la parada del APM de ${myenv}"
               print "****************************************"
               exec_comp_apm="""
               if [ \$(ps -fu weblogic | grep -i ${myenv} | grep -v grep | wc -l) -ne 0 ]
                   then
                       echo ""
                       echo "Algo no se ha parado"
                       ps -fu weblogic | grep -i ${myenv} | grep -v grep
                   exit 3
               else
                       echo ""
                       echo "Parada corecta"
               fi
               """
             //sh "ssh -q weblogic@${Machine_ENV} '${exec_comp_apm}'" //weblogic
               print " ejecucion ${exec_comp_apm}"        
           } //stage

        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if

if ( "${myapp}" == "SERVER" || "${myapp}" == "ALL" ) {
    myapp = "SERVER"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    // Parada SERVER
    node ("eswltbhr-platafor") {       
        stage ("Parada_SERVER_0_1"){
    
            print "*************************************************"
            print " Paramos SERVER de ${myenv}                      "
            print "*************************************************"
            exec_parar_SERVER_0_1="""
            cd ${Path_ENV}
            ./stop_Server.sh 2>/dev/null
            """
            print (exec_parar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
        } //stage
    
       //METER BORRADO DE TMPS?
    } //node
    
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}


if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
    myapp = "CLIENT"
    node ("eswldahr") {     
        stage ("Opciones"){
            checkout scm  

            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
        } //stage

    } //node
    // Parada CLIENT
    node ("eswltbhr-platafor") {       
        stage ("Parada_SERVER_0_1"){
    
            print "*************************************************"
            print " Paramos SERVER de ${myenv}                      "
            print "*************************************************"
            exec_parar_SERVER_0_1="""
            cd ${Path_ENV}
            ./stop_JNLP.sh 2>/dev/null
            """
            print (exec_parar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
        } //stage
    }

    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    }
} //if

//PARADA RULEMANAGER
if ( "${myapp}" == "RULEMANAGER" || "${myapp}" == "ALL" ) {
    myapp = "RULEMANAGER"
    node ("eswldahr") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_rulemanager = Opciones[3]
            } //stage
    } //node
    
    // Parada RULEMANAGER
    if ( "${existe_rulemanager}" == "1" ) {
        node ("eswltbhr-platafor") {       
            stage ("Parada_RULEMANAGER"){
    
                print "*************************************************"
                print " Paramos RULEMANAGER de ${myenv}                      "
                print "*************************************************"
                exec_parar_RULEMANAGER="""
                cd ${Path_ENV}
                ./stop_rulemanager.sh 2>/dev/null
                """
                print (exec_parar_RULEMANAGER)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_RULEMANAGER}'" 
            } //stage
        } //node
    } // 
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}

