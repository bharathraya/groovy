#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Comprobacion: ${myapp} ${myenv}"
    currentBuild.description = "Comprobacion: ${myapp} ${myenv}"
    
if ( "${myapp}" == "ALL" ) {
VariableALL = "true"
}

if ( "${myapp}" == "TUXEDO" || "${myapp}" == "ALL" ){
myapp = "TUXEDO"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Cm_0_1 = Opciones[2]
                    Tuxedo_user = Opciones[3]
                } //stage

} //node

if ( "${myapp}" == "TUXEDO" ){
//Comprobacion TUXEDO
node ("opedes71-platafor") {       
   stage ("Comprobacion_TUXEDO"){
       print "****************************************************"
       print " Comprobamos los tuxedo de ${myenv} en la ${Machine_ENV}"
       print "****************************************************"
       exec_comprobar_TUXEDO="""
       cd ${Path_ENV}
       . ./.profile_hudson
       cd ${Path_ENV}/AmdocsCRM7.5/FlexibleDeployment/
       ./checkservers | egrep -v 'GROUP2|Faltan|encontrando'
       """
       print (exec_comprobar_TUXEDO)
       sh "ssh -q ${Tuxedo_user}@${Machine_ENV} '${exec_comprobar_TUXEDO}'" //tuxedo
   } //stage
} //node
if (( "${myenv}" != "TGA4" ) && ( "${myenv}" != "TGA9" ) && ( "${myenv}" != "TGA8" ) && ( "${myenv}" != "TGA7" )){
myapp = "TUXEDO2"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Cm_0_1 = Opciones[2]
                    Tuxedo_user = Opciones[3]
                } //stage

} //node
node ("opedes71-platafor") {       
   stage ("Comprobacion_TUXEDO2_0"){
       print "****************************************************"
       print " Comprobamos los tuxedo de ${myenv} en la ${Machine_ENV}"
       print "****************************************************"
       exec_comprobar_TUXEDO2="""
       cd ${Path_ENV}
       . ./.profile_hudson
       cd ${Path_ENV}
       ./checkservers | egrep -v 'GROUP2|Faltan|encontrando'
       """
       print (exec_comprobar_TUXEDO2)
       sh "ssh -q ${Tuxedo_user}@${Machine_ENV} '${exec_comprobar_TUXEDO2}'" //tuxedo
   } //stage
} //node
} //if
} //if
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
} //if

if ( "${myapp}" == "PM" || "${myapp}" == "ALL" ) {
myapp = "PM"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Cm_0_1 = Opciones[2]
                } //stage

} //node

if ( "${myapp}" == "PM" && "${Cm_0_1}" == "0" ) {
//Comprobacion PM
node ("eswltbhr-platafor") {       
   stage ("Comprobacion_PM_0"){

      print "*************************************************"
       print " Comprobamos el PM de ${myenv}                       "
       print "*************************************************"
       exec_comprobar_PM_0="""
       cd ${Path_ENV}
       ./check_APM.sh
       """        
   } //stage

} //node
} // if

if ( "${myapp}" == "PM" && "${Cm_0_1}" == "1" ){
node ("eswltbhr-platafor") {       
stage ("Comprobacion_PM_1"){

        print "*************************************************"
        print " Comprobamos PM de ${myenv}                 "
        print "*************************************************"
        exec_comprobar_PM_1="""
        cd ${Path_ENV}
        ./check_APM.sh
        """
        print (exec_comprobar_PM_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_comprobar_PM_1}'" //weblogic

        print "*************************************************"
        print " Comprobamos PM_NEW de ${myenv}                 "
        print "*************************************************"
        exec_comprobar_APM_1="""
        cd ${Path_ENV}
        ./check_PM_NEW.sh
        """
        print (exec_comprobar_APM_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_comprobar_APM_1}'" //weblogic

    } //stage
} //node
} //if
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
} //if

if ( "${myapp}" == "SERVER" || "${myapp}" == "ALL" ) {
myapp = "SERVER"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Cm_0_1 = Opciones[2]
                } //stage

} //node
// Comprobacion SERVER
node ("eswltbhr-platafor") {       
    stage ("Comprobacion_SERVER_0_1"){

        print "*************************************************"
        print " Comprobamos SERVER de ${myenv}                      "
        print "*************************************************"
        exec_comprobar_SERVER_0_1="""
        cd ${Path_ENV}/bin
        ./checkAllManaged.sh
        """
        print (exec_comprobar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_comprobar_SERVER_0_1}'" //weblogic
    } //stage
} //node
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
} // if

if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
myapp = "CLIENT"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Cm_0_1 = Opciones[2]
                } //stage

} //node
// Parada CLIENT
node ("VWT-WEBSERVER01"){
stage ("Parada_CLIENT_0_1"){
        print "**********************************************"
        print "Comprobamos CLIENT en ${myenv}                    "
        print "**********************************************"
            dir ("${Path_ENV}"){
                bat("Check.bat")
                }
} //stage
} //node
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
} //if