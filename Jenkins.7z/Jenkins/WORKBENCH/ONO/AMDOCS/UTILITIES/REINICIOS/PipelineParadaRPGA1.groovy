#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Parada: ${myapp} ${myenv}"
    currentBuild.description = "Parada: ${myapp} ${myenv}"
    
if ( "${myapp}" == "ALL" ) {
VariableALL = "true"
}

if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

if ( "${myapp}" == "PM" || "${myapp}" == "ALL" ) {
myapp = "PM"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                } //stage

} //node

if ( "${myapp}" == "PM" ) {
//Parada PM
node ("opetst75-platafor") {       
   stage ("Parada_PM_0"){

        print "*************************************************"
        print " Paramos PM de ${myenv}                 "
        print "*************************************************"
        exec_parar_PM_1="""
        cd ${Path_ENV}
        ./Parar_PM_${myenv}.sh 2>/dev/null
        """
        print (exec_parar_PM_1)
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_parar_PM_1}'" //weblogic

        print "*************************************************"
        print " Paramos PM_NEW de ${myenv}                 "
        print "*************************************************"
        exec_parar_APM_1="""
        cd ${Path_ENV}
        ./Parar_APM_NEW_${myenv}.sh 2>/dev/null
        """
        print (exec_parar_APM_1)
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_parar_APM_1}'" //weblogic

   } //stage

} //node
} // if

if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
} //if

if ( "${myapp}" == "SERVER" || "${myapp}" == "ALL" ) {
myapp = "SERVER"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                } //stage

} //node
// Parada SERVER
node ("opetst75-platafor") {       
    stage ("Parada_SERVER_0_1"){

        print "*************************************************"
        print " Paramos SERVER de ${myenv}                      "
        print "*************************************************"
        exec_parar_SERVER_0_1="""
        cd ${Path_ENV}/bin
        ./stopAll.sh 2>/dev/null
        ./kill_weblogic_process.sh 2>/dev/null
        """
        print (exec_parar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
    } //stage

    stage ("Borrado_SERVER_0_1"){
        print "*************************************************"
        print " Borramos tmp de SERVER de ${myenv}              "
        print "*************************************************"
        exec_borrado_SERVER_0_1="""
        cd ${Path_ENV}
        ./del_tmp
        """
        print (exec_borrado_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_borrado_SERVER_0_1}'" //weblogic

    } //stage
} //node
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
} // if

if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
myapp = "CLIENT"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  

                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                } //stage

} //node
// Parada CLIENT
node ("VWT-WEBSERVER01"){
stage ("Parada_CLIENT_0_1"){
        print "**********************************************"
        print "Paramos CLIENT en ${myenv}                    "
        print "**********************************************"
            dir ("${Path_ENV}"){
                bat("Stop_Weblogic.bat")
                }
} //stage
} //node
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
} //if
