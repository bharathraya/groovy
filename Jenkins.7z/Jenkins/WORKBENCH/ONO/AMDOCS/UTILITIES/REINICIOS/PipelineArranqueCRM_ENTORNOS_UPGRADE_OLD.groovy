#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def myclient=params.PCK
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Arranque: ${myapp} ${myenv}"
    currentBuild.description = "Arranque: ${myapp} ${myenv}"
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true_ALL"
}

if ( "${myapp}" == "ALL_MAESTRAS" ) {
VariableALL = "true_MAESTRAS"
}

//if ( "${myapp}" == "ALL" || "${myapp}" == "ALL_MAESTRAS" ) {
//    
//    if (( "${myenv}" == "TGA1" ) || ( "${myenv}" == "TGA2" ) || ( "${myenv}" == "TGA3" ) || ( "${myenv}" == "TGA4" ) || ( "${myenv}" == "TGA21" ) || ( "${myenv}" == "TGA6" )) {
//        node ("opetst71-platafor") {
//            stage ("Bloqueos_descompilados") {
//               print "*******************************************************"
//               print " Terminamos bloqueo de ${myenv}                        "
//               print "*******************************************************"
//               exec_bloqueo_entorno="""
//               cd /home/plataforma/release/scripts
//               ./end_env_lock ${myenv}
//               """
//               print (exec_bloqueo_entorno)
//               sh "${exec_bloqueo_entorno}" //platafor        
//        
//               print "**********************************************************************"
//               print " Sacamos numero de descompilados de ${myenv} y compilamos si procede "
//               print "**********************************************************************"
//               exec_recomp_entorno="""
//               cd /home/plataforma/release/scripts
//               ./check_invalids ${myenv}
//               """
//               print (exec_recomp_entorno)
//               sh "${exec_recomp_entorno}" //platafor    
//            } //stage
//    
//        } //node
//    } //if
//} //if

if ( "${myapp}" == "PM"  || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) {
    myapp = "PM"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

    if ( "${myapp}" == "PM" ) {
        // Arranque PM
        node ("eswltbhr-platafor") {       
            stage ("Arranca_PM"){
        
                print "*************************************************"
                print " Arrancamos el PM de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_PM_0="""
                cd ${Path_ENV}
                ./Arranca_APM.sh 2>/dev/null
                """
                print (exec_arrancar_PM_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_PM_0}'" //weblogic
            } //stage
        
        } //node
    } // if
} //if

if ( "${myapp}" == "SERVER"  || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) {
    myapp = "SERVER"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    node ("eswltbhr-platafor") { 
        stage ("Arranque_SERVER_0_1"){
            print "*************************************************"
            print " Arrancamos SERVER de ${myenv}                   "
            print "*************************************************"
            exec_arrancar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_Server.sh 2>/dev/null
            """
            print (exec_arrancar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic        
        } //stage
    } //node
} //if

if ( "${myapp}" == "CLIENT" || "${VariableALL}" == "true_ALL" || "${VariableALL}" == "true_MAESTRAS" ) {
    myapp = "CLIENT"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    } //node
    // Arranque CLIENT
    node ("eswltbhr-platafor") { 
       stage ("Arrancar_CLIENT_0_1"){
            print "**********************************************"
            print "Arrancamos CLIENT en ${myenv}                 "
            print "**********************************************"
            exec_arrancar_SERVER_0_1="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_JNLP.sh 2>/dev/null
            """
            print (exec_arrancar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic
       } //stage
    } //node
} //if


//ARRANQUE RULEMANAGER
if ( "${myapp}" == "RULEMANAGER" || "${myapp}" == "ALL" || "${VariableALL}" == "true_ALL") {
    myapp = "RULEMANAGER"
    node ("eswldahr") {     
        stage ("Opciones"){
            checkout scm 
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REINICIOS/REINICIOS_CRM_UPGRADE.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]
            existe_rulemanager = Opciones[3]
        } //stage
    } //node
    
    // Parada RULEMANAGER
    if ( "${existe_rulemanager}" == "1" ) {
        node ("eswltbhr-platafor") {       
            stage ("Arranque_RULEMANAGER"){
    
                print "*************************************************"
                print " ARRANCAMOS RULEMANAGER de ${myenv}                      "
                print "*************************************************"
                exec_arrancar_RULEMANAGER="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./start_rulemanager.sh 2>/dev/null
                """
                print (exec_arrancar_RULEMANAGER)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_RULEMANAGER}'" 
            } //stage
        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}
