#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

myalms_id=params.List_Packages	
entorno=params.WB_ENTORNO
application=params.WB_APP
server=params.SERVER
 _passcm_bot="Temporal01"
 
if ( application == "SERVER"){
    appName="AMDOCS-SERVER"
}
if ( application == "CLIENT"){
    appName="AMDOCS-CLIENT"
}
   
node ("es036tvr") {     
    stage ("dev_sonar"){
        //Configuramos el nombre del build y su descripcion
        //currentBuild.displayName = "WB: ${paquete} Application ${dominio} Enviroment ${entorno}"
        //currentBuild.description = "ID_WB: ${myalms_id}"
        dev_sonar(application,entorno)
    }
}

node ("es1117yw"){
    stage("leer resultado"){
        def json = readJSON(file: "D:\\plataforma\\json\\${application}_${entorno}.json")
        echo "RESULTADO ${json}"
        id=json['SONAR'].id[0]
        email=json['SONAR'].email[0]
        res=json['SONAR'].resultado[0]

        print (res)

        if (res != "20"){
            echo "El resultado es ..... ${res}.....para el ID : ${id}"
            if (res == "0"){
                currentBuild.displayName = " ${id} "
                echo "INFO: Esta todo OK, extraemos."
                promoteApi("cm_bot","4", "${id}", _passcm_bot)
                try{
                    txeker("","${appName}","${entorno}","${id}","${id}")
                }
                catch(Exception e){
                    RechazatorAPI("cm_bot", "ERROR en el testeo.", "${id}",9,"${id}.txt")
                    error "ERROR: No testea"
                }
                promoteApi("cm_bot","6", "${id}", _passcm_bot)
            }
            if (res == "11"){
                echo "ERROR: No se cumplen las dependencias, cambiamos la fecha para que pase a ser el ultimo"
                //Cambiar la fecha al paquete con un update, hacerlo en utc
                promoteApi("cm_bot","3", "${id}", _passcm_bot)
                error ("Dependencias no cumplidas")
            }
        }else{
            echo "No hay ningun WB a procesar ......: ${id}"
            error ("No hay WB a procesar")
        }

    }

    node ("${server}"){
        stage ("Desplegar"){
                sh ("/home/plataforma/release/scripts/sonarWB -d ${application} -p ${id} -m ${email}")
        }
    }

    node ("es036tvr"){
        stage("leer json"){
            def fecha = new SimpleDateFormat("yyyyMMdd")
            def date = new Date()
            strDate=fecha.format(date)
            echo "........................................."
            echo "${strDate}"
            echo "........................................."
            def json = readJSON(file: "/home/plataforma/plausr/data/paquetes/${strDate}/${id}/res_sonar.json")
            res=json.res_sonar

            print (res)

            switch (res){
                case "0":
                    echo "No hay errores en SONAR"
                    txeker("-l","${appName}","${entorno}","${id}","${id}")
                    promoteApi("cm_bot","10", "${id}", _passcm_bot)
                    echo "Notificamos"
                    notifApi("UsrSonar","${id}", "Sonar_2020")
                    echo "Terminado OK"
                    break
                case "41":
                    echo "Error en la compilacion"
                    RechazatorAPI("cm_bot", "ERROR en la compilacion", "${id}",3,"errores_compilacion.${id}.log")
                    break
                case "51":
                    echo "Error en las reglas de SONAR"
                    RechazatorAPI("cm_bot", "ERROR en las reglas de SONAR", "${id}",3,"errores_sonar.${id}.log")
                    break
                case "68":
                    echo "Error en SVN"
                    break
                case "81":
                    echo "Error descargando validacion uiff"
                    break
                case "69":
                    echo "Error en la ejecuion de HUDSON-SONAR, enviado mail a CM para comprobarlo."
                    break
                case "70":
                    echo "Error en la ejecuion de HUDSON-SONAR, enviado mail a CM para comprobarlo."
                    promoteApi("cm_bot","4", "${id}", _passcm_bot)
                    break
                case "20":
                    echo "Hay semaforo, paramos."
                    break
                case "30":
                    error ("No se ha podido traer el codigo de es036tvr.")
                    promoteApi("cm_bot","4", "${id}", _passcm_bot)
                    break
                case "31":
                    RechazatorAPI("cm_bot", "Hay modulos en el paquete que no son de la aplicacion.", "${id}",5)
                    break
                case "32":
                    RechazatorAPI("cm_bot", "El paquete no tiene ningun modulo de la aplicacion.", "${id}",5)
                    break
                case "33":
                    RechazatorAPI("cm_bot", "El paquete no tiene ningun modulo.", "${id}",5)
                    break
                default:
                    echo "Error no controlado"
                    break
            }
        }
    }
}