#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

myalms_id=params.List_Packages	
entorno=params.WB_ENTORNO
application=params.WB_APP
server=params.SERVER

if ( application == "SERVER"){
    appName="AMDOCS-SERVER"
}
if ( application == "CLIENT"){
    appName="AMDOCS-CLIENT"
}
   
node ("es036tvr") {     
    stage ("pre_sonar"){
        //Configuramos el nombre del build y su descripcion
        //currentBuild.displayName = "WB: ${paquete} Application ${dominio} Enviroment ${entorno}"
        //currentBuild.description = "ID_WB: ${myalms_id}"
        pre_sonar(application,entorno)
    }
}

node ("es1117yw"){
    stage("leer resultado"){
        def json = readJSON(file: "D:\\plataforma\\json\\${application}_${entorno}.json")
        echo "RESULTADO ${json}"
        id=json['SONAR'].id[0]
        email=json['SONAR'].email[0]
        res=json['SONAR'].resultado[0]

        print (res)

        if (res != "20"){
            echo "El resultado es ..... ${res}.....para el ID : ${id}"
            if (res == "0"){
                currentBuild.displayName = " ${id} "
                echo "INFO: Esta todo OK, extraemos."
            }
            if (res == "11"){
                echo "ERROR: No se cumplen las dependencias, cambiamos la fecha para que pase a ser el ultimo"
                //Cambiar la fecha al paquete con un update, hacerlo en utc
                _passUsrSonar="Sonar_2020"
                promoteApi("UsrSonar","3", "${id}", _passUsrSonar)
                error ("Dependencias no cumplidas")
            }
            if (res == "21"){
                echo "INFO: Hay uno en tested, terminamos"
                //Cambiar la fecha al paquete con un update, hacerlo en utc
                error ("Ya hay uno en tested.")
            }
        }else{
            echo "No hay ningun WB a procesar ......: ${id}"
            error ("No hay WB a procesar")
        }
    }

}