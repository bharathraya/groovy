#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def VariableSCPBoolean = true
def VariableALL = false
def pass_sa = "Esp1n3t3"

    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Refresco: ${myenv}"
    currentBuild.description = "Refresco: ${myenv}"
     
node ("opetst75-platafor") {       
stage ("Refresco_RDGA1"){

        print "*************************************************"
        print "             Refrescamos RDGA1                   "
        print "*************************************************"
        exec_RDGA1="""
        . ./.profile 2>/dev/null
        cd /home/plataforma/plausr/refresh_RDGA1
        ./despues_refresco.sh SA ${pass_sa} rdga1
        """
        sh "ssh -q platafor@opetst75 '${exec_RDGA1}'" //platafor

    } //stage
} //node
