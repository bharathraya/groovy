#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def CAB_SPPR="/home/crm_spp/release/CRM/PROCESS_MANAGER/compiled/jar/CustActionBeans.jar"    
def VariableSCPBoolean = true
def VariableALL = false
def act_pvcs_svn = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Refresco: ${myapp} ${myenv}"
    currentBuild.description = "Refresco: ${myapp} ${myenv}"
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true"
}

if ( "${myapp}" == "CAB" || "${myapp}" == "ALL" ) {
myapp = "CAB"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Path_ENV_RS = Opciones[3]
                } //stage

} //node

if ( "${myapp}" == "CAB" ){
node ("opetst75-platafor") {       
stage ("Parada_PM_1"){

        print "*************************************************"
        print " Paramos PM de ${myenv}                 "
        print "*************************************************"
        exec_parar_PM_1="""
        cd ${Path_ENV_RS}
        ./Parar_PM_${myenv}.sh 2>/dev/null
        """
        print (exec_parar_PM_1)
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_parar_PM_1}'" //wlrpga1

        print "*************************************************"
        print " Paramos PM_NEW de ${myenv}                 "
        print "*************************************************"
        exec_parar_APM_1="""
        cd ${Path_ENV_RS}
        ./Parar_APM_NEW_${myenv}.sh 2>/dev/null
        """
        print (exec_parar_APM_1)
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_parar_APM_1}'" //wlrpga1

    } //stage
} //node
node ("opetst75-platafor") {       
   stage ("Refesco_CAB"){

        print "*************************************************"
        print " Hacemos backup del CAB para el entorno ${myenv} "
        print "*************************************************"
        exec_backup_CAB="""
        mv ${Path_ENV}/CustActionBeans.jar ${Path_ENV}/CustActionBeans.jar_${_date}
        if [ -f ${Path_ENV}/CustActionBeans.jar_${_date} ]
        then
            echo "Backup OK"
        else
            echo "Error en backup"
            exit 55
        fi    
        """
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_backup_CAB}'" //wlrpga1


		print "****************************************"
        print "Copiamos el CAB para el entorno ${myenv} "
        print "****************************************"
        exec_copia_CAB="""
        scp platafor@opetst75:${CAB_SPPR} ${Path_ENV}
        if [ -f ${Path_ENV}/CustActionBeans.jar ]
        then
            echo "Copia OK"
        else
            echo "Error en copia del jar CAB"
            exit 56
        fi    
        """
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_copia_CAB}'" //weblogic

} //stage
} //node

node ("opetst75-platafor") {       
   stage ("Arranque_PM_1"){

        print "*************************************************"
        print " Arrancamos PM de ${myenv}                       "
        print "*************************************************"
        exec_arrancar_PM_1="""
        cd ${Path_ENV_RS}
        ./Arranca_PM_${myenv}.sh 2>/dev/null
        """
        print (exec_arrancar_PM_1)
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_arrancar_PM_1}'" //wlrpga1

        print "*************************************************"
        print " Arrancamos PM_NEW de ${myenv}                   "
        print "*************************************************"
        exec_arrancar_APM_1="""
        cd ${Path_ENV_RS}
        ./Arranca_APM_NEW_${myenv}.sh 2>/dev/null
        """
        print (exec_arrancar_APM_1)
        sh "ssh -q wlrpga1@${Machine_ENV} '${exec_arrancar_APM_1}'" //wlrpga1
    } //stage
} //node
} //if



if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
} //if

if ( "${myapp}" == "SERVER" || "${myapp}" == "ALL" ) {

myapp = "SERVER"

node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Path_ENV_RS = Opciones[3]
                } //stage

} //node

node ("opetst75-platafor") {       
    stage ("Parada_SERVER_0_1"){

        print "*************************************************"
        print " Paramos SERVER de ${myenv}                      "
        print "*************************************************"
        exec_parar_SERVER_0_1="""
        cd ${Path_ENV_RS}/bin
        ./stopAll.sh 2>/dev/null
        ./kill_weblogic_process.sh 2>/dev/null
        """
        print (exec_parar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
    } //stage

    stage ("Borrado_SERVER_0_1"){
        print "*************************************************"
        print " Borramos tmp de SERVER de ${myenv}              "
        print "*************************************************"
        exec_borrado_SERVER_0_1="""
        cd ${Path_ENV_RS}
        ./del_tmp
        """
        print (exec_borrado_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_borrado_SERVER_0_1}'" //weblogic

    } //stage
} //node

node ("eswltbhr-platafor"){
   stage ("Gen_ZIP-SERVER"){
        print "************************************************"
        print "Hacemos zip de la release de unix para ${myenv} "
        print "************************************************"
        exec_SERVER_UNIX_zip="""
        cd /home/smart/sppr/release/CRMSmart/
        zip -r ONOServer_sppr.zip ONOServer
        """
        sh "ssh -q smartre@smartapptst05 '${exec_SERVER_UNIX_zip}'" //smartre

        print "************************************************"
        print "Llevamos el zip a la maquina de ${myenv}        "
        print "************************************************"
        exec_SERVER_UNIX_copia="""
        cd /home/smart/sppr/release/CRMSmart
        scp ONOServer_sppr.zip smartre@${Machine_ENV}:/home/smart/release/CRMSmart
        """
        sh "ssh -q smartre@smartapptst05 '${exec_SERVER_UNIX_copia}'" //smartre

   } //stage
} //node

node ("opetst75-platafor"){
    stage ("Refresco_SERVER"){

        print "**********************************************"
        print "Refrescamos SMART SERVER de ${myenv}          "
        print "**********************************************"
        exec_copia_SERVER_1="""
            export FOUND=Y
            while [ "\${FOUND}" = "Y" ]
            do
                    echo "Checking if exist another execution..."
                    if [ -f /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem ]
                    then
                            echo  "we find a semaphore /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem , waiting 10 seconds ..."
                            sleep 10
                    else
                            echo REFRESCO > /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem
                            echo  "Creado semaforo /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem"
                            FOUND=N
                    fi
            done  
            echo "Borramos los backups antiguos de ONOServer de la release"
            cd ${Path_ENV}
            rm -rf ONOServer_refresco_*.zip
            
            cd /home/smart/release/CRMSmart
            echo "Hacemos backup si es que no se ha hecho ya"
            if [ ! -f ONOServer_refresco_${_date}.zip ]
                then
                    echo "No existe backup de hoy, lo hacemos"
                    zip -r ONOServer_refresco_${_date}.zip ONOServer
            fi
            if [ -f ${Path_ENV}/ONOServer_refresco_${_date}.zip ]
                then
                    echo "Backup OK"
                else
                    echo "No se ha hecho el Backup, por favor, revisad"
                    exit 58
            fi

            echo "Borramos ONOServer de la release"
            cd ${Path_ENV}
            rm -rf ONOServer
            if [ -d ${Path_ENV}/ONOServer ]
                then
                    echo "No se ha borrado bien la release, comprobad"
                    exit 59
                else
                    echo "Borrado OK"
            fi

            echo "Traemos el zip de SPPR"
            scp platafor@smartapptst05:/home/smart/sppr/release/CRMSmart/ONOServer_sppr.zip ${Path_ENV}
            if [ -f ${Path_ENV}/ONOServer_sppr.zip ]
                then
                    echo "ZIP traido OK"
                else
                    echo "ZIP no traido OK, revisad"
                    exit 60
            fi

            echo "Descomprimimos el ZIP en la release"
            cd ${Path_ENV}
            unzip -o ONOServer_sppr.zip
            if [ -d ${Path_ENV}/ONOServer ]
                then
                    echo "ZIP descomprimido OK, lo borramos"
                    rm -rf ONOServer_sppr.zip
                else
                    echo "ERROR al descomprimir el ZIP, revisad"
                    exit 61
            fi

            echo "Borramos el semaforo generado para el refresco"
            rm -f /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem
        """
        sh "ssh -q smartre@${Machine_ENV} '${exec_copia_SERVER_1}'" //smartre
} //stage
} //node

// Ejecutar deploy_smartserver_cm
node ("opetst75-platafor") {       
    stage ("Deploy_SERVER_0_1"){

        print "*************************************************"
        print " Ejecutamos deploy_smartserver_cm de ${myenv}    "
        print "*************************************************"
        exec_Deploy_SERVER_0_1="""
        cd /home/weblogic/scripts_cm
        ./deploy_smartserver_cm
        """
        print (exec_Deploy_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_Deploy_SERVER_0_1}'" //weblogic
    } //stage

} //node


// Arranque SERVER
node ("opetst75-platafor") {       
    stage ("Arranque_SERVER_0_1"){

        print "*************************************************"
        print " Arrancamos SERVER de ${myenv}                   "
        print "*************************************************"
        exec_arrancar_SERVER_0_1="""
        cd /home/weblogic
        . ./.profile 2>/dev/null
        cd ${Path_ENV_RS}/bin
        ./startAll.sh 2>/dev/null
        """
        print (exec_arrancar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic
    } //stage

} //node

} //if

if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if

if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" ) {
myapp = "CLIENT"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Path_ENV_RS = Opciones[3]
                } //stage

} //node
// Parada CLIENT
node ("VWT-WEBSERVER01"){
stage ("Parada_CLIENT_0_1"){
        print "**********************************************"
        print "Paramos CLIENT en ${myenv}                    "
        print "**********************************************"
            dir ("${Path_ENV_RS}"){
                bat("Stop_Weblogic.bat")
                }
} //stage
} //node

stage ("Refresco_COPIA_CLIENT"){
    node ("eswltbhr-platafor"){
        exec_copia_release_client="""
        if [ -d /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv} ]
            then
                echo "Existe el directorio, lo borramos y lo creamos de 0"
                rm -rf /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}
                mkdir -p /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}
            else
                echo "No existe el directorio, lo creamos y traemos los ficheros"
                mkdir -p /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}
        fi
        scp smartre@smartapptst05:/home/smart/sppr/release/CRMSmart/ONOClient/compiled/jar/output/* /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}
        """
        sh "${exec_copia_release_client}"
    } //node
        node ("eswltbhr-platafor"){
 	        dir("/home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}"){
 	        stash name: 'sources', includes: '**/*'
	   	    } // dir
	    } // node
    node ("VWT-WEBSERVER01"){
            dir("c:\\Inetpub\\ftproot\\RPGA1"){
    	    unstash name: 'sources'
    	    } //dir
  	} //node
} //stage


node ("eswltbhr-platafor"){
   stage ("Refresco_CLIENT"){
        print "************************************************"
        print "Hacemos zip de la release de unix para ${myenv} "
        print "************************************************"
        exec_CLIENT_UNIX_zip="""
        cd /home/smart/sppr/release/CRMSmart/
        zip -r ONOClient_sppr.zip ONOClient
        """
        sh "ssh -q smartre@smartapptst05 '${exec_CLIENT_UNIX_zip}'" //smartre

        print "************************************************"
        print "Llevamos el zip a la maquina de ${myenv}        "
        print "************************************************"
        exec_CLIENT_UNIX_copia="""
        cd /home/smart/sppr/release/CRMSmart
        scp ONOClient_sppr.zip smartre@${Machine_ENV}:/home/smart/release/CRMSmart
        """
        sh "ssh -q smartre@smartapptst05 '${exec_CLIENT_UNIX_copia}'" //smartre

   } //stage
} //node

node ("opetst75-platafor") {
    stage ("Refresco_CLIENT"){
        print "******************************************************************"
        print "Hacemos backup de release y descomprimimos nuevo zip para ${myenv}"
        print "******************************************************************"
        exec_CLIENT_UNIX_bck="""
        cd /home/smart/release/CRMSmart
        echo "Borramos backups antiguos de la releaes de ONOClient"
        rm -rf ONOClient_refresco_*.zip
        echo "Hacemos backups de la release de ONOClient"
        zip -r ONOClient_refresco_${_date}.zip ONOClient
        if [ -f /home/smart/release/CRMSmart/ONOClient_refresco_${_date}.zip ]
            then
                unzip -o ONOClient_sppr.zip
                if [ -d /home/smart/release/CRMSmart/ONOClient_sppr ]
                then
                mv ONOClient_sppr ONOClient
                fi
                if [ -d /home/smart/release/CRMSmart/ONOClient ]
                    then
                        echo "Codigo descomprimido OK"
                    else
                        echo "Algo ha fallado al descomprimir, revisad"
                        exit 66
                fi
            else
                echo "Ha fallado la creacion del backup, revisad"
                exit 66
        fi
        """
        sh "ssh -q smartre@${Machine_ENV} '${exec_CLIENT_UNIX_bck}'" //smartre

    } //stage
} //node

// Ejecucion bat
node ("VWT-WEBSERVER01"){
   stage ("CLIENT_bat_1"){
        print "**********************************************"
        print "Ejecutamos .bat en NT para ${myenv}           "
        print "**********************************************"
            dir ("C:\\plataforma\\Scripts\\Refrescos_CRM"){
    	        bat("refresco_client.bat ${myenv}")
                }
   } //stage
} //node

// Arranque CLIENT
node ("VWT-WEBSERVER01"){
stage ("Arranca_CLIENT_0_1"){
        print "**********************************************"
        print "Arrancamos CLIENT en ${myenv}                 "
        print "**********************************************"
            dir ("${Path_ENV_RS}"){
                bat("Start_Weblogic.bat")
                }
} //stage
} //node

} //if
