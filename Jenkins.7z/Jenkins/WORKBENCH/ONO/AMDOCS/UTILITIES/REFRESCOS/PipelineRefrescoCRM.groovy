#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myenv2=params.ENV2
def myapp=params.APP
def CAB_SPPR="/home/crm_spp/release/CRM/PROCESS_MANAGER/compiled/jar/CustActionBeans.jar"    
def VariableSCPBoolean = true
def VariableALL = false
def VariableALL_EXCEPT = false
def act_pvcs_svn = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Refresco: ${myapp} ${myenv}"
    currentBuild.description = "Refresco: ${myapp} ${myenv}"

if ( "${myenv}" == "${myenv2}" ) {
    println("ENV OK")
} else {
    println("ERROR, REVIEW, ENV and ENV2 are not the same")
    return 33;
}

if ( "${myapp}" == "ALL" ) {
VariableALL = "true"
}
if ( "${myapp}" == "ALL_EXCEPT_MANMTO" ) {
VariableALL_EXCEPT = "true"
}

if ( "${myapp}" == "ACT_PVCS_SVN" ) {
    if ( "${myenv}" == "TGA4" || "${myenv}" == "TGA1" || "${myenv}" == "TGA6" || "${myenv}" == "TGA2" || "${myenv}" == "TGA21" || "${myenv}" == "TGA3" ) {
        act_pvcs_svn = "true"
        } //if
    else
        {
        act_pvcs_svn = "false"
        }
}

if ( "${myapp}" == "MANMTO_CM" || "${myapp}" == "ALL" ) {
myapp = "MANMTO_CM"
if ( "${myenv}" != "TGA9" ) {
node ("opetst75-platafor") {       
    stage ("MANMTO_CM_BBDD"){

       print "*************************************************"
       print "      Creamos MANMTO_CM en ${myenv}              "
       print "*************************************************"
       exec_MANMTO_CM_BBDD="""
       . /home/plataforma/plausr/.profile_refresco 2>/dev/null
       cd /home/plataforma/plausr/refresh
       ./despues_refresco.sh MANMTO_CM MANMTO_CM77 ${ENV}
       """
       print (exec_MANMTO_CM_BBDD)
       sh "${exec_MANMTO_CM_BBDD}" //platafor
   } //stage
} //node
}
if ( "${myenv}" == "TGA9" ) {
node ("opetst75-platafor") {       
    stage ("MANMTO_CM_BBDD"){

       print "*************************************************"
       print "      Creamos MANMTO_CM en ${myenv}              "
       print "*************************************************"
       exec_MANMTO_CM_BBDD="""
       . /home/plataforma/plausr/.profile_refresco 2>/dev/null
       cd /home/plataforma/plausr/refresh
       ./despues_refresco_TGA9.sh MANMTO_CM MANMTO_CM77 ${ENV}
       """
       print (exec_MANMTO_CM_BBDD)
       sh "${exec_MANMTO_CM_BBDD}" //platafor
   } //stage
} //node
}
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
}


if ( "${myapp}" == "CAB" || "${myapp}" == "ALL" || "${myapp}" == "ALL_EXCEPT_MANMTO" ) {
myapp = "CAB"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node

if ( "${myapp}" == "CAB" && "${Cm_0_1}" == "0" ) {
// Refresco de Cust Action Beans
node ("eswltbhr-platafor") {       
    stage ("Parada_PM_0"){

       print "*************************************************"
       print " Paramos el PM de ${myenv}                       "
       print "*************************************************"
       exec_parar_PM_0="""
       cd ${Path_ENV_RS}
       ./Parar_PM_${myenv}.sh 2>/dev/null
       """
       print (exec_parar_PM_0)
       sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_PM_0}'" //weblogic
   } //stage
    
    stage ("Refesco_CAB"){
        print "*************************************************"
        print " Hacemos backup del CAB para el entorno ${myenv} "
        print "*************************************************"
        exec_backup_CAB="""
        mv ${Path_ENV}/CustActionBeans.jar ${Path_ENV}/CustActionBeans.jar_${_date}
        if [ -f ${Path_ENV}/CustActionBeans.jar_${_date} ]
        then
            echo "Backup OK"
        else
            echo "Error en backup"
            exit 55
        fi    
        """
        print (exec_backup_CAB)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_backup_CAB}'" //weblogic

        print "****************************************"
        print "Copiamos el CAB para el entorno ${myenv} "
        print "****************************************"
        exec_copia_CAB="""
        scp platafor@opetst75:${CAB_SPPR} ${Path_ENV}
        if [ -f ${Path_ENV}/CustActionBeans.jar ]
        then
            echo "Copia OK"
        else
            echo "Error en copia del jar CAB"
            exit 56
        fi    
        """
        sh "ssh -q weblogic@${Machine_ENV} '${exec_copia_CAB}'" //weblogic
} //node
    node ("eswltbhr-platafor") {       
        stage ("Arranca_PM_0"){

            print "*************************************************"
            print " Arrancamos el PM de ${myenv}                    "
            print "*************************************************"
            exec_arrancar_PM_0="""
            cd ${Path_ENV_RS}
            ./Arranca_PM_${myenv}.sh 2>/dev/null
            """
            print (exec_arrancar_PM_0)
            sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_PM_0}'" //weblogic     
        } //stage

} //node
} //node
} //if

if ( "${myapp}" == "CAB" && "${Cm_0_1}" == "1" ){
node ("eswltbhr-platafor") {       
stage ("Parada_PM_1"){

        print "*************************************************"
        print " Paramos PM de ${myenv}                 "
        print "*************************************************"
        exec_parar_PM_1="""
        cd ${Path_ENV_RS}
        ./Parar_PM_${myenv}.sh 2>/dev/null
        """
        print (exec_parar_PM_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_PM_1}'" //weblogic

        print "*************************************************"
        print " Paramos PM_NEW de ${myenv}                 "
        print "*************************************************"
        exec_parar_APM_1="""
        cd ${Path_ENV_RS}
        ./Parar_APM_NEW_${myenv}.sh 2>/dev/null
        """
        print (exec_parar_APM_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_APM_1}'" //weblogic

    } //stage
} //node
node ("eswltbhr-platafor") {       
   stage ("Refesco_CAB"){

        print "*************************************************"
        print " Hacemos backup del CAB para el entorno ${myenv} "
        print "*************************************************"
        exec_backup_CAB="""
        mv ${Path_ENV}/CustActionBeans.jar ${Path_ENV}/CustActionBeans.jar_${_date}
        if [ -f ${Path_ENV}/CustActionBeans.jar_${_date} ]
        then
            echo "Backup OK"
        else
            echo "Error en backup"
            exit 55
        fi    
        """
        sh "ssh -q weblogic@${Machine_ENV} '${exec_backup_CAB}'" //weblogic


		print "****************************************"
        print "Copiamos el CAB para el entorno ${myenv} "
        print "****************************************"
        exec_copia_CAB="""
        scp platafor@opetst75:${CAB_SPPR} ${Path_ENV}
        if [ -f ${Path_ENV}/CustActionBeans.jar ]
        then
            echo "Copia OK"
        else
            echo "Error en copia del jar CAB"
            exit 56
        fi    
        """
        sh "ssh -q weblogic@${Machine_ENV} '${exec_copia_CAB}'" //weblogic

} //stage
} //node

node ("eswltbhr-platafor") {       
   stage ("Arranque_PM_1"){

        print "*************************************************"
        print " Arrancamos PM de ${myenv}                       "
        print "*************************************************"
        exec_arrancar_PM_1="""
        cd ${Path_ENV_RS}
        ./Arranca_PM_${myenv}.sh 2>/dev/null
        """
        print (exec_arrancar_PM_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_PM_1}'" //weblogic

        print "*************************************************"
        print " Arrancamos PM_NEW de ${myenv}                   "
        print "*************************************************"
        exec_arrancar_APM_1="""
        cd ${Path_ENV_RS}
        ./Arranca_APM_NEW_${myenv}.sh 2>/dev/null
        """
        print (exec_arrancar_APM_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_APM_1}'" //weblogic
    } //stage
} //node
} //if
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
if ( "${VariableALL_EXCEPT}" == "true" ) {
myapp = "ALL_EXCEPT_MANMTO"
} //if
} //if


if ( "${myapp}" == "SERVER" || "${myapp}" == "ALL" || "${myapp}" == "ALL_EXCEPT_MANMTO" ) {
myapp = "SERVER"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node


if ( "${myapp}" == "SERVER" && "${Cm_0_1}" == "0" ) {

node ("eswltbhr-platafor") {       
    stage ("Parada_SERVER_0_1"){

        print "*************************************************"
        print " Paramos SERVER de ${myenv}                      "
        print "*************************************************"
        exec_parar_SERVER_0_1="""
        cd ${Path_ENV_RS}/bin
        ./stopAll.sh 2>/dev/null
        """
        print (exec_parar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
    } //stage

    stage ("Borrado_SERVER_0_1"){
        print "*************************************************"
        print " Borramos tmp de SERVER de ${myenv}              "
        print "*************************************************"
        exec_borrado_SERVER_0_1="""
        cd ${Path_ENV_RS}
        ./del_tmp
        """
        print (exec_borrado_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_borrado_SERVER_0_1}'" //weblogic

    } //stage
} //node

node ("eswltbhr-platafor"){

    stage ("Refresco_SERVER"){

        print "**********************************************"
        print "Generamos ZIP de SMART SERVER para ${myenv}   "
        print "**********************************************"
        exec_zip_SERVER_weblogic="""
            echo "Generamos ZIP de los JARs"
            cd /home/smart/sppr/release/CRMSmart/ONOServer/project/lib/
            if [ -f ONOServer_PROD_JARS.zip ]
            then
                rm -f ONOServer_PROD_JARS.zip
            fi
            zip -r ONOServer_PROD_JARS *.jar
                if [ -f /home/smart/sppr/release/CRMSmart/ONOServer/project/lib/ONOServer_PROD_JARS.zip ]
                    then
                        echo "ZIP SERVER LIB GENERADO OK"
                    else
                        echo "ERROR AL GENERAR ZIP SERVER LIB"
                        exit 54
                fi
            cd /home/smart/sppr/release/CRMSmart/IntegracionTOA/IntegracionTOAEAR/target
            if [ -f TOA_PROD_JAR.zip ]
            then
                rm -f TOA_PROD_JAR.zip
            fi
            zip -r TOA_PROD_JAR IntegracionTOA.ear
            if [ -f /home/smart/sppr/release/CRMSmart/IntegracionTOA/IntegracionTOAEAR/target/TOA_PROD_JAR.zip ]
                then
                    echo "ZIP TOA GENERADO OK"
                else
                    echo "ERROR AL GENERAR ZIP TOA EAR"
                    exit 54
            fi
        """
        sh "ssh -q smartre@smartapptst05 '${exec_zip_SERVER_weblogic}'" //smartre

        print "**********************************************"
        print "Refrescamos SMART SERVER de ${myenv}          "
        print "**********************************************"
        exec_copia_SERVER_0="""
            echo "Copying from smartapptst05 neccesary jars to ${Path_ENV}/ClfyAgent.war/WEB-INF/lib"
            scp platafor@smartapptst05:/home/smart/sppr/release/CRMSmart/ONOServer/project/lib/ONOServer_PROD_JARS.zip ${Path_ENV}/ClfyAgent.war/WEB-INF/lib
            scp platafor@smartapptst05:/home/smart/sppr/release/CRMSmart/IntegracionTOA/IntegracionTOAEAR/target/TOA_PROD_JAR.zip ${Path_ENV}/ClfyAgent.war/WEB-INF/lib
            if [ -f ${Path_ENV}/ClfyAgent.war/WEB-INF/lib/ONOServer_PROD_JARS.zip ]
                then
                    echo "Descomprimimos ZIP con los JARS"
                    cd ${Path_ENV}/ClfyAgent.war/WEB-INF/lib
                    unzip -o ONOServer_PROD_JARS.zip
                    rm -f ONOServer_PROD_JARS.zip
                else
                    echo "ZIP SERVER LIBS no copiado correctamente"
                    exit 56
            fi
            if [ -f ${Path_ENV}/ClfyAgent.war/WEB-INF/lib/TOA_PROD_JAR.zip ]
                then
                    echo "Descomprimimos ZIP del EAR de TOA"
                    cd ${Path_ENV}/ClfyAgent.war/WEB-INF/lib
                    unzip -o TOA_PROD_JAR.zip
                    rm -f TOA_PROD_JAR.zip
                else
                    echo "ZIP EAR TOA no copiado correctamente"
                    exit 56
            fi
            echo "Deleting and copying ONOServer__VPVCS.jar"
            rm ${Path_ENV}/ClfyAgent.war/WEB-INF/lib/ONOServer__VPVCS.jar
            scp platafor@smartapptst05:/home/smart/sppr/release/CRMSmart/ONOServer/compiled/ONOServer__VPVCS.jar ${Path_ENV}/ClfyAgent.war/WEB-INF/lib
            if [ -f ${Path_ENV}/ClfyAgent.war/WEB-INF/lib/ONOServer__VPVCS.jar ]
                then
                    echo "ONOServer__VPVCS.jar copiado OK"
                else
                    echo "ONOServer__VPVCS.jar NO COPIADO, por favor, REVISAD"
                    exit 57
            fi
            echo "Copying from ${Path_ENV}/ClfyAgent.war/WEB-INF/lib/ClfyXvo.jar to /home/weblogic/AmdocsCRM7.5/AmdocsCRMApplication/ClfyAgent"
            rm /home/weblogic/AmdocsCRM7.5/AmdocsCRMApplication/ClfyAgent/ClfyXvo.jar
            cp ${Path_ENV}/ClfyAgent.war/WEB-INF/lib/ClfyXvo.jar /home/weblogic/AmdocsCRM7.5/AmdocsCRMApplication/ClfyAgent
            if [ -f /home/weblogic/AmdocsCRM7.5/AmdocsCRMApplication/ClfyAgent/ClfyXvo.jar ]
                then
                    echo "ClfyXvo.jar copiado OK"
                else
                    echo "ClfyXvo.jar NO COPIADO, por favor, REVISAD"
                    exit 57
            fi
        """
        sh "ssh -q weblogic@${Machine_ENV} '${exec_copia_SERVER_0}'" //weblogic
} //stage
} //node
// Arranque SERVER
node ("eswltbhr-platafor") {       
    stage ("Arranque_SERVER_0_1"){

        print "*************************************************"
        print " Arrancamos SERVER de ${myenv}                   "
        print "*************************************************"
        exec_arrancar_SERVER_0_1="""
        cd /home/weblogic
        . ./.profile 2>/dev/null
        cd ${Path_ENV_RS}/bin
        ./startAll.sh 2>/dev/null
        """
        print (exec_arrancar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic
    } //stage

} //node
} //if

if ( "${myapp}" == "SERVER" && "${Cm_0_1}" == "1" ) {

node ("eswltbhr-platafor") {       
    stage ("Parada_SERVER_0_1"){

        print "*************************************************"
        print " Paramos SERVER de ${myenv}                      "
        print "*************************************************"
        exec_parar_SERVER_0_1="""
        cd ${Path_ENV_RS}/bin
        ./stopAll.sh 2>/dev/null
        ./kill_weblogic_process.sh 2>/dev/null
        """
        print (exec_parar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_parar_SERVER_0_1}'" //weblogic
    } //stage

    stage ("Borrado_SERVER_0_1"){
        print "*************************************************"
        print " Borramos tmp de SERVER de ${myenv}              "
        print "*************************************************"
        exec_borrado_SERVER_0_1="""
        cd ${Path_ENV_RS}
        ./del_tmp
        """
        print (exec_borrado_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_borrado_SERVER_0_1}'" //weblogic

    } //stage
} //node

node ("eswltbhr-platafor"){
   stage ("Gen_ZIP-SERVER"){
        print "************************************************"
        print "Hacemos zip de la release de unix para ${myenv} "
        print "************************************************"
        exec_SERVER_UNIX_zip="""
        cd /home/smart/sppr/release/CRMSmart/
        zip -r ONOServer_sppr.zip ONOServer
        zip -r INTEGRACION_TOA_PROD.zip IntegracionTOA
        """
        sh "ssh -q smartre@smartapptst05 '${exec_SERVER_UNIX_zip}'" //smartre

        print "************************************************"
        print "Llevamos el zip a la maquina de ${myenv}        "
        print "************************************************"
        exec_SERVER_UNIX_copia="""
        cd /home/smart/sppr/release/CRMSmart
        scp ONOServer_sppr.zip smartre@${Machine_ENV}:/home/smart/release/CRMSmart
        scp INTEGRACION_TOA_PROD.zip smartre@${Machine_ENV}:/home/smart/release/CRMSmart
        """
        sh "ssh -q smartre@smartapptst05 '${exec_SERVER_UNIX_copia}'" //smartre

   } //stage
} //node

node ("eswltbhr-platafor"){
    stage ("Refresco_SERVER"){

        print "**********************************************"
        print "Refrescamos SMART SERVER de ${myenv}          "
        print "**********************************************"
        exec_copia_SERVER_1="""
            export FOUND=Y
            while [ "\${FOUND}" = "Y" ]
            do
                    echo "Checking if exist another execution..."
                    if [ -f /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem ]
                    then
                            echo  "we find a semaphore /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem , waiting 10 seconds ..."
                            sleep 10
                    else
                            echo REFRESCO > /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem
                            echo  "Creado semaforo /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem"
                            FOUND=N
                    fi
            done  

            cd /home/smart/release/CRMSmart
            echo "Hacemos backup si es que no se ha hecho ya"
            if [ ! -f ONOServer_${_date}.zip ]
                then
                    echo "No existe backup de hoy, lo hacemos"
                    zip -r ONOServer_${_date}.zip ONOServer
            fi
            if [ -f ${Path_ENV}/ONOServer_${_date}.zip ]
                then
                    echo "Backup OK"
                else
                    echo "No se ha hecho el Backup, por favor, revisad"
                    exit 58
            fi
            if [ ! -f IntegracionTOA_${_date}.zip ]
                then
                    echo "No existe backup de hoy, lo hacemos"
                    if [ -d ${Path_ENV}/IntegracionTOA ]
                    then
                        zip -r IntegracionTOA_${_date}.zip IntegracionTOA
                        if [ -f ${Path_ENV}/IntegracionTOA_${_date}.zip ]
                            then
                                echo "Backup OK"
                            else
                                echo "No se ha hecho el Backup, por favor, revisad"
                                exit 58
                        fi
                    else
                        echo "No existe la carpeta ${Path_ENV}/IntegracionTOA, no es necesario backup"
                    fi
            fi

            echo "Borramos ONOServer e IntegracionTOA de la release"
            cd ${Path_ENV}
            
            if [ -d ${Path_ENV}/ONOServer ]
                then
                    rm -rf ONOServer
                    if [ -d ${Path_ENV}/ONOServer ]
                    then
                        echo "No se ha borrado bien la release de SERVER, comprobad"
                        exit 59
                    else
                        echo "Borrado OK"
                    fi
            else
                echo "No existe la carpeta ${Path_ENV}/ONOServer, no es necesario borrarla"
            fi
            if [ -d ${Path_ENV}/IntegracionTOA ]
                then
                    rm -rf IntegracionTOA
                    if [ -d ${Path_ENV}/IntegracionTOA ]
                    then
                        echo "No se ha borrado bien la release de IntegracionTOA, comprobad"
                        exit 59
                    else
                        echo "Borrado OK"
                    fi
            else
                echo "No existe la carpeta ${Path_ENV}/IntegracionTOA, no es necesario borrarla"
            fi
            echo "Traemos el zip de SPPR"
            scp platafor@smartapptst05:/home/smart/sppr/release/CRMSmart/ONOServer_sppr.zip ${Path_ENV}
            scp platafor@smartapptst05:/home/smart/sppr/release/CRMSmart/INTEGRACION_TOA_PROD.zip ${Path_ENV}
            if [ -f ${Path_ENV}/ONOServer_sppr.zip ] && [ -f ${Path_ENV}/INTEGRACION_TOA_PROD.zip ]
                then
                    echo "ZIPs traidos OK"
                else
                    echo "ZIPs no traidos OK, revisad"
                    exit 60
            fi

            echo "Descomprimimos el ZIP en la release"
            cd ${Path_ENV}
            unzip -o ONOServer_sppr.zip | tee -a log_server_zip.log
            if [ `(grep "disc full" log_server_zip.log | wc -l)` -ne 0 -o `(grep "write error" log_server_zip.log | wc -l)` -ne 0 -o `(grep "probably truncated" log_server_zip.log | wc -l)` -ne 0 ]
                then
                    echo "ERROR al descomprimir el ZIP de SERVER, revisad"
                    rm log_server_zip.log
                    exit 61
                else
                    echo "ZIP SERVER descomprimido OK"
                    rm log_server_zip.log
            fi
            if [ -d ${Path_ENV}/ONOServer ]
                then
                    echo "Release ONOServer OK"
                else
                    echo "ERROR, release ONOServer KO"
                    exit 61
            fi
            cd ${Path_ENV}
            unzip -o INTEGRACION_TOA_PROD.zip | tee -a log_IntegracionTOA_zip.log
            if [ `(grep "disc full" log_server_zip.log | wc -l)` -ne 0 -o `(grep "write error" log_server_zip.log | wc -l)` -ne 0 -o `(grep "probably truncated" log_server_zip.log | wc -l)` -ne 0 ]
                then
                    echo "ERROR al descomprimir el ZIP de TOA, revisad"
                    rm log_IntegracionTOA_zip.log
                    exit 61
                else
                    echo "ZIP TOA descomprimido OK"
                    rm log_IntegracionTOA_zip.log
            fi
            if [ -d ${Path_ENV}/IntegracionTOA ]
                then
                    echo "Release IntegracionTOA OK"
                else
                    echo "ERROR, release IntegracionTOA KO"
                    exit 61
            fi
            echo "Borramos el semaforo generado para el refresco"
            rm -f /home/plataforma/plausr/tmp/CRMSmart_TST1_ONOSever.sem
        """
        sh "ssh -q smartre@${Machine_ENV} '${exec_copia_SERVER_1}'" //smartre
} //stage
} //node

// Ejecutar deploy_smartserver_cm
node ("eswltbhr-platafor") {       
    stage ("Deploy_SERVER_0_1"){

        print "*************************************************"
        print " Ejecutamos deploy_smartserver_cm de ${myenv}    "
        print "*************************************************"
        exec_Deploy_SERVER_0_1="""
        cd /home/weblogic/scripts_cm
        ./deploy_smartserver_cm
        """
        print (exec_Deploy_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_Deploy_SERVER_0_1}'" //weblogic
    } //stage

} //node

// Arranque SERVER
node ("eswltbhr-platafor") {       
    stage ("Arranque_SERVER_0_1"){

        print "*************************************************"
        print " Arrancamos SERVER de ${myenv}                   "
        print "*************************************************"
        exec_arrancar_SERVER_0_1="""
        cd /home/weblogic
        . ./.profile 2>/dev/null
        cd ${Path_ENV_RS}/bin
        ./startAll.sh 2>/dev/null
        """
        print (exec_arrancar_SERVER_0_1)
        sh "ssh -q weblogic@${Machine_ENV} '${exec_arrancar_SERVER_0_1}'" //weblogic
    } //stage

} //node

} //if
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
if ( "${VariableALL_EXCEPT}" == "true" ) {
myapp = "ALL_EXCEPT_MANMTO"
} //if
} //if

if ( "${myapp}" == "CLIENT" || "${myapp}" == "ALL" || "${myapp}" == "ALL_EXCEPT_MANMTO" ) {
myapp = "CLIENT"
node ("eswldahr") {     
    stage ("Opciones"){
            checkout scm  
                    ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/UTILITIES/REFRESCOS/REFRESCOS_CRM.yml")
                    Opciones=ENVConfig["${myenv}_${myapp}"]
                    Path_ENV = Opciones[0]
                    Machine_ENV = Opciones[1]
                    Nodo_ENV = Opciones[2]
                    Cm_0_1 = Opciones[3]
                    Path_ENV_RS = Opciones[4]
                } //stage

} //node
// Parada CLIENT
node ("VWT-WEBSERVER01"){
stage ("Parada_CLIENT_0_1"){
        print "**********************************************"
        print "Paramos CLIENT en ${myenv}                    "
        print "**********************************************"
            dir ("${Path_ENV_RS}"){
                bat("Stop_Weblogic.bat")
                }
} //stage
} //node

stage ("Refresco_COPIA_CLIENT"){
    node ("eswltbhr-platafor"){
        exec_copia_release_client="""
        if [ -d /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv} ]
            then
                echo "Existe el directorio, lo borramos y lo creamos de 0"
                rm -rf /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}
                mkdir -p /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}
            else
                echo "No existe el directorio, lo creamos y traemos los ficheros"
                mkdir -p /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}
        fi
        scp smartre@smartapptst05:/home/smart/sppr/release/CRMSmart/ONOClient/compiled/jar/output/* /home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}
        """
        sh "${exec_copia_release_client}"
    } //node
        node ("eswltbhr-platafor"){
 	        dir("/home/plataforma/plausr/Refrescos_CRM/Refresco_${myenv}"){
 	        stash name: 'sources', includes: '**/*'
	   	    } // dir
	    } // node
    node ("VWT-WEBSERVER01"){
            dir("c:\\Inetpub\\ftproot\\${myenv}"){
    	    unstash name: 'sources'
    	    } //dir
  	} //node
} //stage


if ( "${myapp}" == "CLIENT" && "${Cm_0_1}" == "0" ) {
// Ejecucion bat
node ("VWT-WEBSERVER01"){
   stage ("CLIENT_bat_0"){
        print "**********************************************"
        print "Ejecutamos .bat en NT para ${myenv}           "
        print "**********************************************"
            dir ("C:\\plataforma\\Scripts\\Refrescos_CRM"){
    	        bat("refresco_client.bat ${myenv}")
                }
   } //stage
} //node

}//if

if ( "${myapp}" == "CLIENT" && "${Cm_0_1}" == "1" ) {

node ("eswltbhr-platafor"){
   stage ("Refresco_CLIENT"){
        print "************************************************"
        print "Hacemos zip de la release de unix para ${myenv} "
        print "************************************************"
        exec_CLIENT_UNIX_zip="""
        cd /home/smart/sppr/release/CRMSmart/
        zip -r ONOClient_sppr.zip ONOClient
        """
        sh "ssh -q smartre@smartapptst05 '${exec_CLIENT_UNIX_zip}'" //smartre

        print "************************************************"
        print "Llevamos el zip a la maquina de ${myenv}        "
        print "************************************************"
        exec_CLIENT_UNIX_copia="""
        cd /home/smart/sppr/release/CRMSmart
        scp ONOClient_sppr.zip smartre@${Machine_ENV}:/home/smart/release/CRMSmart
        """
        sh "ssh -q smartre@smartapptst05 '${exec_CLIENT_UNIX_copia}'" //smartre

   } //stage
} //node

node ("eswltbhr-platafor") {
    stage ("Refresco_CLIENT"){
        print "******************************************************************"
        print "Hacemos backup de release y descomprimimos nuevo zip para ${myenv}"
        print "******************************************************************"
        exec_CLIENT_UNIX_bck="""
        cd /home/smart/release/CRMSmart
        mv ONOClient ONOClient_refresco_${_date}
        if [ -d /home/smart/release/CRMSmart/ONOClient_refresco_${_date} ]
            then
                unzip -o ONOClient_sppr.zip | tee -a log_client_zip.log
                if [ `(grep "disc full" log_client_zip.log | wc -l)` -ne 0 -o `(grep "write error" log_client_zip.log | wc -l)` -ne 0 -o `(grep "probably truncated" log_client_zip.log | wc -l)` -ne 0 ]
                then
                    echo "Algo ha fallado al descomprimir, revisad"
                    rm log_client_zip.log
                    exit 66
                else
                    echo "Codigo descomprimido OK"
                    rm log_client_zip.log
                fi
                if [ -d /home/smart/release/CRMSmart/ONOClient_sppr ]
                then
                mv ONOClient_sppr ONOClient
                fi
                if [ -d /home/smart/release/CRMSmart/ONOClient ]
                    then
                        echo "Release ONOClient OK"
                    else
                        echo "ERROR, release ONOClient KO"
                        exit 66
                fi
            else
                echo "Ha fallado la creacion del backup, revisad"
                exit 66
        fi
        """
        sh "ssh -q smartre@${Machine_ENV} '${exec_CLIENT_UNIX_bck}'" //smartre

    } //stage
} //node

// Borrar jnlps VF
node ("eswltbhr-platafor") {       
    stage ("Delete_SERVER_JNLP_0_1"){
        print "*********************************************"
        print " Borramos los dos JNLPs de VF en ${myenv}    "
        print "*********************************************"
        exec_Delete_SERVER_JNLP_0_1="""
        if [ -f /home/smart/release/CRMSmart/ONOClient/compiled/jar/JNLP/VodafoneSinAuto.jnlp ]
        then
            rm /home/smart/release/CRMSmart/ONOClient/compiled/jar/JNLP/VodafoneSinAuto.jnlp
            echo "VodafoneSinAuto.jnlp borrado"
        fi
        if [ -f /home/smart/release/CRMSmart/ONOClient/compiled/jar/JNLP/Vodafone.jnlp ]
        then
            echo "Vodafone.jnlp borrado"
            rm /home/smart/release/CRMSmart/ONOClient/compiled/jar/JNLP/Vodafone.jnlp
        fi
        """
        print (exec_Delete_SERVER_JNLP_0_1)
        sh "ssh -q smartre@${Machine_ENV} '${exec_Delete_SERVER_JNLP_0_1}'" //smartre
    } //stage
} //node

// Ejecucion bat
node ("VWT-WEBSERVER01"){
   stage ("CLIENT_bat_1"){
        print "**********************************************"
        print "Ejecutamos .bat en NT para ${myenv}           "
        print "**********************************************"
            dir ("C:\\plataforma\\Scripts\\Refrescos_CRM"){
    	        bat("refresco_client.bat ${myenv}")
                }
   } //stage
} //node

} //if
// Arranque CLIENT
node ("VWT-WEBSERVER01"){
   stage ("Arrancar_CLIENT_0_1"){
        print "**********************************************"
        print "Arrancamos CLIENT en ${myenv}                 "
        print "**********************************************"
            dir ("${Path_ENV_RS}"){
    	        bat("Start_Weblogic.bat")
                }
   } //stage
} //node
if ( "${VariableALL}" == "true" ) {
myapp = "ALL"
} //if
if ( "${VariableALL_EXCEPT}" == "true" ) {
myapp = "ALL_EXCEPT_MANMTO"
} //if
} //if

if (( "${myapp}" == "ALL" || "${myapp}" == "ALL_EXCEPT_MANMTO" ) && ( "${Cm_0_1}" == "1" )) {
if ( "${myenv}" == "TGA1" ) {
myenv = "TST1" 
} //if
if ( "${myenv}" == "TGA2" ) {
myenv = "SIT1" 
} //if
if ( "${myenv}" == "TGA3" ) {
myenv = "SIT2" 
} //if
if ( "${myenv}" == "TGA4" ) {
myenv = "TST" 
} //if
if ( "${myenv}" == "TGA21" ) {
myenv = "PPRD" 
} //if
if ( "${myenv}" == "TGA6" ) {
myenv = "SIT3" 
} //if
node ("opetst75-platafor"){
   stage ("ACT_PVCS_SVN"){
        print "**********************************************"
        print "Ejecutamos act_pvcs_svn para ${myenv}         "
        print "**********************************************"
        exec_ACT_PVCS_SVN="""
        . /home/plataforma/plausr/.profile_refresco 2>/dev/null
        cd /home/plataforma/release/scripts
        ./act_pvcs_svn -e ${myenv}
        """
        sh "${exec_ACT_PVCS_SVN}" //platafor
   } //stage
   } //node
} //if
if ( "${act_pvcs_svn}" == "true" ) {
if ( "${myenv}" == "TGA1" ) {
myenv = "TST1" 
} //if
if ( "${myenv}" == "TGA2" ) {
myenv = "SIT1" 
} //if
if ( "${myenv}" == "TGA3" ) {
myenv = "SIT2" 
} //if
if ( "${myenv}" == "TGA4" ) {
myenv = "TST" 
} //if
if ( "${myenv}" == "TGA21" ) {
myenv = "PPRD" 
} //if
if ( "${myenv}" == "TGA6" ) {
myenv = "SIT3" 
} //if
node ("opetst75-platafor"){
   stage ("ACT_PVCS_SVN_1"){
        print "**********************************************"
        print "Ejecutamos act_pvcs_svn para ${myenv}         "
        print "**********************************************"
        exec_ACT_PVCS_SVN_1="""
        . /home/plataforma/plausr/.profile_refresco 2>/dev/null
        cd /home/plataforma/release/scripts
        ./act_pvcs_svn -e ${myenv}
        """
        sh "${exec_ACT_PVCS_SVN_1}" //platafor
   } //stage
   } //node
} //if
