#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myapp=params.APP
def myenv=params.ENV
def VariableSCPBoolean = true

    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Ejecucion: ${myapp} ${myenv}"
    currentBuild.description = "Ejecucion: ${myapp} ${myenv}"

	
if ( "${myapp}" == "MAESTRAS-CORTO" ) {
myapp = "MAESTRAS-CORTO"
node ("opetst71-platafor") {     
   stage ("MAESTRAS-CORTO"){
       print "*****************************************"
       print " Ejecutamos maestras corto para ${myenv} "
       print "*****************************************"
       exec_maestras_corto="""
       cd /home/plataforma/release/scripts
       ./arranque_maestras -e ${myenv} -C
       """
       print (exec_maestras_corto)
       sh "${exec_maestras_corto}" //platafor      
   } //stage
} //node
} //if


if ( "${myapp}" == "MAESTRAS-LARGO" ) {
myapp = "MAESTRAS-LARGO"
node ("opetst71-platafor") {     
   stage ("MAESTRAS-LARGO"){
       print "*****************************************"
       print " Ejecutamos maestras largo para ${myenv} "
       print "*****************************************"
       exec_maestras_largo="""
       cd /home/plataforma/release/scripts
       ./arranque_maestras -e ${myenv} -L
       """
       print (exec_maestras_largo)
       sh "${exec_maestras_largo}" //platafor      
   } //stage
} //node
} //if
