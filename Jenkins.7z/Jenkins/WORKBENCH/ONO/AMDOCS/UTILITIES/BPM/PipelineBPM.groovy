#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENTORNO
def mymachine=params.MAQUINA 
def mypack=params.PAQUETE
def VariableSCPBoolean = true
def VariableALL = false
def Path_Script_pla="E:\\platafor_scripts"
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Genera BPM ${myenv} : ${mypack}"
    currentBuild.description = "Genera BPM ${myenv} : ${mypack}"

node ("vwd-descver01"){
stage ("INST_BPM"){
        print "**********************************************"
        print "Generamos BPM en ${myenv}                     "
        print "**********************************************"
            dir ("${Path_Script_pla}"){
                bat("GENERA_BPM.bat ${myenv} ${mypack} ${mymachine}")
                }
} //stage
} //node
