#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP 
def VariableSCPBoolean = true
def VariableALL = false
def Path_Script_CLIENT="C:\\plataforma\\Scripts\\SMART_CLIENT"
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Backup CLIENT: ${myenv}"
    currentBuild.description = "Backup CLIENT: ${myenv}"

if ( "${myapp}" == "CLIENT" ) {
node ("VWT-WEBSERVER01"){
stage ("BACKUP_CLIENT"){
        print "**********************************************"
        print "Instalamos CLIENT en ${myenv}                 "
        print "**********************************************"
            dir ("${Path_Script_CLIENT}"){
                bat("Backup_client.bat ${myenv}")
                }
} //stage
} //node
} //if
