#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP 
def mypack=params.PCK
def mypass=params.PASS
def VariableSCPBoolean = true
def VariableALL = false
def Path_Script_pla="E:\\platafor_scripts"
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Instalacion ${myapp}: ${myenv} ${mypack}"
    currentBuild.description = "Instalacion ${myapp}: ${myenv} ${mypack}"

if ( "${myapp}" == "AIF" ) {
node ("vwd-descver01"){
stage ("INST_AIF"){
        print "**********************************************"
        print "Instalamos AIF en ${myenv}                    "
        print "**********************************************"
            dir ("${Path_Script_pla}"){
                bat("Inst_AIF_PROD.bat ${myenv} ${mypack} ${mypass}")
                }
} //stage
stage ("COPIA_AIF"){
        print "**********************************************"
        print "Copiamos release de AIF en ${myenv}           "
        print "**********************************************"
            dir ("${Path_Script_pla}"){
                bat("Copia_AIF_PROD.bat ${myenv} ${mypack}")
                }
} //stage
} //node
} //if
if ( "${myapp}" == "AIF_APM" ) {
node ("vwd-descver01"){
stage ("INST_AIF_APM"){
        print "**********************************************"
        print "Instalamos AIF_APM en ${myenv}                "
        print "**********************************************"
            dir ("${Path_Script_pla}"){
                bat("Inst_AIF_APM_PROD.bat ${myenv} ${mypack} ${mypass}")
                }
} //stage
stage ("COPIA_AIF"){
        print "**********************************************"
        print "Copiamos release de AIF_APM en ${myenv}       "
        print "**********************************************"
            dir ("${Path_Script_pla}"){
                bat("Copia_AIF_APM_PROD.bat ${myenv} ${mypack}")
                }
} //stage
} //node
} //if
