#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myname=params.NAME
def myapp=params.APP
def myteam=params.TEAM
def myoverwrite=params.OVERWRITE
def VariableOVER = false

    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Ejecucion: ${myteam} ${myname} ${myapp}"
    currentBuild.description = "Ejecucion: ${myteam} ${myname} ${myapp}"

if ( "${myoverwrite}" == "YES" ) {
    VariableOVER = "true"
}

if ( "${myteam}" == "DEV" && "${VariableOVER}" == "true" && "${myapp}" == "MAPEOS" ) {
    node ("opetst75-platafor") {     
        stage ("CREATE_ALL_DEV"){
            print "****************************"
            print "  Creamos ${myname}/MAPEOS  "
            print "****************************"
            exec_create_MAPEOS_DEV="""
            . /home/plataforma/plausr/.profile_refresco 2>/dev/null
            cd /home/plataforma/release/scripts
            ./comprobacionesSVN -p ${myname} -M -C -O
            """
            print (exec_create_MAPEOS_DEV)
            sh "${exec_create_MAPEOS_DEV}" //platafor      
        } //stage
    } //node        
} //if

if ( "${myteam}" == "DEV" && "${VariableOVER}" == "false" && "${myapp}" == "MAPEOS" ) {
    node ("opetst75-platafor") {     
        stage ("CREATE_ALL_DEV"){
            print "****************************"
            print "  Creamos ${myname}/MAPEOS  "
            print "****************************"
            exec_create_MAPEOS_DEV="""
            . /home/plataforma/plausr/.profile_refresco 2>/dev/null
            cd /home/plataforma/release/scripts
            ./comprobacionesSVN -p ${myname} -M -C
            """
            print (exec_create_MAPEOS_DEV)
            sh "${exec_create_MAPEOS_DEV}" //platafor      
        } //stage
    } //node        
} //if

if ( "${myteam}" == "DEV" && "${VariableOVER}" == "true" ) {
    node ("opetst75-platafor") {     
        stage ("CREATE_ALL_DEV"){
            print "*************************************************"
            print "  Creamos ${myname}/BBDD and ${myname}/PROCESOS  "
            print "*************************************************"
            exec_create_ALL_DEV="""
            . /home/plataforma/plausr/.profile_refresco 2>/dev/null
            cd /home/plataforma/release/scripts
            ./comprobacionesSVN -p ${myname} -BP -C -O
            """
            print (exec_create_ALL_DEV)
            sh "${exec_create_ALL_DEV}" //platafor      
        } //stage
    } //node        
} //if

if ( "${myteam}" == "DEV" && "${VariableOVER}" == "false" ) {
    node ("opetst75-platafor") {     
        stage ("CREATE_ALL_DEV"){
            print "*************************************************"
            print "  Creamos ${myname}/BBDD and ${myname}/PROCESOS  "
            print "*************************************************"
            exec_create_ALL_DEV="""
            . /home/plataforma/plausr/.profile_refresco 2>/dev/null
            cd /home/plataforma/release/scripts
            ./comprobacionesSVN -p ${myname} -BP -C
            """
            print (exec_create_ALL_DEV)
            sh "${exec_create_ALL_DEV}" //platafor      
        } //stage
    } //node        
} //if


if ( "${myteam}" == "CM" && "${VariableOVER}" == "true" && "${myapp}" == "BBDD" ) {
    node ("opetst75-platafor") {     
        stage ("CREATE_BBDD_CM"){
            print "***************************"
            print "  Creamos ${myname}_BBDD   "
            print "***************************"
            exec_create_BBDD_CM="""
            . /home/plataforma/plausr/.profile_refresco 2>/dev/null
            cd /home/plataforma/release/scripts
            ./comprobacionesSVN -p ${myname} -B -U -O
            """
            print (exec_create_BBDD_CM)
            sh "${exec_create_BBDD_CM}" //platafor      
        } //stage
    } //node        
} //if
    
if ( "${myteam}" == "CM" && "${VariableOVER}" == "true" && "${myapp}" == "PROCESOS" ) {
    node ("opetst75-platafor") {     
        stage ("CREATE_PROCESOS_CM"){
            print "*******************************"
            print "  Creamos ${myname}_PROCESOS   "
            print "*******************************"
            exec_create_PROCESOS_CM="""
            . /home/plataforma/plausr/.profile_refresco 2>/dev/null
            cd /home/plataforma/release/scripts
            ./comprobacionesSVN -p ${myname} -P -U -O
            """
            print (exec_create_PROCESOS_CM)
            sh "${exec_create_PROCESOS_CM}" //platafor      
        } //stage
    } //node        
} //if

if ( "${myteam}" == "CM" && "${VariableOVER}" == "true" && "${myapp}" == "MAPEOS" ) {
    node ("opetst75-platafor") {     
        stage ("CREATE_MAPEOS_CM"){
            print "*******************************"
            print "  Creamos ${myname}_MAPEOS     "
            print "*******************************"
            exec_create_MAPEOS_CM="""
            . /home/plataforma/plausr/.profile_refresco 2>/dev/null
            cd /home/plataforma/release/scripts
            ./comprobacionesSVN -p ${myname} -M -U -O
            """
            print (exec_create_MAPEOS_CM)
            sh "${exec_create_MAPEOS_CM}" //platafor      
        } //stage
    } //node        
} //if
if ( "${myteam}" == "CM" && "${VariableOVER}" == "true" && "${myapp}" == "ALL" ) {
    node ("opetst75-platafor") {     
        stage ("CREATE_ALL_CM"){
            print "***********************************************"
            print "  Creamos ${myname}/BBDD y ${myname}/PROCESOS  "
            print "***********************************************"
            exec_create_ALL_CM="""
            . /home/plataforma/plausr/.profile_refresco 2>/dev/null
            cd /home/plataforma/release/scripts
            ./comprobacionesSVN -p ${myname} -BP -U -O
            """
            print (exec_create_ALL_CM)
            sh "${exec_create_ALL_CM}" //platafor      
        } //stage
    } //node        
} //if

if ( "${myteam}" == "CM" && "${VariableOVER}" == "false" ) {
    print "******************************************"
    print "  IF TEAM IS CM, OVERWRITE HAS TO BE YES  "
    print "******************************************"
}
