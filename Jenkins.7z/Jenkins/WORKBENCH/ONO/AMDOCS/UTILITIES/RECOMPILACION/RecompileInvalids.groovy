#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myapp=params.APP
def myenv=params.ENV
def VariableSCPBoolean = true
def VariableALL = false

    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Ejecucion: ${myapp} ${myenv}"
    currentBuild.description = "Ejecucion: ${myapp} ${myenv}"

if ( "${myapp}" == "ALL" ) {
VariableALL = "true_ALL"
}

if ( "${myapp}" == "RECOMPILE" || "${VariableALL}" == "true_ALL" ) {
node ("opetst71-platafor") {     
   stage ("RECOMPILE"){
       print "******************************************"
       print "          Recompilamos ${myenv}           "
       print "******************************************"
       exec_recompile="""
       cd /home/plataforma/release/scripts
       ./all_invalid.sh -e ${myenv} -R
       """
       print (exec_recompile)
       sh "${exec_recompile}" //platafor      
   } //stage
} //node
} //if


if ( "${myapp}" == "CONSULT" ) {
node ("opetst71-platafor") {     
   stage ("CONSULT"){
       print "******************************************"
       print "  Consultamos descompilados de ${myenv}   "
       print "******************************************"
       exec_CONSULT="""
       cd /home/plataforma/release/scripts
       ./all_invalid.sh -e ${myenv} -C
       """
       print (exec_CONSULT)
       sh "${exec_CONSULT}" //platafor      
   } //stage
} //node
} //if

if ( "${myapp}" == "CACHE" || "${VariableALL}" == "true_ALL" ) {
node ("opetst71-platafor") {     
    stage ("Borra_cache"){
        print "***********************************************"
        print " Ejecutamos el borrado de cache para ${myenv}  "
        print "***********************************************"
        exec_cache="""
        cd /home/plataforma/release/scripts
       ./borrado_cache_bbdd ${myenv}
       """
        print (exec_cache)
        sh "${exec_cache}" //platafor
    } //stage
} //node
} //if

