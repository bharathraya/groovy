#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _env=""
def _ALMS_ID=""

def hoy=new Date().format( 'yyyyMMdd' )
def _dateLog=new Date().format( 'yyyyMMddHHmmss' )
def pckInfo=null


callFromWB=false  



print "La fecha de hoy es ......${hoy}......"


node("es036tvr"){
    stage("ObtenerDatos"){

        _ALMS_ID=params.WB_ID  


        wbpckinfo=get_workbench_package_info(_ALMS_ID)
        _env=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
         print "ALMS ID ${_ALMS_ID}"
         print "Enviroment ${_env}"

        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_env}  "
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_env} "
      }
  }//node
    
node("eswltbhr"){
    stage("Copiar"){
    
    if (_env =="SIT3")
    {
    
        server = "smartapptst06"
        BBDD="TGA6"
        serverBBDD="opetst79"
        USR="SA"
        PORT="1531"
        BBDD_PASSWD="tga61118"
    } 
    else if(_env =="SIT2")
    {
    
        server ="smartapptst03"
        BBDD="TGA3"
        serverBBDD="opetst75"
        PORT="1531"
        USR="SA"
        BBDD_PASSWD="tga32017"
    }
    
        
        
        execCopy="""
         . \$HOME/.profile >/dev/null 2>&1
         . paquete ${_ALMS_ID} ${_env}
         scp es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_ALMS_ID}/${_env}/Annexes/*par .
         ls  *par > bpm_name
         
        """
      
        sh "ssh -q ${server} '${execCopy}'"
        
        sh ". \$HOME/.profile >/dev/null 2>&1 ;. paquete ${_ALMS_ID} ${_env} ; scp ${server}:/home/plataforma/plausr/data/paquetes/${hoy}/${_ALMS_ID}/${_env}/bpm_name ." 
    
        tar_name=readFile(file: "/home/plataforma/plausr/data/paquetes/${hoy}/${_ALMS_ID}/${_env}/bpm_name")      
        
        execEjec="""
         cd
         . \$HOME/.profile 
        
         cd /home/weblogic/AmdocsCRM7.5/AmdocsCRM7.5/Server/dbadmin/
         sh bpmdeploy.sh -jdbcUrl jdbc:oracle:thin:@${serverBBDD}:${PORT}:${BBDD} -user $USR -password ${BBDD_PASSWD} -testers \"*\" /home/plataforma/plausr/data/paquetes/${hoy}/${_ALMS_ID}/${_env}/${tar_name}
        """
      
        sh "ssh -l weblogic ${server} '${execEjec}'"
     //   print "${execEjec}"
      
      }//Stage Revisar
       

    
}//nodo
