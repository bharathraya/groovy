#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml'])
PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml',
    applicationChoices:["MQ_NEPTUNO","AMDOCS-CLIENT","AMDOCS-SERVER","AMDOCS-BBDD","AMDOCS-MAESTRAS","AMDOCS-BPM_APM","AMDOCS-UPSD","AMDOCS-CustActionBeans","AMDOCS-AIF_APM","AMDOCS-ESQUEMA","AMDOCS-PREVIEW","AMDOCS-CLARIFY","AMDOCS-ProcessManager","APM","APM-SMS_Resumen_Compra","AMDOCS-SPM","AMDOCS-PM","AMDOCS-AIF","AMDOCS-FORMS","AMDOCS-CBS","AMDOCS-PROCESOS","Sycamore","AMDOCS-IntegracionTOA","MQ_BRK","MQ-BBDD-BROKER"],
	 environmentChoices:["TST","TST1","SIT1","SIT2","SIT3","PPRD","PPRD1","EBU","PROD"]])
