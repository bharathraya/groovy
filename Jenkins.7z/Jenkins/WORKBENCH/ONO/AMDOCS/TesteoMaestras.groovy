#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _Domain=""
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _Aplicacion=""
def _dataModules=""
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _Pvcs=""

def hoy=new Date().format( 'yyyyMMdd' )
def pckInfo=null

if (PackageInfo==""){
    callFromWB=false  
    //print "llamada manual"
}


print "La fecha de hoy es ......${hoy}......"


node("eswltahr"){
    stage("ObtenerDatos"){
        if (callFromWB){
            pckInfo=readJSON(text: "${PackageInfo}")
            _ALMS_ID=pckInfo.Id.toString()
        }
        else
        {
            _ALMS_ID=params.WB_ID  
         }
         
         
        wbpckinfo=get_workbench_package_info(_ALMS_ID)
        _DeployEnv=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
        _pvcsArray=wbpckinfo.Data.Model.Model.Contents.PVCS
        
         print "ALMS ID ${_ALMS_ID}"
         print "Enviroment ${_DeployEnv}"
        // print "pvcs array ${_pvcsArray}"
        
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv}  "
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_DeployEnv} "
    }

    stage("Revisar"){

             for (pos = 0; pos < _pvcsArray.size(); pos++) {
               pvcs_module_name = _pvcsArray[pos].WorkFile //Nombre del sql a revisar
               print "modulo a revisar ${pvcs_module_name} "
               if ( "${pvcs_module_name}" != "RLS_Refresco_Maestra_Largo.sql" && "${pvcs_module_name}" != "RLS_Refresco_Corto_Maestras.sql" && "${pvcs_module_name}" != "RLS_Refresco_Maestra_Largo_MTO.sql")
               {
                    error("El modulo ${pvcs_module_name} no esta permitido")
               }
            }
        }
    
}
