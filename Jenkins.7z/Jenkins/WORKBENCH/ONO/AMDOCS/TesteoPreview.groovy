#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _env=""
def _ALMS_ID=""

def hoy=new Date().format( 'yyyyMMdd' )
def _dateLog=new Date().format( 'yyyyMMddHHmmss' )
def pckInfo=null

if (PackageInfo==""){
    callFromWB=false  
    //print "llamada manual"
}else
{
  //  print "llamada desde WB"
   //  print "Info enviada -> ${PackageInfo}"
}


print "La fecha de hoy es ......${hoy}......"


node("es036tvr"){
    stage("ObtenerDatos"){
        if (callFromWB){
          //  print "PacakgeInfo -> ${PackageInfo}"
            pckInfo=readJSON(text: "${PackageInfo}")
            _ALMS_ID=pckInfo.Id.toString()
        }
        else
        {
            _ALMS_ID=params.WB_ID  
         }

        wbpckinfo=get_workbench_package_info(_ALMS_ID)
        _env=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
         print "ALMS ID ${_ALMS_ID}"
         print "Enviroment ${_env}"

        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_env}  "
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_env} "
    }
    
    stage("Revisar"){
        execRe="""
            export DIR_BASE_TEMPORAL=/home/plataforma/plausr/data/temporal
            if [  ! -d \$DIR_BASE_TEMPORAL/${hoy}/${_ALMS_ID}/${_env}/Annexes/ ]
                then
                    echo "ERROR Falta anexar la aprobación del OC"
                    exit 1
                else 
                   echo "Existe algo anexado"
            fi
        """
       
      try{
           sh "${execRe}"
        } catch(Exception e){
            createReject (_ALMS_ID , "ERROR Falta la autorización de OC","5")
            error ("ERROR Falta la autorización de OC")
            

        }
       
    }//Stage Revisar

    
}//nodo
