#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

ActualizaPaquetesPipeline([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml',
    applicationChoices:["AMDOCS-BBDD"],
	environmentChoices:["PROD"],
	Modificar_parcheChoices:["NO","YES"]])
