#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

VentanaOnoPipeline([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml', 
environmentChoices:["PPRD","SIT1","SIT3"] , Optionvista:["YES","NO"], OptionPaquetes:["YES","NO"]])

