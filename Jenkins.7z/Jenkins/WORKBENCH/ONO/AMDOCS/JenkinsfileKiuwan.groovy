#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml'])
PVCSPipelineTemplateKiuwan([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml',kiuwanConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/kiuwanConfig.yml',
    applicationChoices:["MQ_NEPTUNO","AMDOCS-CLIENT","AMDOCS-SERVER","AMDOCS-BBDD","AMDOCS-MAESTRAS","AMDOCS-BPM_APM","AMDOCS-UPSD","AMDOCS-CustActionBeans","AMDOCS-AIF_APM","AMDOCS-ESQUEMA","AMDOCS-PREVIEW","AMDOCS-CLARIFY","AMDOCS-ProcessManager","APM","APM-SMS_Resumen_Compra","AMDOCS-SPM","AMDOCS-PM","AMDOCS-AIF","AMDOCS-FORMS","AMDOCS-CBS","AMDOCS-PROCESOS","Sycamore","MQ_BRK","MQ-BBDD-BROKER"],
	 environmentChoices:["KIUWAN","TST","TST1","SIT1","SIT2","SIT3","PPRD","PPRD1","PROD"]])
