#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

SVNGitPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml'])
