#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

EjecutaPaquetes([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/AMDOCS/pipelineConfig.yml'])

