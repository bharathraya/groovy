#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _


PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/MOBILITY/pipelineConfig.yml',
    applicationChoices:["JAVA-JSP" , "JAVA-J2EE", "MOBILITY-BBDD" , "BOA-BBDD" , "DOTNET"],
	environmentChoices:["SIT1","SIT2","PPRD","SIT3","PROD"]])
