#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

SVNPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/MOBILITY/pipelineConfig.yml'])
