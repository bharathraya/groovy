#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/NUBIA/UpgradepipelineConfig.yml'])
PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/NUBIA/UpgradePipelineConfig.yml',
     applicationChoices:["NUBIA-BEANS","NUBIA-CISAS","NUBIA-RESMGR","NUBIA-LIB","NUBIA-LIB-OBSOLETO","NUBIA-MWFM","NUBIA-SCRIPTS","NUBIA-BBDD-CRM","NUBIA-BBDD-HPSA","MQ_NUBIA"],
	 environmentChoices:["SIT1","SIT2","PPRD1","SIT3","PROD"]])
