#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/NUBIA/pipelineConfig.yml'])
PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/NUBIA/pipelineConfig.yml',
    applicationChoices:["NUBIA-BEANS","NUBIA-CRM","NUBIA-ECP","NUBIA-ECP-TEMPLATES","NUBIA-GUI-BLOQUEOS","NUBIA-GUI-CRM","NUBIA-GUI-IPM","NUBIA-GUI-UBR","NUBIA-INVENTORY","NUBIA-LIB","NUBIA-LIB-OBSOLETO","NUBIA-MWFM","NUBIA-SCRIPTS","NUBIA-SOLUTION_CONTAINER","NUBIA-SOSA3","NUBIA-BBDD-CRM","NUBIA-BBDD-HPSA","MQ_NUBIA"],
	 environmentChoices:["SIT1","SIT2","PPRD1","EBU","PROD"]])

