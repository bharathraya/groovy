#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment


// Parametros entrada
def callFromWB=true
def _Domain=""
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _Aplicacion=""
def _HayModulosPVCS=""
def _Pvcs=""
def hoy=new Date().format( 'yyyyMMdd' )



print "La fecha de hoy es ......${hoy}......"

if (PackageInfo==""){
    callFromWB=false  
}

def pckInfo=null
if (callFromWB){
    pckInfo=readJSON(text: "${PackageInfo}")
    _DeployEnv=pckInfo['DeployEnvironment'].Name
	_Domain=pckInfo['AppDomain'].Name	
	_ALMS_ID=pckInfo.Id.toString()
    _server=pckInfo['AppHost'].Host
    _Aplicacion=pckInfo['ApplicationName']
    _Pvcs=pckInfo['Pvcs']
    _HayModulosPVCS=pckInfo['Pvcs'].Archive[0]
	
	//print "DEBUG: parameter PackageInfo =${PackageInfo}"
	
}


node("${_Domain}-${_DeployEnv}"){

    stage ("configure"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Aplicacion}"
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_DeployEnv} Aplicación: ${_Aplicacion}"
        print "NODE_NAME = ${env.NODE_NAME}"

    }
    stage("comprobaciones"){
        
        if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
	        error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
         }
         if( _HayModulosPVCS == null){
            error("No hay modulos de pvcs")
         }

         if ("${env.NODE_NAME}" == "${_server}")
         {
            _server =""
             //print "DEBUG server ${_server} "
         }
    }
	stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        cleanDirPaquete "${_ALMS_ID}","${_server}","${hoy}"
    }
       
	stage ("checkoutPVCS"){
		//Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_server}"
    }
    
	stage ("deploy"){
        //Llamada al migrador_nubia.sh
        migrador_nubia "${_Aplicacion}" ,"${_DeployEnv}","${_ALMS_ID}","${_server}"
    }
}
