#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//PVCSPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/FOW/pipelineConfig.yml'])
PVCSPipelineTemplateChoice([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/ONO/FOW/pipelineConfig.yml',
    applicationChoices:["FOW-BBDD","FOW-SCRIPTS","FOW-LITERALES","FOW-JAVA","FOW-C","FOW-JAVA-ANT"],
	 environmentChoices:["SIT1","SIT2","PPRD","SIT3","PROD"]])

