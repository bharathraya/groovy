#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Parada: ${myapp} ${myenv}"
    currentBuild.description = "Parada: ${myapp} ${myenv}"
    
if ( "${myapp}" == "ALL" ) {
    VariableALL = "true"
}


if ( "${myapp}" == "Ventas" || "${myapp}" == "ALL" ) {
    myapp = "Ventas"
    node ("eswldahr") {     
        stage ("Opciones"){
            checkout scm  
            ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/MOBILITY10.2/UTILITIES/REINICIOS_MOBILITY102.yml")
            Opciones=ENVConfig["${myenv}_${myapp}"]
            Path_ENV = Opciones[0]
            Machine_ENV = Opciones[1]
            User_ENV = Opciones[2]       
        } //stage

    } //node

    if ( "${myapp}" == "Ventas" ) {
    //Parada Ventas
        node ("eswltbhr-platafor") {       
            stage ("Parada_Ventas"){

               print "*************************************************"
               print " Paramos el node del weblogic Ventas de ${myenv}                       "
               print "*************************************************"
               exec_parar_Ventas="""
               . ./.profile 2>/dev/null
               cd ${Path_ENV}
               ./stop_Ventas_DeployCM.sh 2>/dev/null
               """
               print (exec_parar_Ventas)
               sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_Ventas}'" //weblogic
               
               print "****************************************"
               print "Comprobamos la parada del weblogic ventas de ${myenv}"
               print "****************************************"
               exec_comp_Ventas="""
               if [ \$(ps -fu bea | grep -i VentasServer01 | grep -v grep | wc -l) -ne 0 ]
                   then
                       echo ""
                       echo "Algo no se ha parado"
                       ps -fu bea | grep -i VentasServer01 | grep -v grep
                   exit 3
               else
                       echo ""
                       echo "Parada corecta"
               fi
               """
             //sh "ssh -q weblogic@${Machine_ENV} '${exec_comp_Ventas}'" //weblogic
               print " ejecucion ${exec_comp_Ventas}"        
           } //stage

        } //node
    } // if
    if ( "${VariableALL}" == "true" ) {
    myapp = "ALL"
    } //if
} //if

if ( "${myapp}" == "Mobility" || "${myapp}" == "ALL" ) {
    myapp = "Mobility"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/MOBILITY10.2/UTILITIES/REINICIOS_MOBILITY102.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    // Parada Mobility
    node ("eswltbhr-platafor") {       
        stage ("Parada_Mobility"){
    
            print "*************************************************"
            print " Paramos nodo del weblogic Mobility de ${myenv}                      "
            print "*************************************************"
            exec_parar_Mobility="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./stop_Mobility_DeployCM.sh 2>/dev/null
            """
            print (exec_parar_Mobility)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_parar_Mobility}'" //weblogic
            
             print "****************************************"
               print "Comprobamos la parada del weblogic Mobility de ${myenv}"
               print "****************************************"
               exec_comp_Mobility="""
               if [ \$(ps -fu bea | grep -i MobilityServer01 | grep -v grep | wc -l) -ne 0 ]
                   then
                       echo ""
                       echo "Algo no se ha parado"
                       ps -fu bea | grep -i MobilityServer01 | grep -v grep
                   exit 3
               else
                       echo ""
                       echo "Parada corecta"
               fi
               """
             //sh "ssh -q weblogic@${Machine_ENV} '${exec_comp_Mobility}'" //weblogic
               print " ejecucion ${exec_comp_Mobility}"    
        } //stage
    
       //METER BORRADO DE TMPS?
    } //node
    
    if ( "${VariableALL}" == "true" ) {
        myapp = "ALL"
    } //if
}

