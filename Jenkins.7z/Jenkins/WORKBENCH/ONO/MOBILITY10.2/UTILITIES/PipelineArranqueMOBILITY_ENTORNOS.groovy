#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def myenv=params.ENV
def myapp=params.APP
def myclient=params.PCK
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Arranque: ${myapp} ${myenv}"
    currentBuild.description = "Arranque: ${myapp} ${myenv}"
     
if ( "${myapp}" == "ALL" ) {
VariableALL = "true_ALL"
}



if ( "${myapp}" == "Ventas"  || "${VariableALL}" == "true_ALL" ) {
    myapp = "Ventas"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/MOBILITY10.2/UTILITIES/REINICIOS_MOBILITY102.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
        } //stage
    
    } //node

    if ( "${myapp}" == "Ventas" ) {
        // Arranque weblogic Ventas
        node ("eswltbhr-platafor") {       
            stage ("Arranca_Ventas"){
        
                print "*************************************************"
                print " Arrancamos el nodo del weblogic de Ventas de ${myenv}                    "
                print "*************************************************"
                exec_arrancar_Ventas="""
                . ./.profile 2>/dev/null
                cd ${Path_ENV}
                ./start_Ventas_DeployCM.sh 2>/dev/null
                """
                print (exec_arrancar_PM_0)
                sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_Ventas'" //weblogic
            } //stage
        
        } //node
    } // if
} //if

if ( "${myapp}" == "Mobility"  || "${VariableALL}" == "true_ALL" ) {
    myapp = "Mobility"
    node ("eswldahr") {     
        stage ("Opciones"){
                checkout scm  
    
                        ENVConfig=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/MOBILITY10.2/UTILITIES/REINICIOS_MOBILITY102.yml")
                        Opciones=ENVConfig["${myenv}_${myapp}"]
                        Path_ENV = Opciones[0]
                        Machine_ENV = Opciones[1]
                        User_ENV = Opciones[2]
                    } //stage
    
    } //node
    node ("eswltbhr-platafor") { 
        stage ("Arranque_Mobility"){
            print "*************************************************"
            print " Arrancamos el nodo del weblogic de Mobility de ${myenv}                   "
            print "*************************************************"
            exec_arrancar_Mobility="""
            . ./.profile 2>/dev/null
            cd ${Path_ENV}
            ./start_Mobility_DeployCM.sh 2>/dev/null
            """
            print (exec_arrancar_SERVER_0_1)
            sh "ssh -q ${User_ENV}@${Machine_ENV} '${exec_arrancar_Mobility}'" //weblogic        
        } //stage
    } //node
} //if


