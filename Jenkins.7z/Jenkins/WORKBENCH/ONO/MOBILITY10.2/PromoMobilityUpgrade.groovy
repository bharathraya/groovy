#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

// Parametros entrada
def callFromWB=true
def _env=""
def _ALMS_ID=""

def hoy=new Date().format( 'yyyyMMdd' )
def _dateLog=new Date().format( 'yyyyMMddHHmmss' )
def pckInfo=null

if (PackageInfo==""){
    callFromWB=false  
    //print "llamada manual"
}
else
{
  // print "llamada desde WB"
   //  print "Info enviada -> ${PackageInfo}"
}

print "La fecha de hoy es ......${hoy}......"

node("es036tvr"){
    stage("ObtenerDatos"){
        if (callFromWB){
          //  print "PacakgeInfo -> ${PackageInfo}"
            pckInfo=readJSON(text: "${PackageInfo}")
            _ALMS_ID=pckInfo.Id.toString()
        }
        else
        {
            _ALMS_ID=params.WB_ID  
         }

        wbpckinfo=get_workbench_package_info(_ALMS_ID)
        _env=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
         print "ALMS ID ${_ALMS_ID}"
         print "Enviroment ${_env}"

        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_env}  "
        currentBuild.description = "ID_WB: ${_ALMS_ID} Entorno: ${_env} "
    } //Stage
 }//nodo revisar
 
    stage("PromoGit"){
      node("crm5tstmob01.ono.es"){
                 
            exec="""
                . \$HOME/.profile_WB  >/dev/null 2>&1
                . paquete ${_ALMS_ID}
                promoGIT_MOB.sh -d MOBILITY -e ${_env} -p ${_ALMS_ID}
                """

          sh "${exec}"
         //  sh "ssh -q crm5tstmob01 '${exec}'"
       
      }//nodo
    }//Stage PromoGit
