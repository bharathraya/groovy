#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo
import vfes.utils.VFESALMSDeployment



// Parametros entrada
def callFromWB=true
def _Domain=""
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def hoy=new Date().format( 'yyyyMMdd' )


print "La fecha de hoy es ......${hoy}......"

if (PackageInfo==""){
    callFromWB=false  
}

def pckInfo=null
if (callFromWB){
    pckInfo=readJSON(text: "${PackageInfo}")
    _DeployEnv=pckInfo['DeployEnvironment'].Name
	_Domain=pckInfo['AppDomain'].Name	
	_ALMS_ID=pckInfo.Id.toString()
    _server=pckInfo['AppHost'].Host
	
	//print "DEBUG: parameter PackageInfo =${PackageInfo}"
 	//print "DEBUG:  pckInfo =${pckInfo}"
 	
    //Escribir el log en jenkins

    currentBuild.displayName = "ALMS: ${_ALMS_ID} Env: ${_DeployEnv}" 
    currentBuild.description = "ID_ALMS: ${_ALMS_ID} Entorno: ${_DeployEnv} Domain: ${_Domain}"

}



if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
	error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
}

node("${_Domain}-${_DeployEnv}"){

    stage ("configure"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "ALMS: ${_ALMS_ID} Env: ${_DeployEnv} Domain: ${_Domain}"
        currentBuild.description = "ID_ALMS: ${_ALMS_ID} Entorno: ${_DeployEnv} Domain: ${_Domain}"
    }
	stage ("clean"){
		//Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
        cleanDirPaquete "${_ALMS_ID}","${_server}","${hoy}"
    }
       
	stage ("checkoutPVCS"){
		//Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_server}"
    }
    
	stage ("deploy"){
        //Llamada al mig
        mig "${_Domain}" ,"","${_DeployEnv}","${_ALMS_ID}","${_server}","-Wc"
    }
}