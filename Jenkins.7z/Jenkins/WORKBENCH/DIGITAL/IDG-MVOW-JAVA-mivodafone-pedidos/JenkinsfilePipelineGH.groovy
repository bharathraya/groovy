#!groovy
@Library(value='CDMJenkinsSharedLib@feature/github', changelog=false) _

//mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-MVOW-JAVA-mivodafone-pedidos/pipelineConfig.yml'])
mavenPipelineTemplateNoKiuwan([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-MVOW-JAVA-mivodafone-pedidos/pipelineConfigGH.yml',
     artifactChoices:["mivodafone-pedidos"],
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID1CI","master"]])
