#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-WCS/pipelineConfig.yml'])
mavenPipelineTemplateNoKiuwan([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-WCS/pipelineConfig.yml',
     artifactChoices:["vf-back-wcs"],
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID1CI","master"]])

