#!groovy
@Library(value='CDMJenkinsSharedLib@feature/github', changelog=false) _

//mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/ID-NETWORK/pipelineConfig.yml'])
//mavenPipelineTemplateNoKiuwan([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/ID-NETWORK/pipelineConfig.yml',
mavenPipelineTemplateNoKiuwanProperties([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/ID-NETWORK/pipelineConfigGH.yml',
     artifactChoices:["msisdn"],
	 environmentChoices:["PPRD1","master"]])
