#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/ID-NETWORK/pipelineConfig.yml'])
//mavenPipelineTemplateNoKiuwan([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/ID-NETWORK/pipelineConfig.yml',
mavenPipelineTemplateNoKiuwanProperties([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/ID-NETWORK/pipelineConfig.yml',
     artifactChoices:["msisdn"],
	 environmentChoices:["PPRD1","master"]])
