#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-EDC-JAVA/pipelineConfig.yml'])
mavenPipelineTemplateCD([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-EDC-JAVA/pipelineConfig.yml',
     artifactChoices:["edc-answering","edc-batch","edc-billing","edc-cache","edc-callback","edc-config","edc-data-usage","edc-datos-autorizado","edc-facturas-descarga","edc-fwk","edc-installed-services","edc-ipvpn",
                      "edc-login","edc-menu","edc-one-net","edc-repairs","edc-reports","edc-reset","edc-services-management","edc-smoking","edc-terminales","edc-products","md-answering","md-averias","md-batch","md-callback","md-customer","md-customer-group","md-ebilling",
                      "md-fulfillment","md-gae","md-gestor-documental","md-home","md-kpi","md-login","md-menu","md-ordenes","md-pagos","md-premium-management","md-profile","md-resource-configuration",
                      "md-service-balance","md-special-order", "md-terminales", "edc-repairs"],
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID1CI","master"]])



