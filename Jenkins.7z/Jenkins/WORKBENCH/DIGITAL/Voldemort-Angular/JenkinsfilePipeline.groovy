#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/Voldemort-Angular/pipelineConfig.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/Voldemort-Angular/pipelineConfig.yml',
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID","master"]])
