#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/NuevoRegistro-Angular/pipelineConfig.yml'])
