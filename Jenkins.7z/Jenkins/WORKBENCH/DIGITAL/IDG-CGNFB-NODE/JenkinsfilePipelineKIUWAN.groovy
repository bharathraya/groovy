#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

ibmcloudNodePipelineTemplateKIUWAN([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-CGNFB-NODE/pipelineConfig.yml',
     artifactChoices:["vf-plataforma-alarmado","APP-vf-assistant-survey-nps","APP-vf-assistant-survey-cati","APP-vf-eventos-notificaciones"],
	 environmentChoices:["PPRD","master"]])
