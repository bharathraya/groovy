#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'Jenkins/WORKBENCH/DIGITAL/IDG-MVOW-ANGULAR-catalogo-front/pipelineConfig.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-MVOW-ANGULAR-catalogo-front/pipelineConfig.yml',
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID1CI","master","AUX12"]])
