#!groovy
@Library(value='CDMJenkinsSharedLib@feature/github', changelog=false) _

ibmcloudPythonPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-CGNFB-PYTHON/pipelineConfigGH.yml',
     artifactChoices:["vf-generador-urls"],
	 environmentChoices:["PPRD","master"]])
