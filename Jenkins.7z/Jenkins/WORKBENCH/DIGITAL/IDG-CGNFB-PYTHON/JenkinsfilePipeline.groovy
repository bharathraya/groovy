#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

ibmcloudPythonPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-CGNFB-PYTHON/pipelineConfig.yml',
     artifactChoices:["vf-generador-urls"],
	 environmentChoices:["PPRD","master"]])
