#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/front-webbajas-cliente/pipelineConfig.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/front-webbajas-cliente/pipelineConfig.yml',
	 environmentChoices:["SIT1","SIT2","PPRD","HID","master"]])
