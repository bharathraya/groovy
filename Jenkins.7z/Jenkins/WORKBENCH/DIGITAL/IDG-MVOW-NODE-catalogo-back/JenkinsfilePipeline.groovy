#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'Jenkins/WORKBENCH/DIGITAL/IDG-MVOW-NODE-catalogo-back/pipelineConfig.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-MVOW-NODE-catalogo-back/pipelineConfig.yml',
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID","master","AUX12"]])

