#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/front-webbajas-agente/pipelineConfig.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/front-webbajas-agente/pipelineConfig.yml',
	 environmentChoices:["SIT1CI","SIT2CI","PPRD1CI","HID","master"]])
