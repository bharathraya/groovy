#!groovy
@Library(value='CDMJenkinsSharedLib@feature/github', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/AccesoIKKI/pipelineConfig_bit.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/AccesoIKKI/pipelineConfig_GH.yml',
	 environmentChoices:["SIT1CI","SIT2CI","PPRD1CI","HID","SIT3CI","master"]])
