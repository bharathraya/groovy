#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

mavenMVOWBackPipelineKiuwan([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-APP/pipelineConfigKiuwan.yml'])
