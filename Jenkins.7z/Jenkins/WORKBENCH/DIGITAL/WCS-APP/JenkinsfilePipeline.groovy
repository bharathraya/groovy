#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

mavenMVOWBackPipeline([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-APP/pipelineConfig.yml'])
