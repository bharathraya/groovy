#!groovy
@Library(value='CDMJenkinsSharedLib@feature/github', changelog=false) _

mavenMVOWBackPipeline([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-APP/pipelineConfig_GH.yml'])
