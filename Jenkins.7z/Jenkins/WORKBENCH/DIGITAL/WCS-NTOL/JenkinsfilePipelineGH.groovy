#!groovy
@Library(value='CDMJenkinsSharedLib@feature/github', changelog=false) _

//mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-NTOL/pipelineConfig.yml'])
mavenPipelineTemplateCD([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-NTOL/pipelineConfigGH.yml',
     artifactChoices:["vf-back-common","vf-back-digital","vf-back-cesta","vf-back-tienda","vf-back-trastienda","vf-back-catalogo","vf-back-carga-catalogo","criteria-engine"],
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","SIT3CIWL14","PPRD1CI","HID1CI","master"]])