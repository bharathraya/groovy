#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-NTOL/pipelineConfigGitLab.yml'])
