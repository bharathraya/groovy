#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//mavenPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-NTOL/pipelineConfig.yml'])
mavenPipelineTemplateCD([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/WCS-NTOL/pipelineConfig.yml',
     artifactChoices:["vf-back-common","vf-back-digital","vf-back-cesta","vf-back-tienda","vf-back-trastienda","vf-back-catalogo","vf-back-carga-catalogo","criteria-engine"],
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID1CI","master"]])