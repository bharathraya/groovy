#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/SeguimientoPedidos-Angular/pipelineConfig.yml'])
