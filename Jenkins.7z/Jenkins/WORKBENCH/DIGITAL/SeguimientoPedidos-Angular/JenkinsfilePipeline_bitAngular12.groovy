#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/SeguimientoPedidos-Angular/pipelineConfig_bit.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/SeguimientoPedidos-Angular/pipelineConfig_bitAngular12.yml',
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID","master"]])
