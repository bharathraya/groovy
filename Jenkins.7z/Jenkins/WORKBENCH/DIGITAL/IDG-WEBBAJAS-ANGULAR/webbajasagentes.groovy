#!groovy
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-WEBBAJAS-ANGULAR/webbajasagentes.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/IDG-WEBBAJAS-ANGULAR/webbajasagentes.yml',
	 environmentChoices:["SIT1CI","SIT2CI","PPRD1CI","HID","master"]])
