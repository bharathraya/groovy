#!groovy
@Library(value='CDMJenkinsSharedLib@feature/github', changelog=false) _

//angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/Registro-Angular/pipelineConfig_bit.yml'])
angularPipelineTemplate([pipelineConfigFile:'CDM/Jenkins/WORKBENCH/DIGITAL/Registro-Angular/pipelineConfig_GH.yml',
	 environmentChoices:["SIT1CI","SIT2CI","SIT3CI","PPRD1CI","HID","master"]])
