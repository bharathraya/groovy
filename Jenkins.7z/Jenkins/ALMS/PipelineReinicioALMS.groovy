#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
@Library(value='CDMJenkinsSharedLib@master', changelog=false) _
import vfes.utils.VFESALMSDeployment

def _date=new Date().format( 'yyyyMMddHHmm' )
def mynodo=params.NODO
def myapp=params.APP
def VariableSCPBoolean = true
def VariableALL = false
    //Configuramos el nombre del build y su descripcion    
    currentBuild.displayName = "Reinicio: ${myapp} ${mynodo}"
    currentBuild.description = "Reinicio: ${myapp} ${mynodo}"


if ( "${myapp}" == "ALMS" && "${mynodo}" == "nodo1" || "${mynodo}" == "ALL" ){
//Parada ALMS
node ("opedes71-platafor") {    
   stage ("Reinicio_ALMS1"){
       print "**********************"
       print " Reiniciamos el nodo1 "
       print "**********************"
       exec_reinicio_alms1="""
       cd /opt/weblogic/wlalms/ALMS
       ./wl kill nodo1
       ./wl start nodo1
       """
       sh "ssh -q wlalms@webap11p.prod.airtel.es '${exec_reinicio_alms1}'" //wlalms
   } //stage
} //node
} //if

if ( "${myapp}" == "ALMS" && "${mynodo}" == "nodo2" || "${mynodo}" == "ALL" ){
node ("opedes71-platafor") { 
   stage ("Reinicio_ALMS2"){
       print "**********************"
       print " Reiniciamos el nodo2 "
       print "**********************"
       exec_reinicio_alms2="""
       cd /opt/weblogic/wlalms/ALMS
       ./wl kill nodo2
       ./wl start nodo2
       """
       sh "ssh -q wlalms@webap12p.prod.airtel.es '${exec_reinicio_alms2}'" //wlalms
   } //stage
} //node
} //if

if ( "${myapp}" == "ALMS" && "${mynodo}" == "Admin" || "${mynodo}" == "ALL" ){
node ("opedes71-platafor") {
   stage ("Reinicio_ALMS3"){
       print "**********************"
       print " Reiniciamos el Admin "
       print "**********************"
       exec_reinicio_alms3="""
       cd /opt/weblogic/almsadm/ALMS
       ./wl kill Admin
       ./wl start Admin
       """
       sh "ssh -q almsadm@webap12p.prod.airtel.es '${exec_reinicio_alms3}'" //wlalms
   } //stage
} //node
} //if