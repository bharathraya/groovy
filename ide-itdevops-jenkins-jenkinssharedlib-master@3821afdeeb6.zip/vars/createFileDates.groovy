def call(String _Alms,_dataModules,String _remoteServer,String _date,String _Env){

    def data_module_name=""
    def es_tipo_bbdd=""
    def es_rollback=""
    def pos=0
    def order_file=""
    def order_content=""
    
    order_file="modulos_datos_${_Alms}.txt"
    
    for (pos = 0; pos < _dataModules.size(); pos++) {
        data_module_name = _dataModules[pos].FileName;
        es_tipo_bbdd = _dataModules[pos].IsDataBase;
        es_rollback = _dataModules[pos].IsRollback;

        if (es_tipo_bbdd == true){
            if (es_rollback == false){
                order_content = "${order_content} echo ${data_module_name} >> ${order_file};"
            }
            else{
                print "Module [${data_module_name}] is rollback, omited"
            }
        }
        else{
            print "Module [${data_module_name}] is NOT type BBDD, omited"
        }
    }

    if (order_content == ""){
        error("Order file [${order_file}] is empty")
    }

    //def ruta_temp="/home/plataforma/plausr/data/temporal/${_date}/anexo/${_Alms}"
    
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    export ruta_temp1=\$DIR_BASE_PAQUETE/${_date}/${_Alms}
    cd \$USR_LOG
        if [ -f \$USR_LOG/${order_file} ]
        then
            echo \"Already exist the file \$USR_LOG/${order_file}. deleting it\"
            rm -f \$USR_LOG/${order_file} 
        fi
    
    ${order_content}
    if [ ! -d \${ruta_temp1} ]
    then
        mkdir -p \${ruta_temp1}
    fi
    cd \${ruta_temp1}
    scp -qr es036tvr:/home/plataforma/plausr/data/temporal/${_date}/${_Alms}/${_Env}/DataModules/* .
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}

