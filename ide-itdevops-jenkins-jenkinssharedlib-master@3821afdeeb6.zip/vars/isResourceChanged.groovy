def call(String resourcetype,String resourcename,String ENTORNO, List _sChangeList ){
    echo "isResourceChanged"
    def salida=false
    _sChangeList.any(){
        def token=it.tokenize("/")
        if (resourcetype == "configmap"){
            if (token[2]==resourcename && token[3]==ENTORNO){
                salida=true
                return true
            }
        }
        if (resourcetype == "secretTemplates" || resourcetype == "secretGeneric"){
            if (token[3]==resourcename && token[2]==ENTORNO){
                salida=true
                return true
            }
            if (token[2]==resourcename){
                salida=true
                return true
            }
        }
    }
    return salida
}