def call ( String RELEASEORDERFILE, String bitbucket, String _Delivery, String ENTORNO, String _SortCommit ){
    echo "checkBranchCompatibility"
    echo "releasejson:${RELEASEORDERFILE}"
    def cadenajson = readFile("${RELEASEORDERFILE}")
	list BranchList=getBranchList("${bitbucket}")
	echo "Branches:" + BranchList.join(",")
    cadenajson=addMissingBrachesInfo(cadenajson, BranchList)
	list ListPrevRelease=getListPrevRelease(cadenajson, _Delivery, ENTORNO)
	def COMMITDIFF=""
    ListPrevRelease.each{
        def remotebranch=""
        if ("${bitbucket}" == "bitbucket"){
            remotebranch="origin/vodafone/"+"${it}"
        }else{
		    remotebranch="origin/"+"${it}"
        }
        echo "remotebranch:${remotebranch}"
		COMMITDIFF=checkCommitDiff(remotebranch,_SortCommit)
		if("${COMMITDIFF}" != ""){
            echo "WARNING:La entrega ${_SortCommit} no parte de la releases previa ${remotebranch}: ${COMMITDIFF}"
		}
	}
}