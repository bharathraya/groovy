import vfes.git.VFESGitMergeInfo
import vfes.git.VFESGitRepo

def call(VFESGitRepo repo,VFESGitRepo remote, String remoteBranch, String localBranch, String commitID, String localPath,String mergeMessage)
{
    VFESGitMergeInfo ret=new VFESGitMergeInfo()
    // Checkout 
    ret.commitPackage=commitID
    checkout([$class: 'GitSCM', 
            branches: [[name: "${remoteBranch}"]], 
            doGenerateSubmoduleConfigurations: false, 
            extensions: [
                [$class: 'LocalBranch', localBranch: "${localBranch}"], 
                [$class: 'RelativeTargetDirectory', relativeTargetDir: "${localPath}"]], 
            submoduleCfg: [], 
            userRemoteConfigs: [[credentialsId: "${repo.checkoutCred}", 
                        url: "${repo.protocol}${repo.server}/${repo.repoPath}/${repo.repoName}.git"]]
            ])
    // Merge 
    dir("${localPath}"){

        //add remote
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${remote.checkoutCred}",
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            echo "${remote.protocol}${USERNAME}:${PASSWORD}@${remote.server}/${remote.repoPath}/${remote.repoName}.git"
            sh """
                git config --global user.email dl-sp-cm-dep@vodafone.com
                git config --global user.name platafor
                git remote add entregas ${remote.protocol}${USERNAME}:${PASSWORD}@${remote.server}/${remote.repoPath}/${remote.repoName}.git
                git fetch entregas
            """
        }
        ret.commitBefore = sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
        echo "GitCommit Before MERGE: ${ret.commitBefore}"
        sh "git branch"
        try{
            sh "git merge --no-ff -m'${mergeMessage}' ${commitID} "
        }
        catch(Exception){
            echo "There are following merge conflicts!"
            sh '''#!/bin/sh
            git diff --name-only --diff-filter=U | while read f
            do
            echo File: $f
            git log -3 --follow --pretty=format:"%h%x09%an%x09%ad%x09%s" $f
            echo
            done
            '''
            error('Stopping the job, has merge conflicts!!!')
        }
        ret.commitAfter = sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
        echo "GitCommit After MERGE: ${ret.commitAfter}"
        sh """#!/bin/sh
        echo These are the changes between ${ret.commitBefore}..${ret.commitAfter}
        git diff --name-only  ${ret.commitBefore}..${ret.commitAfter}
        """

        if (ret.commitBefore==ret.commitAfter){
            echo "We don't publish changes because both commits are equal!"
        }
        else{
            ret.filesChanged=sh(returnStdout: true, script: "git diff --name-only ${ret.commitBefore}..${ret.commitAfter}").split()
            publishGitChanges pwd(),ret.commitBefore,ret.commitAfter
        }
    }
    return ret;
}
return this;