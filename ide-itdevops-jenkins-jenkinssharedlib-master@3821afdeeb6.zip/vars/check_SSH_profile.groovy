def call(String _user,String _Node,String _remoteServer){
    exec="""
    ksh -x \$HOME/.profile
	"""
    if (_Node==_remoteServer)
    {
        _remoteServer=""
    }
    
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}