def call(String _NombrePaquete,String _OrdenBBDD, String _NombreCRQ){
   hoy=new Date().format( 'yyyyMMdd' )
   myorden=readFile(file: "CDM/DOCUMENTATION/${_NombreCRQ}/${_OrdenBBDD}")
   //print " fichero ${myorden} "
   Ordenjson=myorden.split()
   //print " Fichero spliteado ${Ordenjson}"
   tamano= Ordenjson.size()
   //print " Tamaño ${tamano}"
   rutapaquete="/home/plataforma/plausr/data/paquetes/${hoy}/${_NombrePaquete}"
  // print "${rutapaquete}"
   sh "touch -f ${rutapaquete}/FaltanEnPaquete.txt"
   NoEnElPaquete="${rutapaquete}/FaltanEnPaquete.txt"
   //print "${NoEnElPaquete}"
   sh "touch -f ${rutapaquete}/FaltanEnOrden.txt"
   NoEnElOrden="${rutapaquete}/FaltanEnOrden.txt"
   //print "${NoEnElOrden}"
   sh "cp CDM/DOCUMENTATION/${_NombreCRQ}/${_OrdenBBDD} ${rutapaquete}"
   OrdenPaquete="${rutapaquete}/${_OrdenBBDD}"
   
   //En la maquina eswltbhr en .paquete tengo el codigo
   for (pos = 0; pos < tamano; pos++) { 
       Modulo="${rutapaquete}/PROD/${Ordenjson[pos]}"
      // print "modulo ${Modulo}"
       sh " if [ ! -f  ${Modulo} ] ; then echo ${Ordenjson[pos]} >> ${NoEnElPaquete} ; fi"
   }
    
    sh " cd ${rutapaquete}/PROD ; find CRM -type f > ${rutapaquete}/Ficheros.txt "
    myficheros=readFile(file: "${rutapaquete}/Ficheros.txt")
    FicherosJson=myficheros.split()
    //print "ordenPaquete  ${OrdenPaquete}"
    sh "cd ${rutapaquete}"
    //En la maquina eswltbhr en .paquete tengo el codigo
   for (pos = 0; pos < FicherosJson.size(); pos++) { 
        Modulo= "${FicherosJson[pos]}"
      //  print "modulo ${Modulo}"
          try{
              sh " touch -f ${rutapaquete}/fich ; grep  '${Modulo}' ${OrdenPaquete} > ${rutapaquete}/fich  "
            } catch(Exception e){
                                 echo " Modulo ${Modulo} no esta en el orden error: ${e}" 
                                 sh " echo ${Modulo} >> ${NoEnElOrden}"
                                    }    
        sh "rm -f ${rutapaquete}/fich"
   }//for
   
   //veo que ha fallado
   FalloOrden=readFile(file: "${rutapaquete}/FaltanEnOrden.txt" )
   FalloPaquete=readFile(file: "${rutapaquete}/FaltanEnPaquete.txt")
   
   if (FalloOrden != "" || FalloPaquete != "" )
   {
       print "****************************************"
       print "         INTEGRIDAD INCORRECTA"
       print "****************************************"
   }
   if (FalloOrden == "" && FalloPaquete == "" )
   {
       print "****************************************"
       print "         INTEGRIDAD CORRECTA"
       print "****************************************"
   }
   if (FalloOrden != "")
   {
       print "****************************************"
       print "         FALTAN EN EL ORDEN"
       print "****************************************"
       print "${FalloOrden}"
   }
   else
   {
       sh " rm -f  ${rutapaquete}/FaltanEnOrden.txt"
   }
   if (FalloPaquete != "")
   {
       print "****************************************"
       print "         FALTAN EN EL PAQUETE"
       print "****************************************"
       print "${FalloPaquete}"
   }
   else
   {
       sh " rm -f  ${rutapaquete}/FaltanEnPaquete.txt"
   }
   
   
    
}