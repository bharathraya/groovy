def call(String clusterName, String _ARTID,String _VERSION, String _ENTORNO, String noproxy ) {
    echo "CheckOCImageVersionDSL (${clusterName},..)"
    def version=""
    def versionaux=""
    def lowerARTID=_ARTID.toLowerCase()
    withEnv(["PATH+OC=${tool 'occli-jenkins'}","KUBECONFIG=$HOME/.kube/config"]) {
        openshift.withCluster(clusterName) {
    	    echo "Using Cluster: ${openshift.cluster()}"
    	    openshift.withProject("${_ENTORNO}") {
    	        //echo "Using project: ${openshift.project()}"
    	        if(openshift.selector('is', "${lowerARTID}").exists()){
        	        def tags = openshift.selector('is', "${lowerARTID}").object().status.tags
                	tags.any{
                	    versionaux=it.tag
                        //echo "Found tag:${versionaux}"
                        if( "${versionaux}" == "${_VERSION}"){   
                            version=versionaux
                            echo "Ya existe la imagen ${_ARTID}:${version}"
                            return true
                        }
                    }
                	if ( version == "")
                	{
                	    echo "Existe la imagen en el repositorio, pero no la version ${_VERSION}"
                	}
    	        }else{
    	            echo "No existe la imagen en el repositorio"
    	        }
            }
        }
    }
    return version
}