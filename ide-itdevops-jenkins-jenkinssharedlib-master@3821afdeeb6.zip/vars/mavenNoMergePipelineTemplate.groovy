def deploy_env=""
def commit_id=""
def alms_id=""
def delivery=""
def project_id=""
def squad=""
def pckinfo=null
def gitRepo=null
def pipelineConfig=null
def artifact_id=""
// NOT IN USE 
def mergeInfo=null
def almsPackage=null
def onlyProperties=false



def call(Map pipelineParams){
    pipeline{
        agent none
        parameters { 
            string(name: 'DeployEnv', defaultValue: '', description: '') 
            string(name: 'CommitID', defaultValue: '', description: '') 
            string(name: 'ALMS_ID', defaultValue: '', description: '') 
            string(name: 'Delivery', defaultValue: '', description: '') 
            string(name: 'ProjectId', defaultValue: '', description: '') 
            string(name: 'ArtifactID', defaultValue: '', description: '') 
            string(name: 'SQUAD', defaultValue: 'BAU', description: '') 
            string(name: 'PackageInfo', defaultValue: '', description: '') 
        }
        stages{
            stage('config'){
                agent {
                    label 'MVOW'
                }
                steps
                {
                    // recibir info 
                    script{
                        
                        if (PackageInfo==""){
                            // executed manually or from ALMS
                            deploy_env=DeployEnv
                            commit_id=CommitID
                            alms_id=ALMS_ID
                            delivery=Delivery
                            project_id=ProjectId
                            squad=SQUAD
                            artifact_id=ArtifactID
                        }else{
                            echo "PackageInfo: ${PackageInfo}"
                            (deploy_env,commit_id,alms_id,delivery,project_id,squad)=parsePckInfo(PackageInfo)
                            //pckinfo=readJSON(text:PackageInfo)
                            //deploy_env=pckinfo.Environment.Name
                            //commit_id=pckinfo.decideCommitId(pckinfo.Commits,deploy_env)
                            //alms_id=pckinfo.Id
                            //delivery=pckinfo.Delivery.Name
                            //project_id=pckinfo.Project.CodProject
                            //squad=pckinfo.EnterpriseName

                        }
                        // si es 
                        echo "    DeployEnv: ${deploy_env}"
                        echo "    CommitID:  ${commit_id}"
                        echo "    PackageID: ${alms_id}"
                        echo "    Delivery:  ${delivery}"
                        echo "    Project:   ${project_id}"
                        echo "    Artifact:  ${artifact_id}"
                        echo "    Squad:     ${squad}"
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        almsPackage= new VFESALMSDeployment(alms_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,squad)
                        
                        
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
                        
                    }

                }
            }
            stage('checkout'){
                url=pipelineConfig.gitRepoPath+""

            }
            
        }
        
    }
}