
def pipelineConfig=null

def call(Map pipelineParams){
    

    pipeline {
        agent {
            kubernetes {
                //cloud 'kubernetes'
                defaultContainer 'maven-npm'
                yaml """
apiVersion: v1
kind: Pod
metadata:
labels:
spec:
  imagePullSecrets:
  - name: regcred-harbor
  containers:
  - name: jnlp
    env:
    - name: CONTAINER_ENV_VAR
      value: jnlp
  - name: maven-npm
    image: webpre-adm.es.sedc.internal.vodafone.com:44150/devops/npm-sonar-slave:alpine
    command:
    - cat
    tty: true
    env:
    - name: CONTAINER_ENV_VAR
      value: maven-npm
"""

//                containerTemplate {
//                name 'maven-npm'
//                image 'npm-sonar-slave:alpine'
//                ttyEnabled true
//                command 'cat'
//                workingDir '/home/jenkins/agent'
//                }
            }
        }
        stages {
            stage('config_job'){
                steps{
                    script{
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        //echo sh(returnStdout: true, script: 'env')
                        currentBuild.displayName = "Branch: ${gitlabBranch}"
                        currentBuild.description = "Branch: ${gitlabBranch} Username: ${gitlabUserName} eMail: ${gitlabUserEmail}"
                    }
                }
            }
            stage('clean'){
                steps{
                    script{
                        deleteDir()
                    }
                }            
            }
            stage('checkout'){
                steps{
                    checkout([$class: 'GitSCM', branches: [[name: "*/${gitlabBranch}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'project']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', url: "${gitlabSourceRepoHttpUrl}"]]])
                    checkout([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'CDM']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', url: 'http://eswltbhr:8282/vodafone/CDM.git']]])
                }
            }
            stage('build'){
                steps{
                    script{
                        dir('project'){
                        sh "npm install "                      
                        // este paso deberia ser "parametrizable"
                        sh "grunt build"  
                        //echo "comentado"                    
                        }
                    }
                    
                }
            }
            stage('sonar'){
                steps{
                    script{

                        //sh "cp CDM/${pipelineConfig.sonarproperties} project/"
                        dir('project'){
                        withSonarQubeEnv('sonar') {
                            sh "sonar-scanner  -Dsonar.host.url=http://195.233.178.75:9000/sonar/ -Dsonar.branch.name=${gitlabBranch} "
                        }

                        }
                    }

                }
            }
            
        
        }
    }
}
