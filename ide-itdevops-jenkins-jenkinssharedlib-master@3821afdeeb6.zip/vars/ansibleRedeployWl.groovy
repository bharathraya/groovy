import vfes.utils.VFESALMSDeployment

def call(artifacts,Map config,VFESALMSDeployment alms)
{
    echo "ARTIFACTS: ${artifacts}"
    for (i=0;i<artifacts.size();i++)
    { artifact=artifacts[i]
        echo "Checking for CDM/Ansible/vars/${alms.deployEnv}/${config.artifactPath}/${artifact.artifactId}.yml"
        if (fileExists ("CDM/Ansible/vars/${alms.deployEnv}/${config.artifactPath}/${artifact.artifactId}.yml")){
            echo "Deploying ${config.artifactPath}/${artifact.artifactId} in ${alms.deployEnv} env ..."
            def ansibleInstall='ansibleusrbin'
            if (config.containsKey('ansibleInstall')){
                ansibleInstall=config.ansibleInstall
            }
            echo "Using ansible install config: "+ansibleInstall
			color="#FFA500" // orange
			message="WorkBench Package: ${alms.almsID}\nStarting redeploy of ${artifact.artifactId} in environment ${alms.deployEnv}"
			//slackSend(channel: "#es_sq_devops_pruebas", color: color, message: message)
			slackSend(channel: config.slackChannel, color: color, message: message)
			def opt_rollback=""
			if (config.containsKey("doRollback") && config.doRollback){
				opt_rollback="rollback=true clean_stage=true clean_cache=true"
			}
            ansiblePlaybook(
                playbook: 'CDM/Ansible/redeploy.yml',
                inventory : "CDM/Ansible/inventories/${alms.deployEnv}/hosts",
                installation: ansibleInstall,
                extras: "-e 'deployment_env=${alms.deployEnv} deployment_artifact=${config.artifactPath}/${artifact.artifactId} ${opt_rollback}'")
			color="#00FF00" // green
			message="WorkBench Package: ${alms.almsID}\nFinished redeploy of ${artifact.artifactId} in environment ${alms.deployEnv}"
			//slackSend(channel: "#es_sq_devops_pruebas", color: color, message: message)
			slackSend(channel: config.slackChannel, color: color, message: message)

        }else
        {
            echo "Skipping deployment as file CDM/Ansible/vars/${alms.deployEnv}/${config.artifactPath}/${artifact.artifactId}.yml does not exist"
        }
    }

}