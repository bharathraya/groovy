def call (String _delivery, String _app){
    echo "get_app_max_deliveryenv"
    def entorno="" 
    node ('eswltbhr'){
        //Usuario
        wrap([$class: 'BuildUser']) {
             echo "Exec user: ${env.BUILD_USER_ID}"
             _usuario=env.BUILD_USER_ID
           }
        //Contraseña
         (_pass,_usuario)=findpassword(_usuario)
        
        checkout scm
        
        dir ("CDM/CommonTools/WorkBenchClient"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                
                entorno=sh(returnStdout: true, script: "python get_app_deliveryenv.py -d ${_delivery} -a ${_app} -u ${_usuario} -c ${_pass} |awk -F: '{a[\$3]++}END{max=0;entorno=\"\";for(i in a){if(a[i]>max){max=a[i];entorno=i}}print entorno}'")
                
             }//wrap
        }
    }
    return entorno
}
