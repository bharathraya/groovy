def call(String _CRQ, String _Carpeta, String _env){
   hoy=new Date().format( 'yyyyMMdd' )
   iBtora=0  
   RutaPaquete="/home/plataforma/plausr/tmp/${hoy}/${_CRQ}"
   
   sh ". \$HOME/.profile >/dev/null 2>&1 ; . paquete ${_Carpeta} ${_env} ; find BBDD -type f > ${RutaPaquete}/${_Carpeta}_listaBBDD.txt "
   
   ListaBBDD=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ}/${_Carpeta}_listaBBDD.txt")
   //print "Lista Modulos BBDD  ${ListaBBDD} "
  
    ModulosBBDD = ListaBBDD.split("\n")
    //print "Modulos BBDD ${ModulosBBDD} "
    tam=ModulosBBDD.size()
    //print "Modulos a instalar ${tam}"
    
     for (pos = 0; pos < ModulosBBDD.size(); pos++) {
        Linea = ModulosBBDD[pos]
        BBDDMod=Linea.split("/")
      //print "Modulo: ${BBDDMod}"
        _ServerBBDD=BBDDMod[1]  //Servidor donde ejeuctar
      //print "Servidor ${_ServerBBDD} "
        _user=BBDDMod[2]   //usuario
      //print "Lista ${_user} "
        
        if ("${_ServerBBDD}" == "BTORA" )
        {
             iBtora=1
        }     
         
            //print "Ejecutar ${Linea} en el gestor ${_ServerBBDD} con el usuario ${_user} "
            sh "echo 'Ejecutar ${Linea} en el gestor ${_ServerBBDD} con el usuario ${_user}' >>  ${RutaPaquete}/InstruccionesBBDD.txt"
        
    }//for
    
    if (iBtora==1)
    {
        sh "echo 'Para los modulos del servidor BTORAP ejecutar estos export antes del sqlplus.' >>  ${RutaPaquete}/InstruccionesBBDD.txt"
        sh "echo '         export ORACLE_HOME=/home/oracle/product/12.2.0' >>  ${RutaPaquete}/InstruccionesBBDD.txt"
        sh "echo '         export LD_LIBRARY_PATH=\$ORACLE_HOME/lib:\$LD_LIBRARY_PATH' >>  ${RutaPaquete}/InstruccionesBBDD.txt"
        sh "echo '         export PATH=\$ORACLE_HOME/bin:\$PATH' >>  ${RutaPaquete}/InstruccionesBBDD.txt"
        sh "echo '' >>  ${RutaPaquete}/InstruccionesBBDD.txt"

    }

}
