def call(String API, Object env_config, String check){
    echo "getApigeeDeployedRevision1"
    List REVISION=[]
    def SALIDA=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
                                credentialsId: "${env_config.credentialid}", 
                                usernameVariable: 'USERNAME', 
                                passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            https_proxy="${env_config.proxyurl}"
            export https_proxy
            no_proxy="${env_config.noproxy}"
            export no_proxy
            curl -X GET --write-out "HTTPSTATUS:%{http_code}" --header "Accept: application/json" -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/apis/${API}/deployments"
        """

        def index=SALIDA.indexOf('HTTPSTATUS:')+11
        def errorcode=SALIDA.substring(index,index+3)
        echo "GET status:${errorcode}"
        if (errorcode.substring(0,1) !="2" && errorcode.substring(0,1) !="4"){
            echo "WARNING:${SALIDA}"
            error "Error en ejecucion curl - Revisar CADUCIDAD DEL USUARIO (resetear pwd si aplica)"
        }
        def salidaJson=SALIDA.substring(0,SALIDA.indexOf("HTTPSTATUS:"))
        
        if (salidaJson != ""){
            apiInfo=readJSON(text: "${salidaJson}")
            echo "apiInfo:${apiInfo}"
            apiInfo.environment.each(){
                def ENVinfo=it
                if (ENVinfo.name == env_config.env ){
                    ENVinfo.revision.each(){
                        def revision=it
                        if(revision.state=="deployed"){
                            REVISION.add(revision.name)
                        }else{
                            REVISION.add("-1")
                            echo "WARNING:ENVinfo.revision.state:${revision.state}"
                            if (check=="ERROR"){
                                echo "ERROR -------------------"
                                echo "ERROR "
                                error "Al obtener getApigeeDeployedRevision, avisar al Administrator de Apigee"
                            }
                        }
                    }
                }
            }
        }
    }
    if (REVISION.size()==0){
        REVISION.add("0")
    }
    List REVISIONUNIQUE=REVISION.unique()
    echo "Deployed Revision:${REVISIONUNIQUE}"
    return "${REVISIONUNIQUE}"
}