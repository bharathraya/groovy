def call (String _view){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python get_packagesbyview.py -v ${_view}"
        }
    }
}

def call (String _view ,String _User ,String _pass){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
             wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                 bat "python get_packagesbyview.py -v ${_view} -u ${_User} -c ${_pass}"
             }//wrap
        }
    }
}
