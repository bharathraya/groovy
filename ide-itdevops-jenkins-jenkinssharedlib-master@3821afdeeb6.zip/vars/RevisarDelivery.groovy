def call(String _delivery,String _CRQ_ID){
 
 // hoy=new Date().format( 'yyyyMMdd' )

//print "DATOS RECOGIDOS"
print "Deliverys to review ${_delivery}"
//print " CRQ ${_CRQ_ID}"

   exec="""
        . \$HOME/.profile >/dev/null 2>&1
        CheckDelivery.sh -p ${_CRQ_ID} -D "${_delivery}"
      """
      
sh "${exec}"
}
