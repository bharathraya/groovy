def call(String _Alms,String _Env,String _remoteServer){
 
  hoy=new Date().format( 'yyyyMMdd' )
  fichero_e="${_Alms}.${_Env}.deploy"
  fichero_por="${_Alms}.${_Env}.por_paquete"
  fichero_e_backout="${_Alms}.${_Env}.rollback"

    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_Alms} 
    export fichero_e="${_Alms}.${_Env}.deploy"
    export fichero_e_backout="${_Alms}.${_Env}.rollback"
    export fichero_por="${_Alms}.${_Env}.por_paquete"

    scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_Alms}/${_Env} .
    scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_Alms}/${fichero_e} ${_Env}/e
    scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_Alms}/${fichero_e_backout} ${_Env}/e_backout

    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
