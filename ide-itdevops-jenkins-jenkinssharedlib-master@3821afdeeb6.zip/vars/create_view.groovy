def call (String _Nombre,String _env,String _date,String _user, String _password, String _sistema){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            if (_sistema == "N")
            {
                bat 'python create_view.py -s "CRM AMDOCS" '+"-v ${_Nombre} -e ${_env} -f ${_date} -u ${_user} -c ${_password} "
            }
            else
            {
                bat 'python create_view.py -s "CRM AMDOCS 10.2" '+"-v ${_Nombre} -e ${_env} -f ${_date} -u ${_user} -c ${_password} "
            }
            
        }
    }
}

