def call(String API, Object env_config){
    echo "getApigeeLastRevision"
    def REVISION=""
    def SALIDA=""
    def maxrev=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
                                credentialsId: "${env_config.credentialid}", 
                                usernameVariable: 'USERNAME', 
                                passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            https_proxy="${env_config.proxyurl}"
            export https_proxy
            no_proxy="${env_config.noproxy}"
            export no_proxy
            curl -X GET --write-out "HTTPSTATUS:%{http_code}" --header "Accept: application/json" -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/apis/${API}"
        """
        
        def index=SALIDA.indexOf('HTTPSTATUS:')+11
        def errorcode=SALIDA.substring(index,index+3)
        echo "GET status:${errorcode}"
        if (errorcode.substring(0,1) !="2" && errorcode.substring(0,1) !="4"){
            echo "WARNING:${SALIDA}"
            error "Error en ejecucion curl - Revisar CADUCIDAD DEL USUARIO (resetear pwd si aplica)"
        }
        def salidaJson=SALIDA.substring(0,SALIDA.indexOf("HTTPSTATUS:"))
        if (salidaJson != ""){
            apiInfo=readJSON(text: "${salidaJson}")
            echo "apiInfo:${apiInfo}"
            if (apiInfo.revision !=null){
                maxrev=apiInfo.revision.max{it.toInteger()}
            }else{
                maxrev="0"
            }
        }
    }
    echo "Maxima revision:[${maxrev}]"
    return maxrev
}