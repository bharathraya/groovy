import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitMergeInfo
import vfes.git.VFESGitRepo

def call(Map pipelineParams) {
    
    //pipelineParams MAP contents:
    
    // **** App repo params
    //def gitAppProtocol=null
    //def gitAppServer=null
    //def gitAppPath=null
    //def gitAppName=null
    //def gitAppCredPush=null
    //def gitAppCredClone=null
    //def localAppPath=null

    // **** CDM repo params
    //def gitCDMProtocol=null
    //def gitCDMServer=null
    //def gitCDMPath=null
    //def gitCDMName=null
    //def gitCDMCredClone=null
    //def jobCDMGitPath
    
    // *** ALMS and App global params
    //def appName=null
    //def CommitID=""
    //def Delivery=""
    //def ProjectId=""
    //def ALMS_ID=""
    //def DeployEnv=""

    // *** Docker params 
    //def jobCDMBuildScript=null
    //def npmCacheFolder=null
    //def useNpmCacheFolder=null
    //def dockerImage=null
    
    

    // ** Deploy Params
    def envsJsonFile=null
    def htdocsPath=null
    def htdocsFolderName=null
    
    

    def cdmCheckoutPath=null
    def envConfig=null
    
    def varAppRepo=null
    def almsDeploy=null

    node("${pipelineParams.appName}-${DeployEnv}"){
        stage ("clean"){
            deleteDir()
        }
        stage("config"){

            
            
            jobCDMGitPath="Jenkins/IKKI/FRONT/PortalMovil"
            cdmCheckoutPath="CDM"
            jobCDMBuildScript="cm_build_script"
            dockerImage="vfes_cdm_centos7_ng_5.2.0:latest"
            // URL https://bitbucket.agile.vodafone.com/scm/c4destiny/vfes-web.git
            gitAppProtocol="https://"
            gitAppServer="bitbucket.agile.vodafone.com"
            gitAppPath="scm/c4destiny"
            gitAppName="vfes-web"
            htdocsPath="htdocs"
            htdocsFolderName="PortalMovil"
            envsJsonFile="envs.json"
            almsDeploy=new VFESALMSDeployment(ALMS_ID,localAppPath, DeployEnv, CommitID,Delivery,ProjectId)
            npmCacheFolder="/home/plataforma/jenkins/maven_repos/${JOB_NAME}/${DeployEnv}/node_modules"
            sh "mkdir -p ${npmCacheFolder}"
        }
        stage ("checkoutCDM"){
            def varCDMRepo=new VFESGitRepo("http://","eswltbhr:8282","vfjenkins-passwd","vodafone","CDM");
            checkoutLocal varCDMRepo,"master","master","${cdmCheckoutPath}",false
            def json = readJSON(file: "${WORKSPACE}/${cdmCheckoutPath}/${jobCDMGitPath}/${envsJsonFile}")
            envConfig=json[DeployEnv]
        }
        stage ("checkoutAndMergeCode"){
            def mergeMes=almsDeploy.getMergeMessage()
            echo "Merge Message=${mergeMes}"
            varAppRepo=new VFESGitRepo("${gitAppProtocol}","${gitAppServer}",
            "essvc.essvc-devops-Bitbucket","essvc.essvc-devops-URLEncode","${gitAppPath}","${gitAppName}");
            VFESGitMergeInfo mergeInfo=checkoutBranchAndMerge varAppRepo,"vodafone/${DeployEnv}","${DeployEnv}","${CommitID}",
                "${localAppPath}","${almsDeploy.getMergeMessage()}"
            
        }
        stage ("build"){
            sh "cp ${WORKSPACE}/${cdmCheckoutPath}/${jobCDMGitPath}/${jobCDMBuildScript} ${WORKSPACE}/${localAppPath}"
            sh "chmod 750 ${WORKSPACE}/${localAppPath}/${jobCDMBuildScript}"
            String args="/home/platafor/project/${jobCDMBuildScript}"
            String volApp="${WORKSPACE}/${localAppPath}:/home/platafor/project"
            String volNPMCache="${npmCacheFolder}:/home/platafor/project/node_modules"
            String [] vols=[volApp,volNPMCache]
            dockerBuild dockerImage,args,vols
        }
        stage ("deploy"){
                        
            deployToApache htdocsPath,"${WORKSPACE}/${localAppPath}",'PortalMovil.zip',htdocsFolderName,almsDeploy,envConfig
        }
        stage ("tagAndPush"){
            tagAndPush localAppPath,DeployEnv,"vodafone/${DeployEnv}",varAppRepo,almsDeploy
        }
        stage ("cleanAfterSuccess"){
            deleteDir()
        }

    }

}
