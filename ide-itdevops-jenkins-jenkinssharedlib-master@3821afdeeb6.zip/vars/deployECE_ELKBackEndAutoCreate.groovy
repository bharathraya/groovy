import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
def call(Map config,VFESALMSDeployment alms, VFESGitMergeInfo_aaresmi mergeInfo,Boolean NO_RESTART,ArrayList ParamItem2Delete)
{

  def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
  def _envConfig=myEnvsConfig[alms.deployEnv]

  //////////////////////////////////////////
  /////////CHECK REPOSITORY CHANGES/////////
  //////////////////////////////////////////

  items2DeployConfig=mergeInfo.FilesChangedDetailed.findAll{!(it[1] =~ "templates/" || it[1] =~ "ingest_pipeline/")}
  items2Delete=mergeInfo.FilesChangedDetailed.findAll{it[0] == "D" && (it[1] =~ "templates/" || it[1] =~ "ingest_pipeline/")}
  items2Rename=mergeInfo.FilesChangedDetailed.findAll{it[0] == "R" && (it[1] =~ "templates/" || it[1] =~ "ingest_pipeline/")}
  items2Deploy=mergeInfo.FilesChangedDetailed.findAll{(it[0] == "M" || it[0] == "A") && (it[1] =~ "templates/" || it[1] =~ "ingest_pipeline/")}

  //DEPRECATED
  //def allowDelete=false
  //if (!config.containsKey("allowDelete") || config.allowDelete == "N")
  //{
  //allowDelete=false
  //} else {
  //allowDelete=true
  //}
  echo "=============================================="
  echo "CHANGES FOUNDS IN COMMIT"
  echo "=============================================="
  echo "CHANGES ONLY AT FILESYSTEM LEVEL:"
  echo "Configuration Files to Deploy:  ${items2DeployConfig.size()}"
  echo "CHANGES AT ELASTICSEARCH LEVEL:"
  echo "ElasticSearch Items to Delete:  ${items2Delete.size()}"
  echo "ElasticSearch Items to Rename:  ${items2Rename.size()}"
  echo "ElasticSearch Items to Deploy:  ${items2Deploy.size()}"
  echo "=============================================="

  if (items2Deploy.size() == 0 && items2Delete.size() == 0 && items2Rename.size() == 0 && items2DeployConfig.size() == 0)
  {
    echo "ERROR. There are not any change detected!!!!!. "
    sh ("exit 1")
  }

  if (items2Delete.size() != 0) {
    echo "ElasticSearch Items to Delete detected. Checking with parameter ITEMS2DELETE ....."
    filesItems2Delete = []
    items2Delete.each { filesItems2Delete.add(it[1].value.toString()) }
    listFilesItems2Delete = filesItems2Delete as List
    //echo "listFilesItems2Delete=${listFilesItems2Delete}"

    def diffInFiles = (listFilesItems2Delete - ParamItem2Delete)
    def diffInParam = (ParamItem2Delete - listFilesItems2Delete)

    //echo "diffInFiles=${diffInFiles}"
    //echo "diffInParam=${diffInParam}"

    if (diffInParam.size() != 0) {
      echo "WARN. There are some ElasticSearch Items in the param ITEMS2DELETE that were not detected in the in the commit to be deleted!!!!!. "
      echo "${diffInParam}"
    }

    if (diffInFiles.size() != 0) {
      echo "ERROR. There are some ElasticSearch Items detected to be deleted in the commit that there isn't in the param ITEMS2DELETE!!!!!. We cannot continue"
      echo "${diffInFiles}"
      sh("exit 1")
    }
    echo "OK. ElasticSearch Items to Delete Checked with parameter ITEMS2DELETE Successfully."
    echo "=============================================="
  }

  //DEPRECATED
  //if (items2Delete.size() != 0 && !allowDelete)
  //{
  //  echo "The package try to DELETE the next objects and the allowDelete is disabled. Please check it with the developer"
  //  echo "${items2Delete}"
  //  sh ("exit 1")
  //}

  ///////////////////////////////////
  /////////NEW CHECK ACTIONS/////////
  ///////////////////////////////////
  if (config.containsKey("deployActions"))
  {
    deployECE_ELKCheckVariables config,alms
  }
  else
  {
    echo "===> Legacy"
    echo "Checking Variables ...."
    echo "_envConfig"+_envConfig['check_vars']
    _envConfig['check_vars'].each { item ->
      echo "Server Data:"
      echo "  check_vars_server: " + item.server
      echo "  check_vars_user: " + item.user
      echo "  application_release_path: " + item.application_release_path
      echo "  platafor_release_path: " + item.platafor_release_path
      echo "  repo_vars: " + item.repo_vars

      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.checkVarScript}"
      echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -b ${item.repo_vars}"
      sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.checkVarScript} -a ${config.applicationName} -r ${item.application_release_path} -b ${item.repo_vars}'"
    }
  }
  ///////////////////////////////////
  /////////NEW CHECK ACTIONS/////////
  ///////////////////////////////////

  echo "Deploying IndexTemplates|Templates, Ingest Pipelines, Pipelines Configs ...."
  echo "_envConfig"+_envConfig['deploy_templates']
  _envConfig['deploy_templates'].each { item ->
    echo "Server Data:"
    echo "  deploy_server: " + item.server
    echo "  deploy_user: " + item.user
    echo "  application_release_path: " + item.application_release_path
    echo "  platafor_release_path: " + item.platafor_release_path + "/scripts"
    echo "  variables repository: " + item.repo_vars
    echo "  deploy Script: " + config.deployScript
    echo "ElasticSearch Data:"
    echo "  elastic_sch: " + item.elastic_sch
    echo "  elastic_host: " + item.elastic_host
    echo "  elastic_port: " + item.elastic_port
    echo "  elastic_credential: " + item.elastic_credential
    def _elasticURL=""

    //DELETE
    if ( items2Delete.size() != 0 )
    {
      echo "======================================================="
      echo "DELETE IndexTemplates|Templates and/or Ingest Pipelines"
      echo "======================================================="
      // TEMPLATES
      templates2Delete = []
      items2DeleteTemplates = items2Delete.findAll { it[1] =~ 'templates/' }
      items2DeleteTemplates.each { it -> templates2Delete.add(it[1]) }
      templates2DeleteString = templates2Delete.join(",")
      _paramtemplates = ""
      if (templates2DeleteString != null && templates2DeleteString != "") {
        _paramtemplates = "-t ${templates2DeleteString}"
      }
      echo "IndexTemplates/Templates to delete: " + templates2DeleteString

      // INGEST PIPELINES
      ingestPipelines2Delete = []
      items2DeleteIngestPipelines = items2Delete.findAll { it[1] =~ 'ingest_pipeline/' }
      items2DeleteIngestPipelines.each { it -> ingestPipelines2Delete.add(it[1]) }
      ingestPipelines2DeleteString = ingestPipelines2Delete.join(",")
      _paramingestPipelines = ""
      if (ingestPipelines2DeleteString != null && ingestPipelines2DeleteString != "") {
        _paramingestPipelines = "-i ${ingestPipelines2DeleteString}"
      }
      echo "ingestPipelines to delete: " + ingestPipelines2DeleteString

      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        _elasticURL=item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
        echo "PARAMETERS: -d -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramtemplates} ${_paramingestPipelines}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -d -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramtemplates} ${_paramingestPipelines}'"
      }
    }

    //RENAME
    if ( items2Rename.size() != 0 )
    {
      echo "======================================================="
      echo "RENAME IndexTemplates|Templates and/or Ingest Pipelines"
      echo "======================================================="
      // TEMPLATES
      templates2Rename = []
      items2RenameTemplates = items2Rename.findAll { it[1] =~ 'templates/' }
      items2RenameTemplates.each { it -> templates2Rename.add("${it[1]}#${it[2]}") }
      templates2RenameString = templates2Rename.join(",")
      _paramtemplates = ""
      if (templates2RenameString != null && templates2RenameString != "") {
        _paramtemplates = "-t ${templates2RenameString}"
      }
      echo "IndexTemplates/Templates to rename: " + templates2RenameString

      // INGEST PIPELINES
      ingestPipelines2Rename = []
      items2RenameIngestPipelines = items2Rename.findAll { it[1] =~ 'ingest_pipeline/' }
      items2RenameIngestPipelines.each { it -> ingestPipelines2Rename.add("${it[1]}#${it[2]}") }
      ingestPipelines2RenameString = ingestPipelines2Rename.join(",")
      _paramingestPipelines = ""
      if (ingestPipelines2RenameString != null && ingestPipelines2RenameString != "") {
        _paramingestPipelines = "-i ${ingestPipelines2RenameString}"
      }
      echo "ingestPipelines to rename: " + ingestPipelines2RenameString

      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        _elasticURL=item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
        echo "PARAMETERS: -x -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramtemplates} ${_paramingestPipelines}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -x -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramtemplates} ${_paramingestPipelines}'"
      }
    }

    //UPDATE (ADD/MODIFY)
    if (items2Deploy.size() != 0) {
      echo "=============================================================="
      echo "UPDATE/CREATE IndexTemplates|Templates and/or Ingest Pipelines"
      echo "=============================================================="
      // TEMPLATES
      templates2Deploy = []
      items2DeployTemplates = items2Deploy.findAll { it[1] =~ 'templates/' }
      items2DeployTemplates.each { it -> templates2Deploy.add(it[1]) }
      templates2DeployString = templates2Deploy.join(",")
      _paramTemplates = ""
      if (templates2DeployString != null && templates2DeployString != "") {
        _paramTemplates = "-t ${templates2DeployString}"
      }
      echo "IndexTemplates/Templates to deploy: " + templates2DeployString

      // INGEST PIPELINES
      ingestPipelines2Deploy = []
      items2DeployIngestPipelines = items2Deploy.findAll { it[1] =~ 'ingest_pipeline/' }
      items2DeployIngestPipelines.each { it -> ingestPipelines2Deploy.add(it[1]) }
      ingestPipelines2DeployString = ingestPipelines2Deploy.join(",")
      _paramIngestPipelines = ""
      if (ingestPipelines2DeployString != null && ingestPipelines2DeployString != "") {
        _paramIngestPipelines = "-i ${ingestPipelines2DeployString}"
      }
      echo "IngestPipelines to deploy: " + ingestPipelines2DeployString

      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        _elasticURL=item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
        echo "PARAMETERS: -u -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramTemplates} ${_paramIngestPipelines}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -u -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramTemplates} ${_paramIngestPipelines}'"
      }
    }
  }

  deployECE_ELKRestart config,alms,NO_RESTART
}
