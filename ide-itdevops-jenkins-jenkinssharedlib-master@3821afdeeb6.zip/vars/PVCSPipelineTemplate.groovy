#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def almsPackage=null
def callFromWB=true
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _serverSVN=""
def _dataModules=null
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _HayAnexos=""
def _Pvcs=""
def _Anexos=""
def _funcion=""
def _funcionEnt=""
def funcConfig=""
def hoy=""
def pckInfo=null
def _funcionAejecutar=""
def _serverAenviar=""
def _WB_ID=""
def envsConfig
def databaseConfig
def _listapaquetes=""
def _serverPROD=""
def mybuilduser=""




def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'WB_ID', defaultValue: '', description: 'WB ID or CRQ ID') 
            string(name: 'Application', defaultValue: '', description: 'Application to deploy') 
            string(name: 'Enviroment', defaultValue: '', description: 'Enviroment to deploy') 
            string(name: 'List_Packages', defaultValue: '', description: 'List of package for deploy') 
            string(name: 'Delivery', defaultValue: '', description: 'Delivery of package') 
            choice(name: 'Check_Dependences', choices: ['NO', 'YES'], description: 'Check dependences of the list of packages')
            string(name: 'PackageInfo', defaultValue: '', description: 'WB info') 
         }
         
   
         stages{     
         stage("Prepare"){
                agent {
                    label 'MEDIACION'
                        }
                steps{
                script {
                   
                   wrap([$class: 'BuildUser']) {
                         echo "Exec user: ${env.BUILD_USER_ID}"
                         mybuilduser=env.BUILD_USER_ID
                       }
                  // echo "Exec user: ${mybuilduser}"
                  //Busco la contraseña
                  (_pass,mybuilduser)=findpassword(mybuilduser)
                  
               // funcConfig=readJSON(file: CDM/Jenkins/WORKBENCH/ORACLE/MEDIACION/funciones.json)
                hoy=new Date().format( 'yyyyMMdd' )
                print "La fecha de hoy es ......${hoy}......"
                
                //leemos el fichero de configuracion
                pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                //print "pipelineConfig ${pipelineConfig}"
                //leemos el fichero de entornos
                envsConfig=pipelineConfig.envConfig
                //print "envsConfig ${envsConfig}"
                //leemos el fichero de BBDD
                databaseConfig=pipelineConfig.databaseConfig
                _checkDPD="NO"

                if (PackageInfo==""){
                    //LLamada manual
                        print "Llamada manual"
                        callFromWB=false  
                        _DeployEnv=params.Enviroment  
                        _ALMS_ID=params.WB_ID.trim()  
                        _Domain=params.Application
                        _listapaquetes=params.List_Packages
                        _checkDPD=params.Check_Dependences
                        _Delivery=params.Delivery.trim()
                         
                        if (_listapaquetes==""){
                            _listapaquetes=params.WB_ID  
                        }
                             
                        echo "lista paquetes ${_listapaquetes}"   
                        print "Valor del revisar dependencias ${_checkDPD}"
                        if (_checkDPD == "YES")
                        { //Revisamos las dependencias
                         print "Llamo a check_dependencies_WB"
                         print "si lanzo el check_dependencies_WB"
                         applicationDependencyCRQ(_ALMS_ID,'"' + _listapaquetes + '"')
                         check_dependencies_WB(_ALMS_ID, _listapaquetes , "es036tvr")
                        }
                        else
                        {
                            print "Valor del revisar dependencias ${_checkDPD}"
                            print "no lanzo el check_dependencies_WB"
                        }
                        
                        replica_datos("",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                        txeker("",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                        
                    }
                    else{
                        print "Llamada desde WB "
                        callFromWB=true  
                        pckInfo=readJSON(text: "${PackageInfo}")
                        //print "packageinfo ${PackageInfo}"
                        _DeployEnv=pckInfo['EnvironmentName']
                        _Domain=pckInfo['ApplicationName']
                        _ALMS_ID=pckInfo.Id.toString()
                        _Delivery=pckInfo['DeliveryName']
                        _listapaquetes=_ALMS_ID  
                        _checkDPD="NO"

                    }

                if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
        	        error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
                    }
                
                //Actualizo info del paquete                       
                  print "llamo a getInfoPackage"
                  //(_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
                  (_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN,_Parametros,_HayParametros)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
               
                //Configuramos el nombre del build y su descripcion
                currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Domain}"
                currentBuild.description = "Lista: ${_listapaquetes} Entorno: ${_DeployEnv} Aplicación: ${_Domain}"
             
                    
                  if(_HayModulosDatos == 0 && _HayModulosPVCS == 0 && _HayAnexos == 0) {
                    createReject (_ALMS_ID, "No hay modulos de datos ni de pvcs ni anexos en el paquete","5")
                    error("No hay modulos de datos ni de pvcs ni anexos añadidos al paquee")
                    }
                    
                   //Si el entorno es PROD leo el servidor SPPR  
                   enviroments=readJSON(file: "${envsConfig}")
                   
                   if ("${_DeployEnv}" == "PROD")
                   {
                    _serverPROD=_server
                    //Cambiamos al server de SPPR
                    _server=enviroments["${_Domain}"]["${_DeployEnv}"]["serverSPPR"][0][0]
                   }
                   else
                   {
                       //_serverPROD=""
                       _serverPROD=enviroments["${_Domain}"]["PROD"]["server"][0][0]
                   }

                  
                   }//script
                 }//step
            }//prepare
            
            stage("BorraDirectorio"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_server}"
                        }
                        //Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
                        //Borrado del directorio temporal de anexo si existe por haberse promocionado otra vez este dia
                         cleanDirPaquete "${_ALMS_ID}","${_serverAenviar}","${hoy}","${_DeployEnv}","${_Domain}"

                    }//scripts
                }//steps
            }//BorraDirectorio

            
            stage("checkoutModulosDatos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        
                        if(_HayModulosDatos!= 0){
                            print "DEBUG: hay modulos de datos ${_HayModulosDatos}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            if ("${env.NODE_NAME}" == "${_server}")
                            {
                                _serverAenviar =""
                                //  borramos el server para no hacer ssh
                            }
                            else{
                                _serverAenviar ="${_server}"
                            }
                            getFromModules "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}","${hoy}","${_Domain}"
                        }else{
                            print "DEBUG: No hay modulos de datos "
                        }

                    }//scripts
                }
            }//checkoutModulosDatos

             stage("checkoutAnexos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if(_HayAnexos!= 0){
                            print "DEBUG: hay anexos"
                            if ("${env.NODE_NAME}" == "${_server}")
                            {
                                _serverAenviar =""
                                //  borramos el server para no hacer ssh
                            }
                            else{
                                _serverAenviar ="${_server}"
                            }
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            getAnnexes "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}","${hoy}"
                     }else{
                         print "DEBUG: No hay anexos "
                        }

                    }//scripts
                }//steps
            }//checkoutAnexos

            stage("checkoutPVCS"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_server}"
                        }
                        if(_HayModulosPVCS!= 0){
                            print "DEBUG: hay modulos de pvcs ${_HayModulosPVCS}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}"
                        }else{
                            print "DEBUG: No hay modulos de pvcs "
                        }

                    }//scripts
                }//steps
            }//checkoutPVCS

            stage("Ejecutar"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                         if ("${env.NODE_NAME}" == "${_server}")
                            {
                             _serverAenviar =""
                                //  borramos el server para no hacer ssh
                             }
                             else{
                             _serverAenviar ="${_server}"
                             }
                        
                        //Cargamos la info del paquete en almsPackage para las ejecuciones de funciones
                        almsPackage= new VFESALMSDataRetriever( _ALMS_ID, _Domain, _DeployEnv,  _serverAenviar, _HayModulosPVCS, _dataModules, _HayAnexos, callFromWB, _serverSVN, _serverPROD , _listapaquetes, 0 , 1, _Delivery,_Parametros,_HayParametros )
                        //mirar que exista domain_<entorno>
                        //    si existe la funcion es la de domain_entorno
                        // Si no existe domain_<entorno> em quedo con domain
                        
                        _funcionEnt=pipelineConfig["${_Domain}-${_DeployEnv}"]
                        //print "funciones por entorno ${_funcionEnt}"
                        if ("${_funcionEnt}" == "null"){
                            //print "es nulo"
                            _funcion=pipelineConfig["${_Domain}"]
                        }
                        else{
                            //print "NO es nulo"
                            _funcion=_funcionEnt
                        }
                        print "ejecutamos ${_funcion}"
                        for (pos = 0; pos < _funcion.size(); pos++) { 
                             _funcionAejecutar=_funcion[pos]
                            print "funciona a ejecutar ${_funcionAejecutar}"
                            def ejecutar="CDM/Jenkins/WORKBENCH/common/${_funcionAejecutar}"
                            def clase=load "${ejecutar}"
                            clase.execute(almsPackage)
                     }//Fin del for

                    }//scripts
                }//steps
            }//Ejecutar

        
          
          stage("Etiquetar"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {//Si hay modulos de pvcs y estamos ejecutando de forma manual etiquetamos y no es PROD
                        if(_HayModulosPVCS != 0 && callFromWB == false ) {
                            print "DEBUG: hay modulos pvcs y es manual "
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            txeker("-t -l",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                            
                        }else{
                            print "DEBUG: No hay modulos de pvcs o lo ha llamado WB"
                        }
                        if (_HayModulosPVCS != 0 && callFromWB == false && _serverSVN != null ){
                            //Si hay máquina de SVN ejecuto el promoSVN 
                                print "DEBUG: hay modulos pvcs y es manual y tiene SVN"
                                cleanDirPaquete "${_ALMS_ID}","${_serverSVN}","${hoy}","${_DeployEnv}","${_Domain}"
                                getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverSVN}"
                                promoSVN "${_ALMS_ID}","${_DeployEnv}","${_Domain}","${_serverSVN}"
                            }
                            else{
                                print "server SVN ${_serverSVN}"
                            }
                    }//scripts
                }//steps
          }//etiquetar
          stage("EditPackage"){
             
                agent {
                    node("eswldahr")
                        }

                steps{
                    script {//Si hay modulos de pvcs y estamos ejecutando de forma manual etiquetamos y no es PROD
                         if(_DeployEnv == "PROD" && callFromWB == false) {
              //Los edito a promocionado si no lo llama WB
                           
                           // wrap([$class: 'BuildUser']) {
                             //echo "Exec user: ${env.BUILD_USER_ID}"
                             //mybuilduser=env.BUILD_USER_ID
                             //echo "Exec user: ${mybuilduser}"
                           //}
                            print "DEBUG: Paso a produccion "
                            
                            EditPackage(_ALMS_ID, false, _listapaquetes, false, false,"",mybuilduser,_pass)
                            Notif=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_ALMS_ID}/Todos.txt")
                            PromotePROD=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_ALMS_ID}/PromotePROD.txt")
                                   
                            if (PromotePROD != "")
                            { //Paquetes a promocionar
                                promoteApi("${mybuilduser}","10", '"'+PromotePROD+'"',_pass)
                            }
                             if (Notif != "")
                            { //Paquetes a promocionar
                                notifApi("${mybuilduser}",'"'+Notif+'"',_pass)
                                promoteApi("${mybuilduser}","10", '"'+Notif+'"',_pass)
                            }
                            EditPackage(_ALMS_ID, false, _listapaquetes, true, false,"",mybuilduser,_pass)
                            PaquetesIncorrectos=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_ALMS_ID}/PaquetesIncorrectos.txt")
                            if (PaquetesIncorrectos != "" )
                            {
                                print "Check following package that can not be promoted automatically"
                                print "${PaquetesIncorrectos}"
                            }
                        }//SI es para PROD
                    }//scripts
                }//steps 
          }//EditPackage
          
         }//stages
        }//pipeline
    }//map

