def call(String _domain, String _TipoRege, String _nombreCarpeta, String _listado, String _CRQ_ID, Boolean isBit ,String _usuario, String _pass, String EntSimulacro){

def hoy=""
def RutaTemp=""
def RutaPaquete=""
def iFalloEsquema=0
def TipoBit
def _listadoBBDD
def fichero_errores=""
def exec=""
def _ListadoVistas=""
def iConflictos=""

//print "parametros:::::::::::::::"
//print "parametros _domain: ${_domain}"
//print "parametros _nombreCarpeta: ${_nombreCarpeta}"
//print "parametros _listado: ${_listado}"
//print "parametros _CRQ_ID: ${_CRQ_ID}"
//print "parametros isBit: ${isBit}"
//print "parametros _TipoRege: ${_TipoRege}"
//print "parametros EntSimulacro: ${EntSimulacro}"

hoy=new Date().format( 'yyyyMMdd' )

RutaTemp="/home/plataforma/plausr/tmp"
RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
iFalloEsquema = 0
iConflictos=0

print "****************************************"
print "TESTING ON PROD APPLICATION: ${_domain} "
print "****************************************"
 
//Si esde bitbucket no lanzo el txeker                                    
if (isBit)
 {
      TipoBit=1
      //print "Es de bitbucket" 
 }
else
  {
      TipoBit=0
      //print "Es de pvcs" 
  }
                                    
try{
        if (_TipoRege != "AMDOCS-ESQUEMA"  )
         {
             if ( TipoBit == 0 )
             {
                 txeker("-t",_domain,"PROD",_nombreCarpeta,_listado)
             }
             else
             {
                 txeker_git("*", "PROD_HID",'"' + _listado + '"', _usuario,_pass ,_nombreCarpeta)
                 iConflictos=CheckBit(_domain,_nombreCarpeta,_CRQ_ID, _usuario,_pass)
                 // 0 sin error, 1 error de PR, 2 error de contenido, 3 error en ambos
             }
         }
        else
         {  //Si es de ESQUEMA el que se ha elegido para regenerar
            sh "touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD"
            _listadoBBDD = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD")
             if (_listadoBBDD != "") 
             {
                 //Añdimos los de BBDD si hemos pedido ESQUEMA
                 print "There are DDBB packages"
                 _listado= "${_listadoBBDD} ${_listado}"
                 print "Current list: ${_listado}"
             }
            //Extraemos el codigo para tener el e
            txeker("","AMDOCS102","PROD",_nombreCarpeta,_listado)
         }
   } 
   catch(Exception e){
   
        //Si falla el testeo
         if (_TipoRege == "AMDOCS-ESQUEMA")
         {
            iFalloEsquema=1
         }
                                            
        echo "Test failure on PROD in ${_domain} error: ${e}" 
        sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteoPROD.txt  "
 
        //Lanzo el script para sacar los proveedores que tienen errores
        fichero_errores="${_nombreCarpeta}.PROD.errores_testeo"
        exec="""
             . \$HOME/.profile 
            if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
            then
                mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
            fi 

            echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            getInfoErrores -p  ${_nombreCarpeta} -f ${fichero_errores} >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
        """
    
        sh "ssh -q es036tvr '${exec}'"
 
    } //Fin de error
    
    if (iConflictos != 0 )
    {
        echo "Test failure on PROD in ${_domain}" 
        sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteoPROD.txt  "
        
          // 0 sin error, 1 error de PR, 2 error de contenido, 3 error en ambos
         if (iConflictos == 1)
         {
          execConflicto="""
             . \$HOME/.profile 
            if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
            then
                mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
            fi 

            echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo "***********CONFLICTS in the PR: *********************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo " "*************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            cat '/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/ResultadoCheckIfPRHasConflicts.txt '>> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            """
         }
         else if (iConflictos == 2)
         {
          execConflicto="""
             . \$HOME/.profile 
            if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
            then
                mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
            fi 

            echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo "***********Missing master content on source branch: *********" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo " "*************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            cat '/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/ResultadoCheckContent.txt '>> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            """
         }
         else if (iConflictos == 3)
         {
          execConflicto="""
             . \$HOME/.profile 
            if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
            then
                mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
            fi 

            echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo "***********Missing master content on source branch: *********" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo "***********CONFLICTS in the PR: *********************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            cat '/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/ResultadoCheckIfPRHasConflicts.txt '>> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            cat '/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/ResultadoCheckContent.txt '>> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
            echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
           """
         }
         
        sh "ssh -q es036tvr '${execConflicto}'"
                                      
    }
                                    
print "****************************************"
print "TESTING ON ${EntSimulacro} environment APPLICATION: ${_domain} "
print "****************************************"
                                    
try{
        if (_TipoRege == "AMDOCS-ESQUEMA")
        { //Hago con dominio AMDOCS por si hay de bbdd
             txeker("-t","AMDOCS102","${EntSimulacro}",_nombreCarpeta,_listado)
        }
        else
        {
            if ( TipoBit == 0 )
             {
                 txeker("-t",_domain,"${EntSimulacro}",_nombreCarpeta,_listado)
             }
             
    }
    } 
    catch(Exception e){
                                            
         echo "Test failure on ${EntSimulacro} environment on ${_domain} error: ${e}" 
         sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteoSIMU.txt  "
                                     

        //Lanzo el script para sacar los proveedores que tienen errores
        fichero_errores="${_nombreCarpeta}.${EntSimulacro}.errores_testeo"
        exec="""
            . \$HOME/.profile 
             if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
             then
                   mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
            fi 
            echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_${EntSimulacro}.txt
            echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_${EntSimulacro}.txt
            echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_${EntSimulacro}.txt
            getInfoErrores -p  ${_nombreCarpeta} -f ${fichero_errores} >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_${EntSimulacro}.txt
            echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_${EntSimulacro}.txt
        """
            
        sh "ssh -q es036tvr '${exec}'"
                                      
}  

if (_TipoRege =="AMDOCS-ESQUEMA" && iFalloEsquema ==0)    
  {
    //Lazamos la revisión de vistas
    sh "mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta}"
    check_vistas "${_nombreCarpeta}" , "YES"
    sh "touch -f /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta}/check_vistas_upgrade.PROD.${_nombreCarpeta}.txt"
    //sh "touch -f ${RutaPaquete}/check_vistas_upgrade.PROD.${_nombreCarpeta}.txt"
    //_ListadoVistas = readFile(file: "${RutaPaquete}/check_vistas_upgrade.PROD.${_nombreCarpeta}.txt")
    _ListadoVistas = readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta}/check_vistas_upgrade.PROD.${_nombreCarpeta}.txt")
    if (_ListadoVistas!="")
    {
        print "Summary of revised views to generate: orden_pre and orden_post"
        print "${_ListadoVistas}"
    }
  }
}  
