def call(List sChangeList, Object env_config , String sRutaDeploy, String _Aplicacion, String REVISION, String UNDEPLOYREVISION, List sReleaseList ){
    echo "deployApigee: ${sRutaDeploy}"
    def goal=""
    def config_option=""
    def deploymenttype=""
    def token1=""
    def install_goal=""
    def test_goal=""
    def config_option_compile="validate"
    def rollback=false
    def configchange=false
    def index=""
    def errorcode=""
    def DEPLOYEDREVISION=""
    sChangeList.each(){
        token1=it.tokenize("/")
        switch(token1[0]){ 
            case 'apiproxy':
                install_goal="install"
                break
            case 'config':
                //pack_goal='apigee-config:apiproducts apigee-config:developers apigee-config:apps apigee-config:maskconfigs'
                //edge.json split
                break
            case 'test':
                test_goal="clean"
                break
            case 'pom.xml':
                install_goal="install"
                break
        }
    }
    if (test_goal != "" ){
        if(install_goal=="" ){
            echo "only test"
            goal="${test_goal}"
            config_option = 'none'
        }
    }

    if (install_goal!="" ){
        echo "only api"
        goal="${install_goal}"
        config_option = 'none'
    }
    //USERNAME="VFGROUPSVC.apixuser2@internal.vodafone.com"
    //PASSWORD=$EDGE_PWD_apixuser2
    withCredentials([usernamePassword(credentialsId: "${env_config.credentialid}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
        sChangeList.unique().each(){
            def change=it
            if (sReleaseList.contains(change)){
                def saltar=false
                token1=it.tokenize("/")
                if (rollback==false){
                    if (token1[0] =='config'){
                        def curlbase=""
                        def curladd=""
                        def name=""
                        def action="UPDATE"
                        echo "token:[${token1[0]}][${token1[1]}] size:${token1.size()}"
                        if ("${token1[1]}" == "${env_config.config_dir}"){
                            echo "tratando:${it}"
                            configchange=true
                            switch(token1[2]){ 
                                case 'api':
                                    if (token1[3] == _Aplicacion){
                                        if (token1.size() != 6){
                                            saltar=true
                                            break
                                        }
                                        def token2=token1[5].tokenize(".")
                                        name=token2[0]
                                        curlbase="https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/apis/${_Aplicacion}"
                                        curladd=token1[4].toLowerCase()
                                        if(token1[4] == 'kvms'){
                                            curladd="keyvaluemaps"
                                            action="RECREATE"
                                        }

                                    }
                                    break
                                case 'org':
                                    if (token1.size() != 5){
                                        saltar=true
                                        break
                                    }  
                                    curlbase="https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}"
                                    def token2=token1[4].tokenize(".")
                                    name=token2[0]
                                    curladd=token1[3].toLowerCase()
                                    if(token1[3] == 'kvms'){
                                        curladd="keyvaluemaps"
                                        action="RECREATE"
                                    }
                                    break
                                case 'env':
                                    if (token1[3] == env_config.env){
                                        if (token1.size() != 6){
                                            saltar=true
                                            break
                                        }
                                        def token2=token1[5].tokenize(".")
                                        name=token2[0]
                                        curlbase="https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/environments/${env_config.env}"
                                        curladd=token1[4].toLowerCase()
                                        if(token1[4] == 'kvms'){
                                            curladd="keyvaluemaps"
                                            action="RECREATE"
                                        }

                                    }
                                    break
                                default:
                                    saltar=true
                                    break
                            }
                            if (curlbase != "" || saltar ==false){
                                SALIDA=sh returnStdout: true, script: """
                                    https_proxy="${env_config.proxyurl}"
                                    export https_proxy
                                    no_proxy="${env_config.noproxy}"
                                    export no_proxy
                                    curl --silent --write-out "HTTPSTATUS:%{http_code}" -X GET -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} --header "Content-Type: application/json ; charset=UTF-8" "${curlbase}/${curladd}/${name}" |tr -d '\n' 
                                """
                                index=SALIDA.indexOf('HTTPSTATUS:')+11
                                errorcode=SALIDA.substring(index,index+3)
                                echo "GET status:${errorcode}"
                                if (errorcode.substring(0,1) !="2"){
                                    echo "WARNING:${SALIDA}"
                                    echo "warning no existe: ${curlbase}/${curladd}/${name} ,lo recreamos"
                                    action ="RECREATE"
                                }
                                if (action =="RECREATE"){
                                    def SALIDAGET=""
                                    def SALIDADEL=""
                                    SALIDA=sh returnStdout: true, script: """
                                        https_proxy="${env_config.proxyurl}"
                                        export https_proxy
                                        no_proxy="${env_config.noproxy}"
                                        export no_proxy
                                        curl --silent --write-out "HTTPSTATUS:%{http_code}" -X DELETE -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} --header "Content-Type: application/json ; charset=UTF-8" "${curlbase}/${curladd}/${name}" |tr -d '\n' 
                                    """
                                    index=SALIDA.indexOf('HTTPSTATUS:')+11
                                    errorcode=SALIDA.substring(index,index+3)
                                    echo "DELETE status:${errorcode}"
                                    if (errorcode !="200" && errorcode !="404"&& errorcode !="204"){
                                        echo "WARNING:${SALIDA}"
                                        echo "warning borrando ${curlbase}/${curladd}/${name}"
                                    }
                                    SALIDA=sh returnStdout: true, script: """
                                        https_proxy="${env_config.proxyurl}"
                                        export https_proxy
                                        no_proxy="${env_config.noproxy}"
                                        export no_proxy
                                        curl --silent --write-out "HTTPSTATUS:%{http_code}" -X POST -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  --header "Content-Type: application/json ; charset=UTF-8" -d"@${it}" "${curlbase}/${curladd}" |tr -d '\n' 
                                    """
                                    index=SALIDA.indexOf('HTTPSTATUS:')+11
                                    errorcode=SALIDA.substring(index,index+3)
                                    echo "POST status:${errorcode}"
                                    if (errorcode !="201" && errorcode !="200"){
                                        rollback=true
                                        echo "ERROR:${SALIDA}"
                                        echo "rollback por: ${it}"
                                    }
                                }
                                if (action =="UPDATE"){
                                    SALIDA=sh returnStdout: true, script: """
                                        https_proxy="${env_config.proxyurl}"
                                        export https_proxy
                                        no_proxy="${env_config.noproxy}"
                                        export no_proxy
                                        curl --silent --write-out "HTTPSTATUS:%{http_code}" -X PUT -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} --header "Content-Type: application/json ; charset=UTF-8" -d"@${it}" "${curlbase}/${curladd}/${name}" |tr -d '\n'                                     """
                                    index=SALIDA.indexOf('HTTPSTATUS:')+11
                                    errorcode=SALIDA.substring(index,index+3)
                                    echo "PUT status:${errorcode}"
                                    if (errorcode !="201" && errorcode !="200"){
                                        rollback=true
                                        echo "ERROR:${SALIDA}"
                                        echo "rollback por: ${it}"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (rollback==false){
            sChangeList.any(){
                token1=it.tokenize("/")
                if (token1[0] =='apiproxy' ||token1[0] =='pom.xml'){
                    
                    SALIDA=sh returnStdout: true, script: """
                        https_proxy="${env_config.proxyurl}"
                        export https_proxy
                        curl -X GET --header "Accept: application/json" -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/apis/${_Aplicacion}/deployments"
                    """
                    if (SALIDA != ""){
                        apiInfo=readJSON(text: "${SALIDA}")
                        echo "apiInfo:${apiInfo}"
                        apiInfo.environment.each(){
                            def ENVinfo=it
                            if (ENVinfo.name == env_config.env){
                                DEPLOYEDREVISION=ENVinfo.revision[0].name
                            }
                        }
                    }else{
                        error "curl"
                    }

                    if (REVISION !="" && REVISION != DEPLOYEDREVISION){
                        SALIDA=sh returnStdout: true, script: """
                            https_proxy="${env_config.proxyurl}"
                            export https_proxy
                            curl --silent --write-out "HTTPSTATUS:%{http_code}" -X POST -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  --header "Content-type:application/x-www-form-urlencoded" \
                            "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/environments/${env_config.env}/apis/${_Aplicacion}/revisions/${REVISION}/deployments?delay=15" \
                            -d "override=true" |tr -d '\n'                         """

                        index=SALIDA.indexOf('HTTPSTATUS:')+11
                        errorcode=SALIDA.substring(index,index+3)
                        echo "POST status:${errorcode}"
                        if (errorcode !="200"){
                            echo "ERROR:${SALIDA}"
                            error "desplegando la version:${REVISION}"
                        }
                        echo "Desplegada la version:${REVISION}"
                    }else{
                        echo "WARNING: La revision desplegada de ${_Aplicacion}:${DEPLOYEDREVISION} no se despliega, ya estaba la revision ${REVISION}"
                    }
                    if (UNDEPLOYREVISION !=""){
                        SALIDA=sh returnStdout: true, script: """
                            https_proxy="${env_config.proxyurl}"
                            export https_proxy
                            curl --silent --write-out "HTTPSTATUS:%{http_code}" -X DELETE -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  --header "Content-type:application/x-www-form-urlencoded" \
                            "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/apis/${_Aplicacion}/revisions/${UNDEPLOYREVISION}/deployments" \
                                |tr -d '\n' 
                        """
                        index=SALIDA.indexOf('HTTPSTATUS:')+11
                        errorcode=SALIDA.substring(index,index+3)
                        echo "DELETE status:${errorcode}"
                        if (errorcode !="200" && errorcode !="400"){
                            echo "ERROR:${SALIDA}"
                            error "Undeploy de la version nueva:${UNDEPLOYREVISION}"
                        }

                        SALIDA=sh returnStdout: true, script: """
                            https_proxy="${env_config.proxyurl}"
                            export https_proxy
                            curl --silent --write-out "HTTPSTATUS:%{http_code}" -X DELETE -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  --header "Content-type:application/x-www-form-urlencoded" \
                            "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/apis/${_Aplicacion}/revisions/${UNDEPLOYREVISION}" \
                                |tr -d '\n' 
                        """
                        index=SALIDA.indexOf('HTTPSTATUS:')+11
                        errorcode=SALIDA.substring(index,index+3)
                        echo "DELETE status:${errorcode}"
                        if (errorcode !="200"){
                            echo "ERROR:${SALIDA}"
                            error "borrando la version nueva:${UNDEPLOYREVISION}"
                        }
                        echo "Borrada la version:${UNDEPLOYREVISION}"
                    }
                    return true
                }
            }
        }
    }
    return [rollback, configchange]
}