def call(String _Alms,String _remoteServer,String _env){
  
    
     exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete  ${_Alms}
    if [ -d ${_env} ]
    then
        echo 'Existe el directorio ${_Alms}/${_env} lo borramos.'
        rm -Rf ${_env}
    fi
    
    """
    
    if (_remoteServer!="")
    {
        //print "ejecucion ${exec} "
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
       // print "ejecucion ${exec} "
    }
}
