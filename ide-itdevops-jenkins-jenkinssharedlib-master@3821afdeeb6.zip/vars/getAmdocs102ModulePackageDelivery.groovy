def call (String _usuario, String _ent1, String _ent2, String _app  ){
    node ('es1117yw'){
      //Buscar contraseña del user
        (_pass,_usuario)=findpassword(_usuario)
          checkout scm
          dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
           bat "python getAmdocs102ModulePackageDelivery.py -e ${_ent1} -d ${_ent2} -u ${_usuario}  -c ${_pass} -a ${_app}"
           }//wrap
    }//dir
  }//node
}
