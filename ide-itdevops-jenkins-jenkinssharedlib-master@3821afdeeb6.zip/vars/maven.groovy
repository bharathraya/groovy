import vfes.stages.tool.maven.MavenSourceCodeManagement

def Build(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''
    echo "Into Build script. maven args $args_maven"
    sh "mvn $args_maven clean compile "

}

def CheckMultiModuleProject(Script context) {
    def maven_tool= new MavenSourceCodeManagement()
    maven_tool.initialize(context, null, null)
    def modules = maven_tool.detectMavenArtifactsWithProperties("${WORKSPACE}")
    echo "Modules $modules"
    env.MULTI_MODULE= modules?.size() > 1 ? true : false
    echo "Is multiproject $env.MULTI_MODULE"
}

def NewVersion(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''
    echo "Into NewVersion script. maven args $args_maven"
    sh "mvn $args_maven versions:set -DgroupId=\"*\" -DartifactId=\"*\" -DnewVersion=\"${functionParams.versionPre}-${functionParams.releaseCandidate}\" -DoldVersion=\"*\" -DgenerateBackupPoms=false"
}

def getArtifacts(Map functionParams = [:]) {
    def mavenArtifacts= ["artifactList":[],"repoURL":""]
  	version=functionParams?.version? functionParams.version:""
  	repoURL=functionParams?.repoURL? functionParams.repoURL:""
    poms=findFiles glob:"**/pom.xml"
    for (i=0;i<poms.size();i++)
    {
        def artifact=["artifactId":"","groupId":"","version":"","type":"","artifactURL":"","name":"","type":""]
        def pom = readMavenPom file: poms[i].path
        artifact.groupId=pom?.groupId? pom.groupId:" "
        if (artifact.groupId==null || artifact.groupId=="null"){
          	artifact.groupId=" "
        }
        artifact.artifactId="${pom.artifactId}"
        artifact.version="${pom.version}"
        if (artifact.version =~ "project.version" ||artifact.version==null){
          artifact.version=version
        }
      
        artifact.type="${pom.packaging}"
      	artifact.name="${artifact.artifactId}-${artifact.version}.${artifact.type}"
      	artifact.artifactURL="${repoURL}/${artifact.groupId.replaceAll('\\.','/')}/${artifact.artifactId}/${artifact.version}/${artifact.name}"
      	mavenArtifacts.artifactList.add(artifact)
    }
  return mavenArtifacts
}

def Package(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''
    def version = functionParams.getOrDefault("version", "")
    def addVersion=""
    if (version != ""){
    	addVersion="-D project.version=${version}"
    }
    echo "Into Package script. maven args $args_maven ${addVersion}"
    sh "mvn $args_maven -Dmaven.test.skip=true clean package ${addVersion}"
}

def Package2(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''
    def version = functionParams.getOrDefault("version", "")
    def addVersion=""
    if (version != ""){
    	addVersion="-D project.version=${version}"
    }
  echo "Into Package2 script. maven ${args_maven} -Dmaven.test.skip=true clean package ${addVersion}"
    def response = sh(returnStdout: true, script: "mvn $args_maven -Dmaven.test.skip=true clean package ${addVersion}")
  	return response
}

def Test(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''    
    def version = functionParams.getOrDefault("version", "")
    def addVersion=""
    if (version != ""){
    	addVersion="-D project.version=${version}"
    }
    echo "Into Test script. maven args $args_maven ${addVersion}"
    sh label:"[Maven] Running tests...", script: "mvn $args_maven org.jacoco:jacoco-maven-plugin:prepare-agent verify -B ${addVersion}"
}

def Verify(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''    
    def version = functionParams.getOrDefault("version", "")
    def addVersion=""
    if (version != ""){
    	addVersion="-D project.version=${version}"
    }
    echo "Into Verify script. maven args $args_maven ${addVersion}"
    sh label:"[Maven] Running tests...", script: "mvn $args_maven verify ${addVersion}"
}

def initJacoco(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''
    def version = functionParams.getOrDefault("version", "")
    def addVersion=""
    if (version != ""){
    	addVersion="-D project.version=${version}"
    }
    echo "Into initJacoco script. mvn $args_maven org.jacoco:jacoco-maven-plugin:prepare-agent install ${addVersion}"
    sh "mvn $args_maven org.jacoco:jacoco-maven-plugin:prepare-agent install ${addVersion}"
}

def Jacoco(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}" : ''
    def existKiuwanAppName = env?.KIUWAN_APPNAME != ''
    def isMultiModule = env?.MULTI_MODULE ? Boolean.parseBoolean(env?.MULTI_MODULE) : false
    def jacocoExec = functionParams.getOrDefault("jacocoExec", "**/**.exec")
    echo "Is multiproject $isMultiModule $existKiuwanAppName"
    echo "Kiuwan app name ${env?.KIUWAN_APPNAME}"
    echo "Is Multiproject in Kiuwan ${isMultiModule && existKiuwanAppName}"
    env.DIR_JACOCO = 'jacoco'
    def version = functionParams.getOrDefault("version", "")
    def addVersion=""
    if (version != ""){
    	addVersion="-D project.version=${version}"
    }
	echo "Into Jacoco script. mvn $args_maven org.jacoco:jacoco-maven-plugin:report ${addVersion}"
    sh "mvn $args_maven org.jacoco:jacoco-maven-plugin:report ${addVersion}"
    jacoco execPattern: "${jacocoExec}"
}


def Deploy(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''
    echo "Into Deploy script. maven args $args_maven"
    def branch = functionParams.getOrDefault("branch", "master")
    def versionSuffix = functionParams.getOrDefault("versionSuffix", "")
    def getRawResult=functionParams.getOrDefault("rawResult", false)
    echo "Estamos en la rama ${branch}"
    if (!(branch ==~ /master|release\/.*|vodafone\/.*/)) {
        def version = "${branch}".replaceAll(/feature\/|[0-9]{0,6}/,"").toLowerCase().replace("--","-")
        sh "mvn versions:set -DnewVersion=\"${version}-SNAPSHOT\" "
    }else if (branch ==~ /release\/.*|vodafone\/.*/){
        def version = "${branch}".replaceAll(/vodafone\/|release\//,"").replace("--","-")
        if (versionSuffix!="") versionSuffix=".${versionSuffix}"
        sh "mvn versions:set -DnewVersion=\"${version}${versionSuffix}\" "
    }
    def response = sh(returnStdout: true, script: "mvn $args_maven deploy -Dmaven.test.skip=true")
    if (getRawResult){
      	return response
    }else {
        return slackUtils.messageNexusUrlArtifact(response)
    }

}
def DeployDxl(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''
    echo "Into Deploy script. maven args $args_maven"
    def version = functionParams.getOrDefault("version", "")
    def addVersion=""
    if (version != ""){
    	addVersion="-D project.version=${version}"
    }
    def getRawResult=functionParams.getOrDefault("rawResult", false)
    def response = sh(returnStdout: true, script: "mvn $args_maven deploy ${addVersion} -Dmaven.test.skip=true")
    if (getRawResult){
      	//echo "response:${response}"
        return response
    }else {
        return slackUtils.messageNexusUrlArtifact(response)
    }

}

def messageJacocoReport(Map functionParams = [:]) {
    def JOB_URL = functionParams.getOrDefault("JOB_URL", "")
    def textoJacocoSlack = ""

    // GET
    def get = new URL("${JOB_URL}/lastBuild/jacoco").openConnection();
    def getRC = get.getResponseCode();
    echo "Response url Jenkins Jacoco Report $getRC"
    if(getRC.equals(200)) {
        textoJacocoSlack = "\n Jacoco Report link <${JOB_URL}/lastBuild/jacoco|View Report>."
    }

    echo "Mensaje Slack Report Jacoco ${textoJacocoSlack}"
    return textoJacocoSlack.toString()
}

def getJacocoReportUrl(Map functionParams = [:]) {
    def JOB_URL = functionParams.getOrDefault("JOB_URL", "")
    def BUILD_URL = functionParams.getOrDefault("BUILD_URL", "")
    def textoJacocoSlack = ""
  	def url=""
    // GET
  	if(JOB_URL!=""){
    	url="${JOB_URL}/lastBuild/jacoco"
    }
    if(BUILD_URL!=""){
    	url="${BUILD_URL}/jacoco"
    }
  	def get = new URL(url).openConnection();
    def getRC = get.getResponseCode();
  	echo "Response url Jenkins Jacoco Report ${getRC}"
    if(getRC.equals(200)) {
        JOB_URL = url
    }

    return JOB_URL
}


def getArtifacts2(Map functionParams = [:]) {
    def args_maven = env?.ARGS_CMD_BUILD_MAVEN ? "${env.ARGS_CMD_BUILD_MAVEN}": ''
    def mavenArtifacts= ["artifactList":[],"repoURL":""]
  	version=functionParams?.version? functionParams.version:""
  	repoURL=functionParams?.repoURL? functionParams.repoURL:""
    def addVersion=""
    if (version != ""){
    	addVersion="-D project.version=${version}"
    }    
  	SALIDA=sh(returnStdout: true, script: "mvn $args_maven -q ${addVersion} -Dexec.executable='echo' -Dexec.args='\${project.groupId} \${project.version} \${project.artifactId} \${project.packaging}' exec:exec")

	SALIDA.split('\n').each(){
        def artifact=["artifactId":"","groupId":"","version":"","type":"","artifactURL":"","name":"","type":""]
        tokens=it.tokenize(' ')
        artifact.groupId=tokens[0]
        artifact.artifactId=tokens[2]
        artifact.version=tokens[1]
        artifact.type=tokens[3]
        artifact.name="${artifact.artifactId}-${artifact.version}.${artifact.type}"
        if(artifact.groupId!= null){
          artifact.artifactURL="${repoURL}/${artifact.groupId.replaceAll('\\.','/')}/${artifact.artifactId}/${artifact.version}/${artifact.name}"
        }else{
          artifact.artifactURL="${repoURL}/${artifact.artifactId}/${artifact.version}/${artifact.name}"
        }
        mavenArtifacts.artifactList.add(artifact)
    }
  	mavenArtifacts.repoURL=repoURL
  return mavenArtifacts
}

def getArtifactFromURL(Map functionParams = [:]){
    def mavenArtifacts= ["artifactList":[],"repoURL":""]
    url=functionParams?.url? functionParams.url:""
    repoURL=functionParams?.repoURL? functionParams.repoURL:""
    def artifact=["artifactId":"","groupId":"","version":"","type":"","artifactURL":"","name":"","type":""]
    
    artifact.artifactURL=url
    artifact.name=url.substring(url.lastIndexOf('/')+1)
    artifact.type=url.substring(url.lastIndexOf('.')+1) 
    resto=url.substring(repoURL.size()+1,url.lastIndexOf('/'))
    artifact.version=resto.substring(resto.lastIndexOf('/')+1)
    resto1=resto.substring(0,resto.lastIndexOf('/'))
    artifact.artifactId=resto1.substring(resto1.lastIndexOf('/')+1)
    resto2=resto1.substring(0,resto1.lastIndexOf('/'))
    artifact.groupId=resto2.replaceAll("/","\\.")
    println "resto:${resto} ${artifact.version} ${artifact.artifactId} ${artifact.groupId}"
    mavenArtifacts.artifactList.add(artifact)
    mavenArtifacts.repoURL=repoURL
    return mavenArtifacts
}