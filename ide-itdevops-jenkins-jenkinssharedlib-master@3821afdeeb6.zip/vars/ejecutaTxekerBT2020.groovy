import groovy.time.TimeCategory
 
def call(String _CRQ, String _Carpeta, String _env){
    
   hoy=new Date().format( 'yyyyMMdd' )
   Agrupacion=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ}/agrupacion_paquetes_final_${_Carpeta}")

    print "Agrupacion inicial ${Agrupacion} "
    AgrupacionLineas = Agrupacion.split("\n")
    print "Agrupacion lineas ${AgrupacionLineas} "
    tam=AgrupacionLineas.size()
    print "tamaño ${tam}"
    
     for (pos = 0; pos < AgrupacionLineas.size(); pos++) {
        Linea = AgrupacionLineas[pos]
        LineSpli=Linea.split(":")
        print "LineSpli: ${LineSpli}"
        _Paquete=LineSpli[0]
        print "Paquete ${_Paquete} "
        _lista=LineSpli[1] 
        print "Lista ${_lista} "
        
        print "lanzamos el txeker"
        txeker("","BIZTALK2020-IIS",_env,_Paquete,_lista)
       
        print "Borramos el directorio ${_Paquete}/${_env} "
        CleanPaquete "${_Paquete}","", "${_env}"
        print "Copiamos el directorio ${_Paquete}/${_env} "
        CopiaFicheros "${_Paquete}","${_env}",""
       
    }//for
}
