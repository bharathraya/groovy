import vfes.workbench.Workbench
import vfes.workbench.Workbenchtest
def get_credential(String _protocol,String _server, 
    String _context, String _token, 
    String _info_api, String _credentialId){
    def ret="""
urltoken='${_protocol}://${_server}/${_context}/${_token}'
urlpackageinfo='${_protocol}://${_server}/${_context}/${_info_api}'
host='${_server}'
"""
        withCredentials([usernamePassword(credentialsId: _credentialId, 
            usernameVariable: 'USERNAME',passwordVariable:'PASSWORD')]) {
                ret=ret+"""username='${USERNAME}'
password='${PASSWORD}'
"""
    
    return ret
    }    
}

def set_credentials_pprd(){
    return this.get_credential('https','webpre-adm.es.sedc.internal.vodafone.com:42510',
    'WorkBenchTest','Token',"api/Construction/Package/{}/Model?filters.base=true&filters.references=true&filters.dependences=true&filters.dataModules=true&filters.annexes=true&filters.history=false&filters.contents=true&filters.params=true",
    'WorkBenchAdmin_PPRD'
    )
}
def set_credentials_prod(){
    return this.get_credential('http','es1117yw',
    'WorkBench','Token',"api/Construction/Package/{}/Model?filters.base=true&filters.references=true&filters.dependences=true&filters.dataModules=true&filters.annexes=true&filters.history=false&filters.contents=true&filters.params=true",
    'WorkBenchAdmin_PROD'
    )
}

def get_workbench_credential(){
	def mybuilduser=""
	wrap([$class: 'BuildUser']) {
		echo "Exec user: ${env.BUILD_USER_ID}"
		mybuilduser=env.BUILD_USER_ID
	}
	//echo "Exec user: ${mybuilduser}"
	cred="WorkBenchAdmin_PROD"
	// Crear fichero credenciales
	if (mybuilduser==~/pprdworkbench/){
		cred="WorkBenchAdmin_PPRD"
	}else {
		cred="WorkBenchAdmin_PROD"
	}
	return cred
}
def call(String _package){
	workbench_cred=get_workbench_credential()
	 if (workbench_cred==~/WorkBenchAdmin_PPRD/){
		withCredentials([usernamePassword(credentialsId: "${workbench_cred}", usernameVariable: "usuario", passwordVariable: "password")]) {
			Workbenchtest workbench=new Workbenchtest(this,usuario,password)
			workbench.getToken()
			wbpckinfo=workbench.get_package_info(_package)
		} 

	}else{

		withCredentials([usernamePassword(credentialsId: "${workbench_cred}", usernameVariable: "usuario", passwordVariable: "password")]) {
			Workbench workbench=new Workbench(this,usuario,password)
			workbench.getToken()
			wbpckinfo=workbench.get_package_info(_package)
		} 
	}
	return wbpckinfo
}
def call_old (String _package){
    def ret=[]
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            // Borrar fichero credenciales
            bat "del wbcredentials.py"
            def mybuilduser=""
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
            }
          //  echo "Exec user: ${mybuilduser}"
            // Crear fichero credenciales
            if (mybuilduser==~/pprdworkbench/){
                cred=this.set_credentials_pprd()
            }else {
                cred=this.set_credentials_prod()
            }
            //cred=this.set_credentials_pprd()
            writeFile(file: 'wbcredentials.py', text: cred)        
            //bat "pip install -r requirements.txt"
            bat "python get_package_info.py ${_package} result.json"
            stash includes: 'result.json', name: 'result'
            bat "del result.json"
        }
    }
    unstash name: 'result'
    ret=readJSON file:"result.json"
    //echo "ret=${ret}"
    fileSuccessfullyDeleted =  new File("result.json").delete()  
    return ret
}