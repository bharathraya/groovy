def call(String _package,String _env,String _domain,String _remoteServer){
  
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
        touch /home/plataforma/tmp/${_package}
        . paquete ${_package}
        carga_bbdd_geneva_WB.sh ${_package} GENEVA-ONO-BBDD ${_env} -f /home/plataforma/tmp/${_package} -W
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
