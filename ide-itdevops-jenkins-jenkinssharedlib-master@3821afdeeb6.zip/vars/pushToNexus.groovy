import vfes.utils.VFESALMSDeployment


def call(Map config,VFESALMSDeployment alms)
{
    for (i=0;i<config.artifactId.size();i++){
        echo "Uploading to nexus ${config.distFolder[i]}/${config.distFile[i]}"
        nexusArtifactUploader artifacts: 
            [[artifactId: "${config.artifactId[i]}", 
            classifier: '', 
            file: "${config.extractFolder}/${config.distFolder[i]}/${config.distFile[i]}", 
            type: "${config.artifactType}"]], 
            credentialsId: 'platafor-nexus-es004dxr',  
            groupId: "${config.groupId}", 
            nexusUrl: 'es004dxr:8080/nexus', 
            nexusVersion: 'nexus3', 
            protocol: 'http', repository: "${config.nexusRepo}", version: "SNAPSHOT-${alms.deployEnv}"                
    }

}