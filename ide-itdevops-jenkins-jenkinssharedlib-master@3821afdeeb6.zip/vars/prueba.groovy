def deploy()
{
    echo "hola mundo!"
}