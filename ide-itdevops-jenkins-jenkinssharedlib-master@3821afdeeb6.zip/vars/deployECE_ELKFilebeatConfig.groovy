import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(Map config,VFESALMSDeployment alms,Boolean NO_RESTART)
{
  def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
  def _envConfig=myEnvsConfig[alms.deployEnv]

  /////////////////////////////
  //////TEST NEW RESTART///////
  /////////////////////////////
  //deployECE_ELKRestart config,alms,NO_RESTART
  //sh("exit 1")
  /////////////////////////////
  //////TEST NEW RESTART///////
  /////////////////////////////

  deployECE_ELKRestart config,alms,NO_RESTART

  /////////////////////////
  //////OLD RESTART///////
  ////////////////////////
  //echo "Restarting FileBeat ...."
  //echo "_envConfig"+_envConfig['restart_filebeat']
  //_envConfig['restart_filebeat'].each { item ->
  //  echo "Server Data:"
  //echo "  ReStart Server: " + item.server
  //echo "  ReStart User: " + item.user
  //echo "  ReStart Scripts path: " + item.scripts_path
  //echo "  ReStart Script: " + config.restartScript
  //echo "AT: ${item.user}@${item.server} RUN: ${item.scripts_path}/${config.restartScript}"
  //sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.scripts_path}; ./${config.restartScript}'"
  //echo ""
  //}
}
