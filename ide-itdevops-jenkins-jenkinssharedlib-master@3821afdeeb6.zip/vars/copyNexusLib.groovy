import vfes.utils.nexusData
import java.util.regex.Matcher


def call( nexusData nexus, String projectFolder, String sortCommit, String ENTORNO, String Delivery){
    echo "copyNexusLib"
    def existePom=true
    def pomParent=null
    def parentVersion=""
    def hijoVersion=""
    def parentVersionVar=""
    def hijoVersionVar=""
    dir("${projectFolder}"){
        try{
            pomParent = readMavenPom file: "pom.xml"
        }
        catch(all){
            existePom=false
        }
        if (existePom){
            sh "mkdir target"
            echo "pomParent.version:${pomParent.version}"
            parentVersion=pomParent.version
            if ("${pomParent.version}" =~  "}"){
                echo "pomParent: es una variable"
                parentVersionVar=pomParent.version.substring(pomParent.version.indexOf('{')+1,pomParent.version.indexOf('}'))

                SALIDA=sh returnStdout: true, script: """
                    grep "<${parentVersionVar}>" pom.xml |cut -d '>' -f2 |cut -d '<' -f1
                """
                parentVersion=SALIDA.trim()
                def EXTENSION= pomParent.packaging
                if(EXTENSION==null){
                    EXTENSION=pom
                }
                (parentVersion,DOWNLOADNEXUSARTIFACTURL)=nexusCheckLibVersion(nexus.nexusUrl,nexus.nexusRepo,pomParent.groupId,pomParent.artifactId,EXTENSION,parentVersion,nexus.nexusCred)

                echo "parentVersion:${parentVersion}"

            }
            
            dir("${projectFolder}/target"){
                List urlList=getDownloadUrlNexus(nexus,pomParent.artifactId,pomParent.groupId, parentVersion)
                urlList.each(){
                    def url=it
                    if (url != ""){
                        downloadNexusFile(nexus, url)
                        uploadNexusFile(nexus,url, ENTORNO)
                        if ( ENTORNO =="prod"){
                            deleteNexusFile(nexus,url,ENTORNO)
                        }
                    }
                }
            }
            dir("${projectFolder}"){
                def SALIDA=sh returnStdout: true, script: """
                    grep "<module>" pom.xml |cut -d '>' -f2 |cut -d '<' -f1 
                """
                List listaModules=SALIDA.split("\n").collect{it}
                def existehijo=true
                listaModules.each(){
                    if (it !=""){
                        echo "Trantando:${it}"
                        ruta=it
                        existehijo=true
                        try{
                            pomHijo=readMavenPom file: "${ruta}/pom.xml"
                        }catch(Exception e){
                            echo "Warning: no existe el hijo ${ruta}/pom.xml"
                            existehijo=false
                        }
                        if (existehijo==true){
                            sh "mkdir -p ${ruta}/target"
                            echo "version:${pomHijo.version}"
                            hijoVersion=pomHijo.version
                            if ("${pomHijo.version}" =~ "}"){
                                hijoVersionVar=pomHijo.version.substring(pomHijo.version.indexOf('{')+1,pomHijo.version.indexOf('}'))
                                SALIDA=sh returnStdout: true, script: """
                                    grep "<${hijoVersionVar}>" "${ruta}/pom.xml" |cut -d '>' -f2 |cut -d '<' -f1
                                """
                                hijoVersion=SALIDA.trim()
                                if (hijoVersion == "" || hijoVersion == null){
                                    if (hijoVersionVar == parentVersionVar){
                                        hijoVersion=parentVersion
                                    }
                                }

                            }
                            if (pomHijo.groupId ==null){
                                pomHijo.groupId=pomParent.groupId
                            }
                            if(pomHijo.version == null){
                                hijoVersion=parentVersion
                            }
                            echo "version:${hijoVersion}"
                            dir("${projectFolder}/${ruta}/target"){
                                List urlList=getDownloadUrlNexus(nexus,pomHijo.artifactId,pomHijo.groupId, hijoVersion)
                                urlList.each(){
                                    def url=it
                                    echo "Procesando:${url}"
                                    if (url != ""){
                                        downloadNexusFile(nexus, url)
                                        uploadNexusFile(nexus,url,ENTORNO)
                                        if ( ENTORNO =="prod"){
                                            deleteNexusFile(nexus,url,ENTORNO)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
