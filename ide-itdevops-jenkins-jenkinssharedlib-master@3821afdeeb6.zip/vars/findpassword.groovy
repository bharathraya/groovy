def call(String _user){

node ("eswltbhr-platafor") {     
 
    checkout scm  
    //sh "if [ -f Password.txt ] ; then rm -f Password.txt ; fi; touch -f Password.txt"
    //REV=1
    //try{
     //   sh "grep ${_user} CDM/Jenkins/WORKBENCH/common/user_pass.yml > Password.txt "
      //  } catch(Exception e){
    //    echo "No existe el user ${_user}" 
     //   REV=0
     // }   
    Lispassword=readYaml(file: "CDM/Jenkins/WORKBENCH/common/user_pass.yml")
    
    if (Lispassword.containsKey(_user))
    {
        //print "entro por si user"
        pass=Lispassword["${_user}"][0]
    }
    else
    {
       // print "entro por no user"
        pass=Lispassword["UsrPlata"][0]
        _user="UsrPlata"
    }
    
    return [pass , _user]
    
    } //node
}
