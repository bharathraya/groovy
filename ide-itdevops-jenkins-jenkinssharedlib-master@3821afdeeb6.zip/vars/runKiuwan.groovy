import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo



def runKiuwanAnalysis(Map config, VFESALMSDeployment pck, VFESGitRepo gitRepo, String label)
{
	typeBranch = getTypeBranch(gitRepo.remoteBranch)
	tagBranch = getIdBranch(gitRepo.remoteBranch)
	config["artifactPrefix"] = config.getOrDefault("artifactPrefix","")
	
	def obj = [
			typeBranch       : typeBranch,
			tagBranch        : tagBranch,
			changeReq        : config.artifactPrefix+pck.appName+"#"+gitRepo.remoteBranch,
			kiuwanCredentials: "workbench-kiuwan-user",
			kiuwanAppName    : config.artifactPrefix+pck.appName,
			kiuwanModel      : config.kiuwanModel,
			kiuwanLabel      : label,
			saveUTReports    : env.switchUT,
			kiuwanPath       : "kiuwan/bin/agent.sh",
			kiuwanSource     : config.extractFolder,
			kiuwanBranch     : gitRepo.remoteBranch
	]
	echo "obj:${obj}"
	sh "cp ${config.kiuwanAgentProperties} kiuwan/conf"
	env.QUALITYGATEBLOCKS=true
	kiuwanAnalysis(obj)
	echo "KIUWAN_RESPONSE= ${env.KIUWAN_RESPONSE} qualityAnalysisURL: ${env.analysisURL}"
	if (env.KIUWAN_RESPONSE==10){
		createReject(pck.almsID,"Error during Kiuwan Audit, check analisys URL for details ${env.analysisURL}","3")
		error "Error during Kiuwan Audit, check analisys URL for details"
	}
}
def copyKiuwanToLocal(String kiuwanHomePath){
	sh "rm -rf kiuwan"
	sh "cp -r ${kiuwanHomePath} kiuwan"
}
def call(Map config, VFESALMSDeployment pck, VFESGitRepo gitRepo,String label){

	// Copy kiuwan to local
	this.copyKiuwanToLocal(new File(new File(config.kiuwanPath).parent).parent)
	if (config.kiuwanAppProperties?.trim()){
		sh "mkdir -p kiuwan/conf/apps"
		sh "cp ${config.kiuwanAppProperties} kiuwan/conf/apps"
	}
	if (config.kiuwanRunDiff?.trim()=="True"){
		dir(config.extractFolder){
			sh "sed -i '/^include.patterns/ s/\$/${gitUtils.getFormattedDiffList()}/' ${WORKSPACE}/kiuwan/conf/analyzer.properties"
		}
        
	}
	// Kiuwan 
	this.runKiuwanAnalysis (config,pck, gitRepo,label)
	// Check KA
	
}
def promoteDevelopBaseline(Map config, VFESALMSDeployment pck, VFESGitRepo gitRepo, String developLabel,masterLabel){
	typeBranch = getTypeBranch(gitRepo.remoteBranch)
	tagBranch = getIdBranch(gitRepo.remoteBranch)
	config["artifactPrefix"] = config.getOrDefault("artifactPrefix","")
	
	def obj = [
			typeBranch       : typeBranch,
			tagBranch        : tagBranch,
			changeReq        : config.artifactPrefix+pck.appName+"#"+gitRepo.remoteBranch,
			kiuwanCredentials: "workbench-kiuwan-user",
			kiuwanAppName    : config.artifactPrefix+pck.appName,
			kiuwanModel      : config.kiuwanModel,
			kiuwanLabel      : masterLabel,
			saveUTReports    : env.switchUT,
			kiuwanPath       : "kiuwan/bin/agent.sh",
			kiuwanSource     : config.extractFolder,
			kiuwanBranch     : gitRepo.remoteBranch
	]
	echo "obj:${obj}"
	withCredentials([usernamePassword(credentialsId: obj.kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
      response = sh(encoding: 'UTF-8', label: "[Kiuwan]: Promoting delivery...", returnStdout: true, script: """${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD --promote-to-baseline -n ${obj.kiuwanAppName} -cr "${config.artifactPrefix}${pck.appName}#develop" -l ${developLabel} -pbl ${obj.kiuwanLabel} -wr""").trim()
    }
}


