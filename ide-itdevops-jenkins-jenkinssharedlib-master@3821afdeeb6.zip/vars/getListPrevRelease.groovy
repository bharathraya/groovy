import groovy.json.JsonSlurper

def call (String _CADENAJSON, String _ENTREGA){
    echo "getListPrevRelease"	
    def FECHA_ENTREGA
    List LIST_ENTRE_PREV = []
    def jsonnentregas =new JsonSlurper().parseText(_CADENAJSON)
   	jsonnentregas.each{
   		//echo "Tratando: ${it.release}:${it.fecha}"
		if (it.fecha == ""){
			//echo "Fecha no definida para ${it.release}"
			it.fecha=getFechaRelease(it.release)
			echo "${it.release}:${it.fecha}"
		}
	}
   	FECHA_ENTREGA=""
	jsonnentregas.any{
		if( it.release == "${_ENTREGA}"){
			FECHA_ENTREGA=it.fecha
			return true
		}
	}
    echo "Entrega:${_ENTREGA}:${FECHA_ENTREGA}"
	jsonnentregas.each{
		if( it.fecha == ""){
			echo "Fecha no definida para la release:${it.release}"
		}
		if( it.fecha <= FECHA_ENTREGA){
		    if (it.release != "${_ENTREGA}"){
			    LIST_ENTRE_PREV.add(it.release)
		    }
		}
	}
	if(LIST_ENTRE_PREV.size() == 0){
		echo "No hay entregas previas"
	}
	else{
		echo "Releases previas:" + LIST_ENTRE_PREV.join(",")
	}
	return LIST_ENTRE_PREV
}

def call (String _CADENAJSON, String _ENTREGA, String _ENTORNO){
    echo "getListPrevRelease"	
    def FECHA_ENTREGA
    List LIST_ENTRE_PREV = []
    def jsonnentregas =new JsonSlurper().parseText(_CADENAJSON)
   	jsonnentregas.each{
   		//echo "Tratando: ${it.release}:${it.fecha}:${it.entorno}"
		if (it.fecha == ""){
			//echo "Fecha no definida para ${it.release}"
			it.fecha=getFechaRelease(it.release)
			//echo "${it.release}:${it.fecha}"
		}
	}
   	FECHA_ENTREGA=""
	jsonnentregas.any{
		if( it.release == "${_ENTREGA}"){
			FECHA_ENTREGA=it.fecha
			return true
		}
	}
	echo "Entrega:${_ENTREGA}:${FECHA_ENTREGA}"
	jsonnentregas.each{
		if( it.fecha == ""){
			echo "Fecha no definida para la release:${it.release}"
		}
		if (it.entorno == _ENTORNO){
    		if( it.fecha <= FECHA_ENTREGA){
    		    if (it.release != "${_ENTREGA}"){
    			    LIST_ENTRE_PREV.add(it.release)
    		    }
    		}else{
    	        echo "Descartada entrega: ${it.release} del entorno: ${it.entorno} "
    	    }
        }
	}
	if(LIST_ENTRE_PREV.size() == 0){
		echo "No hay entregas previas"
	}
	else{
		echo "Releases previas:" + LIST_ENTRE_PREV.join(",")
	}
	return LIST_ENTRE_PREV
}
