import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo

def deploy_env=""
def commit_id=""
def alms_id=""
def delivery=""
def project_id=""
def squad=""
def pckinfo=null
def mergeInfo=null
def gitRepo=null
def almsPackage=null
def onlyProperties=false
def pipelineConfig=null

def LOCALdecideCommitId(net.sf.json.JSONArray commits,String _deploy_env){
  
    String ret=""
    String bitbucketBranchPrefix="integration/"
    String branchPrefix=""
    echo "commits.size: ${commits.size()}"
    if (commits[0].Server.ApiEndPoint.contains('bitbucket'))
    {
        // if server is bitbucket we should adhere to naming convention defined
        // for bitbucket where the "delivery" branches start with "integration/"
        echo "bitbucket repo"
        branchPrefix=bitbucketBranchPrefix
    }

    if (commits.size()==1){
        // if we have just one commit, we just take that one
        ret=commits[0].CommitId
    }else if (commits.size()==2){
        // if we have 2 commits, we check if any of them is pre<env> and we take that one
        // else we take the one that does not start by "pre.."
        def branch0=commits[0].BranchHash
        def branch1=commits[1].BranchHash
        if (branch0==branchPrefix+"pre"+_deploy_env || 
                branch1.startsWith(branchPrefix+"pre")){
            ret=commits[0].CommitId
        }else if (branch1==branchPrefix+"pre"+_deploy_env || 
                branch0.startsWith(branchPrefix+"pre")){
            ret=commits[1].CommitId
        }
        

    }else {
        // if there are more than 2 commits, somenthing is wrong :S
        error("There are more than 2 commits on the package !!!")
    }
    if (ret=="") error "If we have two commits in package one of them should be preENV!!!"
    return ret
   
}

def LOCALparsePckInfo(String _pckinfo)
{
    def mypckinfo=readJSON(text:_pckinfo)
    def mydeploy_env=mypckinfo.DeployEnvironment.Name
    def mycommit_id=decideCommitId(mypckinfo.Commits,mydeploy_env)
    def myalms_id=mypckinfo.Id.toString()
    def mydelivery=mypckinfo.Delivery.Name
    def myproject_id=mypckinfo.Project.CodProject
    def mysquad=mypckinfo.EnterpriseName
    // we return multiple values from this fucntion. later values should be 
    // taken like : (a,b,c,d)=fucntion(param)
    return [mydeploy_env,mycommit_id,myalms_id,mydelivery,myproject_id,mysquad]
   
}

def LOCALbuildBackMVOW(Map config,VFESGitMergeInfo mergeInfo){
    def onlyProperties=false
    dir("${config.extractFolder}"){
        def gitPropertiesChanged=sh(returnStdout: true, script: "git diff --name-only  ${mergeInfo.commitBefore}..${mergeInfo.commitAfter} | sed -n '/^WCS-[a-zA-Z0-9]*\\/properties\\//!p'").toString().trim()
        

        echo "gitPropertiesChanged: ${gitPropertiesChanged}"
        echo "Number of gitFilesChanged: ${mergeInfo.filesChanged.size()}"
        if (mergeInfo.filesChanged.size()>0){
            // there are changes involved !
            if (gitPropertiesChanged != ""){
                onlyProperties=false
            }else
            {
                onlyProperties=true
            }
        }else{
            //in case no changes involved , lets recompile all
            onlyProperties=false
        }
    }
    if (onlyProperties){
        echo "There are only property files modified, no need to build!!!"
    }
    else{
        echo "We start build as there are code changes involved in current merge..."
        dir("${config.extractFolder}"){
            sh "mkdir -p .m2"        
            echo "Copy settings.xml  to .m2 folder ... "
            sh "cp ${WORKSPACE}/CDM/${config.settingsXml} .m2"
        }

        buildWithScript(config)
    }
    return onlyProperties
}

def call(Map pipelineParams){
    pipeline{
        agent none
        parameters { 
            string(name: 'DeployEnv', defaultValue: '', description: 'SIT1CI, SIT2CI, SIT3CI, PPRD1CI, HID1CI, masterCI') 
            string(name: 'CommitID', defaultValue: '', description: '') 
            string(name: 'ALMS_ID', defaultValue: '', description: '') 
            string(name: 'Delivery', defaultValue: '', description: '') 
            string(name: 'ProjectId', defaultValue: '', description: '') 
            string(name: 'SQUAD', defaultValue: 'BAU', description: '') 
            string(name: 'PackageInfo', defaultValue: '', description: '') 
        }
        stages{
            stage('config'){
                agent {
                    label 'MVOW'
                }
                steps
                {
                    // recibir info 
                    script{
						env.current_stage=env.STAGE_NAME
                        
                        if (PackageInfo==""){
                            // executed manually or from ALMS
                            deploy_env=DeployEnv
                            commit_id=CommitID
                            alms_id=ALMS_ID
                            delivery=Delivery
                            project_id=ProjectId
                            squad=SQUAD
                        }else{
                            echo "PackageInfo: ${PackageInfo}"
                            (deploy_env,commit_id,alms_id,delivery,project_id,squad)=parsePckInfo(PackageInfo)
                            //pckinfo=readJSON(text:PackageInfo)
                            //deploy_env=pckinfo.Environment.Name
                            //commit_id=pckinfo.decideCommitId(pckinfo.Commits,deploy_env)
                            //alms_id=pckinfo.Id
                            //delivery=pckinfo.Delivery.Name
                            //project_id=pckinfo.Project.CodProject
                            //squad=pckinfo.EnterpriseName

                        }
                        // si es 
                        echo "    DeployEnv: ${deploy_env}"
                        echo "    CommitID:  ${commit_id}"
                        echo "    PackageID: ${alms_id}"
                        echo "    Delivery:  ${delivery}"
                        echo "    Project:   ${project_id}"
                        echo "    Squad:     ${squad}"
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        almsPackage= new VFESALMSDeployment(alms_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,squad)
                        
                        
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
                        // TODO : when 
                        gitRepo=new VFESGitRepo("${pipelineConfig.gitRepo}",this)
                    }

                }
            }
            stage('Checkout'){
                agent {
                    label "MVOW-${deploy_env}"
                    //docker {
                    //    label "MVOW-${deploy_env}"
                    //    reuseNode true
                    //    image "${pipelineConfig.dockerImage}"
                    //    args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    //}
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        docker.image("${pipelineConfig.dockerImage}").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr') { c -> 
                            gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
                        }
                    }
                }
            }
            stage('merge'){
                agent {
                    label "MVOW-${deploy_env}"
                    //docker {
                    //    label "MVOW-${deploy_env}"
                    //    image "${pipelineConfig.dockerImage}"
                    //    reuseNode true
                    //    args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    //}
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        docker.image("${pipelineConfig.dockerImage}").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr') { c -> 
                            mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
                            dir(pipelineConfig.extractFolder){
                                email=sh(returnStdout: true, script: "git show --format='%ae'  ${CommitId}").trim()
                            }
                            echo "eMail: ${email}"
                        }
                    }
                }
            }
            stage('build'){
                agent {
                    label "MVOW-${deploy_env}"
                    //docker {
                    //    label "MVOW-${deploy_env}"
                    //    image "${pipelineConfig.dockerImage}"
                    //    reuseNode true
                    //    args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    //}
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        docker.image("${pipelineConfig.dockerImage}").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr') { c -> 
                            almsPackage.onlyProperties=buildBackMVOW(pipelineConfig,mergeInfo)
                        }
                    }
                }
            }
            /*stage('Sonar'){
                when{
                    expression { return pipelineConfig.runSonar == true }
                    beforeAgent true
                }

                agent {
                    label "MVOW-${deploy_env}"
                    
                    //docker {
                    //    label "MVOW-${deploy_env}"
                    //    image "${pipelineConfig.dockerImage}"
                    //    reuseNode true
                    //    args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    //}
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        docker.image("${pipelineConfig.dockerImage}").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr --entrypoint=""') { c -> 
                            //withSonarQubeEnv('sonar'){
                                dir("${pipelineConfig.extractFolder}"){
                                    sh """mvn --settings ${WORKSPACE}/${pipelineConfig.extractFolder}/.m2/settings.xml \
                                            -Dsonar.host.url=http://195.233.178.75:9000/sonar/ \
                                            -Dsonar.projectKey=IDG-MVOW-JAVA-Wcsapp.MVCJ -Dsonar.branch.name=${deploy_env} \
                                            -Dentorno=${deploy_env} -P${deploy_env} sonar:sonar"""
                                    //timeout(time: 20, unit: 'MINUTES') {
                                    //    waitForQualityGate abortPipeline: true
                                    //}
                                }
                            
                            //}
                        }
                    }
                }
            }*/

            stage('Copy-to-release'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                }
                agent {
                    label "MVOW-${deploy_env}"                    
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        def jobstring="${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}"
                        def zipfilename="${jobstring}.zip"
                        dir("${pipelineConfig.extractFolder}"){
                            echo "Deleting the files under target folders ..."
                            sh 'find . -name "target" -type d -exec rm -rf {} \\; || true'
                            echo "Create zip file..."
                            
                            
                            if (!almsPackage.onlyProperties){
                                echo "Bundling WAR files in ZIP as there are code changes involved..."
                                sh """

                                    find pom.xml assembly.xml WCS-CAS WCS-COA WCS-Coherence WCS-DescargaFicheros \
                                        WCS-Facturacion WCS-Libraries/cas-vodafone/4.0/project WCS-Libraries/cas-ws-client/4.0/project \
                                        WCS-Libraries/mivodafone-api/4.0/project \
                                        WCS-Libraries/mivodafone-cache/4.0/project WCS-Libraries/mivodafone-coh-api/4.0/project \
                                        WCS-Libraries/mivodafone-core/4.0/project WCS-Libraries/mivodafone-dao/4.0/project \
                                        WCS-Libraries/mivodafone-download-core/4.0/project WCS-Libraries/mivodafone-ws-client/4.0/project \
                                        WCS-Logo WCS-MiVF -type f -name "*.war" | grep -v target | zip -r ../${zipfilename} -@;
                                        """
                            }
                            echo "Bundling property files in ZIP ..."
                            sh """
                                find pom.xml assembly.xml WCS-CAS WCS-COA WCS-Coherence WCS-DescargaFicheros \
                                    WCS-Facturacion WCS-Libraries/cas-vodafone/4.0/project WCS-Libraries/cas-ws-client/4.0/project \
                                    WCS-Libraries/mivodafone-api/4.0/project \
                                    WCS-Libraries/mivodafone-cache/4.0/project WCS-Libraries/mivodafone-coh-api/4.0/project \
                                    WCS-Libraries/mivodafone-core/4.0/project WCS-Libraries/mivodafone-dao/4.0/project \
                                    WCS-Libraries/mivodafone-download-core/4.0/project WCS-Libraries/mivodafone-ws-client/4.0/project \
                                    WCS-Logo WCS-MiVF -type d -name "properties" | zip -r ../${zipfilename} -@
                                    """
                        }
                        def json = readJSON(file: "${WORKSPACE}/${pipelineConfig.releaseConfig}")
                        env_config = json["${deploy_env}"]
                            
                        env_config.release.each { item ->
                            echo "Deploying up on ${item.server} ..."
                            sh """
                            ssh -o StrictHostKeyChecking=no  ${item.server} "mkdir -p /home/plataforma/jenkins/tmp/job-${jobstring}/"
                            """
                            sh "scp ${zipfilename} ${item.server}:/home/plataforma/jenkins/tmp/job-${jobstring}/ 2>/dev/null"
                            sh """
                            ssh -o StrictHostKeyChecking=no -l ${item.username}  ${item.server} \
                            'cd ${item.path}; \
                            rm backup-jenkins-${alms_id}-${deploy_env}-*.zip
                            zipinfo -1 /home/plataforma/jenkins/tmp/job-${jobstring}/${zipfilename} | zip backup-jenkins-${jobstring}.zip -@;\
                            unzip -o /home/plataforma/jenkins/tmp/job-${jobstring}/${zipfilename}; '
                            """
                            sh """
                            ssh -o StrictHostKeyChecking=no  ${item.server} "rm /home/plataforma/jenkins/tmp/job-${jobstring}/*.zip"
                            """
                        }
                        echo "Deleting zip file ... "
                        sh "rm ${zipfilename}"

                    }
                }
            }

            stage('Deploy'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                }
                agent {
                    label "MVOW-${deploy_env}"
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        def ansibleInstall='ansibleusrbin'
                        if (pipelineConfig.containsKey('ansibleInstall')){
                            ansibleInstall=pipelineConfig.ansibleInstall
                        }
						color="#FFA500" // orange
						message="WorkBench Package: ${alms_id}\nStarting restart of WebLogic domains ch:cas:coa:dw:ft:lg:mvf:wb in environment ${deploy_env}"
						//slackSend(channel: "#es_sq_devops_pruebas", color: color, message: message)						
						slackSend(channel: pipelineConfig.slackChannel, color: color, message: message)
                        ansiblePlaybook(
                            playbook: 'CDM/Ansible/restart_wl.yml',
                            limit: 'ch:cas:coa:dw:ft:lg:mvf:wb',
                            inventory : "CDM/Ansible/inventories/${deploy_env}/hosts",
                            installation: ansibleInstall,
                            extras: '-e "clean_cache=true clean_stage=true"')
						color="#00FF00" // green
						message="WorkBench Package: ${alms_id}\nFinished restart of WebLogic domains ch:cas:coa:dw:ft:lg:mvf:wb in environment ${deploy_env}"
						//slackSend(channel: "#es_sq_devops_pruebas", color: color, message: message)
						slackSend(channel: pipelineConfig.slackChannel, color: color, message: message)       
                    }
                }
            }
            stage('DeleteBackup'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                }
                agent {
                    label "MVOW-${deploy_env}"
                }
                steps{
                    script{
                        def json = readJSON(file: "${WORKSPACE}/${pipelineConfig.releaseConfig}")
                        env_config = json["${deploy_env}"]
                            
                        env_config.release.each { item ->
                            echo "Deleting release backup ..."
                            sh """
                            ssh -o StrictHostKeyChecking=no -l ${item.username}  ${item.server} \
                            'cd ${item.path}; \
                            rm backup-jenkins-${alms_id}-${deploy_env}-*.zip'
                            """
                        }
                    
                    }
                }
            }
            /*stage('Selenium-Tests'){
                when{
                    expression { return pipelineConfig.runSelenium == true  && deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                    beforeAgent true
                }
                agent{
                    label 'es1117yw'
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        //def ret=bat(returnStdout:true , script:"python CDM/Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${deploy_env} ")
                        //echo "${ret}"
                        bat "python CDM/Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${deploy_env} ${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}"
                        archiveArtifacts artifacts: '*.png', fingerprint: true
                        bat "del *${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}*.png"
                    }
                }   
            }*/


            stage('Prepare PAP'){
                agent{
                    label "MVOW-${deploy_env}"
                    //label "deploy-apache-wcs"
                    //label "${pipelineConfig.releaseAgent}"
                }
                when{
                    expression { return deploy_env ==~ /(?i)(master|masterCI|hid|hid1|hidci|hid1ci)/ }
                }
                steps{
                    echo "running Prepare PAP step"
                    prepareForProdDeployment pipelineConfig, almsPackage
                }
            }

            stage('TagAndPush'){
                agent {
                    docker {
                        label "MVOW-${deploy_env}"
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        echo "Tag commit and push to git "
                        gitRepo.tagAndPush pipelineConfig.extractFolder,
                            almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                    }
                }
            }
            stage('PublishChanges'){
                agent {
                    docker {
                        label "MVOW-${deploy_env}"
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    echo "Publish changes to ELK  and GitPublish plugin"
                    publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                    
                }
            }

        }
        post { 
            always { 
                node('master') {
                    catchError(message:"Error when publishing to InfluxDB") {
                        script{
                            echo 'Publishing to Influx for Pipeline KPI!!!'
                            //squad=get_squad_from_email(email)
                            //echo "eMail: ${email}"
                            echo "Squad: ${squad}"
                            sendInfluxMetrics "${deploy_env}", squad
                        }
                    }
                }
            }
			//failure{
				//slackNotify pipelineConfig,almsPackage,"ERROR"
			//}
			//success{
				//slackNotify pipelineConfig,almsPackage,"OK"
			//}
        }

    }
}

