def call(List jsonDc,String resourcename){
    echo "getListJsonDC"
    def listdc=[]
    jsonDc.each(){
        if(it.name == resourcename){
            listdc.add(it)
        }
    }
    return listdc
}