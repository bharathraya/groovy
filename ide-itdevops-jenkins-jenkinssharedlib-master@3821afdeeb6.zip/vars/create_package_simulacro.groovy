def call (String User, String passw, String paquete, String env, String proyect){
    node ('es1117yw'){

        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: passw ]]]) {
                bat "python create_package_simulacro.py -u ${User} -c ${passw} -p ${paquete} -e ${env} -x ${proyect}  "
            }//wrap
        }
    }
}

