def call(String TAG){
    echo "checkGitTag"
    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
        git tag -l ${TAG}
    """
	return SALIDA
}