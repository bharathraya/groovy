def call(String _Extraer,String _Domain,String _Env,String _SVNfolder,String _Action,String _packageName,String _PackagesList,String _remoteServer){
	def opcionN=""
	def opcionS=""
	
	if(_Extraer=="NO"){
		opcionN="-N"
	}
	
	if(_SVNfolder != ""){
		opcionS="-s ${_SVNfolder}"
	}
	
	exec="""
	. \$HOME/.profile >/dev/null 2>&1
	actualiza_paquetes_drop_WB.sh ${opcionN} -d ${_Domain} -e ${_Env} ${opcionS} -a ${_Action} -p ${_packageName} ${_PackagesList}
	"""
	
	if (_remoteServer!="")
	{
		sh "ssh -q ${_remoteServer} '${exec}'"
	}
	else
	{
		sh "${exec}"
	}
}