import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo

def call(Map config,VFESALMSDeployment alms)
{
  for (i=0;i<config.artifactId.size();i++){
      def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
      def _envConfig=myEnvsConfig[alms.deployEnv]
      echo "_envConfig"+_envConfig['copyToInfraServer']

      def plataforpath="/home/plataforma/plausr/data/temporal/${alms.jobDate}/anexo/${alms.almsID}/${alms.deployEnv}"
      def zipname="${alms.appName}.${alms.almsID}.${alms.jobTimeStamp}"

      _envConfig['copyToInfraServer'].each { item ->
        echo "Preparing deploy to the Infra Server: ${item.server} ..."
        echo "==> Creating path in the Infra Server"
        sh "ssh platafor@${item.server} 'rm -f ${plataforpath}/* 2>/dev/null'"
        sh "ssh platafor@${item.server} 'mkdir -p ${plataforpath}'"
        echo "==> Creating .env file for deployment ..."
        sh "echo export REL_ROOT=${item.application_release_path}/${config.applicationName} >> ${zipname}.${item.server}.env"
        sh "echo export USER_REL=${item.user} >> ${zipname}.${item.server}.env"
        echo "==> Sending .env file for deployment to Infra Server ..."
        sh "scp ${zipname}.${item.server}.env platafor@${item.server}:${plataforpath}/${zipname}.env"
        echo "==> Sending .zip file for deployment to Infra Server ..."
        sh "scp ${WORKSPACE}/${config.extractFolder}/${config.distFolder[i]}/${config.distFile[i]} platafor@${item.server}:${plataforpath}/${zipname}.zip"
        echo "==> Sending ROLLBACK script file for deployment to Infra Server ..."
        sh "scp ${WORKSPACE}/CDM/CommonTools/scripts/ROLLBACK_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.bak.sh"
        echo "==> Sending GO script file for deployment to Infra Server ..."
        sh "scp ${WORKSPACE}/CDM/CommonTools/scripts/DEPLOY_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.sh"
        echo "==> Grant Permissions to script files for deployment into Infra Server ..."
        sh "ssh platafor@${item.server} 'chmod 777 ${plataforpath}; chmod 755 ${plataforpath}/*.sh'"
      }
      echo ""
      echo ""
      echo "************************************************************************"
      echo "************************************************************************"
      _envConfig['copyToInfraServer'].each { item ->
        currentBuild.description = currentBuild.description+"\n\r\n\rExecute FROM: platafor@${item.master_server}:"
        echo "Execute FROM: platafor@${item.master_server}"
        echo "deploy_prod -d ${alms.appName} -f ${alms.jobDate} -p ${alms.almsID} -F"
        echo "Please, take note (only) of the name of the script (only the name, without path) because you will need it in the following step"
        echo ""
        echo "Execute FROM: platafor@${item.master_server}"
        echo "desplegator -d ${alms.appName} -e ${alms.deployEnv} -p ${alms.almsID} {SCRIPT_NAME_WITHOUT_PATH}"
        currentBuild.description = currentBuild.description+"\n\rdeploy_prod -d ${alms.appName} -f ${alms.jobDate} -p ${alms.almsID} -F"
      }
      echo "************************************************************************"
      echo "************************************************************************"
      echo ""
      echo ""
    }
}
