def call(String _ALMS_ID, String _DeployEnv, String _Domain,String _PackageJSON, String _ServerJSON){
 
    if (_PackageJSON==""){
    //LLamada manual
        print "Llamada manual"
        callFromWB=false  
        
    }
    else{
        print "Llamada desde WB "
        callFromWB=true  
    }

    if (callFromWB){
            //Se llama desde WB
            
            pckInfo=readJSON(text: "${_PackageJSON}")
            echo "PackageInfo: ${_PackageJSON}"
            
            // Llamo a la función que trae el superpaquete
            (_DeployEnv,_Domain,_ALMS_ID,_server,_HayModulosPVCS,_dataModules,_HayModulosDatos,_HayAnexos,_Parametros,_HayParametros)=parsePckInfoPVCS(PackageInfo)

    }else{
                
                enviroments=readJSON(file: "${_ServerJSON}")
                _server=enviroments["${_Domain}"]["${_DeployEnv}"]["server"][0][0]
                
                //Funcion que lee los modulos de datos                
                CompruebaModulos "${_ALMS_ID}", "${_DeployEnv}"

                mydataModulesMap= readJSON(file: "CompruebaModulos/modules.json")
           //   print "mydataModulesMap ${mydataModulesMap}"
                modulo=mydataModulesMap.Modules
          //    print "Modulo ${modulo} "
      
                //Funcion que lee los anexos de datos
                CompruebaAnexos "${_ALMS_ID}", "${_DeployEnv}"
                mydataAnexosMap= readJSON(file: "CompruebaAnexos/anexos.json")
                if(mydataAnexosMap.Annexes == "null"){
                         _HayAnexos=0 
                        // print "entro por 0"
                }else{
                        _HayAnexos=mydataAnexosMap.size()
                        //print "entro por 1"
                }
                
                //Funcion que revisa si hay pvcs            
                CompruebaPvcs "${_ALMS_ID}", "${_DeployEnv}"
       
                //Creamos fichero e
                fichero_e="${_ALMS_ID}.${_DeployEnv}.deploy"  
           //     print "fichero e ${fichero_e}"
                def _FicheroModulosPVCS=readFile(file: "CompruebaPvcs/${fichero_e}")
    	 // print "llego a hacer el readfile ${_FicheroModulosPVCS}"
                //fileInfo=myfile.split()
                  //      tamano= fileInfo.size()

                if ("${_FicheroModulosPVCS}" != "" ){
                    modulosPVCS=_FicheroModulosPVCS.split()
                     tamano= modulosPVCS.size()
                    _HayModulosPVCS=tamano                                    
                }else{
                    _HayModulosPVCS=0                   
                }
                //print "Hay módulos de pvcs  ${_HayModulosPVCS}"
                            
                //_HayModulosPVCS=wbpckinfo.Data.Model.Model.Contents.PVCS.size()
                //_Anexos=wbpckinfo.Data.Model.Model.Annexes
                //_HayAnexos=_Anexos.size
               
            //    if(mydataModulesMap.Modules == "null" ){
      			if( "${modulo}" == "null" ){
                        _dataModules=""    
                //   print "entro por 4"
                  }else{
                        _dataModules=mydataModulesMap.Modules
                   // print "entro por 5"
                  }
                    //  print " _dataModules ${_dataModules}"       
      
                if({_dataModules}==""){
                    _HayModulosDatos=0  
                 //   print "entro por 6"
                }
                else{
                //    print "entro por 7"
                    _HayModulosDatos=_dataModules.size()
                //   print " _HayModulosDatos ${_HayModulosDatos}"
                }
                
                //de momento en manual no pasamos estos datos
                _Parametros=""
                _HayParametros=0
            
      		 	print "fin llamada manual"
            
            }//fin llamada manual

            print "Paquete WB ${_ALMS_ID}"
            print "Entorno ${_DeployEnv}"
            print "Dominio ${_Domain}"
            print "Server ${_server}"
           // print "Módulos de datos ${_dataModules}"
           // print "Hay módulos de datos  ${_HayModulosDatos}"
           // print "Hay módulos de pvcs  ${_HayModulosPVCS}"
            //print "Hay módulos de Anexos  ${_HayAnexos}"
            
            print "Saco el servidor SVN para el caso necesario"
            print "_ServerJSON ${_ServerJSON}"

            enviroments=readJSON(file: "${_ServerJSON}")
  		//	print "enviroments ${enviroments} "
            _serverSVN=enviroments["${_Domain}"]["${_DeployEnv}"]["serverSVN"][0][0]
          //  print " _Domain ${_Domain}" 
   		//	print " _DeployEnv ${_DeployEnv}" 
  		//	print " _serverSVN ${_serverSVN}"
           
      
    return [_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos, _serverSVN, _Parametros, _HayParametros ]

}
