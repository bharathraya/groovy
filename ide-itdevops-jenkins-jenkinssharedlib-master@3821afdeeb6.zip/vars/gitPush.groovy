import vfes.git.VFESGitRepo

def call(String _branch, VFESGitRepo _repo) {
  echo "GitTag"
    // get old commitid
    final String GITLAB="Gitlab"
    final String BITBUCKET="Bitbucket"
    final String INTEGRATION_BB_PREFIX="vodafone"
    final String RELEASE_BB_PREFIX="release"
    final String FEATURE_BB_PREFIX="feature"
    final String REGEX_RELEASE=  /ES[0-9]*[A-Za-z_]*/
    final String REGEX_RELEASE_RC=  /ES[0-9]*[A-Za-z_]*-RC/
    final String REGEX_RELEASE_TEAM= /[A-Za-z_0-9]*-ES[0-9]*[A-Za-z_]*/

    final String REGEX_MASTER_DEVELOP= /(master|masterCI|develop)/    
    final String REGEX_ENVIRONMENTS= /(SIT1|SIT1CI|PPRD|PPRD1|PPRDCI|PPRD1CI|SIT2|SIT2CI|HID|HID1|HIDCI|HID1CI)/
    def _localBranch=_branch
    def _remoteBranch=_branch
    def _packagePrefix=""


    vfRepoPath=_repo.repoPath
    if (_repo.repoType==GITLAB){
        vfRepoPath=(_repo.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
    }    
    if (_repo.repoType==BITBUCKET  && !(_branch=='master'||_branch=='masterCI' || _branch=='develop')){
        if(_branch =~ REGEX_RELEASE || _branch =~ REGEX_RELEASE_TEAM || _branch =~ REGEX_RELEASE_RC){
            _remoteBranch=RELEASE_BB_PREFIX+"/"+_branch
        }else{
            _remoteBranch=INTEGRATION_BB_PREFIX+"/"+_branch
            _packagePrefix=_branch+"-"
        }
    }else{
        _packagePrefix=_branch+"-"
    }

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${_repo.pushCred}",
            usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
        sh """
            git remote set-url origin ${_repo.protocol}://${USERNAME}:${PASSWORD}@${_repo.server}/${vfRepoPath}/${_repo.repoName}
            git fetch --tags
        """
    }

    
    // push
    sh ("git push origin ${_localBranch}:${_remoteBranch}")
}


