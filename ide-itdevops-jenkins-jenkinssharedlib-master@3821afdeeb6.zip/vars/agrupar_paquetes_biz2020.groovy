def call(String _NombreCarpeta, String _env, String _listado, String _Opcion){
  hoy=new Date().format( 'yyyyMMdd' )
  _remoteServer = "fwapptst01"
  _ActualServer = "apidpodapptst01"
    
    
   
   //Hay que hacer un txeker de cada paquete para guardarlo
    if (_env == "PROD" && _Opcion =="Ejecutar") 
    {
         //Saco todo los paquetes en _PROD
        ListaIIS=_listado.split()
        print "Lista de paquetes IIS ${ListaIIS} "
        Tam=ListaIIS.size() 
        print "Cuantos paquetes hay de IIS ${Tam} "
        for (pos = 0; pos < ListaIIS.size(); pos++) {
    
         Paquete=ListaIIS[pos]
         WB_ID="${Paquete}_PROD"
         print "Paquete que hacemos el txeker ${Paquete}"
         print "Nombre del paquete que hacemos el txeker ${WB_ID}"
         fichero_e="${WB_ID}.${_env}.deploy"
         fichero_e_backout="${WB_ID}.${_env}.rollback"
         fichero_e_por="${WB_ID}.${_env}.por_paquete"
    
         txeker("-x","BIZTALK2020-IIS",_env,WB_ID,Paquete)
     
         sh ". \$HOME/.profile >/dev/null 2>&1;  if [ -d /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID} ] ;  then rm -Rf  /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID} ; fi ;. paquete ${WB_ID} "
         sh "scp -rp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID}/* /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID}"
         sh "mv /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID}/${fichero_e} /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID}/${_env}/e"
         sh "mv /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID}/${fichero_e_backout} /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID}/${_env}/e_backout"
         sh "mv /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID}/${fichero_e_por} /home/plataforma/plausr/data/paquetes/${hoy}/${WB_ID}/e_por_paquete"
    
        }// for
             
    } //Si es PROD
    
    if (_Opcion == "Ejecutar")
    {
         exec="""
        . \$HOME/.profile >/dev/null 2>&1
        cd 
        agrupar_paquetes_biz2020_WB.sh  ${_NombreCarpeta}  ${_env}
    
        """
    }
    else if (_Opcion == "Revisar")
    {
         exec="""
        . \$HOME/.profile 
        agrupar_paquetes_biz2020_WB.sh  ${_NombreCarpeta}  ${_env} -W
    
        """
    }
    
    
    
    //Ejecuto el script
     //sh "ssh -q fwapptst01 '${exec}'"
     sh "${exec}"
    
   
}
