def call(String _domain, String _nombreCarpeta, String _CRQ_ID,String _User, String _Pass){

def hoy=""
def RutaTemp=""
def RutaPaquete=""
def _repo=""
def _SourceOri=""
def _commit=""
def _proyect=""
def _SourceDest=""
def FicheroCommit=""
def CommitFile=""
def iError=0
def execCheck=""

iError=0
_proyect="ISA-AMDOCS"
_SourceDest="master"
//_SourceDest="release/ESCRMUPGRADE"

hoy=new Date().format( 'yyyyMMdd' )

RutaTemp="/home/plataforma/plausr/tmp"
RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"

//print "parametros:::::::::::::::"
//print "parametros _domain: ${_domain}"
//print "parametros _nombreCarpeta: ${_nombreCarpeta}"
//print "parametros _CRQ_ID: ${_CRQ_ID}"

sh "mkdir -p /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/"
sh "rm -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/txeker_git.${_nombreCarpeta}"
sh "rm -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Resultado*"
sh "scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/txeker_git.${_nombreCarpeta} /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/"
sh "head -1 /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/txeker_git.${_nombreCarpeta}  >> ${RutaPaquete}/commit.${_domain}"
FicheroCommit = readFile(file: "${RutaPaquete}/commit.${_domain}")
CommitFile=FicheroCommit.split(":")
//103907:ISA-AMDOCS-java-smartclient:release/ES2217FR:3ce7ef7532ff3d752357a63202cb34d61137220e:2022-06-13T12:26:22Z:Mantenimiento-ES2251DL
_repo=CommitFile[1]
_SourceOri=CommitFile[2]
_commit=CommitFile[3]

print "Proyecto: ${_proyect}"
print "Repo: ${_repo}"
print "Rama Origen: ${_SourceOri}"
print "Rama Destino: ${_SourceDest}"
print "Commit a comparar: ${_commit}"

print "Lanzamos checkIfPRHasConflicts(${_repo},${_proyect},${_SourceOri},${_SourceDest},${_commit},${_nombreCarpeta}_User,_Pass) "
 try{
      wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _Pass ]]]) {
       checkIfPRHasConflicts(_repo,_proyect,_SourceOri,_SourceDest,_commit,_nombreCarpeta,_User,_Pass)
        } //wrap
      } catch(Exception e){
                        iError=1
                          }
                          
print "lanzamos checkContent checkContent(${_repo},${_proyect},${_SourceDest},${_commit},${_nombreCarpeta})"           
try{
        wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _Pass ]]]) {    
            checkContent(_repo,_proyect,_SourceDest,_commit,"",_nombreCarpeta,_User,_Pass)
            print "Cometado: lanzamos checkContent checkContent(${_repo},${_proyect},${_SourceDest},${_commit},${_nombreCarpeta})"           

        } //wrap
      } catch(Exception e){
                        if (iError==1)
                        {
                            iError=3
                        }
                        else
                        {
                            iError=2
                        }
                        
                          }
  //Sacamos los ficheros que se modifican
 
     execCheck="""
             . \$HOME/.profile                          
             if [ ! -d /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID} ] ; 
             then
                   mkdir -p /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}                    
             fi 
             if [ ! -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Bit_diferencias.txt ] ; 
             then
                   touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Bit_diferencias.txt                    
             fi 
            
           check_git_package_changes.sh -d ${_domain} -b master -c ${_commit} -p ${_nombreCarpeta}
           echo "*****************************************************************************" >> /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Bit_diferencias.txt
           echo "Modulos cambiados para ${_domain}:" >> /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Bit_diferencias.txt
           cat /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/GitModulesCommit.txt >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Bit_diferencias.txt     
           echo "*****************************************************************************" >> /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Bit_diferencias.txt
        """
    sh "${execCheck}"
   // sh "ssh -q devopststtools01 '${execCheck}'"
  
    return iError // 0 sin error, 1 error de PR, 2 error de contenido, 3 error en ambos
}
