import vfes.utils.VFESALMSDeployment
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.json.JsonBuilder

class DataModule implements Comparable<DataModule> {
    public String Order, Package, ModuleFileName, RollBackModuleFileName, Context, StatusGO, StatusRollBack;
    public DataModule(String Order, String Package, String ModuleFileName, String RollBackModuleFileName, String Context, String StatusGO, String StatusRollBack) {
        this.Order = Order;
        this.Package = Package;
        this.ModuleFileName = ModuleFileName;
        this.RollBackModuleFileName = RollBackModuleFileName;
        this.Context = Context;
        this.StatusGO = StatusGO;
        this.StatusRollBack = StatusRollBack;
    }
    public String toString() {
        return ("(" + Order + ", " + Package + ", " + ModuleFileName + ", " + RollBackModuleFileName + ", " + Context + ", " + StatusGO + ", " + StatusRollBack + ")");
    }
    @Override
    public int compareTo(DataModule o) {
        // usually toString should not be used,
        // instead one of the attributes or more in a comparator chain
        return toString().compareTo(o.toString());
    }
}

class SortbyOrder implements Comparator<DataModule>
{
    // Used for sorting in ascending order of
    // roll number
    @NonCPS
    public int compare(DataModule o1, DataModule o2)
    {
         return o1.Order.compareTo(o2.Order);
    }
}


def deploy_env=""
def commit_id=""
def pck_id=""
def delivery=""
def project_id=""
def enterprise=""
def pipelineConfig=null
def modules=""
def modulesHostIP=""
def modulesUserName=""
def modulesAppendPath=""
def modulesCompletePath=""
def modulesUploadPath=""
def persistenceFileCompletePath=""
def deployConfig=null
def dataModuleActionStatus=null
def hoy=null
def Order=""
def Module=""
def persistence_status_filename=""
def AR_StartStop=null
def contextPathToRestart=""
def proxyServers=""
def URLMicroServiceStart=""
def MicroServicePort=""


def printDataModules(ArrayList<DataModule> DataModules){
    for( b in DataModules )
    {
        echo "Order: ${b.Order}, Package: ${b.Package}, ModuleFileName: ${b.ModuleFileName}, RollBackModuleFileName: ${b.RollBackModuleFileName}, Context: ${b.Context}, StatusGO: ${b.StatusGO}, StatusRollBack: ${b.StatusRollBack}"
    }
}

def WriteDataModulesToFile(ArrayList<DataModule> DataModules, String File){
    String Line = ""
    for( b in DataModules )
    {
        Line = Line + "Order: ${b.Order}, Package: ${b.Package}, ModuleFileName: ${b.ModuleFileName}, RollBackModuleFileName: ${b.RollBackModuleFileName}, Context: ${b.Context}, StatusGO: ${b.StatusGO}, StatusRollBack: ${b.StatusRollBack}" + "\r\n"
    }
    writeFile([file: File, text: Line])
}

def returnSplitName (String full_name){
    def _context=null
    def _free=null
    def _extension=null

    int sepPos1 = full_name.indexOf('_')
    if (sepPos1 == -1) {
        return [_context,_free,_extension]
    }
    _context=full_name.substring(0,sepPos1).trim()

    int sepPos2 = full_name.lastIndexOf('.')
    if (sepPos2 == -1) {
        return [_context,_free,_extension]
    }
    _free=full_name.substring(sepPos1+1,sepPos2).trim()
    _extension=full_name.substring(sepPos2+1).trim()

    return [_context,_free,_extension]
}

def findBinaryFromContext(String context, String ip, String name){
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 3
    remote.retryWaitSec = 2
    remote.timeoutSec = 5
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
        connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
        {
            remote.host = ip
            remote.name = name
            remote.identityFile = keyfile
            compose_ret=" --command=\"deployment-info\" | grep \"${context}\" | awk '{print \$1\" \"\$4}'| grep \"true\"| wc -l"
            command=connect + compose_ret
            echo "        =>Command: ${command}"
            ret=sshCommand remote: remote, command:"${command}"
            if (ret != "1")
            {
                return
            }
            compose_bin=" --command=\"deployment-info\" | grep \"${context}\" | awk '{print \$1\" \"\$4}'| grep \"true\" | awk '{print \$1}'"
            command=connect + compose_bin
            bin_name=sshCommand remote: remote, command:"${command}"
            return bin_name
        }
    }

}


def UploadToProxyServer(){
    echo "Cleaning Package Temporal Path in each Proxy Server"
    withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
    {
        for (ps in proxyServers)
        {
            echo "====> Cleaning ${modulesUploadPath} at proxy server ${ps}"
            sh(script:"ssh -o ConnectTimeout=30 -i ${keyfile} ${pipelineConfig.releaseUser}@${ps} rm -fr ${modulesUploadPath}", returnStatus:false)
            echo "====> Creating new fresh ${modulesUploadPath} at proxy server ${ps}"
            sh(script:"ssh -o ConnectTimeout=30 -i ${keyfile} ${pipelineConfig.releaseUser}@${ps} mkdir -p ${modulesUploadPath}")
        }
    }

    echo "Getting Modules to Local Path"
    sh(script:"rm -fr ${modulesAppendPath}", returnStatus:false)
    sh(script:"mkdir -p ${modulesAppendPath}")
    sh("scp -o ConnectTimeout=30 ${modulesUserName}@${modulesHostIP}:${modulesCompletePath}* ${modulesAppendPath}.")

    withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
    {
        for (dataModule in dataModuleActionStatus)
        {
            _fileGO=dataModule.ModuleFileName
            _fileBACKUP=dataModule.RollBackModuleFileName
            _proxyServerName=deployConfig[deploy_env]["DataBases"][dataModule.Context].name
            _proxyServerIP=deployConfig[deploy_env]["DataBases"][dataModule.Context].ip
            echo "====> Upload Module ${_fileGO} & ${_fileBACKUP} to ${_proxyServerName} with ip ${_proxyServerIP}"
            sh("scp -o ConnectTimeout=30 -i ${keyfile} ${modulesAppendPath}${_fileGO} ${pipelineConfig.releaseUser}@${_proxyServerIP}:${modulesUploadPath}.")
            sh("scp -o ConnectTimeout=30 -i ${keyfile} ${modulesAppendPath}${_fileBACKUP} ${pipelineConfig.releaseUser}@${_proxyServerIP}:${modulesUploadPath}.")
        }
    }
}

def StopMicros(){
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 3
    remote.retryWaitSec = 2
    remote.timeoutSec = 5

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
        connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"

        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
        {
            remote.identityFile = keyfile
            for (_context in contextPathToRestart)
            {
                _ar=AR_StartStop.find{it.context == _context}
                _binaryName=_ar.binaryName
                if (_binaryName != "")
                {
                    disable=" --command=\"deployment disable ${_binaryName}\""
                    _arEnv=deployConfig[deploy_env]["Environment"][_context]
                    for (_server in _arEnv)
                    {
                        remote.host = _server.ip
                        remote.name = _server.name

                        echo "====> Disabling MicroService ${_binaryName} into the ${_server.name} with ip ${_server.ip}"
                        command=connect+disable
                        echo "command: ${command}"
                        //OJO!!!! DESCOMENTAR
                        sshCommand remote: remote, command:"${command}"
                    }
                }
                else
                {
                    echo "Context:${_context} found without binary. Maybe is a new binary. Nothing to do"
                }
            }
        }
    }
}

def StartMicros(){
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 3
    remote.retryWaitSec = 2
    remote.timeoutSec = 5

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
        connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
        activate_command="curl -s --location --request POST "
        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
        {
            remote.identityFile = keyfile
            for (_context in contextPathToRestart)
            {
                _ar=AR_StartStop.find{it.context == _context}
                _binaryName=_ar.binaryName
                if (_binaryName != "")
                {
                    enable=" --command=\"deployment enable ${_binaryName}\""
                    _arEnv=deployConfig[deploy_env]["Environment"][_context]
                    for (_server in _arEnv)
                    {
                        remote.host = _server.ip
                        remote.name = _server.name
                        url_curl="\"http://${_server.ip}:${MicroServicePort}/"
                        echo "====> Enabling MicroService ${_binaryName} into the ${_server.name} with ip ${_server.ip}"
                        command=connect+enable
                        echo "command: ${command}"
                        //OJO!!!! DESCOMENTAR
                        sshCommand remote: remote, command:"${command}"
                        echo "====> Starting MicroService ${_binaryName} into the ${_server.name} with ip ${_server.ip}"
                        _context_to_start=_context.substring(0, _context.length() - 1)
                        command=activate_command + url_curl + _context_to_start + "${URLMicroServiceStart}" + "\""
                        echo "command: ${command}"
                        //OJO!!!! DESCOMENTAR
                        sshCommand remote: remote, command:"${command}", failOnError:false
                    }
                }
                else
                {
                    echo "Context:${_context} found without binary. Maybe is a new binary. Nothing to do"
                }
            }
        }
    }
}

def CleanEnvironment(){
    echo "Cleaning Package Temporal Path in each Proxy Server"
    withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
    {
        for (ps in proxyServers)
        {
            echo "====> Cleaning ${modulesUploadPath} at proxy server ${ps}"
            sh(script:"ssh -o ConnectTimeout=30 -i ${keyfile} ${pipelineConfig.releaseUser}@${ps} rm -fr ${modulesUploadPath}", returnStatus:false)
        }
    }
}

def Deploy(){
  def remote = [:]
  remote.user = pipelineConfig.releaseUser
  remote.allowAnyHosts = true
  remote.retryCount = 3
  remote.retryWaitSec = 2
  remote.timeoutSec = 5

  withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
  {
      remote.identityFile = keyfile
      persistence_status_filename="${persistenceFileCompletePath}" + "persistence_status_" + "${pck_id}" + ".info"

      echo "Writing Actions Persistence File at: ${persistence_status_filename}"
      for( DM in dataModuleActionStatus)
      {
        _DBInfo=deployConfig[deploy_env]["DataBases"][DM.Context]
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${_DBInfo.Password_File}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
        {
          schamanDBproxyCommand="java -jar ${pipelineConfig.schamanDBproxyPath}/${pipelineConfig.schamanDBproxyJar} -u ${USERNAME} -p ${PASSWORD}"
          remote.host = _DBInfo.ip
          remote.name = _DBInfo.name
          DBproxyServer=" -S ${_DBInfo.databaseServer}"
          DBproxyPort=" -P ${_DBInfo.Port}"
          DBproxyDBName= " -D ${_DBInfo.database}"
          DBproxyConnParam= " -C \"${_DBInfo.Parameters}\""
          DBproxyFile=" -f ${modulesUploadPath}${DM.ModuleFileName}"
          command=schamanDBproxyCommand + DBproxyServer + DBproxyPort + DBproxyDBName + DBproxyConnParam + DBproxyFile
          echo "====>      Data Module to execute:          ${DM.ModuleFileName}"
          echo "======>    (If ERROR) RollBack Module:          ${DM.RollBackModuleFileName}"
          echo "======>    Command to execute: ${command}"
          echo "======>    Executing ......."
          DM.StatusGO="KO"
          WriteDataModulesToFile(dataModuleActionStatus, persistence_status_filename)
          Order=DM.Order
          Module=DM.ModuleFileName
          //OJO!!!! DESCOMENTAR
          sshCommand remote: remote, command:"${command}"
          DM.StatusGO="OK"
          WriteDataModulesToFile(dataModuleActionStatus, persistence_status_filename)
      }
    }
  }
}

def rollBackDeploy()
{
  echo "!!!!!!!!ROLLBACK DEPLOY PHASE START!!!!!!!!"
  echo "Status Actions Before the RollBack:"
  printDataModules(dataModuleActionStatus)

  echo "Starting RollBack Actions:"
  def remote = [:]
  remote.user = pipelineConfig.releaseUser
  remote.allowAnyHosts = true
  remote.retryCount = 3
  remote.retryWaitSec = 2
  remote.timeoutSec = 5

  index=dataModuleActionStatus.findIndexOf{it.ModuleFileName == Module && it.Order == Order}
  withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
  {
      remote.identityFile = keyfile

      for( int i = index; i>= 0; i--)
      {
        _DBInfo=deployConfig[deploy_env]["DataBases"][dataModuleActionStatus[i].Context]
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${_DBInfo.Password_File}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
        {
          schamanDBproxyCommand="java -jar ${pipelineConfig.schamanDBproxyPath}/${pipelineConfig.schamanDBproxyJar} -u ${USERNAME} -p ${PASSWORD}"
          remote.host = _DBInfo.ip
          remote.name = _DBInfo.name
          DBproxyServer=" -S ${_DBInfo.databaseServer}"
          DBproxyPort=" -P ${_DBInfo.Port}"
          DBproxyDBName= " -D ${_DBInfo.database}"
          DBproxyConnParam= " -C \"${_DBInfo.Parameters}\""
          DBproxyFile=" -f ${modulesUploadPath}${dataModuleActionStatus[i].RollBackModuleFileName}"

          command=schamanDBproxyCommand + DBproxyServer + DBproxyPort + DBproxyDBName + DBproxyConnParam + DBproxyFile
          echo "====>      RollBack Module to execute:           ${dataModuleActionStatus[i].RollBackModuleFileName}"
          echo "======>    Command to execute: ${command}"
          echo "======>    Executing ......."
          dataModuleActionStatus[i].StatusRollBack="KO"
          //OJO!!!! DESCOMENTAR
          sshCommand remote: remote, command:"${command}"
          dataModuleActionStatus[i].StatusRollBack="OK"
          WriteDataModulesToFile(dataModuleActionStatus, persistence_status_filename)
        }
      }
  }
  echo "!!!!!!!!ROLLBACK DEPLOY PHASE END!!!!!!!!"
}


def rollBack(err){
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "!!!!!!!!STARTING THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!STARTING THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "Stage error at: ${stageError}"
    echo "Error Details: ${err}"

    switch(stageError) {
        case ["UploadToProxyServer","PreviousChecks"]:
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION"
            CleanEnvironment()
            break
        case "StopMicros":
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION. SOMETHING WRONG IN THE ENV. PLEASE LET IT KNOW TO ENV TEAM"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION. SOMETHING WRONG IN THE ENV. PLEASE LET IT KNOW TO ENV TEAM"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION. SOMETHING WRONG IN THE ENV. PLEASE LET IT KNOW TO ENV TEAM"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION. SOMETHING WRONG IN THE ENV. PLEASE LET IT KNOW TO ENV TEAM"
            //StartMicros()
            CleanEnvironment()
            break
        case "Deploy":
            rollBackDeploy()
            //StartMicros()
            CleanEnvironment()
            break
        case "StartMicros":
            //StopMicros()
            rollBackDeploy()
            //StartMicros()
            CleanEnvironment()
            break
    }

    currentBuild.result = Result.FAILURE
    error('!!!!!!!!AUTOMATED ROLLBACK ENDED SUCCESSFULLY!!!!!!!!')
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "!!!!!!!!END THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!END THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
}


def call(Map pipelineParams){
        pipeline{
            agent {label "SCHAMAN-Consolas"}
            parameters{
                string(name: 'DeployEnv', defaultValue: '', description: '')
                string(name: 'CommitID', defaultValue: '', description: '')
                string(name: 'Package_ID', defaultValue: '', description: '')
                string(name: 'Delivery', defaultValue: '', description: '')
                string(name: 'ProjectId', defaultValue: '', description: '')
                string(name: 'enterprise', defaultValue: 'BAU', description: '')
                string(name: 'PackageInfo', defaultValue: '', description: '')
            }
            stages{
                stage("Prepare"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            AR_StartStop=[]
                            echo "============================================="
                            echo "============================================="
                            echo "===================PREPARE==================="
                            echo "============================================="
                            echo "============================================="
                            dataModuleActionStatus = new ArrayList<DataModule>();
                            if (params.PackageInfo=="")
                            {
                                // executed manually or from ALMS
                                echo "    Manual or Jenkins GUI execution!!!"
                                deploy_env=params.DeployEnv
                                pck_id=params.Package_ID
                                delivery=params.Delivery
                                project_id=params.ProjectId
                                enterprise=params.enterprise
                            }else{
                                echo "    Workbench execution!!!"
                                echo "PackageInfo: ${params.PackageInfo}"
                                (deploy_env,pck_id,delivery,project_id,enterprise,annexes,modules)= parsePckInfo_WithAnnexes_WithoutGit(PackageInfo)
                            }
                            hoy=new Date().format('yyyyMMdd')
                            pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                            deployConfig=readJSON(file: pipelineConfig.deployConfig)
                            commit_id=""
                            workbenchPackage= new VFESALMSDeployment(pck_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,enterprise)
                            currentBuild.displayName = workbenchPackage.jobDisplayName
                            currentBuild.description = workbenchPackage.jobDescription
                            URLMicroServiceStart=pipelineConfig.URLMicroServiceStart
                            URLMicroServiceStop=pipelineConfig.URLMicroServiceStop
                            MicroServicePort=pipelineConfig.MicroServicePort


                            // TODO : when

                            echo "Deploy Info:"
                            echo "    DeployEnv:        ${deploy_env}"
                            echo "    PackageID:        ${pck_id}"
                            echo "    Delivery:         ${delivery}"
                            echo "    Project:          ${project_id}"
                            echo "    Enterprise:       ${enterprise}"
                            echo "    Modules:          ${modules}"
                        }
                    }
                }
                stage("PreviousChecks"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "================PREVIOUS CHECKS=============="
                            echo "============================================="
                            echo "============================================="
                            echo "====> Check Modules Host Info"
                            echo "======> Check Modules Host IP"
                            modulesHostIP = modules.HostDestiny.Host.IP
                            if (modulesHostIP == null || modulesHostIP == "")
                            {
                                echo "        ERROR. Modules Host IP cannot be null or \"\""
                                sh "exit 1"
                            }
                            echo "        Modules Host IP: ${modulesHostIP}"
                            echo "======> Check Modules Configured Path"
                            modulesConfiguredPath = modules.HostDestiny.ConfiguredPath
                            if (modulesConfiguredPath == null || modulesConfiguredPath == "")
                            {
                                echo "        ERROR. Modules Host Configure Path cannot be null or \"\""
                                sh "exit 1"
                            }

                            modulesAppendPath="${hoy}" + '/' + "${pck_id}" + '/' + "${deploy_env}" + '/' + 'DataModules/'
                            persistenceFileAppendPath="${hoy}" + '/' + "${pck_id}" + '/' + "${deploy_env}" + '/'
                            persistenceFileCompletePath="${modulesConfiguredPath}" + '/' + "${persistenceFileAppendPath}"
                            modulesCompletePath="${modulesConfiguredPath}" + '/' + "${modulesAppendPath}"
                            if (pipelineConfig.packagesPath == null || pipelineConfig.packagesPath == "")
                            {
                                echo "        ERROR. pipelineConfig.packagesPath cannot be null or \"\""
                                sh "exit 1"
                            }
                            modulesUploadPath="${pipelineConfig.packagesPath}" + '/' + "${modulesAppendPath}"
                            echo "        Modules Base Path: ${modulesConfiguredPath}"
                            echo "        Modules Append Path: ${modulesAppendPath}"
                            echo "        Modules Complete Path (local): ${modulesCompletePath}"
                            echo "        persistenceFiles Path (local): ${persistenceFileCompletePath}"
                            echo "        Modules Upload Path (Proxy Server): ${modulesUploadPath}"

                            echo "======> Check Modules User Name"
                            modulesUserName = modules.HostDestiny.Host.UserName
                            if (modulesUserName == null || modulesUserName == "")
                            {
                                echo "        ERROR. Modules Host UserName cannot be null or \"\""
                                sh "exit 1"
                            }
                            echo "        Modules Host UserName: ${modulesUserName}"


                            echo "====> Check Data Modules Data"
                            echo "======> Check Modules Number"
                            if (modules.Modules.size() <= 0){
                                echo "        Num modules: ${modules.Modules.size()}"
                                echo "        Num modules must to be > 0"
                                sh "exit 1"
                            }
                            echo "        Num modules: ${modules.Modules.size()}"
                            echo "          Num GO modules: ${modules.Modules.findAll{it.IsRollback == 0}.size()}"
                            echo "          Num ROLLBACK modules: ${modules.Modules.findAll{it.IsRollback == 1}.size()}"

                            echo "======> Check Modules Files Existence"
                            for( module in modules.Modules ){

                                ModuleNameWithPath="${modulesCompletePath}" + "${module.FileName}"
                                exist = sh(script:"ssh ${modulesUserName}@${modulesHostIP} \"ls -1 ${ModuleNameWithPath}\"",  returnStatus: true)
                                if (exist!=0){
                                    echo "        ERROR. ${ModuleNameWithPath} not found at server " + "${modulesHostIP}"
                                    sh "exit 1"
                                }
                                echo "        ${ModuleNameWithPath}: OK!"
                            }



                            //Load Context and Binary name
                            echo "==> Load In-Memory HashMap List for start/stop <=="
                            if (modules.Modules.findAll{it.IsRollback == 0}.size() != 0)
                            {
                                goModules=modules.Modules.findAll{it.IsRollback == 0}
                                _contextPathToRestart=[]
                                _proxyServers=[]
                                echo "====> Checking Name Format, and context and Database info in the configuration file"
                                for( goModule in goModules )
                                {
                                    goModuleName = goModule.FileName
                                    (_context,_free,_extension)=returnSplitName(goModuleName)

                                    if (_extension == null || _context == null || _free == null)
                                    {
                                      echo "        ERROR. Module ${goModuleName} with incorrect naming"
                                      echo "               The naming must to be {contextPath}_{FreeText}.sql"
                                      sh "exit 1"
                                    }

                                    if (_extension == "" || _context == "" || _free == "")
                                    {
                                      echo "        ERROR. Module ${goModuleName} with incorrect naming"
                                      echo "               The naming must to be {contextPath}_{FreeText}.sql"
                                      sh "exit 1"
                                    }

                                    if (_extension != "sql")
                                    {
                                      echo "        ERROR. Module ${goModuleName} with incorrect naming"
                                      echo "               The naming must to be {contextPath}_{FreeText}.sql"
                                      sh "exit 1"
                                    }

                                    _context=_context+"_"
                                    _existe=deployConfig[deploy_env]["Environment"][_context]
                                    if (_existe == null)
                                    {
                                        echo "        ERROR. Context ${_context} not found at deploy config file for the env ${deploy_env} at Environment Section"
                                        sh "exit 1"
                                    }

                                    _existeDBInfo=deployConfig[deploy_env]["DataBases"][_context]
                                    if (_existeDBInfo == null)
                                    {
                                        echo "        ERROR. Context ${_context} not found at deploy config file for the env ${deploy_env} at DataBases Section"
                                        sh "exit 1"
                                    }

                                    _proxyServers+=deployConfig[deploy_env]["DataBases"][_context].ip
                                    _contextPathToRestart+=_context
                                    echo "          Naming of file ${goModuleName} => OK"
                                    echo "          Context ${_context} Found at configuration file at Environment Section=> OK"
                                    echo "          Context ${_context} Found at configuration file at DataBases Section=> OK"
                                }

                                proxyServers=new LinkedHashSet<String>(_proxyServers)
                                contextPathToRestart=new LinkedHashSet<String>(_contextPathToRestart)

                                echo "==> Load In-Memory HashMap List for Start/Stop Actions <=="
                                for (_context in contextPathToRestart)
                                {
                                  _existeFirst=deployConfig[deploy_env]["Environment"][_context].first()
                                  _BinaryName=findBinaryFromContext(_context,_existeFirst.ip,_existeFirst.name)

                                  if (_BinaryName == null){
                                    echo "          Context ${_context} without Binary"
                                    _AR_StartStop=[context: "${_context}", binaryName: ""]
                                  }
                                  else{
                                    echo "          Context ${_context} corresponds to the Binary ${_BinaryName}"
                                    _AR_StartStop=[context: "${_context}", binaryName: "${_BinaryName}"]
                                  }
                                  AR_StartStop+=_AR_StartStop
                                }
                                echo "AR_StartStop=${AR_StartStop}"

                                echo "==> Load In-Memory HashMap List for status control <=="
                                echo "====> Loading the GO modules and DBNAME"
                                for( goModule in goModules )
                                {
                                  goModuleName = goModule.FileName
                                  (_context,_free,_extension)=returnSplitName(goModuleName)
                                  _context=_context+"_"

                                  _dataModuleActionStatus = new DataModule("${goModule.Order}", "${pck_id}","${goModule.FileName}", "", "${_context}", "", "")
                                  dataModuleActionStatus.add(_dataModuleActionStatus)
                                }
                            }

                            echo "====> Loading the RollBack modules for each GO Module"
                            //Now Map the RollBack Modules with Go Modules if any
                            if (modules.Modules.findAll{it.IsRollback == 1}.size() != 0)
                            {
                                rollBackModules=modules.Modules.findAll{it.IsRollback == 1}
                                for( rollBackModule in rollBackModules )
                                {
                                    rollBackModuleDependence=rollBackModule.ModuleDependenceWorkBenchId
                                    index=modules.Modules.findIndexOf{it.WorkBenchId == rollBackModule.ModuleDependenceWorkBenchId}
                                    if (index != -1)
                                    {
                                        goModuleName = modules.Modules[index].FileName
                                        index2=dataModuleActionStatus.findIndexOf{it.ModuleFileName == goModuleName}
                                        if (index2 != -1)
                                        {
                                            dataModuleActionStatus[index2].RollBackModuleFileName = "${rollBackModule.FileName}"
                                        } else {
                                            echo "    ERROR. Parent Module not found in In-Memory Hash Map List"
                                            sh "exit 1"
                                        }
                                    } else {
                                        echo "    ERROR. ${rollBackModule.FileName} without parent"
                                        sh "exit 1"
                                    }
                                }
                            }
                            echo "====> Sorting modules for Order field"
                            Collections.sort(dataModuleActionStatus, new SortbyOrder())
                            echo "    In-Memory Hash Map List Sorted by Order Field (With RollBack Modules): "
                            printDataModules(dataModuleActionStatus)
                        }
                    }
                }

                stage("UploadModules"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try
                            {
                                echo "=========================================="
                                echo "========UPLOAD MODULES PHASE START========"
                                echo "========UPLOAD MODULES PHASE START========"
                                echo "=========================================="
                                UploadToProxyServer ()
                                echo "=========================================="
                                echo "=========UPLOAD MODULES PHASE END========="
                                echo "=========UPLOAD MODULES PHASE END========="
                                echo "=========================================="
                            }
                            catch (err)
                            {
                                stageError="UploadToProxyServer"
                                rollBack(err)
                            }
                        }
                    }
                }

            //stage("StopMicros"){
            //    agent { label "SCHAMAN-Consolas"}
            //    steps{
            //        script{
            //            try{
            //                echo "========================================"
            //                echo "=====STOP MICROSERVICES PHASE START====="
            //               echo "=====STOP MICROSERVICES PHASE START====="
            //                echo "========================================"
                            //StopMicros()
            //                echo "========================================"
            //                echo "=====STOP MICROSERVICES PHASE END======="
            //                echo "=====STOP MICROSERVICES PHASE END======="
            //                echo "========================================"
            //              }
            //              catch (err)
            //              {
            //                stageError="StopMicros"
            //                rollBack(err)
            //              }
            //        }
            //    }
            //}

            stage("Deploy"){
                agent { label "SCHAMAN-Consolas"}
                steps{
                    script{
                        try{
                            echo "========================================"
                            echo "===========DEPLOY PHASE START==========="
                            echo "===========DEPLOY PHASE START==========="
                            echo "========================================"
                            Deploy()
                            echo "========================================"
                            echo "============DEPLOY PHASE END============"
                            echo "============DEPLOY PHASE END============"
                            echo "========================================"
                          }
                          catch (err)
                          {
                            stageError="Deploy"
                            rollBack(err)
                          }
                    }
                }
            }

            //stage("StartMicros"){
            //    agent { label "SCHAMAN-Consolas"}
            //    steps{
            //        script{
            //            try{
            //                echo "========================================="
            //                echo "=====START MICROSERVICES PHASE START====="
            //                echo "=====START MICROSERVICES PHASE START====="
            //                echo "========================================="
            //                StartMicros()
            //                echo "========================================="
            //                echo "======START MICROSERVICES PHASE END======"
            //                echo "======START MICROSERVICES PHASE END======"
            //                echo "========================================="
            //              }
            //              catch (err)
            //              {
            //                stageError="StartMicros"
            //                rollBack(err)
            //              }
            //          }
            //      }
            //}

            stage('CleanEnvironment') {
                agent {label "SCHAMAN-Consolas"}
                steps {
                    script{
                        echo "==========================================="
                        echo "=======CLEAN ENVIRONMENT PHASE START======="
                        echo "=======CLEAN ENVIRONMENT PHASE START======="
                        echo "==========================================="
                        CleanEnvironment()
                        echo "==========================================="
                        echo "========CLEAN ENVIRONMENT PHASE END========"
                        echo "========CLEAN ENVIRONMENT PHASE END========"
                        echo "==========================================="
                    }
                }
            }


        }
    }
}
