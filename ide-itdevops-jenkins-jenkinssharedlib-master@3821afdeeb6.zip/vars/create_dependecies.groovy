def call ( String _User , String _paquete, String _dependecias ){
    
    (_pass,_User)=findpassword(_User)
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
             wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
        //    bat "python create_dependecies.py -p ${_paquete}  -d ${_dependecias}"
            bat "python create_dependencies.py -u ${_User} -c ${_pass} -p ${_paquete}  -d ${_dependecias}"
             } //wrap
        }
    }
}
