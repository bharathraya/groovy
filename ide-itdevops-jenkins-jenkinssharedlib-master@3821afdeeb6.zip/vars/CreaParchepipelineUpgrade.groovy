import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def mybuilduser=""
def _pass=""
def _CRQ_ID=""
def _Orden=""
def _listapaquetes=""
def _opcion=""
def  _NomVista=""
def  _TipoRege=""
def  _delivery=""
def  _devToDeploy=""
def  _Ventana
def _upgrade=""
def iConectividades=0
def hoy=""
def pipelineConfig
def AppConfig
def envsConfig
def enviroments
def Tipos_Bit
def idescarga=0
def _View
def RutaTemp=""
def RutaPaquete=""
def exec=""
def PaquetesSinPromote=""
def DeliveryMal=""
def MODSIMU=0
def iFalloEsquema=0
def Tipos=""
def TipoDespliegues
def tamanoDesp=0
def pos=0
def _domain=""
def _listado=""
def _serverSPPPR=""
def _serverSIMU=""
def ibit=0
def isBit
def _Tipo=""
def _ScriptsSIMU
def _ScriptsPROD
def _nombreCarpeta=""
def AplicacionesFalloTesteoPROD=""
def AplicacionesFalloTesteoSIMU=""
def InfoErroresTesteoSIMU=""
def InfoErroresTesteoPROD=""
def EntSimulacro=""
def iCab=0
def iAif=0
def iServer=0
def iTOA=0
def iPermas=0
def iOferta=0
def iBuild=0

//EntSimulacro="SIT2"

def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'CRQ_ID', defaultValue: '', description: 'CRQ ID') 
            string(name: 'Deliverys', defaultValue: '', description: 'Deliverys to check') 
            string(name: 'List_Packages', defaultValue: '', description: 'List of packages')
            string(name: 'Vista', defaultValue: '', description: 'View with packages') 
            string(name: 'Orden', defaultValue: '', description: 'Order file for DDBB packages')
            choice(name: 'EntornoSimulacro',  choices: pipelineParams.EnvChoices , description: 'Choose the Simulation environment') 
          //  choice(name: 'IncludePROD',  choices: pipelineParams.IncludePROD , description: 'Se testea y prepara PROD?') 
            choice(name: 'Opcion',  choices: pipelineParams.OptionChoices , description: 'Choose the options:1. Testing 2. DDBB patch integrity 3. Executions 4. Labeling') 
            choice(name: 'TypeToReg',  choices: pipelineParams.TypesChoices , description: 'Types for regenerate') 
            string(name: 'DeliveryFromNexus', defaultValue: '', description: 'Delivery for download dependencies') 
         }
         
         stages{     
         stage("Prepare"){
                agent {
                    label 'AMDOCS-PARCHE'
                        }
                steps{
                script {
                     //Saco el ejecutor
                     wrap([$class: 'BuildUser']) {
                         echo "Exec user: ${env.BUILD_USER_ID}"
                         mybuilduser=env.BUILD_USER_ID
                       }
                       // print "saco contraseña"
                        //Contraseña
                         (_pass,mybuilduser)=findpassword(mybuilduser)
                        // print "ya la he sacado contraseña"
                        //Leo los parametros
                        _CRQ_ID=params.CRQ_ID.trim()  
                        _Orden=params.Orden.trim()
                        _listapaquetes=params.List_Packages.trim()
                        _opcion=params.Opcion
                        _NomVista=params.Vista.trim()
                        _TipoRege=params.TypeToReg
                        _delivery=params.Deliverys
                        _devToDeploy=params.DeliveryFromNexus.trim()
                        EntSimulacro=params.EntornoSimulacro

                  
                        _Ventana = false
                        _upgrade="S"
                        iConectividades=0
                        iCab=0
                        iAif=0
                        iServer=0
                        iTOA=0
                        iPermas=0
                        iOferta=0
                        iBuild=0
                        hoy=new Date().format( 'yyyyMMdd' )
                        
                        print "Today's date is ......${hoy}......"
                
                        //leemos el fichero de configuracion
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        AppConfig=readYaml(file: pipelineParams.pipelineAppFile)
                        //leemos el fichero de entornos
                        envsConfig=pipelineConfig.envConfig
                        enviroments=readJSON(file: "${envsConfig}")
                        Tipos_Bit=pipelineConfig.Tipos_BB
                        
                        idescarga=0
                                        
                  
                       //Miramos si los parametros están bien
                        if (_CRQ_ID == "" && _NomVista == "" ){
                           error("CRQ Name or View Name are required.")
                        }
                        if (_CRQ_ID == "" && _NomVista != "" ){
                            idescarga=1
                          // No hay CRQ pero si vista no hay que descargar de bit
                        }
                        if (_opcion == "" || (_opcion != "1" && _opcion != "2" && _opcion != "3" && _opcion != "4" ) ){
                            error("You must indicate an option between 1 and 4.")
                        }
                        if(_CRQ_ID != "" && _listapaquetes == "" && _NomVista == "" ) { 
                	        error("A package list is required for this CRQ ${_CRQ_ID}.")
                        }
                        if(_CRQ_ID != "" && (_listapaquetes != "" && _NomVista != "" ) ) { 
                	        error("The packages come in the list or in the view.")
                        }
                        if( "${_Orden}" == "" && _opcion == "2" && _TipoRege !="AMDOCS-ESQUEMA") { 
                	       error("The Order file is mandatory.")
                        } 
                        if (( _TipoRege == "AMDOCS-ESQUEMA" || _TipoRege == "AMDOCS-CAB"  || _TipoRege == "AMDOCS-AIF") && (_devToDeploy=="")) { 
                	       error("Delivery is mandatory for nexus artifacts.")
                        } 
                        if (_TipoRege == "AMDOCS-ESQUEMA" && _opcion == "1")
                  		{
                          //Solo estamos testeando
                          idescarga=1
                        }
                        
                         //Configuramos el nombre del build y su descripcion
                        if (_CRQ_ID != "")
                        {
                            currentBuild.displayName = "CRQ: ${_CRQ_ID} Date: ${hoy} Option ${_opcion} Simulation Environment: ${EntSimulacro}"
                            if (_listapaquetes != "" && _Orden != "" )
                            {
                                currentBuild.description = "CRQ: ${_CRQ_ID} List of Packages: ${_listapaquetes} Order File ${_Orden} Regenerate: ${_TipoRege}"
                            }
                            else if (_listapaquetes != "" && _Orden == "" )
                            {
                                currentBuild.description = "CRQ: ${_CRQ_ID} List of Packages: ${_listapaquetes} Regenerate: ${_TipoRege}"
                            }
                            else if (_listapaquetes == "" && _NomVista != "" )
                            {
                                currentBuild.description = "View: ${_NomVista} Regenerate: ${_TipoRege}"
                            }
                        }
                        else
                        {
                            currentBuild.displayName = "View: ${_NomVista} Date: ${hoy} Option ${_opcion} Simulation Environment: ${EntSimulacro}"
                            if (_Orden == "")
                            {
                                currentBuild.description = "View: ${_NomVista} Regenerate: ${_TipoRege}"
                            }
                            else
                            {
                                 currentBuild.description = "View: ${_NomVista} Order File ${_Orden} Regenerate: ${_TipoRege} "
                            }
                        }
                        
                        if (_CRQ_ID == "" &&  _NomVista != "")
                        {  //No hay CRQ
                            _CRQ_ID="${_NomVista}"
                            _View = true
                        }
                        else if (_CRQ_ID != "" &&  _NomVista != "")
                        {  //Hay crq y lista de paquetes en la vista
                            _View = true
                        }
                        else if ( _NomVista == "")
                        {  //NO hay vista
                            _View = false
                        }
                            
                        //Escribo las opciones
                        if ( _opcion=="2" ) 
                        {
                            print "******************************"
                            print "Chosen option 2 of INTEGRITY"
                            print "Patch name ${_CRQ_ID} "
                            print "******************************"
                        }  
                         if ( _opcion=="1" ) 
                        {
                            print "******************************"
                            print "Chosen option 1 of TEST"
                            print "Patch name ${_CRQ_ID} "
                            print "******************************"
                        }  
                        if ( _opcion=="3" ) 
                        {
                            print "******************************"
                            print "Chosen option 3 of PACKAGES CREATION"
                            print "Patch name ${_CRQ_ID} "
                            print "******************************"
                        } 
                         if ( _opcion=="4" ) 
                        { 
                            print "******************************"
                            print "Chosen option 4 of LABELING"
                            print "Patch name  ${_CRQ_ID} "
                            print "******************************"
                        } 
                         RutaTemp="/home/plataforma/plausr/tmp"
                         RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
                      //  RutaContenido="/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"
                        sh "if [ -d ${RutaPaquete} ] ; then rm -rf ${RutaPaquete} ; fi ; mkdir -p ${RutaPaquete} "
                        if (_View == false || _Orden != "" || _TipoRege=="AMDOCS-ESQUEMA")
                        { //No hay vista
                           //Funcion para descargar los datos
                           print "CRQ -> ${_CRQ_ID}"
                           print "List of packages -> ${_listapaquetes}"
                           print "Order -> ${_Orden}"
                           print "Type of app for regenerate -> ${_TipoRege}"
                          
                          print "I am on: ${_TipoRege} and ${_View} and ${_Orden} "
                           
                              if (_TipoRege=="AMDOCS-ESQUEMA" && _opcion !="1")
                              {    
                                    DescargaFicheros "${_CRQ_ID}" , "${_listapaquetes}", "${_Orden}" , true
                              }
                              else
                              {
                                    //if ( idescarga == 0)
                                   if ( _Orden != "" || _listapaquetes != "") 
                                {
                                        DescargaFicheros "${_CRQ_ID}" , "${_listapaquetes}", "${_Orden}" , false
                                    }
                              }
                        }
                        //Reviso si los paquetes estan promocionados
                        if (_View == false)
                        {
                            _listapaquetes=readFile(file: "${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt")
                        }
                        else
                        {
                            _listapaquetes=""
                        }
                        
                        print "Executing separate function"
                        //print "Vista ${_View}"
                        SeparaPaquete2 "${_CRQ_ID}" , _View , _Ventana, "${_NomVista}" , mybuilduser , _pass , _upgrade
                       
                       //Copio los fichero a opetst75
                        exec="""
                            . \$HOME/.profile >/dev/null 2>&1
                            . paquete  ${_CRQ_ID}
                        """
                        // sh "ssh -q opetst75 '${exec}'"
                        // sh "scp ${RutaPaquete}/* opetst75:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                       
                        //Reviso los que no estan promoted en entornos no productivos
                        EditPackage(_CRQ_ID)
                        PaquetesSinPromote=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PaquetesSin.txt")

                       // print "Tipo elegido ${_TipoRege}"

                        if ("${_TipoRege}" != "ALL")
                        {   
                            print "I enter here because it is not ALL" 
                            RevisarTipos (_TipoRege, RutaPaquete , _CRQ_ID, "YES")
                        }
                        //Revisamos si es necesario el delivery
                           TiposApp = readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")
                          // print "which are types ${TiposApp}"
                           if ((TiposApp.contains("AMDOCS-CAB") || TiposApp.contains("AMDOCS-AIF")) && (_devToDeploy=="") && _opcion == "3") 
                           { 
                	            error("Delivery is mandatory for nexus artifacts.")
                           }     
                        //25-03-21
                        if (_delivery !="")
                        {
                            print "Deliverys to review ${_delivery}" 
                            RevisarDelivery (_delivery,_CRQ_ID)
                            DeliveryMal=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/Deliverys.txt") 
                        }
                        else
                        {
                            DeliveryMal=""
                        }
                   }//script
                 }//step
            }//prepare
            
            stage("Opciones"){ //Testeo los paquetes
                agent {
                    node("AMDOCS-PARCHE")
                        }
                steps{
                    script {//Elige las opciones:1. Testeo 2. Integridad parche BBDD 3. Commit de los parches en SVN 4. Ejecuciones
                        //Si solo se elige opcion 1 solo testear
                        //Si se elige opcion 2 testear y extraer solo BBDD
                        //Si se elige opcion 3 testear y extraer
                        //Si se elige opcion 4 se testea y versiona-> Opcion de poner paquetes en estado correcto???
                         if ( _opcion == "1" ||  _opcion == "3"  ||  _opcion == "4" )
                         {
                            print "We test the packages"
                            MODSIMU=0
                            iFalloEsquema=0
                            Tipos=readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")
                            //print " File ${Tipos} "
                            TipoDespliegues=Tipos.split()
                            print " Applications to treat ${TipoDespliegues}"
                            tamanoDesp= TipoDespliegues.size()
                            //print " Size ${tamanoDesp}"
                            sh "touch -f ${RutaPaquete}/AplicacionesFalloTesteoPROD.txt"
                            sh "touch -f ${RutaPaquete}/AplicacionesFalloTesteoSIMU.txt"
                            sh "touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Bit_diferencias.txt"
                            sh "touch -f ${RutaPaquete}/Instrucciones.txt"
                            
                            
                            for (pos = 0; pos < TipoDespliegues.size(); pos++) {
                                
                               _domain = TipoDespliegues[pos]
                               _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
                               _serverSPPPR=""
                               _serverSIMU=""
                               
                               if (_domain == "AMDOCS-CAB")
                               {
                                    iCab=1    
                               }
                               if (_domain == "AMDOCS-AIF")
                               {
                                    iAif=1    
                               }
                               if (_domain == "AMDOCS-SERVER")
                               {
                                    iServer=1    
                               }
                               if (_domain == "AMDOCS-IntegracionTOA")
                               {
                                    iTOA=1    
                               }
                               if (_domain == "AMDOCS-IntegracionPermanencias")
                               {
                                    iPermas=1    
                               }
                               if (_domain == "AMDOCS-IntegracionOferta")
                               {
                                    iOferta=1    
                               }
                               if (_domain == "AMDOCS-SCRIPTS-BUILD")
                               {
                                    iBuild=1    
                               }
                            
                              
                              //print "is bit type: ${Tipos_Bit.contains(_domain)}"
                              if (Tipos_Bit.contains(_domain))
                              {
                                   ibit=1
                                   isBit=true
                                   print "This is bitbucket app" 
                              }
                              else
                              {
                                   ibit=0
                                   isBit=false
                                   print "This is pvcs app" 
                              }

                               //print "list ${_listado}"

                                if (_domain != "APM")
                                {
                                    _Tipo=(_domain.split("-")[-1]) 
                                }
                                else
                                {
                                    _Tipo="APM"
                                }
                                 
                                _nombreCarpeta="${_CRQ_ID}_${_Tipo}"

                                 //Solo testeamos
                                 if ( _opcion == "1")
                                 {
                                     CreaParcheUpgradeOpcion1( _domain, _TipoRege, _nombreCarpeta, _listado, _CRQ_ID, isBit, mybuilduser, _pass,EntSimulacro)
                                 }
                                 //Testeamos y extraemos el codigo ¿Poner opcion par hacerlo solo para TGA3 y para PROD?
                                 if ( _opcion == "3")
                                 {    
                                    
                                    if (!isBit)
                                    {
                                         //Maquina a replicar
                                         _serverSPPPR=enviroments["${_domain}"]["PROD"]["serverSPPR"][0][0]
                                      //  print "Server de SPPR  ${_serverSPPPR}"
                                        _serverSIMU=enviroments["${_domain}"]["${EntSimulacro}"]["server"][0][0]
                                      //  print "Server de ${EntSimulacro} ${_serverSIMU}"
                                        _ScriptsPROD=AppConfig["${_domain}-PROD"]
                                        _ScriptsSIMU=AppConfig["${_domain}-${EntSimulacro}"]
                                      // print "Scripts a ejecutar ${_ScriptsSIMU} ${_ScriptsPROD}"
                                    }
                                    else
                                    {
                                        //print "*****Es de bit no sacamos datos de server ****"
                                         _ScriptsPROD=AppConfig["${_domain}-PROD"]
                                        _ScriptsSIMU=AppConfig["${_domain}-${EntSimulacro}"]
                                        //print "Scripts a ejecutar ${_ScriptsSIMU} ${_ScriptsPROD}"
                                    }

                                    print "****************************************"
                                    print "TREATING APPLICATION: ${_domain}"
                                    print "****************************************"
                                    
                                   //print "lanzo CreaParcheUpgradeOpcion3( ${_domain}, ${_TipoRege}, ${_nombreCarpeta}, ${_listado}, ${_CRQ_ID}, ${_serverSPPPR},${_serverSIMU}, ${_Orden}, ${isBit}, ${mybuilduser}, ${_pass}, ${_ScriptsSIMU}, ${_ScriptsPROD}, ${_devToDeploy}, ${EntSimulacro})"
                                   CreaParcheUpgradeOpcion3( _domain, _TipoRege, _nombreCarpeta, _listado, _CRQ_ID, _serverSPPPR,_serverSIMU, _Orden, isBit, mybuilduser, _pass, _ScriptsSIMU, _ScriptsPROD, _devToDeploy, EntSimulacro)
                                   

                                 }//OPCION 3
                                 
                                 //Testeamos de nuevo y versionamos en PROD
                                  if ( _opcion == "4")
                                   {
                                        CreaParcheUpgradeOpcion4(_domain,_nombreCarpeta,_listado,isBit)
                                   }//OPCION 4
                                 
                            }//for
                            
                             if ( _opcion == "1")
                              { //Revisar si han fallado
                                  AplicacionesFalloTesteoPROD= readFile(file: "${RutaPaquete}/AplicacionesFalloTesteoPROD.txt")
                                  AplicacionesFalloTesteoSIMU= readFile(file: "${RutaPaquete}/AplicacionesFalloTesteoSIMU.txt")                                
                                  BitDiferencias=readFile(file: "/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Bit_diferencias.txt")                    
                                  
                                  if (AplicacionesFalloTesteoSIMU != "")
                                  {
                                      sh "scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_${EntSimulacro}.txt  ${RutaPaquete}/InfoErroresTesteo_${EntSimulacro}.txt"
                                      InfoErroresTesteoSIMU= readFile(file: "${RutaPaquete}/InfoErroresTesteo_${EntSimulacro}.txt")
                                  }
                                  if (AplicacionesFalloTesteoPROD != "")
                                  {
                                      sh "scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt  ${RutaPaquete}/InfoErroresTesteo_PROD.txt"
                                      InfoErroresTesteoPROD= readFile(file: "${RutaPaquete}/InfoErroresTesteo_PROD.txt")
                                  }
                                  if (AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIMU != "")
                                  {
                                    print "****************************************"
                                    print "         INCORRECT TESTING"
                                    print "****************************************"
                                    print "These applications have been analyzed:"
                                    print "${Tipos}"
                                    print "These applications fail in PROD:"
                                    print "${AplicacionesFalloTesteoPROD}"
                                    //07-10-20 meguiza2
                                    print "INFO of SUPPLIERS with PROD TESTING ERRORS"
                                    print "${InfoErroresTesteoPROD}"
                                    //07-10-20 meguiza2
                                    print "Fails in ${EntSimulacro} environment these apps:"
                                    print "${AplicacionesFalloTesteoSIMU}"
                                    //07-10-20 meguiza2
                                    print "INFO of SUPPLIERS with TESTING ERRORS in ${EntSimulacro} environment"
                                    print "${InfoErroresTesteoSIMU}"
                                    //07-10-20 meguiza2
                                    //error ("Fallos de testeo en PROD y ${EntSimulacro}")
                                  }
                                  if (AplicacionesFalloTesteoSIMU != "" && AplicacionesFalloTesteoPROD == "")
                                  {
                                    print "****************************************"
                                    print "INCORRECT TESTING ${EntSimulacro} but correct in PROD"
                                    print "****************************************"
                                    
                                    print "These applications have been analyzed:"
                                    print "${Tipos}"
                                    print "Fails in ${EntSimulacro} environment these apps:"
                                    print "${AplicacionesFalloTesteoSIMU}"
                                    print "INFO of SUPPLIERS with TESTING ERRORS in ${EntSimulacro} environment"
                                    print "${InfoErroresTesteoSIMU}"
                                    

                                   }
                                   if (AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIMU == "")
                                  {
                                    print "********************************************"
                                    print "INCORRECT TESTING PROD but correct in ${EntSimulacro}"
                                    print "*********************************************"
                                    
                                    print "These applications have been analyzed:"
                                    print "${Tipos}"
                                    print "Fails in PROD these apps:"
                                    print "${AplicacionesFalloTesteoPROD}"
                                    //07-10-20 meguiza2
                                    print "INFO of SUPPLIERS with PROD TESTING ERRORS"
                                    print "${InfoErroresTesteoPROD}"
                                    //07-10-20 meguiza2
                                    //error ("Fallos de testeo en PROD")
                                   }
                                   if  (AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIMU == "")
                                   {
                                    print "********************************************"
                                    print "         CORRECT TESTING"
                                    print "These applications have been analyzed:"
                                    print "${Tipos}"
                                    print "********************************************"
                                    print "*********Modules changed in bitbucket*********"
                                    print "${BitDiferencias}"
                                     
                                     
                                   }

                                   if (PaquetesSinPromote != "" )
                                    {
                                     print "****************************************************************"
                                     print "These packages are not promoted in the preproduction environment"
                                     print "${PaquetesSinPromote}"
                                     print "****************************************************************"
                                    // error ("Paquetes en estados incorrectos")
                                    }
                                    
                                    if (DeliveryMal != "")
                                    {   print "****************************************************************"
                                        print "These packages are not from the correct deliveries"
                                        print "${DeliveryMal}"
                                        print "****************************************************************"
                                    }
                                   // print "la gestion de errores"
                                    GestionErroresCreaParche (_opcion, PaquetesSinPromote,  AplicacionesFalloTesteoPROD, AplicacionesFalloTesteoSIMU,  DeliveryMal, 0, _delivery)

                              }
                              if ( _opcion == "3")
                              {
                                  print "***************************************************************"
                                  print "These are the instructions:"

                                  def sharedlibPckgTypes=0

                                  if (iTOA == 1){
                                        sharedlibPckgTypes++
                                  }
                                  if (iPermas == 1){
                                        sharedlibPckgTypes++
                                  }
                                  if (iOferta == 1){
                                        sharedlibPckgTypes++
                                  }
                                  if (iAif == 1){
                                        sharedlibPckgTypes++
                                  }
                                  if (iCab == 1){
                                        sharedlibPckgTypes++
                                  }
                                  if (iServer == 1){
                                        sharedlibPckgTypes++
                                  }

                                  if (iBuild == 1){
                                        sh "echo '***********************************************************************************' >> ${RutaPaquete}/Instrucciones.txt"
                                        sh "echo '**************IMPORTANT!!!!********************************************************' >> ${RutaPaquete}/Instrucciones.txt"
                                        sh "echo '' >> ${RutaPaquete}/Instrucciones.txt"
                                        sh "echo 'Execute AMDOCS-SCRIPTS-BUILD the first of all' >> ${RutaPaquete}/Instrucciones.txt"
                                        sh "echo '' >> ${RutaPaquete}/Instrucciones.txt"
                                  }

                                  if(sharedlibPckgTypes > 1){
                                        if (iBuild == 0){
                                            sh "echo '*******************************************************************************' >> ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '**************IMPORTANT!!!!****************************************************' >> ${RutaPaquete}/Instrucciones.txt" 
                                        }
                                        sh "echo '***THE ORDER OF COMPILATION AND DEPLOYMENT HAS TO BE THE SAME FOR THESE PACKAGES***' >> ${RutaPaquete}/Instrucciones.txt"

                                        def cadenaAux=""
                                        def comienzoAux="                   "
                                        def orderNumber=1

                                        if (iTOA == 1){
                                                cadenaAux = comienzoAux /*+ orderNumber.toString() + " --> "*/ + "AMDOCS-IntegracionTOA"
                                                sh "echo '${cadenaAux}' >> ${RutaPaquete}/Instrucciones.txt"
                                                orderNumber++
                                        }
                                        if (iPermas == 1){
                                                cadenaAux = comienzoAux /*+ orderNumber.toString() + " --> "*/ + "AMDOCS-IntegracionPermanencias"
                                                sh "echo '${cadenaAux}' >> ${RutaPaquete}/Instrucciones.txt"
                                                orderNumber++
                                        }
                                        if (iOferta == 1){
                                                cadenaAux = comienzoAux /*+ orderNumber.toString() + " --> "*/ + "AMDOCS-IntegracionOferta"
                                                sh "echo '${cadenaAux}' >> ${RutaPaquete}/Instrucciones.txt"
                                                orderNumber++
                                        }
                                        if (iAif == 1){
                                                cadenaAux = comienzoAux /*+ orderNumber.toString() + " --> "*/ + "AMDOCS-AIF"
                                                sh "echo '${cadenaAux}' >> ${RutaPaquete}/Instrucciones.txt"
                                                orderNumber++
                                        }
                                        if (iCab == 1){
                                                cadenaAux = comienzoAux /*+ orderNumber.toString() + " --> "*/ + "AMDOCS-CAB"
                                                sh "echo '${cadenaAux}' >> ${RutaPaquete}/Instrucciones.txt"
                                                orderNumber++
                                        }
                                        if (iServer == 1){
                                                cadenaAux = comienzoAux /*+ orderNumber.toString() + " --> "*/ + "AMDOCS-SERVER"
                                                sh "echo '${cadenaAux}' >> ${RutaPaquete}/Instrucciones.txt"
                                                orderNumber++
                                        }
                                  }
                                  
                                  sh "echo '****************************************************************************' >> ${RutaPaquete}/Instrucciones.txt"
                                  
                                  print "${RutaPaquete}/Instrucciones.txt"
                                  sh "cat ${RutaPaquete}/Instrucciones.txt"
                                  print "***************************************************************"
                                  
                                   //05-10-20
                                   if (PaquetesSinPromote != "" )
                                    {
                                     print "****************************************************************"
                                     print "These packages are not promoted in the preproduction environment"
                                     print "${PaquetesSinPromote}"
                                     print "****************************************************************"
                                    }//05-10-20
                                
                                 iConectividades=ChequeoConectividades (RutaPaquete , _CRQ_ID, _upgrade)
                                // print "resultado conectividaddes ${iConectividades}"

                                   if (DeliveryMal != "")
                                    {   print "****************************************************************"
                                        print "These packages are not from the correct deliveries"
                                        print "${DeliveryMal}"
                                        print "****************************************************************"
                                    }
                                      // print "la gestion de errores"
                                       GestionErroresCreaParche (_opcion, PaquetesSinPromote,  "", "",  DeliveryMal, iConectividades, _delivery)

                              }
                         }//of de opciones 1, 3 o 4 
                         
                         if ( _opcion == "2") //Integridad de BBDD
                         {
                                 //Lllamamos a la funcion que revisa la integridad
                                 MODSIMU=CreaParcheOption2( "${RutaPaquete}","${_CRQ_ID}","${_TipoRege}", "${_Orden}","${_upgrade}", "${EntSimulacro}")
                                //05-10-20
                                 if (PaquetesSinPromote != "" )
                                 {
                                    print "****************************************************************"
                                    print "These packages are not promoted in the preproduction environment"
                                    print "${PaquetesSinPromote}"
                                    print "****************************************************************"
                                  }//05-10-20
                                  
                                  //25-03-21 meguiza2
                                   if (DeliveryMal != "")
                                    {   print "****************************************************************"
                                        print "These packages are not from the correct deliveries"
                                        print "${DeliveryMal}"
                                        print "****************************************************************"
                                    }
                                    //  print "la gestion de errores"
                                    GestionErroresCreaParche (_opcion, PaquetesSinPromote,  "", "",  DeliveryMal, 0, _delivery)
                                    //25-03-21 meguiza2
                             
                         }//Integridad
                         
                         
                        if ( _opcion=="2" ) 
                        {
                            print "******************************"
                            print "Chosen option 2 of INTEGRITY"
                            print "Patch name ${_CRQ_ID} "
                            print "******************************"
                        }  
                         if ( _opcion=="1" ) 
                        {
                            print "******************************"
                            print "Chosen option 1 of TEST"
                            print "Patch name ${_CRQ_ID} "
                            print "******************************"
                        }  
                        if ( _opcion=="3" ) 
                        {
                            print "******************************"
                            print "Chosen option 3 of PACKAGES CREATION"
                            print "Patch name ${_CRQ_ID} "
                            print "******************************"
                        } 
                    }//scripts
                }//steps
            }//Testeo
            stage("EditPackage"){
                agent {
                    node("AMDOCS-PARCHE")
                        }
                steps{
                    script {//Si hay modulos de pvcs y estamos ejecutando de forma manual etiquetamos y no es PROD
                        
                        if(_opcion=="4"  ) {
                            EditPackageAmdocs(_CRQ_ID, mybuilduser, _View,_NomVista, _pass) 
                             
                        }//SI es opcion 4
                    }//scripts
                }//steps
          }//etiquetar
         }//stages
        }//pipeline
    }//map
