def call (String _Repo, String _Project, String _Origen, String _Destino, String _Commit, String _Fichero, String _User, String _pass){
    node ('es1117yw'){
     checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            try {
              ansiColor('xterm') {
                if(_Commit!=""){
                    if(_Fichero!=""){
                        bat "python test-bitbucket1.py -r ${_Repo} -p ${_Project} -o ${_Origen} -d ${_Destino} -c ${_Commit} -f ${_Fichero} -u ${_User} -x ${_pass}"
                    }else{
                        bat "python test-bitbucket1.py -r ${_Repo} -p ${_Project} -o ${_Origen} -d ${_Destino} -c ${_Commit} -u ${_User} -x ${_pass}"
                    }
                }else{
                    if(_Fichero!=""){
                        bat "python test-bitbucket1.py -r ${_Repo} -p ${_Project} -o ${_Origen} -d ${_Destino} -f ${_Fichero} -u ${_User} -x ${_pass}"
                    }else{
                        bat "python test-bitbucket1.py -r ${_Repo} -p ${_Project} -o ${_Origen} -d ${_Destino} -u ${_User} -x ${_pass}"
                    }
                  
                }
              }
            }
            catch (Exception e){
              echo "ERROR: ${e}"
              error ("Fallo en la comprobacion de rama ${_Origen} a ${_Destino}")
            }
        }
    }
}
