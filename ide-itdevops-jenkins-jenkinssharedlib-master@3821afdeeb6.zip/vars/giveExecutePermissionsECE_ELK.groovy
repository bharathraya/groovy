import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(Map config,VFESALMSDeployment alms){
  if (config.changePermissions == 'Y')
  {
    for (i=0;i<config.artifactId.size();i++){
        sh """
            cd ${config.extractFolder}/${config.filesExecutePermissionFolder}
            chmod ${config.filesExecutePermissions} *
            """
    }
  }
}
