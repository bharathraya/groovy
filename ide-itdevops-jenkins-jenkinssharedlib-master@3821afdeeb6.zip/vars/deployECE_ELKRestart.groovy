import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi
import vfes.utils.VFESALMSDeployment

def call(Map config, VFESALMSDeployment alms, Boolean NO_RESTART)
{
    if (NO_RESTART == true) {
        echo "NO_RESTART Param Detected. Continue without Restart"
    } else {
        def myEnvsConfig = readJSON file: "${WORKSPACE}/${config.releaseConfig}"
        def _envConfig = myEnvsConfig[alms.deployEnv]
        if (config.operateInProd == 'N' && alms.deployEnv == "master") {
            echo "This is a PROD Deployment and the operateInProd Flag is disabled."
            echo "The Start/Stop must to be done by AO after we finish our deployment steps."
            echo "Please, Review the log of the stage CopyToRelease and manually launch all the commands of the output if needed"
        } else {
            component = 'no_restart'
            switch (config.deployType) {
                case ~/^backend$/:
                    component = 'restart_logstash'
                    break
                case ~/^autocreate-backend$/:
                    component = 'restart_logstash'
                    break
                case ~/^logstash-config$/:
                    component = 'restart_logstash'
                    break
                case ~/^filebeat-config$/:
                    component = 'restart_filebeat'
                    break
                case ~/^metricbeat-config$/:
                    component = 'restart_metricbeat'
                    break
                case ~/^heartbeat-config$/:
                    component = 'restart_heartbeat'
                    break
                case ~/^triage$/:
                    component = 'restart_triage'
                    break
            }
            if (component == 'no_restart') {
                echo "No Action Restart defined for the component ${config.deployType}"
            } else {
                if (config.restartScript != "" && config.restartScript != null) {
                    echo "Restarting ...."
                    echo "_envConfig" + _envConfig[component]
                    _envConfig[component].each { item ->
                        echo "Server Data:"
                        echo "  ReStart Server: " + item.server
                        echo "  ReStart User: " + item.user
                        echo "  ReStart Scripts path: " + item.scripts_path
                        echo "  ReStart Script: " + config.restartScript
                        echo "AT: ${item.user}@${item.server} RUN: ${item.scripts_path}/${config.restartScript}"
                        switch (config.deployType) {
                            case ~/^triage$/:
                                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} '. ./.profile; cd ${item.scripts_path}; ./${config.restartScript}'"
                                break
                            default:
                                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.scripts_path}; ./${config.restartScript}'"
                                break
                        }
                    }
                } else {
                    echo "RESTART SCRIPT not defined at config file. Continue without Restart"
                }
            }
        }
    }
}