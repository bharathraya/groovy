def call(String _nombreCarpeta,String _CRQ_ID){
 
  hoy=new Date().format( 'yyyyMMdd' )
  print "Parametros"
  print "NombreCarpeta ${_nombreCarpeta}"
  print "CRQ a tratar ${_CRQ_ID}"

//Borro en es036tvr de ejecuciones anteriores
execBorrar="""
       . \$HOME/.profile >/dev/null 2>&1
    if [ -d /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta} ]
    then
        rm -Rf /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta}
    fi
    mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta}
    """
    
sh "ssh -q es036tvr '${execBorrar}'"
                                                   
//Extraigo codigo
checkout scm

sh " if [ -f CDM/DOCUMENTATION/${_CRQ_ID}/orden_pre.txt ] ; then scp CDM/DOCUMENTATION/${_CRQ_ID}/orden_pre.txt es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta} ;fi"
sh " if [ -f CDM/DOCUMENTATION/${_CRQ_ID}/orden_post.txt ] ; then scp CDM/DOCUMENTATION/${_CRQ_ID}/orden_post.txt es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta} ;fi"


//Quito lineas en blanco
execQuitar="""
       . \$HOME/.profile >/dev/null 2>&1
    if [ -f /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta}/orden_pre.txt ]
    then
        QuitaLineas -p /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta} -f orden_pre.txt
    fi
    if [ -f /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta}/orden_post.txt ]
    then
        QuitaLineas -p /home/plataforma/plausr/tmp/${hoy}/${_nombreCarpeta} -f orden_post.txt
    fi
    """
    
sh "ssh -q es036tvr '${execQuitar}'"

//Ejecutamos el script de install
execEsq="""
        . \$HOME/.profile >/dev/null 2>&1
        . paquete ${_nombreCarpeta}
        install_schema_WB -W -d AMDOCS-ESQUEMA -e  PROD -p ${_nombreCarpeta} ${_nombreCarpeta} 
    """
 sh "ssh -q opetst75 '${execEsq}'"
//print "ejecutamos ...${execEsq}"
 
 }