def call(Map config, String artifact)
{
	def ret=false
	if (!config.containsKey("runAllKiuwan")){
		return false
	}
	switch(config.runAllKiuwan) {
		case "none":
			return false
		break
		case "all":
			return true
		break
		case "only_included":
			if(!config.containsKey("kiuwanIncluded")){
				return false
			}
			else{
				if (config.kiuwanIncluded.contains(artifact))
				{
					return true
				}
			}
			return false
		break
		case "all_but_excluded":
			if(!config.containsKey("kiuwanExcluded")){
				return true
			}else {
				if (config.kiuwanExcluded.contains(artifact))
				{
					return false
				}
			}
			return true
		break

	}
}