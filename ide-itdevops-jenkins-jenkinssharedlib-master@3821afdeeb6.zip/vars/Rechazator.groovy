def call (String _usuario, String _mensaje, String _paquete ){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python Rechazator.py -u ${_usuario} -M \"${_mensaje}\" ${_paquete} "
        }
    }
}