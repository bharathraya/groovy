def call(String tag, String commit){
	echo "getGitDiffTagFileList"
    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
        git diff --name-only ${tag}..${commit} || true
    """
	def lista = SALIDA.split("\n").collect{it}
	return lista
}