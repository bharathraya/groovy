def call(String _bitbucket,String delivery, String commit){
	echo "getCommitsCompatility"
    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
        #git branch -r
        if [ "${_bitbucket}" != "bitbucket" ]
        then
            git merge-base vodafone/${delivery}..${commit}
        else
            git merge-base origin/vodafone/${delivery}..${commit}
        fi
    """
    def ancestor=SALIDA.trim()
    SALIDA=sh returnStdout: true, script: """
        #git branch -r
        if [ "${_bitbucket}" != "bitbucket" ]
        then
            git diff --name-only vodafone/${delivery}..${ancestor}
        else
            git diff --name-only origin/vodafone/${delivery}..${ancestor}
        fi
    """    
	def lista = SALIDA.split("\n").collect{it}
	return lista
}
