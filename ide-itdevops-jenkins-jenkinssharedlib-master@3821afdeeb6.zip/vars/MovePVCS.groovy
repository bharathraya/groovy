def call(String _Alms,String _Env,String _OriginServer, String _remoteServer){
 
  hoy=new Date().format( 'yyyyMMdd' )
  fichero_e="${_Alms}.${_Env}.deploy"
  fichero_e_backout="${_Alms}.${_Env}.rollback"
  _OriginServer = "appcrm"
  
  if ( "${_Env}" == "PROD" )
   {
      //Copio el e a opetst75
        execE="""
            . \$HOME/.profile >/dev/null 2>&1
            . paquete ${_Alms} ${_Env}
            scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_Alms}/${fichero_e} e
            scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_Alms}/${fichero_e_backout} e_backout
            scp -qr es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_Alms}/${_Env}/* .
            """
                
         if (_remoteServer !="")
            {
                sh "ssh -q ${_remoteServer} '${execE}'"
            }
            else
            {
                sh "${execE}"
            }
    
      exec="""
            . \$HOME/.profile >/dev/null 2>&1
            . paquete ${_Alms} ${_Env}
            ssh -q appcrm " . \$HOME/.profile ; . paquete ; if [ -d ${_Alms}/${_Env} ] ; then  rm -Rf ${_Alms}/${_Env} ; fi ; . paquete ${_Alms} ${_Env}"
            scp e e_backout platafor@appcrm:/home/plataforma/plausr/data/paquetes/${hoy}/${_Alms}/${_Env} 
            if [ -f DataModules/extras.txt ]
                then
                ssh -q appcrm " . \$HOME/.profile ; if [ -d /home/plataforma/plausr/data/temporal/${hoy}/anexo/${_Alms}/${_Env} ] ; then  rm -Rf /home/plataforma/plausr/data/temporal/${hoy}/anexo/${_Alms}/${_Env} ; fi ; mkdir -p /home/plataforma/plausr/data/temporal/${hoy}/anexo/${_Alms}/${_Env}"
                scp DataModules/extras.txt platafor@appcrm:/home/plataforma/plausr/data/temporal/${hoy}/anexo/${_Alms}/${_Env} 
            fi
        """
     
        
        if (_remoteServer!="")
            {
                sh "ssh -q ${_remoteServer} '${exec}'"
            }
            else
            {
                sh "${exec}"
           }
    }    
    else{
            exec="""
                . \$HOME/.profile >/dev/null 2>&1
                export ruta_temp=\$DIR_BASE_TEMPORAL/${hoy}/anexo/${_Alms}/${_Env}
                . paquete ${_Alms} ${_Env}
                scp -qr es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_Alms}/${_Env}/* .
                if [ -f DataModules/extras.txt ]
                   then
                    mkdir -p \${ruta_temp}
                    cp DataModules/extras.txt \${ruta_temp}
                    rm -Rf DataModules
                fi
            """

            if (_remoteServer!="")
                {
                    sh "ssh -q ${_remoteServer} '${exec}'"
                }
                else
                {
                    sh "${exec}"
                }
        
            
        }//Para SIT2


}