import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario

def _CRQ_ID=""
def _listapaquetes=""
def _NomVista=""
def _Env=""
def _FechaSanity=""
def _CreaVista=""
def _CrearPaquete=""
def _Ventana
def _upgrade=""
def ibit=0
def hoy=""
def passUsrPlata=""
def RutaTemp=""
def RutaPaquete=""
def _Orden=""
def Tipos=""
def TipoDespliegues=""
def tamanoDesp=""
def pos=0
def _domain=""
def _listado=""
def Testeo
def _Tipo=""
def _nombreCarpeta=""
def fichero_e=""
def fichero_por=""
def fichero_e_backout=""
def _FechaSanityVentana=""
def execCO=""
def exec=""
def AplicacionesFalloTesteo=""


def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            choice(name: 'CrearVISTA',  choices: pipelineParams.Optionvista , description: 'Elige las opciones:YES. Para lanzar el report y crear la vista 2. NO. La vista ya esta creada')
            choice(name: 'CrearPaquetes',  choices: pipelineParams.OptionPaquetes , description: 'Elige las opciones:YES. Para crear los paquetes 2. NO. Creamos los paquetes a mano') 
            string(name: 'CRQ_ID', defaultValue: '', description: 'Nombre de la ventana') 
            string(name: 'List_Packages', defaultValue: '', description: 'Listado de paquetes a tratar')
            string(name: 'Vista', defaultValue: '', description: 'Nombre de la vista de paquetes') 
            //string(name: 'Entorno', defaultValue: '', description: 'Entorno de la ventana')
            choice(name: 'Entorno',  choices: pipelineParams.environmentChoices , description: 'Entorno de la ventana') 
            string(name: 'FechaSanity', defaultValue: '', description: 'Fecha del Sanity <yymmddhhmm>')
         }
         
         stages{     
         stage("Prepare"){
                agent {
                    label 'AMDOCS-PARCHE'
                        }
                steps{
                script {
                        //Leo los parametros
                        _CRQ_ID=params.CRQ_ID  
                        _listapaquetes=params.List_Packages
                        _NomVista=params.Vista
                        _Env=params.Entorno
                        _FechaSanity=params.FechaSanity
                        _CreaVista=params.CrearVISTA
                        _CrearPaquete=params.CrearPaquetes
                        _Ventana = true
                        _upgrade="S"
                        hoy=new Date().format( 'yyyyMMdd' )
                        print "La fecha de hoy es ......${hoy}......"
                        ibit =0
                        
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        TiposAnalizar=pipelineConfig.Tipos_ventana
                        Tipos_Bit=pipelineConfig.Tipos_BB
                        
                        _NomVista = _NomVista.trim()
                        _CRQ_ID = _CRQ_ID.trim()

                        
                        //Errores de parametros
                         if (_CRQ_ID == "" && _NomVista == "" ){
                           error("Nombre del directorio donde esta el listado de paquetes o Nombre de la vista son obligatorios.")
                        }
                        if (_CRQ_ID != "" && _NomVista != "" ){
                           error("Solo se puede poner el nombre del paquete ${_CRQ_ID} o de la vista ${_NomVista} .")
                        }
                        if ( _Env == "" ) { 
                	        error("Entorno es obligatorio.")
                        }
                        if ( _Env != "SIT1" && _Env != "PPRD" && _Env != "SIT3") { 
                	        error("El entorno debe de ser SIT1 o PPRD o SIT3.")
                        }
                        if(_CRQ_ID != "" && _listapaquetes == "" ) { 
                	        error("Es necesaria una lista de paquetes para este directorio ${_CRQ_ID}.")
                        }  
                        if (_CreaVista =="YES" && _NomVista == "" )
                        {
                             error("Tienes que introducir el Nombre de la vista que quieres crear.")
                        }
                        if(_FechaSanity == "")
                        {
                          _FechaSanity=new Date().format( 'yyyyMMddHHmm' )
                        }
                        //Saco los datos del que ejecuta la ventana
                         
                        wrap([$class: 'BuildUser']) {
                             //  echo "Exec user: ${env.BUILD_USER_ID}"
                               mybuilduser=env.BUILD_USER_ID
                          }
                               //Contraseña
                           (_pass,mybuilduser)=findpassword(mybuilduser)
                        
                         //Configuramos el nombre del build y su descripcion
                        if (_CRQ_ID != "")
                        {
                            currentBuild.displayName = "CRQ: ${_CRQ_ID} Dia: ${hoy} Entorno ${_Env}"
                            currentBuild.description = "CRQ: ${_CRQ_ID} Lista Paquetes: ${_listapaquetes} "
                        }
                        else
                        {
                            currentBuild.displayName = "Vista: ${_NomVista} Dia: ${hoy} Entorno ${_Env}"
                            currentBuild.description = "Vista: ${_NomVista} "
                        }
                        if (_NomVista != "")
                        {
                            _CRQ_ID="${_NomVista}"
                            _View = true
                        }
                        else
                        {
                            _View = false
                        }
                        
                        if (_CreaVista =="YES" && _NomVista != "" )
                        { //UsrPlata:
                            passUsrPlata= "Temporal01"
                            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: passUsrPlata ]]]) {
                              create_view(_NomVista,_Env,_FechaSanity,"UsrPlata",passUsrPlata, _upgrade )
                            }//wrap
                        }
                        
                        RutaTemp="/home/plataforma/plausr/tmp"
                        RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
                        sh "if [ -d ${RutaPaquete} ] ; then rm -rf ${RutaPaquete} ; fi ; mkdir -p ${RutaPaquete} "
                        
                        if (_View == false)
                        {
                            //Funcion para descargar los datos
                               _Orden=""
                           //  print "CRQ -> ${_CRQ_ID}"
                           //  print "Lista paquetes -> ${_listapaquetes}"
                           //  print "Orden Vacio-> ${_Orden}"
                               
                               DescargaFicheros "${_CRQ_ID}" , "${_listapaquetes}", "${_Orden}"
                             // Paquetes=readFile(file: "${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt")
                        }
                        
                        SeparaPaquete2 "${_CRQ_ID}" , _View, _Ventana, _NomVista ,mybuilduser , _pass , _upgrade

                   }//script
                 }//step
            }//prepare
            
            stage("Testeo"){ //Testeo los paquetes
                agent {
                    node("AMDOCS-PARCHE")
                        }

                steps{
                script {
                        print "Testeamos los paquetes"
                            
                        Tipos=readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")
                        TipoDespliegues=Tipos.split()
                        print "Aplicaciones a tratar ${TipoDespliegues}"
                        tamanoDesp= TipoDespliegues.size()
                        sh "touch -f ${RutaPaquete}/AplicacionesFalloTesteo.txt"
                       
                        for (pos = 0; pos < TipoDespliegues.size(); pos++ ) {
                           _domain = TipoDespliegues[pos]
                           
                          // print "Es de bit: ${Tipos_Bit.contains(_domain)}"
                          // print "Es de analizar ${TiposAnalizar.contains(_domain)}"
                          
                            _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
                           if ((TiposAnalizar.contains(_domain) || _CrearPaquete== "NO") && !Tipos_Bit.contains(_domain) )
                           {//REvisamos si es de los que hay que analizar y se va a crear paquete
                             //Si no se va a crear paquete revisamos de todos
                                
                              
                                Testeo = true
                                if (_domain != "APM")
                                {
                                    _Tipo=(_domain.split("-")[-1]) 
                                }
                                else
                                {
                                    _Tipo="APM"
                                }
                                     
                                _nombreCarpeta="${_CRQ_ID}_${_Tipo}"
                              
                                 //Solo testeamos y extraemos para obtener el e
                                print "****************************************"
                                print "TESTEANDO CONTRA ${_Env} APLICACION: ${_domain} "
                                print "****************************************"
                                        
                                try{
                                        txeker("",_domain,_Env,_nombreCarpeta,_listado)
                                        } catch(Exception e){
                                                
                                        echo "Fallo Testeo contra ${_Env} en ${_domain} error: ${e}" 
                                        sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteo.txt  "
                                        sh " scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${_nombreCarpeta}.${_Env}.errores_testeo  ${RutaPaquete}/ "
                                        sh " cat ${RutaPaquete}/${_nombreCarpeta}.${_Env}.errores_testeo >> ${RutaPaquete}/AplicacionesFalloTesteo.txt  "
                                        Testeo = false
                                        }
                                if (Testeo == true)
                                {
                                    if (_domain == "AMDOCS-UPSD" || _domain == "AMDOCS-CLARIFY")
                                      {
                                        replica_datos("",_domain,_Env,_nombreCarpeta,_listado)
                                      }
                                                
                                    //Llamamos funcio que genera el fichero WB
                                    GenerarWBFile "${_CRQ_ID}" , "${_nombreCarpeta}", "${_Env}", "${_domain}" ,true ,  "${_upgrade}"
                                    fichero_e="${_nombreCarpeta}.${_Env}.deploy"
                                    fichero_por="${_nombreCarpeta}.${_Env}.por_paquete"
                                    fichero_e_backout="${_nombreCarpeta}.${_Env}.rollback"
                                    
                                    if (_domain == "AMDOCS-BBDD")
                                    {
                                      //Copio los fichero a crm50tst02
                                        exec="""
                                        . \$HOME/.profile >/dev/null 2>&1
                                        . paquete ${_nombreCarpeta} ${_Env}
                                         export fichero_e="${_nombreCarpeta}.${_Env}.deploy"
                                         export fichero_e_backout="${_nombreCarpeta}.${_Env}.rollback"
                                         export fichero_por="${_nombreCarpeta}.${_Env}.por_paquete"
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_e} e
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_e_backout} e_backout
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_por} ../e_por_paquete
                                         """
                                        //sh "${exec}"
                                        sh "ssh -q crm50tst02 '${exec}'"
                                        
                                        _FechaSanityVentana="${_FechaSanity}00"
                                        print "Fecha de la ventana ${_FechaSanityVentana}"
                                        creaOrdenVentanaONO "${_Env}" , "${_CRQ_ID}" , "${_FechaSanityVentana}" , "" ,"devopststtools01"
                                     
                                        //Copio los fichero a crm50tst02
                                        execCO="""
                                        . \$HOME/.profile >/dev/null 2>&1
                                        . paquete ${_nombreCarpeta} 
                                         scp  crm50tst02:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/orden.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}
                                         scp  crm50tst02:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/orden.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}
                                         touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Rollback.sql
                                         touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Rollback.sql
                                         """
                                       
                                        sh "${execCO}"
                                        
                                    } //Si el dominio es AMDOCS-BBDD
                                    else
                                    {
                                         //Copio los fichero a crm50tst02
                                        exec="""
                                        . \$HOME/.profile >/dev/null 2>&1
                                        . paquete ${_nombreCarpeta} ${_Env}
                                         export fichero_e="${_nombreCarpeta}.${_Env}.deploy"
                                         export fichero_e_backout="${_nombreCarpeta}.${_Env}.rollback"
                                         export fichero_por="${_nombreCarpeta}.${_Env}.por_paquete"
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_e} e
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_e_backout} e_backout
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_por} ../e_por_paquete
                                         """
                                         sh "${exec}"
                                    } //No es amdocs-bbdd
                                    
                                }//No ha fallado el testeo
                           }
                           else if (Tipos_Bit.contains(_domain))
                            { 
                               _Tipo=(_domain.split("-")[-1]) 
                               _nombreCarpeta="${_CRQ_ID}_${_Tipo}"
                               print "Es de bit, lanzamos el txeker_git"
                               txeker_git("*", "NO_PROD",'"' + _listado + '"', mybuilduser,_pass ,_nombreCarpeta)
                               ibit=1
                               print "Copio el commit mas alto"
                               sh "touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/bit.commit.txt"
                               sh "mkdir -p /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/"
                               sh "rm -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/*"
                               sh "scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/txeker_git.${_nombreCarpeta} /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/"
                               sh "echo '**************************************************************************' >> /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/bit.commit.txt"
                               sh "echo 'Paquete a migrar del tipo: ${_domain}*************************************' >> /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/bit.commit.txt"
                               sh "head -1 /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/txeker_git.${_nombreCarpeta} >> /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/bit.commit.txt"
                               sh "echo 'Promocionar: ${_listado}' >> /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/bit.commit.txt"
                           }
                           else
                            {
                               print "NO testeo la aplicacion ${_domain}"
                            }
                        }//for
                            
                        //Revisar si han fallado
                        AplicacionesFalloTesteo= readFile(file: "${RutaPaquete}/AplicacionesFalloTesteo.txt")
                        if (AplicacionesFalloTesteo != "" )
                          {
                            print "****************************************"
                            print "         TESTEO INCORRECTO"
                            print "****************************************"
                            
                            print "Se han tratado estos tipos ${Tipos}"  
                            print "Fallan en ${_Env} estas aplicaciones:"
                            print "${AplicacionesFalloTesteo}"
                            error("Fallos de Testeo. Revisar")
                          }
                         else
                           {
                            print "********************************************"
                            if (_CrearPaquete== "YES")
                            {
                                print "TESTEO CORRECTO DE LAS APLICACIONES DE LAS QUE SE VAN A CREAR PAQUETES"
                            }
                            else
                            {
                                   print "TESTEO CORRECTO DE LAS APLICACIONES"
                            }
                            print "En la vista hay estos tipos de aplicaciones:"
                            print "${Tipos}"
                            print "********************************************"
                            print "********************************************"
                            print "Los ficheros para generar los paquetes de la ventana estan en la crm50tst02:"
                            print "/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}:"
                            print "********************************************"
                            if (_CrearPaquete=="YES")
                            {
                                //Copiamos en es036tvr los ficheros
                                exec="""
                                . \$HOME/.profile >/dev/null 2>&1 
                                ssh -q es036tvr " . \$HOME/.profile ; . paquete ; if [ -d ${_CRQ_ID} ] ; then  rm -Rf ${_CRQ_ID}/ ; fi ; . paquete ${_CRQ_ID} "
                                . paquete ${_CRQ_ID}
                                scp * es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}
                                
                                """
                                
                               sh "${exec}"
                           
                                print "********************************************"
                                print "         CREAMOS los paquetes"
                                print "********************************************"
                                if (_Env =="SIT1")
                                { // DROP ES2225FR
                                     wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                                        create_package(mybuilduser,_pass,_CRQ_ID,_Env,"CM_Ventana_SAT", _upgrade, "N" )
                                     }//wrap
                                }
                                else if (_Env =="SIT3")
                                { // DROP ES2225FR 
                                     wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                                        create_package(mybuilduser,_pass,_CRQ_ID,_Env,"CM_Ventana_SAT", _upgrade, "N" )
                                     }//wrap
                                }
                                else if (_Env =="PPRD")
                                { // DROP  ES2230FR 
                                    wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                                        create_package(mybuilduser,_pass,_CRQ_ID,_Env,"CM_Ventana_SIT", _upgrade, "N"  )
                                    }//wrap
                                }
                            }
                            else
                            {
                                print "********************************************"
                                print "         HAY QUE CREAR los paquetes a mano" 
                                print "********************************************"
                            }
                            if (ibit==1)
                            {
                                print "Hay paquete de bitbucket"
                                print "Los paquetes de bitbucket que hay que migrar, con el commit más alto son estos:"
                                sh "cat /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/bit.commit.txt"
                            }
                           }

                    }//scripts
                }//steps
            }//Testeo
          
         }//stages
        }//pipeline
    }//map
