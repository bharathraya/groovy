def call(String sharedFlow, Object env_config){
    echo "getSharedFlowDeployedRevision"
    List REVISIONAUX=[]
    def SALIDA=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
                                credentialsId: "${env_config.credentialid}", 
                                usernameVariable: 'USERNAME', 
                                passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            https_proxy="${env_config.proxyurl}"
            export https_proxy
            no_proxy="${env_config.noproxy}"
            export no_proxy
            curl -X GET --header "Accept: application/json" -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/sharedflows/${sharedFlow}/deployments"
            
 
        """
        if (SALIDA != ""){
            apiInfo=readJSON(text: "${SALIDA}")
            echo "apiInfo:${apiInfo}"
            apiInfo.environment.each(){
                def ENVinfo=it
                if (ENVinfo.name == env_config.env){
                    ENVinfo.revision.each(){
                        REVISIONAUX.add(it.name)
                    }
                }
            }
        }else{
            error "curl"
        }
    }
    return REVISIONAUX
}