def call(String _nombreCarpeta,String _CRQ_ID, String _delivery){
 
 def hoy=""
 def RupaEsquema=""
 def RutaTemp=""
 def RutaPaquete=""
 def execQuitar=""
 def execEsq=""
 
 // print "Parametros:"
 // print "NombreCarpeta ${_nombreCarpeta}"
 // print "CRQ a tratar ${_CRQ_ID}"
 // print "Delivery a tratar ${_delivery}"
  hoy=new Date().format( 'yyyyMMdd' )

   RupaEsquema="/home/plataforma/plausr/data/temporal/${hoy}/anexo/${_nombreCarpeta}/PROD/DataModules"

   RutaTemp="/home/plataforma/plausr/tmp/${hoy}"
   RutaPaquete="${RutaTemp}/${_CRQ_ID}"
 
  print "Copiamos los ordenes al directorio ${_nombreCarpeta}"
 // sh "ssh crm50tst02 'mkdir -p ${RupaEsquema}'"
 // sh " if [ -f ${RutaPaquete}/orden_pre.txt ] ; then scp ${RutaPaquete}/orden_pre.txt crm50tst02:${RupaEsquema}/orden_pre.txt ;fi"
 // sh " if [ -f ${RutaPaquete}/orden_post.txt ] ; then scp ${RutaPaquete}/orden_post.txt crm50tst02:${RupaEsquema}/orden_post.txt ;fi"
  
  //Usando devopststtools01
  sh "mkdir -p ${RupaEsquema}"
  sh " if [ -f ${RutaPaquete}/orden_pre.txt ] ; then cp ${RutaPaquete}/orden_pre.txt ${RupaEsquema}/orden_pre.txt ;fi"
  sh " if [ -f ${RutaPaquete}/orden_post.txt ] ; then cp ${RutaPaquete}/orden_post.txt ${RupaEsquema}/orden_post.txt ;fi"


//Quito lineas en blanco
execQuitar="""
       . \$HOME/.profile >/dev/null 2>&1
    if [ -f ${RupaEsquema}/orden_pre.txt ]
    then
        QuitaLineas -p ${RupaEsquema} -f orden_pre.txt
    fi
    if [ -f ${RupaEsquema}/orden_post.txt ]
    then
        QuitaLineas -p ${RupaEsquema} -f orden_post.txt
    fi
    """
    
print "Borramos posibles lineas en blanco"    
sh "${execQuitar}"
//sh "ssh -q crm50tst02 '${execQuitar}'"

//Ejecutamos el script de install
//print "Ejecutamos el script install_schema_up -W  -D ${_delivery} -d AMDOCS-ESQUEMA -e  PROD -p ${_nombreCarpeta} ${_nombreCarpeta} "
execEsq="""
        . \$HOME/.profile >/dev/null 2>&1
        . paquete ${_nombreCarpeta}
        install_schema_up -W -D ${_delivery} -d AMDOCS-ESQUEMA -e  PROD -p ${_nombreCarpeta} ${_nombreCarpeta} 
    """
 sh "${execEsq}"
 //sh "ssh -q crm50tst02 '${execEsq}'"
//print "Ejecutamos: ${execEsq}"
 
 }
