import vfes.utils.nexusData

def call(nexusData nexus, String url){
    echo "downloadNexusFile"
    def urlList=[]
    def fichero=url.substring(url.lastIndexOf("/")+1,url.size())
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${nexus.nexusCred}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
                curl -k --get -u"${USERNAME}:${PASSWORD}" --url ${url} -o ${fichero}
        """
    }
}