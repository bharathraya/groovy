def call(String _Alms,_dataModules,String _remoteServer,String _date){

    def data_module_name=""
    def es_tipo_bbdd=""
    def es_rollback=""
    def pos=0
    def order_file=""
    def order_content=""
    
    order_file="${_Alms}_orden_catalogo.txt"
    
    for (pos = 0; pos < _dataModules.size(); pos++) {
        data_module_name = _dataModules[pos].FileName;
        es_tipo_bbdd = _dataModules[pos].IsDataBase;
        es_rollback = _dataModules[pos].IsRollback;
        order_content = "${order_content} echo ${data_module_name} >> ${order_file};"
        
    }

    if (order_content == ""){
        error("Order file [${order_file}] is empty")
    }

    //def ruta_temp="/home/plataforma/plausr/data/temporal/${_date}/anexo/${_Alms}"
    
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    export ruta_temp=\$DIR_BASE_TEMPORAL/${_date}/anexo/${_Alms}
    if [ -d \${ruta_temp} ]
    then
        if [ -f \${ruta_temp}/${order_file} ]
        then
            echo \"Already exist the file \${ruta_temp}/${order_file}. deleting it\"
            rm -f \${ruta_temp}/${order_file} 
        fi
    else
        mkdir -p \${ruta_temp}
    fi
    cd \${ruta_temp}
    ${order_content}
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}