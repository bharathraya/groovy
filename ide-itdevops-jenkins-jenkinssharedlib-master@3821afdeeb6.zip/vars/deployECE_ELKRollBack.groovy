import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(Map config,VFESALMSDeployment alms)
{
    switch(config.deployType) {
        default:
            for (i=0;i<config.artifactId.size();i++){
                def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
                def _envConfig=myEnvsConfig[alms.deployEnv]
                echo "_envConfig"+_envConfig['copyToRelease']

                dir(config.extractFolder) {
                    _envConfig['copyToRelease'].each { item ->
                        def scriptName="rollback-backup-${alms.appName}-${alms.almsID}-${alms.jobTimeStamp}.sh"
                        echo "ROLLINGBACK: ${alms.appName} ${alms.almsID}: RUN ${item.application_release_path}/staging/${alms.jobDate}/${alms.almsID}/${scriptName}"
                        sh "ssh -q -o StrictHostKeyChecking=no ${item.user}@${item.server} '. ${item.application_release_path}/staging/${alms.jobDate}/${alms.almsID}/${scriptName}'"
                    }
                }
            }
            break
        case ~/^k8s-beat$/:
            echo "RollBack to the release not needed for deploy type: ${config.deployType}"
            break
    }
}
