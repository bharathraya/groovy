import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever
import groovy.time.TimeCategory

// Parametros necesario
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _serverSVN=""
def _funcion=""
def _funcionEnt=""
def funcConfig=""
def hoy=""
def _funcionAejecutar=""
def _serverAenviar=""
def _WB_ID=""
def envsConfig
def _listapaquetes=""
def _serverPROD=""
def MaquinaRemota="fwapptst01"
def mybuilduser=""
def _password
def _passwordPROD

def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'CRQ_ID', defaultValue: '', description: 'CRQ ID') 
            string(name: 'List_Packages', defaultValue: '', description: 'Listado de paquetes a tratar')
            string(name: 'Vista', defaultValue: '', description: 'Nombre de la vista de paquetes') 
            choice(name: 'Enviroment',  choices: pipelineParams.environmentChoices , description: 'Enviroment to deploy') 
            choice(name: 'Opcion',  choices: pipelineParams.OptionChoices , description: 'Elige las opciones:1. Separa y Testeo 2. Ejecuciones 3. Versionar') 
           
         }
    stages{     
         stage("Prepare"){
                agent {
                    label 'BIZTALK'
                        }
                steps{
                script {
                    //Saco el que lo ejecuta
                     wrap([$class: 'BuildUser']) {
                     echo "Exec user: ${env.BUILD_USER_ID}"
                         mybuilduser=env.BUILD_USER_ID
                       }
                     //Busco la contraseña
                     (_pass,mybuilduser)=findpassword(mybuilduser)
                              
                        //Leo los parametros
                        _CRQ_ID=params.CRQ_ID.trim()  
                        _listapaquetes=params.List_Packages
                        _opcion=params.Opcion
                        _NomVista=params.Vista.trim()
                        _env=params.Enviroment
                        hoy=new Date().format( 'yyyyMMdd' )
                        tomorrow =  new Date().plus(1).format( 'yyyyMMdd' )
                        _password='Anm%chg9Vochg13$)."'
                         
                        print "La fecha de hoy es ......${hoy}......"
                        _passwordPROD="PASSWORDPROD"
                        //leemos el fichero de configuracion
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        //leemos el fichero de entornos
                        envsConfig=pipelineConfig.envConfig
                        enviroments=readJSON(file: "${envsConfig}")
                      
                       //Miramos si los parametros están bien
                        if (_CRQ_ID == "" && _NomVista == "" ){
                           error("Nombre del CRQ o Nombre de la vista son obligatorios.")
                        }
                        if(_CRQ_ID != "" && _listapaquetes == "" && _NomVista == "" ) { 
                	        error("Es necesaria una lista de paquetes para este CRQ ${_CRQ_ID}.")
                        }
                        if(_CRQ_ID != "" && (_listapaquetes != "" && _NomVista != "" ) ) { 
                	        error("Los paquetes vienen en la lista o en la vista.")
                        }
                       
                        if (_opcion == "" || (_opcion != "1" && _opcion != "2" && _opcion != "3" ) ){
                            error("Hay que indicar una opcion entre 1 y 3.")
                        }
                        
                        
                         //Configuramos el nombre del build y su descripcion
                        if (_CRQ_ID != "")
                        {
                            currentBuild.displayName = "CRQ: ${_CRQ_ID} Dia: ${hoy} Opcion ${_opcion}"
                            if (_listapaquetes != "")
                            {
                                currentBuild.description = "CRQ: ${_CRQ_ID} Lista Paquetes: ${_listapaquetes} "
                            }
                            else if (_NomVista!= "")
                            {
                                currentBuild.description = "CRQ: ${_CRQ_ID} Vista: ${_NomVista} "
                            }
                            
                        }
                        else
                        {
                            currentBuild.displayName = "Vista: ${_NomVista} Dia: ${hoy} Opcion ${_opcion}"
                            currentBuild.description = "Vista: ${_NomVista} "
                        }
                        
                        if (_CRQ_ID == "" &&  _NomVista != "")
                        {  //No hay CRQ
                            _CRQ_ID="${_NomVista}"
                            _View = true
                        }
                        else if (_CRQ_ID != "" &&  _NomVista != "")
                        {  //Hay crq y lista de paquetes en la vista
                            _View = true
                        }
                        else if ( _NomVista == "")
                        {  //NO hay vista
                            _View = false
                        }

                        //Escribo las opciones
                        //'Elige las opciones:1. Separa y Testeo 2. Ejecuciones 3. Versionar'
                        if ( _opcion=="2" ) 
                        {
                            print "******************************"
                            print "Elegida opcion 2 de CREACIÓN DE PARCHES"
                            print "Nombre del parche ${_CRQ_ID} "
                            print "******************************"
                        }  
                         if ( _opcion=="1" ) 
                        {
                            print "******************************"
                            print "Elegida opcion 1 de TESTEO"
                            print "Nombre del parche ${_CRQ_ID} "
                            print "******************************"
                        }  
                        if ( _opcion=="3" ) 
                        {
                            print "******************************"
                            print "Elegida opcion 3 de VERSIONADO"
                            print "Nombre del parche ${_CRQ_ID} "
                            print "******************************"
                        } 
                        RutaTemp="/home/plataforma/plausr/tmp"
                        RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
                        sh "if [ -d ${RutaPaquete} ] ; then rm -rf ${RutaPaquete} ; fi ; mkdir -p ${RutaPaquete} "
                       
                        //Reviso si los paquetes estan promocionados
                        if (_View == true)
                        {
                            if ( "${_CRQ_ID}" != "${_NomVista}" )
                            {   //Hay vista y CRQ
                                get_packagesbyview(_NomVista,mybuilduser,_pass)
                                
                                //lo muevo al directorio del nombre del CRQ
                                exec="""
                                . \$HOME/.profile >/dev/null 2>&1
                                . paquete  ${_CRQ_ID} >/dev/null 2>&1
                                cp  /home/plataforma/plausr/data/paquetes/${hoy}/${_NomVista}/ListaPaquetes.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}
                                """
                                sh "ssh -q es036tvr '${exec}'"
                            }
                            else{
                                 get_packagesbyview(_CRQ_ID,mybuilduser,_pass)
                            }

                        }
                        else
                        {   //saco la info del listado
                             get_applicationCRQ(_CRQ_ID,'"' + _listapaquetes + '"', mybuilduser, _pass)
                        }
                        //Reviso los que no estan promoted en entornos no productivos
                        EditPackage(_CRQ_ID)
                        PaquetesSinPromote=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PaquetesSin.txt")
                        
                        print "Lanzo funcion de separar"
                        exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                        SeparaPaquetes.sh -p  ${_CRQ_ID} 
                        . paquete  ${_CRQ_ID}
                        cp  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/* ${RutaPaquete}/
                        """
                        sh "${exec}"
                        //lanzo en fwapptst01

                   }//script
                 }//step
            }//prepare

    stage("Opciones"){ //Testeo los paquetes
                agent {
                    node("BIZTALK")
                        }

                steps{
                    script {//Elige las opciones:1. Separa y Testeo 2. Ejecuciones 3. Versionar
                        //Si solo se elige opcion 1 solo testear y separar
                        //Si se elige opcion 2 testear y extraer 
                        //Si se elige opcion 3 se testea y versiona
                       // print "Testeamos los paquetes"
                        Tipos=readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")
                        TipoDespliegues=Tipos.split()
                        print " Aplicaciones a tratar ${TipoDespliegues}"
                        tamanoDesp= TipoDespliegues.size()
                        print "tamaño de despliegue ${tamanoDesp}"
                        sh "touch -f ${RutaPaquete}/AplicacionesFalloTesteo.txt"
                        sh "touch -f ${RutaPaquete}/Instrucciones.txt"
                            
                            for (pos = 0; pos < TipoDespliegues.size(); pos++) {
                                _domain = TipoDespliegues[pos]
                                _domainnew=_domain.replace('2020','')
                                _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
                                _Tipo=(_domain.split("-")[-1]) 
                                _nombreCarpeta="${_CRQ_ID}_${_Tipo}"

                            //Solo testeamos
                                 if ( _opcion == "1" )
                                 {
                                     if (_domain != "BIZTALK-SQLSERVER" && _domain != "BIZTALK2020-SQLSERVER" )
                                    {
                                        print "****************************************"
                                        print "TESTEANDO CONTRA ${_env} APLICACION: ${_domain} "
                                        print "****************************************"
                                        Fallo=false
                                        try{ 
                                            if (_domain != "BIZTALK-IIS" && _domain != "BIZTALK2020-IIS")
                                            { //No extraemos
                                                txeker("-t",_domain,_env,_nombreCarpeta,_listado)
                                            }
                                            else{ 
                                                //Extaemos para luego revisar las app a parar
                                                txeker("",_domain,_env,_nombreCarpeta,_listado)
                                            }
                                        } catch(Exception e){
                                            Fallo=true    
                                            echo "Fallo Testeo contra ${_env} en ${_domain} error: ${e}" 
                                            sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteo.txt  "
                                            fichero_errores="${_nombreCarpeta}.${_env}.errores_testeo"
                                            exec="""
                                                . \$HOME/.profile 
                                                if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
                                                then
                                                     mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
                                                fi 
        
                                                echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                                echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                                echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                                getInfoErrores -p  ${_nombreCarpeta} -f ${fichero_errores} >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                                echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                            """
        
                                            sh "ssh -q es036tvr '${exec}'"
                                        

                                        }//Si falla
                                         
                                        //Sacamos las aplicaciones a parar
                                        if ( (_domain == "BIZTALK-IIS" || _domain == "BIZTALK2020-IIS") && Fallo == false)
                                        {
                                            //Para BIZTALK-IIS o BIZTALK2020-IIS lanzamos el agrupa
                                            print "Borramos el directorio ${_nombreCarpeta}/${_env} "
                                            CleanPaquete "${_nombreCarpeta}","", "${_env}"
                                            print "Copiamos el directorio ${_nombreCarpeta}/${_env} "
                                            CopiaFicheros "${_nombreCarpeta}","${_env}",""
                                    
                                            sh " touch -f /home/plataforma/plausr/tmp/paquetes_biztalk_${_nombreCarpeta}.txt"
                                            sh" cp ${RutaPaquete}/${_CRQ_ID}_${_domain} /home/plataforma/plausr/tmp/paquetes_biztalk_${_nombreCarpeta}.txt "

                                            print "Lanzo agrupar_paquetes_biz2016 para ver aplicaciones a parar"
                                            if ( _domain == "BIZTALK-IIS" ) {
                                                agrupar_paquetes_biz2016 _nombreCarpeta ,  _env , _listado , "Revisar"
                                            } else {
                                              	agrupar_paquetes_biz2020 _nombreCarpeta ,  _env , _listado , "Revisar"
                                            }
                                            
                                            sh "touch -f ${RutaPaquete}/proyectos_${_CRQ_ID}_${_Tipo}_BT"
                                            sh "if [ \$(cat /home/plataforma/plausr/agrupacion_paquetes/${_nombreCarpeta}/proyectos_${_nombreCarpeta} | grep 'TIPO_APLICACION_BIZTALK:' | wc -l) -gt 0 ]; then grep 'TIPO_APLICACION_BIZTALK:' /home/plataforma/plausr/agrupacion_paquetes/${_nombreCarpeta}/proyectos_${_nombreCarpeta} > ${RutaPaquete}/proyectos_${_CRQ_ID}_${_Tipo}_BT; fi"
                                        }
                                        
                                    }//fin no es sqlserver
                                    
                            }//opcion 1
                             //Testeamos de nuevo y versionamos en PROD
                                  if ( _opcion == "3")
                                 {
                                   if (_domain != "BIZTALK-SQLSERVER" && _domain != "BIZTALK2020-SQLSERVER")
                                    {
                                    print "****************************************"
                                    print "TESTEANDO CONTRA ${_env} APLICACION: ${_domain} "
                                    print "****************************************"
                                    txeker("",_domain,_env,_nombreCarpeta,_listado)
                                    //Si hay máquina de SVN ejecuto el promoSVN 

                                    print "Hay que subir a SVN"
                                    print "borramos la carpeta ${_nombreCarpeta}"
                                    cleanDirPaquete "${_nombreCarpeta}","","${hoy}","${_env}","${_domain}"
                                    _HayModulosPVCS=1
                                         //Miramos si en BBDD hay modulos pvcs
                                        if (_domain == "BIZTALK-BBDD" || _domain == "BIZTALK2020-BBDD")
                                        {
                                            CompruebaPvcs "${_nombreCarpeta}", "${_env}"
                                            //Creamos fichero e
                                            fichero_e="${_nombreCarpeta}.${_env}.deploy"  
                                            //print "fichero e ${fichero_e}"
                                            def _FicheroModulosPVCS=readFile(file: "CompruebaPvcs/${fichero_e}")
                                
                                                if ("${_FicheroModulosPVCS}" != "" ){
                                                    modulosPVCS=_FicheroModulosPVCS.split()
                                                    tamano= modulosPVCS.size()
                                                    _HayModulosPVCS=tamano
                                                  print "BBDD con modulos pvcs"
                                                }else{
                                                    _HayModulosPVCS=0
                                                     print "BBDD sin modulos pvcs"
                                                }
                                        }
                                    
                                        if (_HayModulosPVCS != 0)
                                        {
                                            print "traemos el codigo a ${_nombreCarpeta}"
                                            getFromPVCS "${_nombreCarpeta}","${_env}",""
                                          if (_domain == "BIZTALK2020-TEST"  || _domain == "BIZTALK2020-IIS" || _domain == "BIZTALK2020-CONFIG"  || _domain == "BIZTALK2020-BBDD" || _domain == "BIZTALK2020-BINDINGS") {
                                            //  sh ". \$HOME/.profile >/dev/null 2>&1; . paquete  ${_nombreCarpeta}"
                                              print "!!lanzamos el promoSVN!!"
                                                               
                                              exec="""
                                                 . \$HOME/.profile >/dev/null 2>&1
                                                 . paquete  ${_nombreCarpeta}
                                                  promoSVN -d BIZ2020 -e ${_env} -p ${_nombreCarpeta} 
                                              """
                                              sh "${exec}"
                                           } else {
                                             print "lanzamos el promoSVN"
                                              exec="""
                                                 . \$HOME/.profile >/dev/null 2>&1
                                                 . paquete  ${_nombreCarpeta}
                                                  promoSVN -d BIZ2016 -e ${_env} -p ${_nombreCarpeta} 
                                              """
                                              sh "${exec}"
                                           }
                                                                 
                                            
                                         
                                            print "****************************************"
                                            print "ETIQUETANDO CONTRA ${_env} APLICACION: ${_domain} "
                                            print "****************************************"
                                            txeker("-l",_domain,_env,_nombreCarpeta,_listado)
                                        }//Hay modulos de pvcs
                                        
                                    }//Si hay SVN subir a SVN meno SQL-SERVER
                                 }//OPCION 3
                                 if ( _opcion == "2")
                                 {
                                    
                                    if (_domain != "BIZTALK-SQLSERVER" && _domain != "BIZTALK2020-SQLSERVER" )
                                    {
                                         // testeamos y extraemos
                                        print "****************************************"
                                        print "TESTEANDO CONTRA ${_env} APLICACION: ${_domain} "
                                        print "****************************************"
                                        txeker("",_domain,_env,_nombreCarpeta,_listado)
                                        // traemos el codigo a api
                                        
                                        print "Borramos el directorio ${_nombreCarpeta}/${_env} "
                                        CleanPaquete "${_nombreCarpeta}","", "${_env}"
                                        print "Copiamos el directorio ${_nombreCarpeta}/${_env} "
                                        _HayModulosPVCS=1
                                        //Miramos si en BBDD hay modulos pvcs
                                        if (_domain == "BIZTALK-BBDD" || _domain == "BIZTALK2020-BBDD")
                                        {
                                            CompruebaPvcs "${_nombreCarpeta}", "${_env}"
                                            //Creamos fichero e
                                            fichero_e="${_nombreCarpeta}.${_env}.deploy"  
                                            //print "fichero e ${fichero_e}"
                                            def _FicheroModulosPVCS=readFile(file: "CompruebaPvcs/${fichero_e}")
                                
                                                if ("${_FicheroModulosPVCS}" != "" ){
                                                    modulosPVCS=_FicheroModulosPVCS.split()
                                                    tamano= modulosPVCS.size()
                                                    _HayModulosPVCS=tamano
                                                  print "BBDD con modulos pvcs"
                                                }else{
                                                    _HayModulosPVCS=0
                                                     print "BBDD sin modulos pvcs"
                                                }

                                        }
                                        if ( _HayModulosPVCS != 0)
                                        {
                                            CopiaFicheros "${_nombreCarpeta}","${_env}",""
                                        }
                                        //Lanzamos el copia_paquete_fecha
                                         sh ". \$HOME/.profile >/dev/null 2>&1 ; copia_paquete_fecha -f ${tomorrow} ${_nombreCarpeta} "
                                         
                                    }
                                    if (_domain == "BIZTALK-SQLSERVER" || _domain == "BIZTALK-BBDD" || _domain == "BIZTALK2020-SQLSERVER" || _domain == "BIZTALK2020-BBDD")
                                    { 
                                        replica_datos("-r",_domain,_env,_nombreCarpeta,_listado)
                                        _HayModulosDatos=1
                                        if (_domain == "BIZTALK-BBDD" || _domain == "BIZTALK2020-BBDD")
                                        {
                                            CompruebaModulos "${_nombreCarpeta}", "${_env}"
                                            mydataModulesMap= readJSON(file: "CompruebaModulos/modules.json")
                                             if(mydataModulesMap.Modules == "null"){
                                                      _HayModulosDatos=0    
                                                }else{
                                                      _HayModulosDatos=1
                                                }

                                        }
                                        //SQLSERVER
                                        if (_HayModulosDatos==1)
                                        {
                                            ListaSQL=_listado.split()
                                            print "Lista de paquetes ${_domain} :  ${ListaSQL} "
                                            TamSQL=ListaSQL.size() 
                                            print "Cuantos paquetes hay de ${_domain} ${TamSQL} "
                                            sh ". \$HOME/.profile >/dev/null 2>&1 ;. paquete ${_nombreCarpeta}"
                                           
                                            //23-12-20 meguiza2 28-07-21 quitamos la opcion -o para que copie los modulos poniendoles en el nombre el orden y numero de paquete lgonza54
                                           // replica_datos("-r",_domain,_env,_nombreCarpeta,_listado)
                                            execZip="""
                                              . \$HOME/.profile  >/dev/null 2>&1
                                              cd /home/plataforma/plausr/data/temporal/${hoy}
                                              find ${_listado} -exec zip -ru ${_nombreCarpeta}.zip  {} \\;
                                            """
                                            sh "ssh -q es036tvr '${execZip}'"
                                           
                                           
                                           //Copiamos el zip a la maquina de fwapptst01     
                                            execCop="""
                                               . \$HOME/.profile  >/dev/null 2>&1
                                              mkdir -p /home/plataforma/plausr/data/temporal/${hoy}/anexo
                                              cd /home/plataforma/plausr/data/temporal/${hoy}/anexo
                                              rm -Rf ${_listado}
                                              scp es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_nombreCarpeta}.zip . 
                                              unzip -o ${_nombreCarpeta}.zip
                                               """
                                             sh "${execCop}"
                                           
                                             //Movemos los ficheros a la carpeta
                                             for (posi = 0; posi < ListaSQL.size(); posi++) {
                                                    Paquete=ListaSQL[posi]
                                                    print "Paquete que hacemos el copy ${Paquete}"
                                                    sh " if [ \$(find /home/plataforma/plausr/data/temporal/${hoy}/anexo/${Paquete} -type f| wc -l) -ne 0  ]; then cp /home/plataforma/plausr/data/temporal/${hoy}/anexo/${Paquete}/${_env}/DataModules/* /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta} ;fi"
                                                }//Hay mas de un paquete for
                                                
                                             //Lanzamos el copia_paquete_fecha
                                             sh ". \$HOME/.profile >/dev/null 2>&1 ; copia_paquete_fecha -f ${tomorrow} ${_nombreCarpeta} "
                                        }//Hay modulos de datos                                      
                                    }//SQLSERVER o BBDD
                                        
                                       
                                       if (_domain == "BIZTALK-TEST" || _domain == "BIZTALK2020-TEST")
                                       {
                                            sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '***************************************************************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '***************************************************************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'ANTES DE COMPILAR HAY QUE EJECUTAR LA PARTE DE ${_domain} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Para lanzar ${_domainnew} tienes que hacer lo siguiente:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
                                       }
                                       else
                                       {
                                            sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '***************************************************************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '***************************************************************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Para lanzar ${_domainnew} tienes que hacer lo siguiente:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
                                       }
                                       
                                        
                                        if ( _domain != "BIZTALK-BBDD" && _domain != "BIZTALK-IIS" && _domain != "BIZTALK2020-BBDD" && _domain != "BIZTALK2020-IIS")
                                        {
                                            sh "echo 'EXECUTE on HVD-CM2020-01:  Set-Location C:\\home\\platafor\\release\\scripts\\Compile ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            if (_env =="PROD")
                                            {
                                                sh "echo 'EXECUTE .\\Master-COMP.ps1 -d \"BIZ2020\" -t \"${_domainnew}\" -e \"${_env}\" -p \"${_nombreCarpeta}\" -c \"Release\" -password \'${_passwordPROD}\' ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            }
                                            else 
                                            {
                                                sh "echo 'EXECUTE .\\Master-COMP.ps1 -d \"BIZ2020\" -t \"${_domainnew}\" -e \"${_env}\" -p \"${_nombreCarpeta}\" -c \"Release\" -password \"${_password}\" '>>  ${RutaPaquete}/Instrucciones.txt"
                                            }
                                        }
                                        else if ( (_domain == "BIZTALK-BBDD" || _domain == "BIZTALK2020-BBDD") && _HayModulosPVCS != 0 )
                                        {   
                                            print "Reviso que ejecutar en BBDD"
                                            print "LeerBTBBDD  ${_CRQ_ID} , ${_nombreCarpeta}, ${_env}"
                                            leerBTBBDD _CRQ_ID , _nombreCarpeta, _env
                                            sh "echo 'Conectarse a la maquina unix fwapptst01' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'cd /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}' >>  ${RutaPaquete}/Instrucciones.txt"
                                            if (_HayModulosDatos != 0)
                                            {
                                                sh "echo 'Hay parametrizaciones: conectarse a la BBDD indicada en los modulos de datos y ejecutar los modulos con sqlplus' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'Si las paramterizaciones son sobre BTORAP ejecutar estos export antes del sqlplus.' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '         export ORACLE_HOME=/home/oracle/product/12.2.0' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '         export LD_LIBRARY_PATH=\$ORACLE_HOME/lib:\$LD_LIBRARY_PATH' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '         export PATH=\$ORACLE_HOME/bin:\$PATH' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '' >>  ${RutaPaquete}/Instrucciones.txt"
                                            }
                                            sh "echo 'Conectarse a la BBDD correspondiente con el usuario correspondiente' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "cat ${RutaPaquete}/InstruccionesBBDD.txt >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Sacar los invalidos actuales ejecutando:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '      Select object_name,object_type from user_objects where status='INVALID'; ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Ejecutar los modulos uno a uno.' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Sacar los invalidos posteriores ejecutando:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '      Select object_name,object_type from user_objects where status='INVALID'; ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Recompilar los nuevos invalidos:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '      exec dbms_utility.compile_schema(UPPER('USER'),FALSE); ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '      Select object_name,object_type from user_objects where status='INVALID'; ' >>  ${RutaPaquete}/Instrucciones.txt"
                                           
                                        }
                                        else if ( (_domain == "BIZTALK-BBDD" || _domain == "BIZTALK2020-BBDD" ) && _HayModulosPVCS == 0)
                                        { 
                                            //Hay modulos de pvcs y estan en la ruta del paquete
                                            sh "echo 'Conectarse a la maquina unix fwapptst01' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'cd /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Si las paramterizaciones son sobre BTORAP ejecutar estos export antes del sqlplus.:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '         export ORACLE_HOME=/home/oracle/product/12.2.0' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '         export LD_LIBRARY_PATH=\$ORACLE_HOME/lib:\$LD_LIBRARY_PATH' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo '         export PATH=\$ORACLE_HOME/bin:\$PATH' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Conectarse a la BBDD indicada en los modulos de datos' >>  ${RutaPaquete}/Instrucciones.txt"
                                            sh "echo 'Ejecutar los modulos con sqlplus ' >>  ${RutaPaquete}/Instrucciones.txt"
                                        }    
                                        else if ( _domain == "BIZTALK-IIS" ||  _domain == "BIZTALK2020-IIS")
                                        {
                                            //Para BIZTALK-IIS lanzamos el agrupa
                                            sh "touch -f /home/plataforma/plausr/tmp/paquetes_biztalk_${_nombreCarpeta}.txt"
                                            sh "cp ${RutaPaquete}/${_CRQ_ID}_${_domain} /home/plataforma/plausr/tmp/paquetes_biztalk_${_nombreCarpeta}.txt "
                                            //sh "scp ${RutaPaquete}/${_CRQ_ID}_${_domain} fwapptst01:/home/plataforma/plausr/tmp/paquetes_biztalk_${_nombreCarpeta}.txt"
                                            print "Lanzo agrupar_paquetes_biz2016"
                                            if ( _domain == "BIZTALK-IIS" ) {
                                              agrupar_paquetes_biz2016 _nombreCarpeta ,  _env , _listado ,"Ejecutar"
                                            } else {
                                              agrupar_paquetes_biz2020 _nombreCarpeta ,  _env , _listado ,"Ejecutar"
                                            }
                                            
                                            sh "cp /home/plataforma/plausr/agrupacion_paquetes/${_nombreCarpeta}/comandos_ejecutar.sh ${RutaPaquete}/comandos_ejecutar.sh"
                                            sh "cat ${RutaPaquete}/comandos_ejecutar.sh >> ${RutaPaquete}/Instrucciones.txt "
                                            sh "cp /home/plataforma/plausr/agrupacion_paquetes/${_nombreCarpeta}/agrupacion_paquetes_final_${_nombreCarpeta} ${RutaPaquete}/agrupacion_paquetes_final_${_nombreCarpeta}"
                                            
                                            print "Revisamos que esten todos los paquetes en el agrupacion_paquetes_final_${_nombreCarpeta} obtenido"
                                        //    print "ejecuto reviewIIPa ${_CRQ_ID} , ${_nombreCarpeta}, ${_listado} " 
                                            reviewIIPa _CRQ_ID , _nombreCarpeta, _listado
                                             if ( _domain == "BIZTALK-IIS" ) {
                                              ejecutaTxekerBT _CRQ_ID , _nombreCarpeta, _env
                                            } else {
                                             ejecutaTxekerBT2020 _CRQ_ID , _nombreCarpeta, _env
                                            }
                                       

                                        }
            
                                    
                                    
                                 }//OPCION 2
                            
                        }//for aplicaciones
                        
                        if ( _opcion == "2")
                         { 
                            print "****************************************************************"
                            print "Estas son las instrucciones"
                            print "${RutaPaquete}/Instrucciones.txt"
                            sh "cat ${RutaPaquete}/Instrucciones.txt"
                            print "****************************************************************"
                          }   

                        if ( _opcion == "1")
                              { //Revisar si han fallado
                                  AplicacionesFalloTesteo= readFile(file: "${RutaPaquete}/AplicacionesFalloTesteo.txt")
                                    
                                  
                                  if (AplicacionesFalloTesteo != "" && PaquetesSinPromote == "" )
                                  {
                                      sh "scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt ${RutaPaquete}"
                                      InfoErroresTesteo= readFile(file: "${RutaPaquete}/InfoErroresTesteo.txt")
                                  
                                    print "****************************************"
                                    print "         TESTEO INCORRECTO"
                                    print "****************************************"
                                    print "Se han analizado estas aplicaciones:"
                                    print "${Tipos}"
                                    print "Fallan en ${_env} estas aplicaciones:"
                                    print "${AplicacionesFalloTesteo}"
                                    
                                    print "INFO de PROVEEDORES con ERRORES de TESTEO en ${_env}"
                                    print "${InfoErroresTesteo}"
                                    error ("Fallos de testeo")
                                            
                                  }
                                  
                                   
                                   
                                   if (PaquetesSinPromote != "" &&  AplicacionesFalloTesteo == "")
                                    {
                                     print "****************************************************************"
                                     print "Estos paquetes no están promocionados en el entorno preproductivo"
                                     print "${PaquetesSinPromote}"
                                     print "****************************************************************"
                                     error ("Paquetes en estados incorrectos, pero testeo correcto")
                                    }
                                    if (PaquetesSinPromote != "" &&  AplicacionesFalloTesteo != "")
                                    {
                                        print "****************************************************************"
                                        print "Estos paquetes no están promocionados en el entorno preproductivo"
                                        print "${PaquetesSinPromote}"
                                        print "****************************************************************"
                                         
                                        sh "scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt ${RutaPaquete}"
                                        InfoErroresTesteo= readFile(file: "${RutaPaquete}/InfoErroresTesteo.txt")
                                  
                                        print "****************************************"
                                        print "         TESTEO INCORRECTO"
                                        print "****************************************"
                                        print "Se han analizado estas aplicaciones:"
                                        print "${Tipos}"
                                        print "Fallan en ${_env} estas aplicaciones:"
                                        print "${AplicacionesFalloTesteo}"
                                        
                                      //  print "INFO de PROVEEDORES con ERRORES de TESTEO en ${_env}"
                                        print "${InfoErroresTesteo}"
                                        error ("Fallos de testeo y Paquetes en estados incorrectos")
                                         
                                    }
                                    if  (AplicacionesFalloTesteo == "" )
                                   {
                                    print "********************************************"
                                    print "         TESTEO CORRECTO"
                                    
                                    for (pos = 0; pos < TipoDespliegues.size(); pos++) {
                                        _domain = TipoDespliegues[pos]
                                        _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
                               
                                        print "Para la aplicacion ${_domain}"
                                        print "Los paquetes son ${_listado}"
                                        
                                        if (_domain =="BIZTALK-IIS" || _domain =="BIZTALK2020-IIS")
                                         {   
                                            _Tipo=(_domain.split("-")[-1]) 
                                            _App = readFile(file: "${RutaPaquete}/proyectos_${_CRQ_ID}_${_Tipo}_BT")
                                           
                                           if (_App != "")
                                           {  
                                               print "Aplicaciones a parar durante el CRQ"
                                               print "${_App}"
                                           }
                                         }
                                        print " "
                                       }//for
                                    print "********************************************"
                                   }
                                   
                              }//opcion 1
                              
                              if  ( _opcion == "2")
                              {
                                   if (PaquetesSinPromote != "" )
                                    {
                                     print "****************************************************************"
                                     print "Estos paquetes no están promocionados en el entorno preproductivo"
                                     print "${PaquetesSinPromote}"
                                     print "****************************************************************"
                                     error ("Paquetes en estados incorrectos")
                                    }
                              }

                   } //scripts
                }//steps
            }//Testeo
            stage("EditPackage"){
                agent {
                    node("BIZTALK")
                        }

                steps{
                    script {
                        
                   
                        if(_opcion=="3" && _env=="PROD" ) {
                           
                             
                            print "Edito los paquetes "
                            
                            EditPackage(_CRQ_ID, _View, _listapaquetes, false, false, _NomVista,mybuilduser,_pass)
                            PromotePROD=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PromotePROD.txt")
                            Notif=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/Todos.txt")
                            if (PromotePROD != "")
                            { //Paquetes a promocionar
                                promoteApi("${mybuilduser}","10", '"'+PromotePROD+'"',_pass)
                            }
                            if (Notif  != "")
                            { //Paquetes a promocionar
                                notifApi("${mybuilduser}",'"'+Notif+'"',_pass)
                                promoteApi("${mybuilduser}","10", '"'+Notif+'"',_pass)
                            }
                            
                            EditPackage(_CRQ_ID, _View, _listapaquetes, true,false, _NomVista,mybuilduser,_pass)
                            PaquetesIncorrectos=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PaquetesIncorrectos.txt")
                            if (PaquetesIncorrectos != "" )
                            {
                                print "Check following package that can not be promoted automatically"
                                print "${PaquetesIncorrectos}"
                            }
                                print "******************************"
                                print "Elegida opcion 3 de VERSIONADO"
                                print "Nombre del parche ${_CRQ_ID} "
                                print "******************************"
                             
                        }//SI es opcion 3
                    }//scripts
                }//steps
          }//etiquetar

            
        
          
         }//stages
        }//pipeline
    }//map
                        

