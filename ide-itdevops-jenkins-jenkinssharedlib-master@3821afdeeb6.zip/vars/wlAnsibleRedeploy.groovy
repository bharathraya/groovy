

def call(jobDeployEnv,ansibleDir,artifact)
{
    dir(ansibleDir){
            sh "ansible-playbook -i inventories/${jobDeployEnv}/hosts redeploy.yml --extra-vars \"deployment_env=${jobDeployEnv} deployment_artifact=${artifact}\""
    }
}
return this;