def call (String _delivery, String _app){
     node ('es1117yw'){
        //Usuario
        wrap([$class: 'BuildUser']) {
             echo "Exec user: ${env.BUILD_USER_ID}"
             _usuario=env.BUILD_USER_ID
           }
        //Contraseña
         (_pass,_usuario)=findpassword(_usuario)
        
        checkout scm
        
        dir ("CDM/CommonTools/WorkBenchClient"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                
                bat "python get_app_deliveryenv.py -d ${_delivery} -a ${_app} -u ${_usuario} -c ${_pass} "
                
             }//wrap
        }
    }
}
