import vfes.git.VFESGitRepo

def call(String _TAG, String _COMMIT, VFESGitRepo _repo) {
  echo "GitTag2"
    // get old commitid

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${_repo.pushCred}",
            usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
        sh "git remote set-url origin ${_repo.protocol}://${USERNAME}:${PASSWORD}@${_repo.server}/${_repo.repoPath}/${_repo.repoName}"
    }
    def _remotetags=sh(returnStdout: true, script: """
            git ls-remote --tags origin |cut -d"/" -f3
        """).split("\n").collect{it}
    echo "REMOTE_TAGS:${_remotetags}"
    
    if ("${_TAG}" != ""){
        
        def existetag=sh returnStdout: true, script: """
            git tag -l ${_TAG}
        """
        // deletes current snapshot tag
        if ("${existetag}" != ""){

            sh ("git tag -d ${_TAG} || true")
        }
        // tags current changeset

        sh ("git tag -f ${_TAG} ${_COMMIT}")
    
        // deletes tag on remote if exist in order not to fail pushing the new one
    
        _remotetags.any{
            if (it == "${_TAG}"){
                sh ("git push --delete origin  ${_TAG}" )
                return true
             }
        }
    }

    // pushes the tags
    sh ("git push origin ${_TAG}")
}
