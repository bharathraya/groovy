 import groovy.json.JsonSlurper

def call(String _SERVER,String _CREDENTIALID, String _ARTID,String _VERSION, String _ENTORNO, String _REPO ) {
    echo "importOCImageVersion"
    def version=""
    def SALIDA=""
    def lowerARTID=_ARTID.toLowerCase()
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${_CREDENTIALID}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
		sh returnStdout: true, script: """
            export PATH=$PATH:/var/lib/jenkins/occli
            export KUBERNETES_NAMESPACE="${_ENTORNO}"
            export KUBECONFIG=${HOME}/.kube/"${KUBECONFIG}"
            #oc login "${_SERVER}" --token="$PASSWORD" --insecure-skip-tls-verify=true >/dev/null 2>&1
    	    #oc project "${_ENTORNO}" >/dev/null 2>&1
            oc --server="${_SERVER}" --token="$PASSWORD" import-image "${lowerARTID}":"${_VERSION}" --from="${_REPO}":"${_VERSION}" --confirm -n="${_ENTORNO}" --insecure=true
	    """
    }

}
