def call(String _bitbucket,String _ORIGEN,String _DESTINO){
	echo "checkCommitDiffRelease"
    def SALIDA=""
    
    if (_ORIGEN=='master'||_ORIGEN=='masterCI'||_ORIGEN=='develop'){
        SALIDA=sh returnStdout: true, script: """
            #git branch -r
            git log "${_DESTINO}..origin/${_ORIGEN}" --pretty=%h --no-merges

        """ 
    }else{
        if (_ORIGEN =~/[A-Za-z_0-9]*-ES[0-9]*[A-Za-z_]*/ || _ORIGEN=~/ES[0-9]*[A-Za-z_]*/ || _ORIGEN=~/ES[0-9]*[A-Za-z_]*-RC/){
            SALIDA=sh returnStdout: true, script: """
                #git branch -r
                if [ "${_bitbucket}" != "bitbucket" ]
                then
                    git log "${_DESTINO}..origin/vodafone/${_ORIGEN}" --pretty=%h --no-merges
                else
                    git log "${_DESTINO}..origin/release/${_ORIGEN}" --pretty=%h --no-merges
                fi
            """ 
        }else{
            if (_ORIGEN =="SIT1" || _ORIGEN =="SIT2" ||_ORIGEN =="PPRD" ){
                SALIDA=sh returnStdout: true, script: """
                    #git branch -r
                    git log "${_DESTINO}..origin/vodafone/${_ORIGEN}" --pretty=%h --no-merges
        
                """ 
            }else{
                SALIDA=sh returnStdout: true, script: """
                    #git branch -r
                    git log "${_DESTINO}..origin/${_ORIGEN}" --pretty=%h --no-merges
        
                """ 
            }
        }
    }
	def lista = SALIDA.split("\n").collect{it.trim()}
	return lista
}