import vfes.utils.VFESALMSDeployment

def call(Map config,VFESALMSDeployment alms) {
    def plataforpath=""
    def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    def envConfig=myEnvsConfig[alms.deployEnv]
        
        
    sh """
        find ${config.extractFolder} -type f | grep -v /.git/ |  zip -q -r ${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}.zip -@;
        """

    if (alms.deployEnv != 'master' && alms.deployEnv != 'HID1' && alms.deployEnv != 'masterCI' && alms.deployEnv != 'HID1CI'  ) {
        
        envConfig.release.each { item ->
            echo "Deploying up on ${item.server} ..."
            sh """
                ssh -q -o StrictHostKeyChecking=no  ${item.server} "mkdir -p /home/plataforma/jenkins/tmp/job-${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}/"
                """
            sh "scp ${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}.zip ${item.server}:/home/plataforma/jenkins/tmp/job-${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}/ 2>/dev/null"
            sh """
                ssh -o StrictHostKeyChecking=no -l ${item.username}  ${item.server} \
                'cd ${item.path}; \
                rm backup-jenkins-${alms.almsID}-${alms.deployEnv}-*.zip
                zipinfo -1 /home/plataforma/jenkins/tmp/job-${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}/${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}.zip | zip -q backup-jenkins-${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}.zip -@;\
                unzip -q -o /home/plataforma/jenkins/tmp/job-${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}/${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}.zip;'
                """
            sh """
                ssh -q -o StrictHostKeyChecking=no  ${item.server} "rm /home/plataforma/jenkins/tmp/job-${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}/*.zip"
                """
        }
    }
    sh "rm -f ${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}.zip"
}
