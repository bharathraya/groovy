def call(String _Cadena, String _Entorno){
	echo "getResouceFileList"
    def lista=""
    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
        find ${_Cadena} -type f |grep /${_Entorno}/ && find ${_Cadena} -maxdepth 2 -type f |sort -r
        
    """
    lista = SALIDA.split("\n").collect{it}
	return lista
}