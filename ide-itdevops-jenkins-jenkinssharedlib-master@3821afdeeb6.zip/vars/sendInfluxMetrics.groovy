def call(String environment_name, String squad_name){
	echo "Influx disabled"
}