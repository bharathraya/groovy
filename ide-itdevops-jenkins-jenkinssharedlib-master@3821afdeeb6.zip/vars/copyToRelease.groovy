import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and 
// executes it 
// The .sh file is created through a template that is taken from config.releaseDeployTemplate 
def call(Map config,VFESALMSDeployment alms)
{
    for (i=0;i<config.artifactId.size();i++){
        //meguiza2
        echo " cual es el workspace ${WORKSPACE}"
        echo "cual es el fichero de configuracion ${config.releaseConfig}"
        
        def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
        def _envConfig=myEnvsConfig[alms.deployEnv]
        echo "_envConfig"+_envConfig
        dir(config.extractFolder) {

            _envConfig['release_servers'].each { item ->
                // ${zip2deploy}
                // ${rootPath}
                // ${deployPath}
                // ${appName}
                // ${alms}
                
                def pname=config.releaseFolder.substring(config.releaseFolder.lastIndexOf("/")+1)
                def dpath=config.releaseFolder.substring(0, config.releaseFolder.lastIndexOf("/"))
                def variables = [ 'zip2deploy' : "${config.distFile[i]}",
                'rootPath' : "${item.release_path}/${dpath}",
                'deployPath' : "${pname}",
                'appName' : "${alms.appName}",
                'alms' :  "${alms.almsID}"
                ]
                
                def template = libraryResource("${config.releaseDeployTemplate}")
                //render the template  for the item (server etc) into string variable
                def strDeployScript=helpers.renderTemplate(template, variables)
                def scriptName="${item.release_server}.${alms.appName}.${alms.almsID}.${alms.jobTimeStamp}.sh"
                
                // Create script from string variable ...
                sh """#!/bin/sh
                echo '${strDeployScript}' > ${scriptName}
                chmod 755 ${scriptName}
                """
                // push template and zip file to server 
                sh "scp ${config.distFolder[i]}/${config.distFile[i]} ${item.release_user}@${item.release_server}:${item.release_path}/${dpath} " 
                sh "scp ${scriptName} ${item.release_user}@${item.release_server}:${item.release_path}/${dpath} " 
                echo "Deploying ${alms.appName} ${alms.almsID} ${item.release_user}@${item.release_server}:${item.release_path}/${dpath}/${scriptName}"
                
                sh "ssh -q -o StrictHostKeyChecking=no ${item.release_user}@${item.release_server} '${item.release_path}/${dpath}/${scriptName}' "
                
            
            }
        }
    }
}