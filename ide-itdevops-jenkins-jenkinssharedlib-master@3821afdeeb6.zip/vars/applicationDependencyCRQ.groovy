def call (String _Nombre,String _lista){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "echo %PATH%"
            bat "python get_applicationDependencyCRQ.py -p ${_lista} -c ${_Nombre}"
        }
    }
}
