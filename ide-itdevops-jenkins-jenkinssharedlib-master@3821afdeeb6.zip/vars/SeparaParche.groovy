def call(String _NombreCRQ){
   hoy=new Date().format( 'yyyyMMdd' )
   RutaTemp="/home/plataforma/plausr/tmp"
   RutaPaquete="${RutaTemp}/${hoy}/${_NombreCRQ}"
   _listapaquetes=readFile(file: "${RutaPaquete}/${_NombreCRQ}_ListaPaquetes.txt")
   //lanzo funcion de separar

   //get_applicationCRQ "${_NombreCRQ}", _listapaquetes
   get_applicationCRQ(_NombreCRQ,'"' + _listapaquetes + '"')
   
   sh "touch -f ${RutaPaquete}/${_NombreCRQ}_tipos"
   //Tengo el listado en es036tvr
   sh " scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_NombreCRQ}/ListaPaquetes.txt ${RutaPaquete}/ListaPorDominio.txt"
  // sh "ls -l ${RutaPaquete}/ListaPorDominio.txt"
    //  print "modulo ${Modulo}"
          try{
              sh " grep -v '^CRM AMDOCS:' ${RutaPaquete}/ListaPorDominio.txt > ${RutaPaquete}_PaquetesIncorrecto.txt "
            } catch(Exception e){
                                 echo " Todos los paquetes son de CRM AMDOCS: ${e}" 
                                    }    
        PaquetesErroneos=readFile(file: "${RutaPaquete}_PaquetesIncorrecto.txt")   
        if (PaquetesErroneos != "" )
        { 
         print "HAY PAQUETES DE OTRAS APLICACIONES"
         print "${PaquetesErroneos}"
         error ("HAY PAQUETES DE OTRAS APLICACIONES")
        }
        //Tipos de aplicaciones
        TiposConfig=readFile(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/TiposAmdocs.yml")
        TiposAmdocs=TiposConfig.split()
        print " Fichero spliteado ${TiposAmdocs}"
        total=TiposAmdocs.size()
        print "tipos de amdocs ${total}"
        for (pos = 0; pos < total; pos++) { 
            mydomain="${TiposAmdocs[pos]}"
            print "Analizamos tipo ${mydomain}"
            sh " touch -f ${RutaPaquete}/${_NombreCRQ}_${mydomain}"
            try{
            sh " grep '^CRM AMDOCS:${mydomain}:'  ${RutaPaquete}/ListaPorDominio.txt > ${RutaPaquete}/${_NombreCRQ}_${mydomain}_tmp "
            
            } catch(Exception e){
                                 echo " No hay paquetes de ${mydomain} : ${e}" 
                                    } 
            Paquetes_domain = "Paquetes_${mydomain}"
            Paquetes_domain=readFile(file: "${RutaPaquete}/${_NombreCRQ}_${mydomain}_tmp")
            if (Paquetes_domain != "")
            {   
                sh "cut -d: -f3 ${RutaPaquete}/${_NombreCRQ}_${mydomain}_tmp > ${RutaPaquete}/${_NombreCRQ}_${mydomain}"
                sh "cat ${RutaPaquete}/${_NombreCRQ}_${mydomain} | tr '\n' ' ' >> ${RutaPaquete}/${_NombreCRQ}_${mydomain}_temp ; mv ${RutaPaquete}/${_NombreCRQ}_${mydomain}_temp ${RutaPaquete}/${_NombreCRQ}_${mydomain} ; rm -f ${RutaPaquete}/${_NombreCRQ}_${mydomain}_temp "
                sh "echo ${mydomain} >>  ${RutaPaquete}/${_NombreCRQ}_tipos "
                
            }  
            else
            {
                sh "rm -f  ${RutaPaquete}/${_NombreCRQ}_${mydomain}"
            }
            sh "rm -f ${RutaPaquete}/${_NombreCRQ}_${mydomain}_tmp"
        }//for
        
        
   
    
}
