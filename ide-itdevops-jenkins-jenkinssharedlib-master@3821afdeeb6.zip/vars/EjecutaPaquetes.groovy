#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def _listapaquetes=""
def _NomVista=""
def hoy=""
def mybuilduser=""
def _pass=""
def _formatoHora=""
def SeparaPaquete=""
def tam=""
def pos=""
def Paquete=""
def ComPaquete=""
def _Paquete=""
def String _Tipo=""
def String _Env=""
def NomPaquete=""
def Datos =""
def DatosSplit =""
def  Estado =""
def String Entorno =""
def String Tipo =""
def JobResult =""
def iError=0


def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            text(name: 'List_Packages', defaultValue: '', description: 'Listado de paquetes a tratar Paquete:tipo:Entorno')
          //  string(name: 'Vista', defaultValue: '', description: 'Nombre de la vista de paquetes') 
         }
         
         stages{     
         stage("Prepare"){
                agent {
                    label 'AMDOCS'
                        }
                steps{
                script {
                     //Saco el ejecutor
                     wrap([$class: 'BuildUser']) {
                         echo "Exec user: ${env.BUILD_USER_ID}"
                         mybuilduser=env.BUILD_USER_ID
                       }
                        //Contraseña
                         (_pass,mybuilduser)=findpassword(mybuilduser)
                       
                        _listapaquetes=params.List_Packages
                       
                       // _NomVista=params.Vista.trim()
                        _NomVista=""
                        hoy=new Date().format( 'yyyyMMdd' )
                        
                        print "La fecha de hoy es ......${hoy}......"
                        print "La lista de paquetes: ${_listapaquetes}"
                        
                        //Configuramos el nombre del build y su descripcion
                        if (_NomVista !="")
                        {
                            currentBuild.displayName = "Executed Date: ${hoy} View ${_NomVista} "
                        }
                        else
                        {
                            currentBuild.displayName = "Executed Date: ${hoy}  "
                        }
                        currentBuild.description = "Executed by ${mybuilduser} "

                }//script
              }//step
            }//prepare
            
            stage("Promocionar"){ //
                agent {
                    node("AMDOCS")
                        }

                steps{
                    script {   
                               _formatoHora = new Date().format("yyyyMMddHHmmss");
                              // print " fecha total ${_formatoHora}"

                               sh "mkdir -p /home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}"
                               sh "touch -f /home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Tratados.txt"
                               SeparaPaquete = _listapaquetes.split("\n")
                               //print "Agrupacion lineas ${SeparaPaquete} "
                               tam=SeparaPaquete.size()
                               //print "tamaño ${tam}"
                               for (pos = 0; pos < SeparaPaquete.size(); pos++) {
                                   iError=0
                                    print "Paquete ${pos} de ${tam} "
                                    Paquete = SeparaPaquete[pos]
                                    ComPaquete=Paquete.split(":")
                                    _Paquete=ComPaquete[0]
                                    print "Paquete ${_Paquete} "
                                    _Tipo=ComPaquete[1] 
                                    print "Tipo ${_Tipo} "
                                    _Env=ComPaquete[2] 
                                    print "Entorno ${_Env} "
                                    
                                    //Lanzmaos lo que busca los datos
                                    //NomPaquete="Ejecucion_${hoy}_${_Paquete}"
                                    // print "Nombre del paquete ${NomPaquete}"
                                    // get_applicationCRQ(NomPaquete,'"' + _Paquete + '"',mybuilduser,_pass)
                                    // sh " scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${NomPaquete}/ListaPaquetes.txt /home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Datos_${_Paquete}.txt"
                                    //Datos=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Datos_${_Paquete}.txt")
                                    //    DatosSplit=Datos.split(":")
                                    
                                    //  Estado=DatosSplit[3]
                                    //print "estado en el fichero ${Estado}"
                                    //    Entorno=DatosSplit[4].trim()  
                                    //print "Entorno en el fichero ${Entorno}"
                                    //   Tipo=DatosSplit[1]
                                    //print "Tipo en el fichero ${Tipo}"
                                   
                                    wbpckinfo=get_workbench_package_info(_Paquete) 
                                    Estado=wbpckinfo.Data.Model.Model.Base.Status.Name
                                    print "Estado actual ${Estado}"
                                    Entorno=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
                                    print "Entorno actual ${Entorno}"
                                    Tipo=wbpckinfo.Data.Model.Model.Base.Application.Description
                                    print "Tipo actual ${Tipo}"
                                    
                                    
                                    print "************************************************************"
                                    print "Revisamos que los datos coinciden el actual con los enviados ${_Paquete}"
                                    print "Tipo actual ${Tipo} vs Tipo enviado ${_Tipo}"
                                    print "Entorno actual ${Entorno} vs Entorno enviado ${_Env}"
                                    print "Estado  actual ${Estado} "
                                    print "************************************************************"
                                    
                                    if ("${Estado}" == "Pending migration" && "${Entorno}" == "${_Env}" && "${Tipo}"=="${_Tipo}" )
                                    {   
                                        
                                        //paso a migrating 
                                        print "Paso a migrating el paquete ${_Paquete}"
                                        try{
                                                promoteApi("${mybuilduser}","7", '"'+_Paquete+'"', _pass)
                                           } catch(Exception e){
                                                print "No se ha podido cambiar de estado a migrating"   
                                                 iError=1
                                                sh "echo '${_Paquete}:NO TRATADO' >>/home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Tratados.txt "
                                        }    
                                       
                                       if (iError == 0 )
                                       {
                                           //si esta pendiente de migracion y en el entorno que dice y el tipo que dice 
                                            JobResult = build job: 'WB.Amdocs_deployment', parameters: [string(name: 'WB_ID', value: "${_Paquete}"), string(name: 'Application', value: "${_Tipo}"),  string(name: 'Enviroment', value: "${_Env}") ,  string(name: 'List_Packages', value: "${_Paquete}"),  extendedChoice(name: 'Check_Dependences', value: 'YES')], propagate: false
                							
                							print " Resultado del job ${JobResult.getResult()}"
    					
    				                    	if ("${JobResult.getResult()}" != 'SUCCESS') {
                							     print "Paso a fallo migración el paquete ${_Paquete}" 
                                                  try{
                                                        promoteApi("${mybuilduser}","12", '"'+_Paquete+'"', _pass)
                                                    } catch(Exception e){
                                                         print "No se ha podido cambiar de estado a fallo migracion"   
                                                         iError=2
                                                         sh "echo '${_Paquete}:FALLO MIGRACION HAY QUE ACTUALIZAR ESTADO' >>/home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Tratados.txt "
                                                  }
                                                  if (iError==0)
                                                  {
                                                    sh "echo '${_Paquete}:FALLO MIGRACION' >>/home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Tratados.txt "
                                                  }
    				                    	}
                                           else {
                                                print "Paso a promoted el paquete ${_Paquete}" 
                                                 try{
                                                    promoteApi("${mybuilduser}","10", '"'+_Paquete+'"', _pass)
                                                    } catch(Exception e){
                                                         iError=3
                                                         print "No se ha podido cambiar de estado a Promoted"   
                                                         sh "echo '${_Paquete}:PROMOCIONADO HAY QUE ACTUALIZAR ESTADO' >>/home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Tratados.txt "
                                                    }
                                                     if (iError==0)
                                                      {
                                                        sh "echo '${_Paquete}:PROMOCIONADO' >>/home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Tratados.txt "
                                                      }
                                           }
                                       }//se ha podido cambiar el estado
                                       
                                    } //esta pendiente de migracion
                                    else
                                    {
                                        //paso a migrating 
                                        print "No trato el paquete ${_Paquete}"
                                    }
                    }//for


                    PaqTratados=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/ejecucion_${_formatoHora}/Tratados.txt")
                    print "Paquetes tratados"
                    print "${PaqTratados}"
    

                        
                }//scripts
                }//steps
          }//etiquetar
         }//stages
        }//pipeline
    }//map
                        
