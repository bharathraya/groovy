def call(String _Alms,String _Env,_Pvcs,String _remoteServer,String _date){

    def PVCS_module_name=""
    def PVCS_path=""
    def pos=0
    def file_content=""
    
    print "DEBUG: Modulos pvcs ${_Pvcs}"
    
    for (pos = 0; pos < _Pvcs.size(); pos++) {
        PVCS_module_name = _Pvcs[pos].WorkFile;
        PVCS_path = _Pvcs[pos].Archive
        
        print "DEBUG pvcs_module {PVCS_module_name}"
        print "DEBUG path {PVCS_path}"
        file_content="${file_content} echo \${DIR_BASE_PAQUETE}/${_date}/${_Alms}/${PVCS_path}/${PVCS_module_name} >> ${_Alms};"
        
        print "DEBUG contenido_fichero {file_content} "
    }

    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    if [ -f \${DIR_BASE_TMP_COMP}/${_Alms} ]
    then
        echo 'Already exist the file \${DIR_BASE_TMP_COMP}/${_Alms}. deleting it'
        rm -f \${DIR_BASE_TMP_COMP}/${_Alms} 
    fi
    cd \${DIR_BASE_TMP_COMP}
    if [ ${file_content} != "" ]
    then
        ${file_content}
    fi
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }


	//find /home/plataforma/plausr/data/paquetes/20190809/774/PPRD/* -type f >> /home/plataforma/plausr/tmp/774 2>/dev/null

    /*
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    find \${DIR_BASE_PAQUETE}/${_date}/${_Alms}/${_Env}/* -type f >> \${DIR_BASE_TMP_COMP}/${_Alms} 2>/dev/null
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
    */
}
