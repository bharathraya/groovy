def call(String _CRQ, String _Carpeta, String _listado){
    
   hoy=new Date().format( 'yyyyMMdd' )
 //  print "Today is ${hoy}"
 //  print "Parametro CRQ  ${_CRQ}"
 //  print "Parametro  _Carpeta ${_Carpeta}"
 //  print "Parametro  _listado ${_listado}"
   
    Agrupacion=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ}/agrupacion_paquetes_final_${_Carpeta}")
    ListaIIS=_listado.split()
   //print "Lista de paquetes IIS ${ListaIIS} "
   //Tam=ListaIIS.size() 
   //print "Cuantos paquetes hay de IIS ${Tam} "
    for (pos = 0; pos < ListaIIS.size(); pos++) {
         Paquete=ListaIIS[pos]
           if  (! Agrupacion.contains(Paquete))       
           {
                error("El paquete ${Paquete} NO se está en el fichero: agrupacion_paquetes_final_${_Carpeta}")
           }
           else 
           {
               print "El paquete ${Paquete} esta en el contenido"
           }

     }//fin del for


       
}
