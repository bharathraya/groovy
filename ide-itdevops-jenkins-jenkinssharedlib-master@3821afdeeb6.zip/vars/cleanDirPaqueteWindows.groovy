def call(String _Alms,String _remoteServer,String _Today){
    node("${_remoteServer}") {
    	dir("c:\\home\\plataforma\\plausr\\data\\paquetes\\${_Today}\\${_Alms}"){
      	  deleteDir()
        }
    }
}
