def call(String repoUrl)
{
    def result=""
    switch (repoUrl) {
        case ~/^.*eswltbhr.*$/:
            result="vfjenkins-passwd"
            break
        case ~/^.*195.233.178.75:8282.*$/:
            result="vfjenkins-passwd"
            break
        case ~/^.*bitbucket.agile.vodafone.com.*$/:
            result="essvc.essvc-devops-URLEncode"
            break

    }
    return  result
}
