#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever
import groovy.time.TimeCategory


 
def call(Map pipelineParams){
    pipeline{
         agent none
         parameters { 
            string(name: 'PACKAGE', defaultValue: '', description: 'PAQUETE IIS o BT a desplegar') 
            choice(name: 'ENVIROMENT',  choices: pipelineParams.EnviromentChoices , description: 'Entorno a desplegar') 
          //  choice(name: 'OPTION',  choices: pipelineParams.OptionChoices , description: 'Elige las opciones:1. COMPILAR 2. BACKUP 3. DESPLEGAR') 
            
         }
    stages{     
         stage("DEPLOY"){
                agent {
                    label 'BIZ2016'
                        }
                steps{
                script {
                
                 //Leo los parametros
                _CRQ_ID=params.PACKAGE.trim()  
               // _opcion=params.OPTION
                _env=params.ENVIROMENT
                
                _opcion="COMPILAR"
                hoy=new Date().format( 'yyyyMMdd' )
                currentBuild.displayName = "CRQ: ${_CRQ_ID} Dia: ${hoy} Entorno ${_env}"
                currentBuild.description = "CRQ: ${_CRQ_ID} Dia: ${hoy} Entorno ${_env}"
                
           

                print "La fecha de hoy es ......${hoy}......"
                print "Se ha elegido el paquete ${_CRQ_ID} en el entorno ${_env} la opcion ${_opcion}"
                _domain ="BIZTALK-IIS"
                _DomBiz="BIZ2016"
               _Release="Release"
               
               if (_env != "PROD" && _opcion != "COMPILAR" )
               {
                   error("Para el entorno ${_env} solo se puede elegir la opcion DESPLEGAR")
               }
               
               //PROD
               if (_env == "PROD")
               {
                dir ("C:/home/platafor/release/scripts/Compile"){
    	       
        	       if (_opcion =="COMPILAR")
        	       {
        	              print "Vamos a COMPILAR el paquete ${_CRQ_ID} en ${_env}"
        	              print "EJECUTAMOS c:\\home\\platafor\\release\\scripts\\Compile\\Master-COMP.ps1 -d ${_DomBiz} -t  ${_domain} -e ${_env} -p ${_CRQ_ID} -c ${_Release} -onlycomp \$true -password \"Svcbtspass2\" " 
                          bat(returnStatus: true,script:"powershell.exe -ExecutionPolicy ByPass -File c:\\home\\platafor\\release\\scripts\\Compile\\Master-COMP.ps1 -d ${_DomBiz} -t  ${_domain} -e ${_env} -p ${_CRQ_ID} -c ${_Release} -onlycomp \$true -password \"Svcbtspass2\" " )
                        //                                                                                                                         .\Master-COMP.ps1 -d "BIZ2016" -t "BIZTALK-IIS" -e "PROD" -p "iis16_7" -c "Release"  -onlycomp $true  -password "Svcbtspass2"

                    }//COMPILAR
                  }   //dir      
               }
               else
               { //PARA NO PROD
                  dir ("C:/home/platafor/release/scripts/Compile"){
        	           print "EJECUTAMOS c:\\home\\platafor\\release\\scripts\\Compile\\Master-COMP.ps1 -d ${_DomBiz} -t  ${_domain} -e ${_env} -p ${_CRQ_ID} -c ${_Release}"
                        bat(returnStatus: true,script:"powershell.exe -ExecutionPolicy ByPass -File c:\\home\\platafor\\release\\scripts\\Compile\\Master-COMP.ps1 -d ${_DomBiz} -t  ${_domain} -e ${_env} -p ${_CRQ_ID} -c ${_Release}")
                      } //dir

                   
               }
           }//script
          }//step
        }//prepare

  }//stages
 }//pipeline
}//map
               


