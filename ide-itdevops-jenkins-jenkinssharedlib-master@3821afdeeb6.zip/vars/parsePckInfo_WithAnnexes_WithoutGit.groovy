def call(String _pckinfo)
{
    def mypckinfo=readJSON(text:_pckinfo)
    def mydeploy_env=""
    def myalms_id=mypckinfo.Id.toString()
    def mydelivery=""
    def myproject_id=""
    def mysquad=mypckinfo.EnterpriseName
    def myannexes=""
    def mymodules=""

    
    
    
    if (mypckinfo.containsKey("Application")){
        mydeploy_env=mypckinfo.DeployEnvironment.Name
        mydelivery=mypckinfo.Delivery.Name
        myproject_id=mypckinfo.Project.CodProject
    }
    else{
        wbpckinfo=get_workbench_package_info(myalms_id)
        mydeploy_env=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
        mydelivery=wbpckinfo.Data.Model.Model.Base.Project.Delivery.Name
        myproject_id=wbpckinfo.Data.Model.Model.Base.Project.CodProject
        myannexes=wbpckinfo.Data.Model.Model.Annexes
        mymodules=wbpckinfo.Data.Model.Model.Modules
    }

    // we return multiple values from this fucntion. later values should be 
    // taken like : (a,b,c,d)=fucntion(param)
    return [mydeploy_env,myalms_id,mydelivery,myproject_id,mysquad,myannexes,mymodules]
   
}