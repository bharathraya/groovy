def call (String User, String passw, String ruta , String type, String paquete ){
    
    node ('es1117yw'){
      
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts/"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: passw ]]]) {
                 bat "python modify_package_amdocs.py -u ${User} -c ${passw}  -p ${paquete} -d ${ruta} -t ${type}"
            }//wrap
        }
    }
}
