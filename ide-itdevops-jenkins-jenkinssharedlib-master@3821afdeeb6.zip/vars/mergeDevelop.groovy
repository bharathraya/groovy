import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo
import vfes.utils.VFESALMSDeployment

def call(VFESGitRepo gitRepo, String BASEDIR, VFESALMSDeployment almsPackage, String SourceEnv) {
    echo "mergeDevelop"
    //merge develop
    def OLDCOMMIT=""
    final String GITLAB="Gitlab"
    final String BITBUCKET="Bitbucket"
    final String INTEGRATION_BB_PREFIX="vodafone"
    final String RELEASE_BB_PREFIX="release"
    final String FEATURE_BB_PREFIX="feature"
    final String REGEX_RELEASE=  /ES[0-9]*[A-Za-z_]*/
    final String REGEX_RELEASE_TEAM= /[A-Za-z_0-9]*-ES[0-9]*[A-Za-z_]*/
    final String REGEX_MASTER_DEVELOP= /(master|masterCI|develop)/    
    final String REGEX_ENVIRONMENTS= /(SIT1|SIT1CI|PPRD|PPRD1|PPRDCI|PPRD1CI|SIT2|SIT2CI|HID|HID1|HIDCI|HID1CI)/
	def _branch="develop"
    def _localBranch=_branch
    def _remoteBranch=_branch


    def jobTimeStamp=almsPackage.jobTimeStamp
    def ENTORNO=almsPackage.deployEnv.toLowerCase()
    def _SortCommit=almsPackage.commitID.substring(0,7)
    def PACKAGE=almsPackage.almsID
    def _Aplicacion=almsPackage.appName
    def mergeMessage="[${PACKAGE}][${jobTimeStamp}][${ENTORNO}][${almsPackage.deliveryID}][${almsPackage.projectID}]"
 
    if ("${almsPackage.almsID}" != "" && "${ENTORNO}" == "prod"){
        
        def packageTag="develop-PACKAGE-${PACKAGE}"
        def checkTag="develop.${_SortCommit}"
        def existetag=""
        dir("${BASEDIR}/${_Aplicacion}"){
            existetag=sh returnStdout: true, script: """
                git tag -l ${checkTag}
            """
        }
	
        if (existetag.trim() == ""){
	        //crear develop tag

    		vfRepoPath=gitRepo.repoPath
            if (gitRepo.repoType==GITLAB){
                vfRepoPath=(gitRepo.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
            }    
            if (gitRepo.repoType==BITBUCKET  && !(_branch=='master'||_branch=='masterCI' || _branch=='develop')){
                if(_branch =~ REGEX_RELEASE || _branch =~ REGEX_RELEASE_TEAM){
                    _remoteBranch=RELEASE_BB_PREFIX+"/"+_branch
                }else{
                    _remoteBranch=INTEGRATION_BB+"/"+_branch
                }
            }

            sh returnStdout: true, script: """
                mkdir ${BASEDIR}/develop_${_Aplicacion}
            """
            dir(BASEDIR){
                //checkout develop
                gitRepo.cloneBranchToLocalFolder("develop_${_Aplicacion}","develop")
            }
            dir("${BASEDIR}/develop_${_Aplicacion}"){	
                //merge		
                mergeCommitID=getGitMergecommitfromCommit(_SortCommit, SourceEnv,almsPackage.deliveryID )
            }
            dir(BASEDIR){
                mergeInfo=gitRepo.mergeCommit("develop_${_Aplicacion}",mergeCommitID,mergeMessage)
            }
            dir("${BASEDIR}/develop_${_Aplicacion}"){
                //tag
                vfRepoPath=gitRepo.repoPath
                withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${gitRepo.pushCred}",
                        usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                    sh """
                        git remote set-url origin ${gitRepo.protocol}://${USERNAME}:${PASSWORD}@${gitRepo.server}/${vfRepoPath}/${gitRepo.repoName}
                    """
                }
                def _remotetags=sh(returnStdout: true, script: """
                        git ls-remote --tags origin |cut -d"/" -f3
                """).split("\n").collect{it}
                echo "REMOTE_TAGS:${_remotetags}"
                // tag the packege
                if ("${packageTag}" != ""){    
                    def existetagversion=sh returnStdout: true, script: """
                        git tag -l ${packageTag}
                    """
                    // deletes current version tag
                    if ("${existetagversion}" != ""){
                
                        sh ("git tag -d ${packageTag} || true")
                    }
                
                    sh ("git tag -a ${packageTag} -m \"${mergeMessage}\"")
                    // deletes tag on remote if exist in order not to fail pushing the new one
                    _remotetags.any(){
                        if (it == "${packageTag}"){
                            sh ("git push --delete origin  ${packageTag}" )
                            return true
                        }
                    }
                }
                if ("${checkTag}" != ""){    
                    def existetagversion=sh returnStdout: true, script: """
                        git tag -l ${checkTag}
                    """
                    // deletes current version tag
                    if ("${existetagversion}" != ""){
                
                        sh ("git tag -d ${checkTag} || true")
                    }
                
                    sh ("git tag -a ${checkTag} -m \"${mergeMessage}\"")
                    // deletes tag on remote if exist in order not to fail pushing the new one
                    _remotetags.any(){
                        if (it == "${checkTag}"){
                            sh ("git push --delete origin  ${packageTag}" )
                            return true
                        }
                    }
                }
                // tag the ENV
                def ENTORNOHID="hid"
                if ("${ENTORNOHID}" != ""){    
                    def existetagversion=sh returnStdout: true, script: """
                        git tag -l ${ENTORNOHID}
                    """
                    // deletes current version tag
                    if ("${existetagversion}" != ""){
                
                        sh ("git tag -d ${ENTORNOHID} || true")
                    }
                
                    sh ("git tag -a ${ENTORNOHID} -m \"${mergeMessage}\"")
                    // deletes tag on remote if exist in order not to fail pushing the new one
                    _remotetags.any(){
                        if (it == "${ENTORNOHID}"){
                            sh ("git push --delete origin  ${ENTORNOHID}" )
                            return true
                        }
                    }
                }				
                //push
                sh ("git push --tags origin ${_localBranch}:${_remoteBranch}")
            }
        }
    }
}