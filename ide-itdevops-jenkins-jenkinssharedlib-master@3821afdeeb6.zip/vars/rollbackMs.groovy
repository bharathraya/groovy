def call(Map salidaMs, String oc_cluster){
    echo "rollbackMs"
    withEnv(["PATH+OC=${tool 'occli-jenkins'}","KUBECONFIG=$HOME/.kube/config"]) {
        openshift.withCluster(oc_cluster) {
            echo "Using Cluster: ${openshift.cluster()}"
            //rollback dc
            salidaMs.listrollbackresource.each(){
                def resourcetype=it.kind
                def resourcename=it.metadata.name
                def resourcenamespace=it.metadata.namespace
                openshift.withProject(resourcenamespace) {
                    try{
                        openshift.apply(it)
                        echo "recurso ${resourcetype}/${resourcename} rollback"
                    }
                    catch(e){
                        openshift.delete(it)
                        openshift.create(it)
                    }
                }
            }
            salidaMs.listdeleteresource.each(){
                def resourcetype=it.kind
                def resourcename=it.metadata.name
                def resourcenamespace=it.metadata.namespace
                openshift.withProject(resourcenamespace) {
                    openshift.delete(it)
                    echo "recurso ${resourcetype}/${resourcename} borrado"
                }
            }
        }
    }
}