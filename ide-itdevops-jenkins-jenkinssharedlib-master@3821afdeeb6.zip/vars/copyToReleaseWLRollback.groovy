import vfes.utils.VFESALMSDeployment

def call(Map config,VFESALMSDeployment alms) {
    def plataforpath=""
    def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    def envConfig=myEnvsConfig[alms.deployEnv]
        
        
    if (alms.deployEnv != 'master' && alms.deployEnv != 'HID1' && alms.deployEnv != 'masterCI' && alms.deployEnv != 'HID1CI'  ) {
        
        envConfig.release.each { item ->
           
            sh """
                ssh -o StrictHostKeyChecking=no -l ${item.username}  ${item.server} \
                'cd ${item.path}; \
                unzip -o backup-jenkins-${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}.zip; \
                rm -f  backup-jenkins-${alms.almsID}-${alms.deployEnv}-${alms.jobTimeStamp}.zip;'
                """
        }
    }

}