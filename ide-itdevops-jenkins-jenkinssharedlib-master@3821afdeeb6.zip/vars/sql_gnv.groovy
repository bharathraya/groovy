def call(String _package,String _env,String _remoteServer,String _Aplicacion){
 //Llamada al sql_gnv.sh
 //sql_gnv.sh -d GENEVA-ONO-MAPEOS-BILLING -e <environment> -p <alms_pck>  
  exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_package}
    sql_gnv.sh  -d ${_Aplicacion} -e ${_env} -p ${_package}
    """

    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
