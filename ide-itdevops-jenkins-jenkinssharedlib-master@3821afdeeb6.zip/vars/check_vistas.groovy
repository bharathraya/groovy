def call(String _nombreCarpeta, String Upgrade){


def fichero_e
def hoy
def exec=""

hoy=new Date().format( 'yyyyMMdd' )
//print "Parametros:"
//print "NombreCarpeta: ${_nombreCarpeta}"
//print "Upgrade: ${Upgrade}"

fichero_e="${_nombreCarpeta}.PROD.deploy"
//print "El fichero e: ${fichero_e}"


if ( Upgrade == "NO")
{
    //Creamos directorio en opetst75
    CleanPaquete "${_nombreCarpeta}","opetst75","PROD"
    //Descargar el fichero extraido por WB en es036tvr para el alms y entorno
}
else
{
    //Creamos directorio en crm50tst01
    CleanPaquete "${_nombreCarpeta}","crm50tst01","PROD"
    //Descargar el fichero extraido por WB en es036tvr para el alms y entorno
}
    if (Upgrade == "NO")
    {
         exec="""
              . \$HOME/.profile >/dev/null 2>&1
              . paquete ${_nombreCarpeta} PROD
              scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_e} e
              check_vistas -e PROD -p ${_nombreCarpeta} -W
            """
        sh "ssh -q opetst75 '${exec}'"
    }
    else
    {
        exec="""
              . \$HOME/.profile >/dev/null 2>&1
              . paquete ${_nombreCarpeta} PROD
              scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_e} e
              check_vistas_upgrade -e PROD -p ${_nombreCarpeta} -W
            """
         sh "ssh -q crm50tst01 '${exec}'"
    }
    
}