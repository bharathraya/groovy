import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and 
// executes it 
// The .sh file is created through a template that is taken from config.releaseDeployTemplate 
def call(Map config,VFESALMSDeployment alms)
{
   
   //def _envConfig=myEnvsConfig[alms.deployEnv]
   //_envConfig.deploy_servers.each { item ->
   //   sh "ssh ${item.deploy_user}@${item.deploy_server} '$HOME/deployCatalogo2.sh /home/docker ${alms.deployEnv}'"
   //}
   sh "cd CDM/Ansible ; ansible-playbook -i inventories/${alms.deployEnv}/hosts --extra-vars 'env=${alms.deployEnv}' -l catalogo redeploy_catalogo.yml"

}
