def call(){
    echo "getGitTags"
    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
            git tag --contains || true
    """
    def lista = SALIDA.split("\n").collect{it}
	return lista
}