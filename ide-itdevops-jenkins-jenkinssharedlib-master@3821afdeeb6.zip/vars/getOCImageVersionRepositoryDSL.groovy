def call(String clusterName, String _ARTID,String _VERSION, String _ENTORNO ) {
    echo "CheckOCImageVersionDSL"
    def version=""
    def repo=""
    def lowerARTID=_ARTID.toLowerCase()
    withEnv(["PATH+OC=${tool 'occli-jenkins'}"]) {
        openshift.withCluster(clusterName) {
    	    openshift.verbose()
    	    openshift.logLevel(3)
    	    echo "Using Cluster: ${openshift.cluster()}"
    	    openshift.withProject("${_ENTORNO}") {
    	        echo "Using project: ${openshift.project()}"
    	        def tags = openshift.selector('is', "${lowerARTID}").object().status.tags
            	tags.any{ 
                    echo "Found tag:${it.tag}"
                    if( "${it.tag}" == "${_VERSION}"){   
                        version=it.tag
                        echo "Ya existe la imagen ${_ARTID}:${version}"
                        repo=jsonnexusquery.status.dockerImageRepository
                        return true
                    }
                }
            	if ( version == "")
            	{
            	    echo "Existe la imagen en el repositorio, pero no la version ${_VERSION}"
            	}
            }
        }
    }
    return repo
}
