import vfes.utils.VFESALMSDeployment

def call(Map config,VFESALMSDeployment alms)
{
	def ansibleInstall='ansibleusrbin'
	if (config.containsKey('ansibleInstall')){
		ansibleInstall=config.ansibleInstall
	}
	color="#FFA500" // orange
	message="WorkBench Package: ${alms.almsID}\nStarting restart of WebLogic domains ${config.wl_domains} in environment ${alms.deployEnv}"
	//slackSend(channel: "#es_sq_devops_pruebas", color: color, message: message)
	slackSend(channel: config.slackChannel, color: color, message: message)
	echo "Using ansible install config: "+ansibleInstall
	ansiblePlaybook(
		playbook: 'CDM/Ansible/restart_wl.yml',
		inventory : "CDM/Ansible/inventories/${alms.deployEnv}/hosts",
		installation: ansibleInstall,
		limit:"${config.wl_domains}",
		extras: "-e 'clean_cache=${config.wl_clean_cache} clean_stage=${config.wl_clean_stage}'")
	color="#00FF00" // green
	message="WorkBench Package: ${alms.almsID}\nFinished restart of WebLogic domains ${config.wl_domains} in environment ${alms.deployEnv}"
	//slackSend(channel: "#es_sq_devops_pruebas", color: color, message: message)
	slackSend(channel: config.slackChannel, color: color, message: message)

}