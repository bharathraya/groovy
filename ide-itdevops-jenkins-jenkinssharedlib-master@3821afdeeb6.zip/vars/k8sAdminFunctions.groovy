import vfes.git.VFESGitMergeInfo_aaresmi
import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import org.apache.commons.io.FilenameUtils
import org.apache.commons.lang.RandomStringUtils

def k8sLoadInfoFromFS (Map config)
{
    def k8sObjects = []
    def groups_list=getGroupList()
    groups_list.each { group ->
        def errcode = null
        def stdout = ""
        def stderr = ""
        (errcode,stdout,stderr)=shplus("cd project/${group.name};find . -name *.${config.extensionDeploymentFiles}* -type f ")
        def files = stdout.split()
        files.each { file ->
            def k8sObject=[:]
            def original = FilenameUtils.normalize("${group.name}${file}")
            def dirs=FilenameUtils.getPath(original).split('/')
            def environment=dirs[1]
            def fileName=FilenameUtils.getName(original)
            def unEncryptedFileName = fileName
            def extension=FilenameUtils.getExtension(original)
            def k8sObjectName = ""
            def k8sNameSpace = ""
            def k8sKind = ""

            if (".${extension}" == "${config.extension2decrypt}" ) {
                unEncryptedFileName=FilenameUtils.removeExtension(fileName)
            }

            def k8sData = unEncryptedFileName.split("\\.")
            if (unEncryptedFileName.count('.') == 3) {
                k8sObjectName=k8sData[0]
                k8sNameSpace=k8sData[1]
                k8sKind=k8sData[2]
            } else if (unEncryptedFileName.count('.') == 2) {
                k8sObjectName=k8sData[0]
                k8sKind=k8sData[1]
                k8sNameSpace="Cluster"
            }
            if (k8sObjectName.isEmpty() || k8sNameSpace.isEmpty() || k8sKind.isEmpty())
            {
                echo "ERROR. Bad Format name in the file ${original}"
                sh ("exit 1")
            }

            k8sObject.name = group.name
            k8sObject.original = original
            k8sObject.environment = environment
            k8sObject.k8sObjectName = k8sObjectName
            k8sObject.k8sNameSpace = k8sNameSpace
            k8sObject.k8sKind = k8sKind
            k8sObjects.add(k8sObject)
        }
    }
    return k8sObjects
}

def shplus (String command) {
    String charset = (('A'..'Z') + ('0'..'9')).join()
    Integer length = 9
    String randomString = RandomStringUtils.random(length, charset.toCharArray())
    sh(returnStatus: true, script: "set +x; rm /var/tmp/shplus_stdout_${randomString}.log > /dev/null 2>&1")
    sh(returnStatus: true, script: "set +x; rm /var/tmp/shplus_stderr_${randomString}.log > /dev/null 2>&1")
    def exit_code=sh(returnStatus: true, script: """${command} 2>/var/tmp/shplus_stderr_${randomString}.log 1>/var/tmp/shplus_stdout_${randomString}.log""")
    def stdout = readFile("/var/tmp/shplus_stdout_${randomString}.log").trim()
    def stderr = readFile("/var/tmp/shplus_stderr_${randomString}.log").trim()
    sh(returnStatus: true, script: "set +x; rm /var/tmp/shplus_stdout_${randomString}.log > /dev/null 2>&1")
    sh(returnStatus: true, script: "set +x; rm /var/tmp/shplus_stderr_${randomString}.log > /dev/null 2>&1")
    return [exit_code,stdout,stderr]
}

def getGroupList() {
    def errcode = null
    def stdout = ""
    def stderr = ""
    (errcode,stdout,stderr)=shplus("cd project; ls -1d */")
    def groups_name = stdout.split()
    def groups_list = []
    groups_name.each { group_name ->
        def group_map = [:]
        group_map.name = group_name
        groups_list.add(group_map)
    }
    return groups_list
}

def checkInitialStructure(ArrayList groups_list, Map config) {
    echo "=============================================="
    echo "         REPOSITORY STRUCTURE CHECKS"
    echo "=============================================="
    def group_action_list = []
    groups_list.each { group ->
        def errcode = null
        def stdout = ""
        def stderr = ""
        def group_details_map = [:]
        def actions_details_map = [:]
        def actions_details_list = []

        group_details_map.name = group.name

        actions_details_map.file = "Check Reserved Group Names"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        def isEnvDir = false
        config.validEnvironmentsDirectories.split(',').any { allowedEnvDir ->
            if ("${group.name}" == "${allowedEnvDir}/") {
                isEnvDir = true
                return true
            }
        }

        if (isEnvDir) {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """
            ERROR. Found invalid group name [${group.name}]!!!
            ERROR. Reserved group names are: ${config.validEnvironmentsDirectories}. 
            ERROR. Also can be an error in the grouping. The files must to be grouped. For example:
                        root/group1/PPRD/file1.yaml
                                   /SIT1/file2.yaml
                                   /PROD/file1.yaml
                                   /PROD/file2.yaml
                        root/group2/PPRD/file1.yaml
                                   /PROD/file1.yaml
                                   /PROD/file2.yaml
            """
        }
        actions_details_list.add(actions_details_map)

        actions_details_map = [:]
        actions_details_map.file = "Check invalid environments directories inside groups"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""

        (errcode,stdout,stderr)=shplus("cd project/${group.name}; ls -1d */")

        def environment_envs_name=stdout.split()


        def configured_envs_name = config.validEnvironmentsDirectories.split(',')
        def hasInvalidEnvDir = false
        environment_envs_name.each { envDir ->
            env=envDir[0..-2]
            if (!(env in configured_envs_name))
            {
                echo "hasInvalidEnvDir=true"
                hasInvalidEnvDir=true
            }
        }
        if (hasInvalidEnvDir) {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """ERROR. Found Invalid environment directory inside the group ${group.name}!!!! The valid environemts directories names are: ${config.validEnvironmentsDirectories}"""
        }
        actions_details_list.add(actions_details_map)

        actions_details_map = [:]
        actions_details_map.file = "Check NO environments directories inside groups"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        if (environment_envs_name.size() == 0) {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """ERROR. Not Found any environment directory inside the group ${group.name}!!!! The valid environemts directories names are: ${config.validEnvironmentsDirectories}"""
        }
        actions_details_list.add(actions_details_map)

        group_details_map.put("actionDetails", actions_details_list)
        group_action_list.add(group_details_map)
    }

    return group_action_list
}


def loadCommitInfo(ArrayList groups_list, Map config, VFESGitMergeInfo_aaresmi mergeInfo,ArrayList items2Delete) {
    echo ""
    echo "=============================================="
    echo "          LOAD COMMIT INFO"
    echo "=============================================="
    groups_list.each { group ->
        def AllItemsForGroup = mergeInfo.FilesChangedDetailed.findAll{it[1] =~ "${group.name}"}
        def fileInfo_list=[]
        AllItemsForGroup.each{ file ->
            def fileInfo_map=[:]
            def isDelete = false
            def isRename = false
            def isModify = false
            def original = ""
            def oldName=""
            def gitAction=file[0]
            def isAllowedDelete = false

            if ("${gitAction}" == "A" || "${gitAction}" == "M" ) {
                isModify=true
                original=file[1]
            }
            if ("${gitAction}" == "D") {
                isDelete=true
                original=file[1]
            }
            if ("${gitAction}" == "R") {
                isRename=true
                oldName=file[1]
                original=file[2]
            }

            items2Delete.any { it2dlt ->
                if ("${original}" == "${it2dlt}") {
                    isAllowedDelete=true
                    return true
                }
            }

            def filePath=FilenameUtils.getPath(original)
            def fileName=FilenameUtils.getName(original)
            def unEncryptedFileName=fileName
            def extension=FilenameUtils.getExtension(original)
            def k8sObjectName=""
            def k8sKind=""
            def k8sNameSpace=""
            def environment=""
            def isValidFormatName = false
            def isValidYaml = false
            def isAllowedKind=false
            def isEncrypted=false
            def insideEnvDir=false
            def isDeployableExtension = false
            def isClusterKindFormatName = false

            config.validEnvironmentsDirectories.split(",").any { env ->
                if ("${filePath}" =~ "${group.name}${env}/" ) {
                    insideEnvDir=true
                    def path = filePath.split('/')
                    environment = path[1]
                    return true
                }
            }

            if (".${FilenameUtils.getExtension(original)}" == "${config.extension2decrypt}" ) {
                isEncrypted = true
                unEncryptedFileName=FilenameUtils.removeExtension(fileName)
            }

            if (unEncryptedFileName.count('.') == 3) {
                isValidFormatName = true
                def k8sData = unEncryptedFileName.split("\\.")
                k8sObjectName=k8sData[0]
                k8sNameSpace=k8sData[1]
                k8sKind=k8sData[2]
                extension=k8sData[3]
                config.allowedKinds.split(',').each { allowedKinds ->
                    if ("${k8sKind}" == "${allowedKinds}") {
                        isAllowedKind = true
                        return true
                    }
                }
            } else if (unEncryptedFileName.count('.') == 2) {
                isClusterKindFormatName = true
                isValidFormatName = true
                def k8sData = unEncryptedFileName.split("\\.")
                k8sObjectName=k8sData[0]
                k8sKind=k8sData[1]
                k8sNameSpace="Cluster"
                extension=k8sData[2]
                config.allowedKindsWithOutNameSpaces.split(',').each { allowedKinds ->
                    if ("${k8sKind}" == "${allowedKinds}") {
                        isAllowedKind = true
                        return true
                    }
                }
            }

            if ("${extension}" == "${config.extensionDeploymentFiles}") {
                isDeployableExtension = true
            }

            fileInfo_map.original=original
            fileInfo_map.oldName=oldName
            fileInfo_map.filePath=filePath
            fileInfo_map.fileName=fileName
            fileInfo_map.unEncryptedFileName=unEncryptedFileName
            fileInfo_map.extension=extension
            fileInfo_map.environment=environment
            fileInfo_map.k8sObjectName=k8sObjectName
            fileInfo_map.k8sNameSpace=k8sNameSpace
            fileInfo_map.k8sKind=k8sKind
            fileInfo_map.isValidFormatName=isValidFormatName
            fileInfo_map.isAllowedDelete=isAllowedDelete
            fileInfo_map.isAllowedKind=isAllowedKind
            fileInfo_map.isClusterKindFormatName=isClusterKindFormatName
            fileInfo_map.isEncrypted=isEncrypted
            fileInfo_map.insideEnvDir=insideEnvDir
            fileInfo_map.isDeployableExtension=isDeployableExtension
            fileInfo_map.isValidYaml=isValidYaml
            fileInfo_map.isDelete=isDelete
            fileInfo_map.isRename=isRename
            fileInfo_map.isModify=isModify

            fileInfo_list.add(fileInfo_map)
        }
        group.put("commitInfo",fileInfo_list)
        echo "=> COMMIT INFO Loaded for Group ${group.name}"
    }
}

def decryptFiles(ArrayList groups_list, Map config) {
    echo ""
    echo "=============================================="
    echo "           DECRYPT PHASE"
    echo "=============================================="
    def group_action_list = []
    groups_list.each { group ->
        group_details_map = [:]

        group_details_map.name = group.name
        echo "==> DECRYPT FOR [${group.name}] GROUP <=="

        files2Decrypt=group.commitInfo.findAll{files -> files.isEncrypted == true &&  files.insideEnvDir == true && files.isAllowedKind == true && files.isModify == true}
        actions_details_list = []
        files2Decrypt.each { ef ->
            actions_details_map = [:]
            def errcode = null
            def stdout = ""
            def stderr = ""
            echo "=> DECRYPTING file ${ef.original}"
            actions_details_map.file=ef.original
            withCredentials([string(credentialsId: "${config.credential_decrypt_passphrase}", variable: 'PASSPHRASE')]) {
                (errcode,stdout,stderr)=shplus("""gpg --batch --yes --passphrase="${PASSPHRASE}" --pinentry-mode loopback -o ./project/${ef.filePath}${ef.unEncryptedFileName} -d ./project/${ef.original}""")
            }
            actions_details_map.exit_code = errcode
            actions_details_map.stderr = stderr
            actions_details_map.stdout = stdout
            actions_details_list.add(actions_details_map)
        }
        group_details_map.put("actionDetails",actions_details_list)
        group_action_list.add(group_details_map)
    }

    return group_action_list
}

def cleanDecryptedFiles(ArrayList groups_list) {
    echo ""
    echo "=========================================="
    echo "            CLEAN ENVIRONMENT"
    echo "=========================================="
    groups_list.each { group ->
        def files2Decrypt=group.commitInfo.findAll{files -> files.isEncrypted == true &&  files.insideEnvDir == true && files.isAllowedKind == true && files.isModify == true}
        if (files2Decrypt.size() !=  0) {
            echo "==> Cleaning for Group ${group.name}"
            files2Decrypt.each { decrypt ->
                def errcode = null
                def stdout = ""
                def stderr = ""
                echo "=> Clean DECRYPT file ${decrypt.filePath}${decrypt.unEncryptedFileName}"
                (errcode,stdout,stderr)=shplus("rm ./project/${decrypt.filePath}${decrypt.unEncryptedFileName}")
            }
        }
    }
}

def k8sCheckAndUpdateValidYaml(ArrayList groups_list) {
    groups_list.each { group ->
        def deployablesItems = group.commitInfo.findAll{files -> files.isValidFormatName == true && files.insideEnvDir == true && files.isDeployableExtension == true && files.isAllowedKind == true}
        deployablesItems.each { depfile ->
            try {
                def fileYaml = readYaml(file: "./project/${depfile.filePath}${depfile.unEncryptedFileName}")
                def metadataName = fileYaml.metadata.name
                def kind = fileYaml.kind
                def metadataNamespace = ""
                if (depfile.k8sNameSpace == "Cluster") {
                    metadataNamespace = "Cluster"
                } else {
                    metadataNamespace = fileYaml.metadata.namespace
                }
                if (!metadataName.isEmpty() && !kind.isEmpty() && !metadataNamespace.isEmpty()) {
                    if (metadataName.getClass() != java.util.ArrayList && kind.getClass()!=java.util.ArrayList) {
                        if (metadataName == depfile.k8sObjectName && kind==depfile.k8sKind && metadataNamespace==depfile.k8sNameSpace) {
                            depfile.isValidYaml = true
                        }
                    }
                }
            } catch (Exception ex) {

            }
        }
    }
}

def k8sCheckDuplicatedObjects(ArrayList groups_list, ArrayList k8sObjects) {
    groups_list.each { group ->
        def groupName=group.name
        group.commitInfo.findAll{files -> files.isValidYaml == true}.each {validFile ->
            def validK8s=[:]
            validK8s.name = groupName
            validK8s.original = validFile.original
            validK8s.environment = validFile.environment
            validK8s.k8sObjectName = validFile.k8sObjectName
            validK8s.k8sNameSpace = validFile.k8sNameSpace
            validK8s.k8sKind = validFile.k8sKind
            k8sObjects.add(validK8s)
        }
    }
    def duplicateK8sObjects=k8sObjects.findAll{grupos1 -> k8sObjects.findAll{grupos2 -> grupos2.original != grupos1.original && grupos2.k8sObjectName == grupos1.k8sObjectName && grupos2.k8sKind == grupos1.k8sKind && grupos2.k8sNameSpace == grupos1.k8sNameSpace && grupos2.environment == grupos1.environment}.size() > 1}.unique()
    return duplicateK8sObjects
}

def commitCheckConstraints(ArrayList groups_list, Map config) {
    echo ""
    echo "=============================================="
    echo "          CHECK COMMIT CONSTRAINTS"
    echo "=============================================="
    def group_action_list = []
    groups_list.each { group ->
        def filesOutEnvDir = []
        def filesWithOutEncrypt = []
        def filesWithOutNamingFormat = []
        group_details_map = [:]
        actions_details_map = [:]
        actions_details_list = []

        group_details_map.name = group.name

        actions_details_map.file = "Check files Out Envs Dir"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        //validamos si hay ficheros o directorios dentro de los grupos fuera de los directorios de entorno permitidos
        filesOutAllowedEnvDir=group.commitInfo.findAll{files -> files.insideEnvDir == false}
        if (filesOutAllowedEnvDir.size() != 0)
        {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """
            Found ${filesOutAllowedEnvDir.size()} files out of allowed envs dirs
            Files: ${filesOutAllowedEnvDir.original}
            """
        }
        actions_details_list.add(actions_details_map)

        //Validamos si hay ficheros con isDeployableExtension false dentro de env dir
        actions_details_map = [:]
        actions_details_map.file = "Check not deployable files inside Env Dirs"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        notDeployfilesInEnvDir=group.commitInfo.findAll{files -> files.isDeployableExtension == false &&  files.insideEnvDir == true}
        if (notDeployfilesInEnvDir.size() != 0)
        {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """
            Found ${notDeployfilesInEnvDir.size()} files with not valid extension inside Env Dirs
            Files: ${notDeployfilesInEnvDir.original}
            """
        }
        actions_details_list.add(actions_details_map)

        //Si isForceEncryptInEnvDir es true validamos si hay ficheros no encriptados dentro de los directorios de entorno
        actions_details_map = [:]
        actions_details_map.file = "Check isForceEncryptInEnvDir"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        if (config.isForceEncryptInEnvDir)
        {
            filesWithOutEncrypt=group.commitInfo.findAll{files -> files.isEncrypted == false &&  files.insideEnvDir == true}
            if (filesWithOutEncrypt.size() != 0)
            {
                actions_details_map.exit_code = 1
                actions_details_map.stderr = """
                isForceEncryptInEnvDir is ${config.isForceEncryptInEnvDir} and found ${filesWithOutEncrypt.size()} files inside envs dirs without encrypt
                Files: ${filesWithOutEncrypt.original}
                """
            }
        }
        actions_details_list.add(actions_details_map)

        actions_details_map = [:]
        actions_details_map.file = "Check not allowed files to delete. Files in Commit vs Param items2Delete"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        //validamos si hay ficheros detectados en el commit para borrar que no están en items2Delete
        filesNotInItems2Delete=group.commitInfo.findAll{files -> files.isDelete == true && files.isAllowedDelete == false}
        if (filesNotInItems2Delete.size() != 0)
        {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """
            Found ${filesNotInItems2Delete.size()} files deleted in merge but not in items2Delete Param
            Files: ${filesNotInItems2Delete.original}
            """
        }
        actions_details_list.add(actions_details_map)

        actions_details_map = [:]
        actions_details_map.file = "Check marked files to delete (items2Delete) but no detected in merge. Files in Param items2Delete vs Commit"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        //validamos si hay ficheros listado en items2Delete pero no detectados en el commit para borrar
        filesNotInMerge=group.commitInfo.findAll{files -> files.isDelete == false && files.isAllowedDelete == true}
        if (filesNotInMerge.size() != 0)
        {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """
            Found ${filesNotInMerge.size()} files listed in items2Delete Param but not detected in merge
            Files: ${filesNotInMerge.original}
            """
        }
        actions_details_list.add(actions_details_map)

        //Validamos si hay ficheros sin el naming dentro de los directorios de entornos
        actions_details_map = [:]
        actions_details_map.file = "Check isForceNamingFormatInEnvDir"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        filesWithOutNamingFormat=group.commitInfo.findAll{files -> files.isValidFormatName == false &&  files.insideEnvDir == true}
        if (filesWithOutNamingFormat.size() != 0)
        {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """
            Found ${filesWithOutNamingFormat.size()} files with not valid naming format inside env directories
            Files: ${filesWithOutNamingFormat.original}
            """
        }
        actions_details_list.add(actions_details_map)

        //Validamos si hay ficheros con kinds no admitidos dentro de los directorios de entornos para isClusterKind == false
        actions_details_map = [:]
        actions_details_map.file = "Check not Allowed Kinds inside Env Dirs for no Cluster Kinds"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        notValidKinds=group.commitInfo.findAll{files -> files.isAllowedKind == false && files.insideEnvDir == true && files.isClusterKindFormatName == false}
        if (notValidKinds.size() != 0)
        {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """
            Found ${notValidKinds.size()} not valid kind
            Files: ${notValidKinds.original}
            """
        }
        actions_details_list.add(actions_details_map)

        //Validamos si hay ficheros con kinds no admitidos dentro de los directorios de entornos para isClusterKind == true
        actions_details_map = [:]
        actions_details_map.file = "Check not Allowed Kinds inside Env Dirs for Cluster kinds"
        actions_details_map.exit_code = 0
        actions_details_map.stderr = ""
        actions_details_map.stdout = ""
        notValidKinds=group.commitInfo.findAll{files -> files.isAllowedKind == false && files.insideEnvDir == true && files.isClusterKindFormatName == true}
        if (notValidKinds.size() != 0)
        {
            actions_details_map.exit_code = 1
            actions_details_map.stderr = """
            Found ${notValidKinds.size()} not valid kind
            Files: ${notValidKinds.original}
            """
        }
        actions_details_list.add(actions_details_map)

        group_details_map.put("actionDetails",actions_details_list)
        group_action_list.add(group_details_map)
    }
    return group_action_list
}

def k8sDryRun(ArrayList groups_list) {
    echo ""
    echo "=========================================="
    echo "              DRY RUN PHASE"
    echo "=========================================="
    def group_action_list = []
    groups_list.each { group ->
        group_details_map = [:]
        group_details_map.name = group.name
        echo "===> DRY RUN FOR [${group.name}] GROUP <==="
        actions_details_list = []
        group.commitInfo.findAll{files -> files.isModify == true}.each {ModifFile ->
            def errcode = null
            def stdout = ""
            def stderr = ""
            def actions_details_map = [:]
            echo "=> Executing DRY RUN for file ${ModifFile.filePath}${ModifFile.unEncryptedFileName}"
            (errcode,stdout,stderr)=shplus("kubectl apply --dry-run=client -f project/${ModifFile.filePath}${ModifFile.unEncryptedFileName}")
            actions_details_map.file = "${ModifFile.filePath}${ModifFile.unEncryptedFileName}"
            actions_details_map.exit_code = errcode
            actions_details_map.stdout = stdout
            actions_details_map.stderr = stderr

            actions_details_list.add(actions_details_map)
        }
        group_details_map.put("actionDetails",actions_details_list)
        group_action_list.add(group_details_map)
    }
    return group_action_list
}

def k8sRunDelete(ArrayList groups_delete_actions, String envPath) {
    echo "=========================================="
    echo "DELETED K8S OBJECTS"
    echo "=========================================="
    def group_action_list = []
    groups_delete_actions.each { group ->
        group_details_map = [:]
        group_details_map.name = group.name
        echo "===> RUN DELETE FOR [${group.name}] GROUP <==="
        actions_details_list = []
        group.commitInfo.findAll { files -> files.isDelete == true && files.environment == envPath }.each { ModifFile ->
            def actions_details_map = [:]
            def errcode = null
            def stdout = ""
            def stderr = ""

            if (ModifFile.isClusterKindFormatName){
                echo "=> Executing RUN DELETE for CLUSTER K8S Object ${ModifFile.filePath}${ModifFile.unEncryptedFileName}"
                (errcode,stdout,stderr)=shplus("kubectl delete ${ModifFile.k8sKind} ${ModifFile.k8sObjectName}")
            } else {
                echo "=> Executing RUN DELETE for NAMESPACE K8S Object ${ModifFile.filePath}${ModifFile.unEncryptedFileName}"
                (errcode,stdout,stderr)=shplus("kubectl delete ${ModifFile.k8sKind} ${ModifFile.k8sObjectName} -n ${ModifFile.k8sNameSpace}")
            }
            actions_details_map.file = "${ModifFile.filePath}${ModifFile.unEncryptedFileName}"
            actions_details_map.exit_code = errcode
            actions_details_map.stdout = stdout
            actions_details_map.stderr = stderr

            actions_details_list.add(actions_details_map)
        }
        group_details_map.put("actionDetails", actions_details_list)
        group_action_list.add(group_details_map)
    }
    return group_action_list
}

def k8sRunRename(ArrayList groups_rename_actions) {
    echo "=========================================="
    echo "RENAMED K8S OBJECTS"
    echo "=========================================="
    echo "Nothing to do with renamed files. Nothing change at k8s"
    echo "RENAME DETAILS:"
    groups_rename_actions.each { group ->
        echo "===> RENAME FOR [${group.name}] GROUP <==="
        group.commitInfo.findAll { files -> files.isRename == true && files.environment == envPath }.each { ModifFile ->
            echo "===> From  ${ModifFile.original} To ${ModifFile.oldName}"
        }
    }
}

def k8sRunApply(ArrayList groups_modify_actions, String envPath) {
    echo "=========================================="
    echo "ADDED OR MODIFIED K8S OBJECTS"
    echo "=========================================="
    def group_action_list = []
    groups_modify_actions.each { group ->
        group_details_map = [:]
        group_details_map.name = group.name
        echo "===> RUN APPLY FOR [${group.name}] GROUP <==="
        actions_details_list = []
        group.commitInfo.findAll{files -> files.isModify == true  && files.environment == envPath}.each {ModifFile ->
            def actions_details_map = [:]
            def errcode = null
            def stdout = ""
            def stderr = ""
            echo "=> Executing RUN APPLY for file ${ModifFile.filePath}${ModifFile.unEncryptedFileName}"
            (errcode,stdout,stderr)=shplus("kubectl apply -f project/${ModifFile.filePath}${ModifFile.unEncryptedFileName}")
            actions_details_map.file = "${ModifFile.filePath}${ModifFile.unEncryptedFileName}"
            actions_details_map.exit_code = errcode
            actions_details_map.stdout = stdout
            actions_details_map.stderr = stderr

            actions_details_list.add(actions_details_map)
        }
        group_details_map.put("actionDetails",actions_details_list)
        group_action_list.add(group_details_map)
    }
    return group_action_list
}

def checkDetails(ArrayList actions_details, String action) {
    def groups_KO = actions_details.findAll{ group -> group.actionDetails.findAll{it.exit_code != 0}}
    def groups_OK = actions_details - groups_KO
    echo "=========================================="
    echo "==> Groups OK:        ${groups_OK.name}"
    echo "==> Groups Errors:    ${groups_KO.name}"
    echo "=========================================="
    groups_KO.each { group ->
        echo "============================================"
        echo "${action} Errors Details for group ${group.name}"
        echo "============================================"
        group.actionDetails.findAll{ it.exit_code != 0}.each {
            echo "==> ${action} Error Details for ${it.file} !!!!"
            echo "=> Details: "
            echo "Exit Code: ${it.exit_code}"
            echo "stdout: "
            echo "${it.stdout}"
            echo "stderr: "
            echo "${it.stderr}"
        }
    }
    if (groups_KO.size() != 0) {
        return 1
    } else {
        return 0
    }
}