def call (){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python unlock.py"
        }
    }
}