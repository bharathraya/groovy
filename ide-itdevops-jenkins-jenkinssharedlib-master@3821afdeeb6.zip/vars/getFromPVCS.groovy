def call(String _Alms,String _Env,String _remoteServer){
 
  hoy=new Date().format( 'yyyyMMdd' )
 
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_Alms}
    scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_Alms}/${_Env} .
    """
   try{  
        if (_remoteServer!="")
        {
            sh "ssh -q ${_remoteServer} '${exec}'"
        }
        else
        {
            sh "${exec}"
        }
      } catch(Exception e){
                
                createReject (_Alms , "Para este tipo de paquetes no se tratan los pvcs/For this kind of packages pvcs are not treated.","5")
                error("Para este tipo de paquetes no se tratan los pvcs/For this kind of packages pvcs are not treated.")
            
    }
    
}