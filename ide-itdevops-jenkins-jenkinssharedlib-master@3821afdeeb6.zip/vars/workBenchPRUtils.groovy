import groovy.json.*

import java.util.regex.Matcher

import groovy.util.*

def getGitURLFromPR(pullrequest){
    objPullReq=readJSON text:pullrequest
    //echo "getGitURLFromPR url:"+objPullReq.repository
    return objPullReq.repository.repositoryFullURL
}

def getGitSourceBranchFromPR(pullrequest,requestType){
    objPullReq=readJSON text:pullrequest
    return objPullReq["${requestType}"].sourceBranch.branchName
}


def storeResult(deliveryResult){
	
    def result=[
            "ciResult":[:],
            "deliveryPullRequest":[:],
            "integrationPullRequest":[:],
            "deliveryArtifacts":[:],
            "integrationArtifacts":[:],
            "qualityAnalysisURL":"",
            "integrationDockerimage":[:],
            "deliveryDockerimage":[:]
    ]

    if (deliveryResult == null){

        result.ciResult["resultCode"]="90"
        result.ciResult["resultMessage"]="Delivery Request: Could not create delivery pull request"
    }else{
        result.ciResult["resultCode"]=deliveryResult.result.prResult.resultCode+"0"
        result.ciResult["resultMessage"]="Delivery Request: "+deliveryResult.result.prResult.resultMessage
        result.deliveryPullRequest=deliveryResult.result
        result.deliveryArtifacts=deliveryResult.artifacts
        result.qualityAnalysisURL=deliveryResult.qualityAnalysisURL
        result.deliveryDockerimage=deliveryResult.dockerimage
    }

    def jsonOut = readJSON text: groovy.json.JsonOutput.toJson(result)
    writeJSON file: 'result.json', json: jsonOut, pretty: 4
    archiveArtifacts 'result.json'
}


def storeResult(deliveryResult,integrationResult){

    def result=[
            "ciResult":[:],
            "deliveryPullRequest":[:],
            "integrationPullRequest":[:],
            "deliveryArtifacts":[:],
            "integrationArtifacts":[:],
            "qualityAnalysisURL":"",
            "integrationDockerimage":[:],
            "deliveryDockerimage":[:]
    ]
    resultCode=0
    if (deliveryResult == null){

        result.ciResult["resultCode"]="9"
        result.ciResult["resultMessage"]="Delivery Request: Could not create delivery pull request"
    }else{
        result.ciResult["resultCode"]=deliveryResult.result.prResult.resultCode
        result.ciResult["resultMessage"]="Delivery Request: "+deliveryResult.result.prResult.resultMessage
        result.deliveryPullRequest=deliveryResult.result
        result.deliveryArtifacts=deliveryResult.artifacts
        result.qualityAnalysisURL=deliveryResult.qualityAnalysisURL
        result.deliveryDockerimage=deliveryResult.dockerimage
    }
    if (integrationResult == null){
        result.ciResult["resultCode"]=result.ciResult.resultCode+"9"
        result.ciResult["resultMessage"]=result.ciResult.resultMessage+"\\n Integration Request:Could not create integration pull request"
    }else
    {
        result.ciResult["resultCode"]=result.ciResult.resultCode+integrationResult.result.prResult.resultCode
        result.ciResult["resultMessage"]=result.ciResult.resultMessage+"\\n IntegrationRequest"+integrationResult.result.prResult.resultMessage
        result.integrationPullRequest=integrationResult.result
        result.integrationArtifacts=integrationResult.artifacts
        result.integrationDockerimage=integrationResult.dockerimage
    }
    def jsonOut = readJSON text: groovy.json.JsonOutput.toJson(result)
    writeJSON file: 'result.json', json: jsonOut, pretty: 4
    archiveArtifacts 'result.json'
}

def mavenArtifactsFromDeployLog(response){
    final String NEXUS_URL="https://nexus-apps.es.sedc.internal.vodafone.com/nexus/"
    final String UPLOADED_MATCHER=/Uploaded to(.*): (https?:\/\/[0-9\.a-zA-Z_:-]*(\/nexus?)\/(repository|content\/repositories)\/([0-9\.a-zA-Z_-]*)\/([0-9\.a-zA-Z_\/-]*)\/([0-9\.a-zA-Z_-]*)\/([0-9\.a-zA-Z_-]*))/
    def Matcher matcher =  response =~ UPLOADED_MATCHER
    def mavenArtifacts=["artifactList":[],"repoURL":""]
    while (matcher.find()) {
        def artifact=["artifactId":"","groupId":"","version":"","artifactURL":"","name":"","type":""]
        artifactURL=NEXUS_URL+"repository/"+matcher.group(4)+"/"+matcher.group(6)+"/"+matcher.group(7)
        artifact.artifactId=matcher.group(5).split('/')[-1]
        artifact.groupId=matcher.group(5).split('/')
        artifact.artifactURL=matcher.group(2)
        artifact.groupId=matcher.group(5)
        lastSlashIndex=artifact.groupId.lastIndexOf('/')
        artifact.artifactId=artifact.groupId[(lastSlashIndex+1)..-1]
        artifact.groupId=artifact.groupId[0..(lastSlashIndex-1)].replaceAll('/','.')
        artifact.version=matcher.group(6)
        artifact.name=matcher.group(7)
        lastDotIndex=artifact.name.lastIndexOf('.')
        artifact.type=artifact.name[(lastDotIndex+1)..-1]
        mavenArtifacts.repoURL=NEXUS_URL+"repository/"+matcher.group(4)
        mavenArtifacts.artifactList << artifact
    }
    return mavenArtifacts
}

def mavenArtifactsFromDeployLog(String response, String NEXUS_URL){
  	echo "mavenArtifactsFromDeployLog"
    final String UPLOADED_MATCHER=/Uploaded to(.*): (https?:\/\/[0-9\.a-zA-Z_:-]*(\/nexus?)\/content\/repositories\/([0-9\.a-zA-Z_-]*)\/([0-9\.a-zA-Z_\/-]*)\/([0-9\.a-zA-Z_-]*)\/([0-9\.a-zA-Z_-]*)) */
    def Matcher matcher =  response =~ UPLOADED_MATCHER
    def mavenArtifacts=["artifactList":[],"repoURL":""]
  	def listaArtifacts=[]
    while (matcher.find()) {
        def artifact=["artifactId":"","groupId":"","version":"","artifactURL":"","name":"","type":""]
        artifactURL=NEXUS_URL+"content/repositories/"+matcher.group(4)+"/"+matcher.group(6)+"/"+matcher.group(7)
        artifact.artifactId=matcher.group(5).split('/')[-1]
        artifact.groupId=matcher.group(5).split('/')
        artifact.artifactURL=matcher.group(2)
        artifact.groupId=matcher.group(5)
        lastSlashIndex=artifact.groupId.lastIndexOf('/')
        artifact.artifactId=artifact.groupId[(lastSlashIndex+1)..-1]
        artifact.groupId=artifact.groupId[0..(lastSlashIndex-1)].replaceAll('/','.')
        artifact.version=matcher.group(6)
        artifact.name=matcher.group(7)
        lastDotIndex=artifact.name.lastIndexOf('.')
        artifact.type=artifact.name[(lastDotIndex+1)..-1]
      	if (artifact.type !="pom" && artifact.type !="xml"){
        	mavenArtifacts.repoURL=NEXUS_URL+"content/repositories/"+matcher.group(4)
        	listaArtifacts.add(artifact)
        }
      //echo "artifact:${artifact}"
    }
  	mavenArtifacts.artifactList=listaArtifacts.unique()
    return mavenArtifacts
}

def mavenArtifactsFromPackageLog(String response, String NEXUS_URL){
  	echo "mavenArtifactsFromPackageLog"
    final String UPLOADED_MATCHER=/\[INFO\] Generating flattened POM of project ([0-9\.a-zA-Z_-]*):([0-9\.a-zA-Z_-]*):([0-9\.a-zA-Z_-]*):([0-9\.a-zA-Z_-]*)\.\.\./
    def Matcher matcher =  response =~ UPLOADED_MATCHER
    def mavenArtifacts=["artifactList":[],"repoURL":""]
    while (matcher.find()) {
        def artifact=["artifactId":"","groupId":"","version":"","artifactURL":"","name":"","type":""]
        artifact.artifactId=matcher.group(2)
        artifact.groupId=matcher.group(1)
        artifact.version=matcher.group(4)
        artifact.type=matcher.group(3)
        artifact.name=artifact.artifactId+"-"+artifact.version+"."+artifact.type
        artifact.artifactURL=NEXUS_URL+"/content/repositories/"+matcher.group(1).replaceAll("\\.","/")+"/"+artifact.artifactId+"/"+artifact.version+"/"+artifact.name
        mavenArtifacts.artifactList.add(artifact)
      //echo "artifact:${artifact}"
    }
  	mavenArtifacts.repoURL=NEXUS_URL
    return mavenArtifacts
}


def eliminarPomModules(String xml1,List affectedmoduleInfo){
  List modules=[]
  final String UPLOADED_MATCHER=/<module>(([0-9\.a-zA-Z_-]*\/)*[0-9\.a-zA-Z_-]*)<.?module>/
  def Matcher matcher =  xml1 =~ UPLOADED_MATCHER
  while (matcher.find()){
      modules.add(matcher.group(1))
  }
  println  modules
  List modulesEliminar=modules
  affectedmoduleInfo.each(){
  	modulesEliminar.remove(it.ruta)
  }
  modulesEliminar.each(){
    module=it.replaceAll("\\/","\\\\/")
    println "eliminado "+module
    xml=xml1.replaceAll("<module>${module}<.?module>","")
    xml1=xml
  }
  return xml1
}

def get_app_max_deliveryenv(String _delivery, String _app){
    echo "get_app_max_deliveryenv"
    def entorno="" 
    node ('eswltbhr'){
        //Usuario
        wrap([$class: 'BuildUser']) {
             echo "Exec user: ${env.BUILD_USER_ID}"
             _usuario=env.BUILD_USER_ID
           }
        //Contraseña
         (_pass,_usuario)=findpassword(_usuario)
        
        checkout scm
        
        dir ("CDM/CommonTools/WorkBenchClient"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                
                entorno=sh(returnStdout: true, script: "python get_app_deliveryenv.py -d ${_delivery} -a ${_app} -u ${_usuario} -c ${_pass} |awk -F: '{a[\$3]++}END{max=0;entorno=\"\";for(i in a){if(a[i]>max){max=a[i];entorno=i}}print entorno}'")
                
             }//wrap
        }
    }
    return entorno
}
