def call(String API, Object env_config, String check){
    echo "getApigeeDeployedRevision"
    def REVISION="0"
    def SALIDA=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
                                credentialsId: "${env_config.credentialid}", 
                                usernameVariable: 'USERNAME', 
                                passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            https_proxy="${env_config.proxyurl}"
            export https_proxy
            no_proxy="${env_config.noproxy}"
            export no_proxy
            curl -X GET --write-out "HTTPSTATUS:%{http_code}" --header "Accept: application/json" -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/apis/${API}/deployments"
        """

        def index=SALIDA.indexOf('HTTPSTATUS:')+11
        def errorcode=SALIDA.substring(index,index+3)
        echo "GET status:${errorcode}"
        if (errorcode.substring(0,1) !="2" && errorcode.substring(0,1) !="4"){
            echo "WARNING:${SALIDA}"
            error "Error en ejecucion curl - Revisar CADUCIDAD DEL USUARIO (resetear pwd si aplica)"
        }
        def salidaJson=SALIDA.substring(0,SALIDA.indexOf("HTTPSTATUS:"))
        
        if (salidaJson != ""){
            apiInfo=readJSON(text: "${salidaJson}")
            echo "apiInfo:${apiInfo}"
            apiInfo.environment.each(){
                def ENVinfo=it
                if (ENVinfo.name == env_config.env ){
                    if(ENVinfo.revision.size()==0){
                        REVISION="-1"
                    }else{
                        if(ENVinfo.revision[0].state=="deployed"){
                            REVISION=ENVinfo.revision[0].name
                        }else{
                            REVISION="-1"
                            echo "WARNING:ENVinfo.revision.state:${ENVinfo.revision[0].state}"
                            if (check=="ERROR"){
                                echo "ERROR -------------------"
                                echo "ERROR "
                                error "Al obtener getApigeeDeployedRevision, avisar al Administrator de Apigee"
                            }
                        }
                    }
                }
            }
        }
    }
    echo "Deployed Revision:${REVISION}"
    return "${REVISION}"
}