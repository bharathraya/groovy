def call (String _usuario, String _vista, String _sistema, String _pass, String _entorno, String _fecha){
   //Buscar contraseña del user
  // (_pass,_usuario)=findpassword(_usuario)

    node ('es1117yw'){
        checkout scm
        
       
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
            if (_fecha!=""){
                bat "python create_view.py -u ${_usuario} -v ${_vista} -s \"${_sistema}\" -e ${_entorno} -f ${_fecha} -c ${_pass} "
            }else{
                bat "python create_view.py -u ${_usuario} -v ${_vista} -s \"${_sistema}\" -e ${_entorno} -c ${_pass} "
            }
             }//wrap
        }
    }
}

def call (String _usuario, String _vista, String _sistema, String _entorno, String _fecha){
   //Buscar contraseña del user
   (_pass,_usuario)=findpassword(_usuario)

    node ('es1117yw'){
        checkout scm
        
       
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {

            if (_fecha!=""){
                bat "python create_view.py -u ${_usuario} -v ${_vista} -s \"${_sistema}\" -e ${_entorno} -f ${_fecha} -c ${_pass} "
            }else{
                bat "python create_view.py -u ${_usuario} -v ${_vista} -s \"${_sistema}\" -e ${_entorno} -c ${_pass} "
            }
             }//wrap
        }
    }
}