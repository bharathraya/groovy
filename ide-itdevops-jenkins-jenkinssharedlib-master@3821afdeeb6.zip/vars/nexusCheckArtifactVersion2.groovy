import groovy.json.JsonSlurper;
/**
* this method need below params:
*    env_config
*    GID
*    ARTID
*    EXTENSION
*    COMMIT
*/
def call(Object env_config,String _GID,String _ARTID,String _EXTENSION,String _COMMIT) {
    echo "nexusCheckArtifactVersion2"
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${env_config.nexus_cred}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
        def SALIDA=sh returnStdout: true, script: """
            curl -u ${USERNAME}:${PASSWORD} -k "${env_config.nexus_url}/service/rest/v1/search?repository=${env_config.nexus_repo}&format=maven2&group=${_GID}&name=${_ARTID}&maven.extension=${_EXTENSION}"
            """
        def version=""
        def versionaux=""
        def downloadUrl=""
            if (SALIDA != ""){
            def jsonSlurper = new JsonSlurper()
            def jsonnexusquery = jsonSlurper.parseText(SALIDA)
            def downloadUrlaux=""
            jsonnexusquery.items.any{
                echo "encontrada version: ${it.version}"
                versionaux=it.version
                def versiontoken=versionaux.tokenize(".")
                def commit=versiontoken[2]
                echo "commit:${commit}"
                if( "${commit}" == "${_COMMIT}"){   
                    echo "Ya existe el artefacto en nexus ${_ARTID}:${version}"
                    version=versionaux
                    def base="${env_config.nexus_url}/repository/${env_config.nexus_repo}/${_GID}/${_ARTID}/${version}/"
                    it.assets.any{
                        downloadUrlaux=it.downloadUrl
                        echo "tratando: ${it.downloadUrl}"
                        def artifact="${downloadUrlaux.substring(base.size(),downloadUrlaux.size())}"
                        echo "chequeando: ${artifact} vs ${_ARTID}-${version}.${_EXTENSION}"
                    	if ( "${artifact}" == "${_ARTID}-${version}.${_EXTENSION}"){
                    	    downloadUrl=downloadUrlaux
                    	    return true
                    	}
                    }
                    return true
                }
            }
        }
        return [version,downloadUrl]
    }
}
