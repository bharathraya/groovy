def call(String commitID){
    echo "getGitTagsCommit"
    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
            git describe --tags --exact-match ${commitID} || true

    """
    def lista = SALIDA.split("\n").collect{it}
	return lista
}