import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
def call(Map config,VFESALMSDeployment alms, VFESGitMergeInfo_aaresmi mergeInfo)
{

  def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
  def _envConfig=myEnvsConfig[alms.deployEnv]

  echo "Deploying Kibana Objects ...."
  echo "_envConfig"+_envConfig['deploy_kibanaobjects']
  _envConfig['deploy_kibanaobjects'].each { item ->
    echo "Server Data:"
    echo "  deploy_server: " + item.server
    echo "  deploy_user: " + item.user
    echo "  application_release_path: " + item.application_release_path
    echo "  platafor_release_path: " + item.platafor_release_path + "/scripts"
    echo "  deploy Script: " + config.deployScript
    echo "Kibana Data:"
    echo "  kibana_space: " + item.kibana_space
    echo "  kibana_sch: " + item.kibana_sch
    echo "  kibana_host: " + item.kibana_host
    echo "  kibana_port: " + item.kibana_port
    echo "  kibana_credential: " + item.kibana_credential
    def _kibanaURL=""
    def _paramKibanaSpace=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
      _kibanaURL=item.kibana_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.kibana_host + ":" + item.kibana_port
      echo "  Kibana URL: " + _kibanaURL
    }

    //Get Files Added or Modified
    items2Add=mergeInfo.FilesChangedDetailed.findAll{it[0] == "A"}
    items2Mod=mergeInfo.FilesChangedDetailed.findAll{it[0] == "M"}

    // ORDEN: tags => indexPatterns => Searchs => Visualizacion => Dashboards

    //SPACE
    if (item.kibana_space != "")
    {
      _paramKibanaSpace="-k ${item.kibana_space}"
    }
    //TAGS
    items2AddTags=items2Add.findAll{it[1] =~ 'Tags/'}
    items2ModTags=items2Mod.findAll{it[1] =~ 'Tags/'}
    tags2Add=[]
    tags2Mod=[]
    items2AddTags.each {it -> tags2Add.add(it[1])}
    items2ModTags.each {it -> tags2Mod.add(it[1])}
    echo "Number of TAGS to Add: ${tags2Add.size}"
    echo "Number of TAGS to Mod: ${tags2Mod.size}"
    paramTagsAdd=""
    if (tags2Add.size() != 0)
    {
      paramTagsAdd="-n ${tags2Add.join(",")}"
    }
    paramTagsMod=""
    if (tags2Mod.size() != 0)
    {
      paramTagsMod="-m ${tags2Mod.join(",")}"
    }
    //INDEXPATTERNS
    items2AddIndexPatterns=items2Add.findAll{it[1] =~ 'IndexPatterns/'}
    items2ModIndexPatterns=items2Mod.findAll{it[1] =~ 'IndexPatterns/'}
    indexPatterns2Add=[]
    indexPatterns2Mod=[]
    items2AddIndexPatterns.each {it -> indexPatterns2Add.add(it[1])}
    items2ModIndexPatterns.each {it -> indexPatterns2Mod.add(it[1])}
    echo "Number of INDEXPATTERNS to Add: ${indexPatterns2Add.size}"
    echo "Number of INDEXPATTERNS to Mod: ${indexPatterns2Mod.size}"
    paramIndexPatternsAdd=""
    if (indexPatterns2Add.size() != 0)
    {
      paramIndexPatternsAdd="-n ${indexPatterns2Add.join(",")}"
    }
    paramIndexPatternsMod=""
    if (indexPatterns2Mod.size() != 0)
    {
      paramIndexPatternsMod="-m ${indexPatterns2Mod.join(",")}"
    }
    //SEARCHS
    items2AddSearchs=items2Add.findAll{it[1] =~ 'Searchs/'}
    items2ModSearchs=items2Mod.findAll{it[1] =~ 'Searchs/'}
    searchs2Add=[]
    searchs2Mod=[]
    items2AddSearchs.each {it -> searchs2Add.add(it[1])}
    items2ModSearchs.each {it -> searchs2Mod.add(it[1])}
    echo "Number of SEARCHS to Add: ${searchs2Add.size}"
    echo "Number of SEARCHS to Mod: ${searchs2Mod.size}"
    paramSearchsAdd=""
    if (searchs2Add.size() != 0)
    {
      paramSearchsAdd="-n ${searchs2Add.join(",")}"
    }
    paramSearchsMod=""
    if (searchs2Mod.size() != 0)
    {
      paramSearchsMod="-m ${searchs2Mod.join(",")}"
    }
    //VISUALIZATIONS
    items2AddVisualizations=items2Add.findAll{it[1] =~ 'Visualizations/'}
    items2ModVisualizations=items2Mod.findAll{it[1] =~ 'Visualizations/'}
    visualizations2Add=[]
    visualizations2Mod=[]
    items2AddVisualizations.each {it -> visualizations2Add.add(it[1])}
    items2ModVisualizations.each {it -> visualizations2Mod.add(it[1])}
    echo "Number of VISUALIZATIONS to Add: ${visualizations2Add.size}"
    echo "Number of VISUALIZATIONS to Mod: ${visualizations2Mod.size}"
    paramVisualizationsAdd=""
    if (visualizations2Add.size() != 0)
    {
      paramVisualizationsAdd="-n ${visualizations2Add.join(",")}"
    }
    paramVisualizationsMod=""
    if (visualizations2Mod.size() != 0)
    {
      paramVisualizationsMod="-m ${visualizations2Mod.join(",")}"
    }
    //DASHBOARDS
    items2AddDashboards=items2Add.findAll{it[1] =~ 'Dashboards/'}
    items2ModDashboards=items2Mod.findAll{it[1] =~ 'Dashboards/'}
    dashboards2Add=[]
    dashboards2Mod=[]
    items2AddDashboards.each {it -> dashboards2Add.add(it[1])}
    items2ModDashboards.each {it -> dashboards2Mod.add(it[1])}
    echo "Number of DASHBOARDS to Add: ${dashboards2Add.size}"
    echo "Number of DASHBOARDS to Mod: ${dashboards2Mod.size}"
    paramDashboardsAdd=""
    if (dashboards2Add.size() != 0)
    {
      paramDashboardsAdd="-n ${dashboards2Add.join(",")}"
    }
    paramDashboardsMod=""
    if (dashboards2Mod.size() != 0)
    {
      paramDashboardsMod="-m ${dashboards2Mod.join(",")}"
    }

    //FIRST ALL CHECKS
    echo "==========CHECKS========="
    if (tags2Add.size() != 0 || tags2Mod.size() != 0)
    {
      echo "==> TAGS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t Tags ${paramTagsAdd} ${paramTagsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t Tags ${paramTagsAdd} ${paramTagsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not TAGS"
    }

    if (indexPatterns2Add.size() != 0 || indexPatterns2Mod.size() != 0)
    {
      echo "==> INDEXPATTERNS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t IndexPatterns ${paramIndexPatternsAdd} ${paramIndexPatternsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t IndexPatterns ${paramIndexPatternsAdd} ${paramIndexPatternsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not INDEXPATTERNS"
    }

    if (searchs2Add.size() != 0 || searchs2Mod.size() != 0)
    {
      echo "==> SEARCHS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t Searchs ${paramSearchsAdd} ${paramSearchsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t Searchs ${paramSearchsAdd} ${paramSearchsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not SEARCHS"
    }

    if (visualizations2Add.size() != 0 || visualizations2Mod.size() != 0)
    {
      echo "==> VISUALIZATIONS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t Visualizations ${paramVisualizationsAdd} ${paramVisualizationsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t Visualizations ${paramVisualizationsAdd} ${paramVisualizationsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not VISUALIZATIONS"
    }

    if (dashboards2Add.size() != 0 || dashboards2Mod.size() != 0)
    {
      echo "==> DASHBOARDS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t Dashboards ${paramDashboardsAdd} ${paramDashboardsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -c -t Dashboards ${paramDashboardsAdd} ${paramDashboardsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not DASHBOARDS"
    }

    echo "==========DEPLOY========="
    if (tags2Add.size() != 0 || tags2Mod.size() != 0)
    {
      echo "==> TAGS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t Tags ${paramTagsAdd} ${paramTagsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t Tags ${paramTagsAdd} ${paramTagsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not TAGS"
    }

    if (indexPatterns2Add.size() != 0 || indexPatterns2Mod.size() != 0)
    {
      echo "==> INDEXPATTERNS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t IndexPatterns ${paramIndexPatternsAdd} ${paramIndexPatternsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t IndexPatterns ${paramIndexPatternsAdd} ${paramIndexPatternsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not INDEXPATTERNS"
    }

    if (searchs2Add.size() != 0 || searchs2Mod.size() != 0)
    {
      echo "==> SEARCHS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t Searchs ${paramSearchsAdd} ${paramSearchsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t Searchs ${paramSearchsAdd} ${paramSearchsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not SEARCHS"
    }

    if (visualizations2Add.size() != 0 || visualizations2Mod.size() != 0)
    {
      echo "==> VISUALIZATIONS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t Visualizations ${paramVisualizationsAdd} ${paramVisualizationsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t Visualizations ${paramVisualizationsAdd} ${paramVisualizationsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not VISUALIZATIONS"
    }

    if (dashboards2Add.size() != 0 || dashboards2Mod.size() != 0)
    {
      echo "==> DASHBOARDS"
      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.kibana_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t Dashboards ${paramDashboardsAdd} ${paramDashboardsMod} ${_paramKibanaSpace}"
        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_kibanaURL} -d -t Dashboards ${paramDashboardsAdd} ${paramDashboardsMod} ${_paramKibanaSpace}'"
      }
    }
    else
    {
      echo "==> There is not DASHBOARDS"
    }
  }
}
