def call(String NombreCarpeta,String _Env,String _OriginServer, String _remoteServer){
 
  hoy=new Date().format( 'yyyyMMdd' )
  _OriginServer = "appcrm"
  dir_paquete=/home/plataforma/plausr/data/paquetes/${hoy}/${NombreCarpeta}
  dir_ruta=/home/plataforma/plausr/data/paquetes/${hoy}/
  
  execProcesos="""
        . \$HOME/.profile >/dev/null 2>&1
        . paquete ${_Alms} 
        ssh -q -n appcrm  " if [ ! -d $dir_paquete ]; then mkdir -p $dir_paquete; fi"
        scp -r $dir_paquete appcrm:${dir_ruta} 2>/dev/null
        ssh appcrm ". ./.profile >/dev/null 2>&1;mig_procesos -e ${_Env} -p ${dir_paquete}"
        scp -r appcrm:${dir_paquete} ${dir_ruta} 2>/dev/null
    """
    
    if (_remoteServer!="")
        {
            sh "ssh -q ${_remoteServer} '${execProcesos}'"
        }
        else
        {
            sh "${execProcesos}"
       }

    exec="""
        . \$HOME/.profile >/dev/null 2>&1
        . paquete ${_Alms} 
        
         if [ -d ${dir_paquete}/${_Env}_o_no/DATA_CONFIGURATION/DATA ]
         then
                 rm -rf ${dir_paquete}/${_Env}_o_no/DATA_CONFIGURATION/DATA/*
         else
                mkdir -p ${dir_paquete}/${_Env}_o_no/DATA_CONFIGURATION/DATA
         fi
          cp ${dir_paquete}/${_Env}_TMP/CRM/Procesos/* ${dir_paquete}/${_Env}_o_no/DATA_CONFIGURATION/DATA
          rm -rf ${dir_paquete}/${_Env}_TMP
         
    """
    // promoSVN_todo -a -d AMDOCS -e PROD -p ${dir_paquete} 2>/dev/null 
    if (_remoteServer!="")
        {
            sh "ssh -q ${_remoteServer} '${exec}'"
        }
        else
        {
            sh "${exec}"
       }

}
