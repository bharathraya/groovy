def call(String _Alms,String _Env,String _remoteServer,String _date){
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    export ruta_temp=\$DIR_BASE_TEMPORAL/${_date}/anexo/${_Alms}
    export ruta_temp1=\$DIR_BASE_PAQUETE/${_date}/${_Alms}
    
    if [ ! -d \${ruta_temp} ]
    then
        mkdir -p \${ruta_temp}
    fi
    
    cd \${ruta_temp}
    scp -qr es036tvr:/home/plataforma/plausr/data/temporal/${_date}/${_Alms}/${_Env}/DataModules/* .
    
    if [ ! -d \${ruta_temp1} ]
    then
        mkdir -p \${ruta_temp1}
    fi
    
    cd \${ruta_temp1}
    scp -qr es036tvr:/home/plataforma/plausr/data/temporal/${_date}/${_Alms}/${_Env}/DataModules/* .
    """
    
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}