def call(String _application,String _env,String _package,String _remoteServer){
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_package}
    gen_meddata.sh -d ${_application} -e ${_env} -p ${_package}
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
