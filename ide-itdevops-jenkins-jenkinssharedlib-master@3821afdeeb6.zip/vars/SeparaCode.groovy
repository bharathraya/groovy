def call(String _nombreCarpeta, String _domain, String _server, String _env){

def Compilable=""
def RutaNueva=""
def RutaVieja=""
def FicheroWB=""
def RutaCarpeta=""
def iTipo=0 //1 -> comp 2 -> ambos 3 -> no comp
def hoy=""
def FicheroWB_SIN=""
def execCON=""
def execSMS=""
def execSPM=""


hoy=new Date().format( 'yyyyMMdd' )

//print "parametros:Separa Code :"
//print "parametros _domain: ${_domain}"
//print "parametros _nombreCarpeta: ${_nombreCarpeta}"
//print "parametros _server: ${_server}"
//print "parametros _env: ${_env}"

    iTipo=0
    Compilable="${_nombreCarpeta}_COMP"
   // print "Nueva carpeta ${Compilable}"
    
    RutaNueva="/home/plataforma/plausr/data/paquetes/${hoy}/${Compilable}/${_env}"
    RutaVieja="/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${_env}"
    RutaCarpeta="/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}"
    //print "RutaNueva ${RutaNueva}"
    //print "RutaVieja ${RutaVieja}"
    
   // sh "ls -l ${RutaCarpeta}/WB_${_nombreCarpeta}.txt"
    FicheroWB = readFile(file: "${RutaCarpeta}/WB_${_nombreCarpeta}.txt")
   //print "Leo el fichero WB FILE ${FicheroWB}"

    if (_domain == "AMDOCS-CONTRATOS") 
    {
        if (_env =="PROD")
        {
            if (FicheroWB.contains("APM/impresionContratos/project"))
            {
                iTipo=1
            }           
            else
            {
                iTipo=2
            }
            if (iTipo==1 )
                {//tiene comp miramos si tiene no_comp
                    sh "rm -f ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN "
                    sh "touch -f ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN "
                    try{
                        sh " grep -v 'APM/impresionContratos/project/' ${RutaCarpeta}/WB_${_nombreCarpeta}.txt > ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN "                                           }
                   catch(Exception e){
                      
                   }//Catch
                    // sh "ls -l ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN"
                        FicheroWB_SIN = readFile(file: "${RutaCarpeta}/WB_${_nombreCarpeta}_SIN")
                      //  print "Fichero sin ${FicheroWB_SIN}"
                        
                        if ("${FicheroWB_SIN}" != "")
                        {
                            iTipo=3 //tiene ambos
                        }
                }// itipo   
           }//PROD    
        
       // print "El dominio es ${_domain}"
        execCON="""
        . \$HOME/.profile >/dev/null 2>&1
        
        if [ -d /home/plataforma/plausr/data/paquetes/${hoy}/${Compilable} ]
        then
            rm -rf /home/plataforma/plausr/data/paquetes/${hoy}/${Compilable}
        fi
        
        . paquete ${_nombreCarpeta} ${_env}
        
        if [ -d APM/impresionContratos/project ]
        then
            . paquete ${Compilable} ${_env}
            mkdir -p APM/impresionContratos/project
            cd 
            mv ${RutaVieja}/APM/impresionContratos/project ${RutaNueva}/APM/impresionContratos/
            rm -rf ${RutaVieja}/APM/impresionContratos/project
        fi       
        """
   
        sh "ssh -q ${_server} '${execCON}'"
        
        
    }
     if (_domain == "AMDOCS-SMS") 
        {
            if (_env =="PROD")
            {
                if (FicheroWB.contains("APM/SMS_Resumen_Compra/project/src"))
                {
                    iTipo=1
                }
                else if (FicheroWB.contains("APM/SMS_Resumen_Compra/project/build.properties"))
                {
                    iTipo=1
                }
                else if (FicheroWB.contains("APM/SMS_Resumen_Compra/project/build.xml"))
                {
                    iTipo=1
                }
                else
                {
                    iTipo=2
                }
                if (iTipo==1 )
                {//tiene comp miramos si tiene no_comp
                    sh "rm -f ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN_tmp ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN_tmp1"
                    sh "touch -f ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN_tmp ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN_tmp1"
                    try{
                        sh " grep -v 'APM/SMS_Resumen_Compra/project/src' ${RutaCarpeta}/WB_${_nombreCarpeta}.txt > ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN_tmp "
                        sh " grep -v 'APM/SMS_Resumen_Compra/project:build.properties' ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN_tmp > ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN_tmp1 "
                        sh " grep -v 'APM/SMS_Resumen_Compra/project:build.xml' ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN_tmp1 > ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN "
                   }
                   catch(Exception e){
                       
                   }//Catch
                        FicheroWB_SIN = readFile(file: "${RutaCarpeta}/WB_${_nombreCarpeta}_SIN")
                      //  print "Fichero sin ${FicheroWB_SIN}"
                        if ("${FicheroWB_SIN}" != "")
                        {
                            iTipo=3 //tiene ambos
                        }
               }   
            }//PROD
            
          //  print "El dominio es ${_domain}"
            execSMS="""
            . \$HOME/.profile >/dev/null 2>&1
            
            if [ -d /home/plataforma/plausr/data/paquetes/${hoy}/${Compilable} ]
            then
                rm -rf /home/plataforma/plausr/data/paquetes/${hoy}/${Compilable}
            fi
            
            . paquete ${_nombreCarpeta} ${_env}
            
            if [ -d APM/SMS_Resumen_Compra/project/src ]
            then
                . paquete ${Compilable} ${_env}
                mkdir -p APM/SMS_Resumen_Compra/project/src
                cd 
                mv ${RutaVieja}/APM/SMS_Resumen_Compra/project/src/ ${RutaNueva}/APM/SMS_Resumen_Compra/project/
                rm -rf ${RutaVieja}/APM/SMS_Resumen_Compra/project/src/
            fi
             . paquete ${_nombreCarpeta} ${_env}
            if [ -f APM/SMS_Resumen_Compra/project/build.properties ]
            then
                . paquete ${Compilable} ${_env}
                mkdir -p APM/SMS_Resumen_Compra/project
                cd 
                mv ${RutaVieja}/APM/SMS_Resumen_Compra/project/build.properties ${RutaNueva}/APM/SMS_Resumen_Compra/project/build.properties
            fi
             . paquete ${_nombreCarpeta} ${_env}
            if [ -f APM/SMS_Resumen_Compra/project/build.xml ]
            then
                . paquete ${Compilable} ${_env}
                mkdir -p APM/SMS_Resumen_Compra/project
                cd 
                mv ${RutaVieja}/APM/SMS_Resumen_Compra/project/build.xml ${RutaNueva}/APM/SMS_Resumen_Compra/project/build.xml
            fi
            """
       
        sh "ssh -q ${_server} '${execSMS}'"
        }
        
        if (_domain == "AMDOCS-SPM") 
        {   
            if (_env =="PROD")
            {
                if (FicheroWB.contains("APM/JAVA_DEAMONS/JAVA"))
                {
                    iTipo=1  //es compilable
                }
                else if (!FicheroWB.contains("APM/JAVA_DEAMONS/JAVA"))
                {
                    iTipo=2  //no tiene compilable
                }
             
                if (iTipo==1 )
                {//tiene comp miramos si tiene no_comp
                    sh "rm -f ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN"
                    sh "touch -f ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN"
                   try{
                        sh " grep -v 'APM/JAVA_DEAMONS/JAVA' ${RutaCarpeta}/WB_${_nombreCarpeta}.txt > ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN "
                   }
                   catch(Exception e){
                       
                   }//Catch
                   // sh "ls -l ${RutaCarpeta}/WB_${_nombreCarpeta}_SIN"
                        FicheroWB_SIN = readFile(file: "${RutaCarpeta}/WB_${_nombreCarpeta}_SIN")
                      //  print "Fichero sin ${FicheroWB_SIN}"
                        
                        if ("${FicheroWB_SIN}" != "")
                        {
                            iTipo=3 //tiene ambos
                        }
                }    
            }//PROD
           
          //  print "El dominio es ${_domain}"
            execSPM="""
            . \$HOME/.profile >/dev/null 2>&1
            
            if [ -d /home/plataforma/plausr/data/paquetes/${hoy}/${Compilable} ]
            then
                rm -rf /home/plataforma/plausr/data/paquetes/${hoy}/${Compilable}
            fi
            
            . paquete ${_nombreCarpeta} ${_env}
            
            if [ -d APM/JAVA_DEAMONS/JAVA ]
            then
                . paquete ${Compilable} ${_env}
                mkdir -p APM/JAVA_DEAMONS/JAVA
                cd 
                mv ${RutaVieja}/APM/JAVA_DEAMONS/JAVA  ${RutaNueva}/APM/JAVA_DEAMONS/
                rm -rf ${RutaVieja}/APM/JAVA_DEAMONS/JAVA
            fi
            """
       
            sh "ssh -q ${_server} '${execSPM}'"
    }
    // print "iTipo ahora ${iTipo}"
     return iTipo
}
