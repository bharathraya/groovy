def call(String _dockerImage,String _commandLine,String [] _volumes)
{
    def volumesArg=""
    _volumes.each(){
        volumesArg="${volumesArg} -v ${it} "
    } 
    sh "docker run ${volumesArg} ${_dockerImage} ${_commandLine}"
}
return this;