def call(String RutaPaquete, String _CRQ_ID, String _TipoRege , String _Orden, String _upgrade, String EntSimulacro){

//print "Parametros:"
//print "RutaPaquete: ${RutaPaquete}"
//print "CRQ_ID: ${_CRQ_ID}"
//print "Tipo a Regenerar: ${_TipoRege}"
//print "Es del upgrade: ${_upgrade}"
//print "Entorno del Simulacro: ${EntSimulacro}"

def _listadoEsquema=""
def _listadoBBDD=""
def _listado=""
def _domain=""
def _Tipo=""
def _nombreCarpeta=""
def MODSIMU=0

hoy=new Date().format( 'yyyyMMdd' )

if (_TipoRege =="AMDOCS-ESQUEMA")
{
     sh "touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-ESQUEMA"
     _listadoEsquema = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-ESQUEMA")
     if ( _listadoEsquema == "" ) 
        {
             error ("You have chosen Schema integrity and there are no Schema packages")
        }
     sh "touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD"
     _listadoBBDD = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD")
     if (_listadoBBDD != "") 
        {
            print "There are DDBB packages"
            _listado= "${_listadoEsquema} ${_listadoBBDD}"
        }
        else
        {
            _listado = _listadoEsquema
        }
    _domain ="AMDOCS-ESQUEMA"
}
else
{
sh "touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD"
     _listadoBBDD = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD")
     if ( _listadoBBDD == "" ) 
        {
             error ("You have chosen DDBB integrity and there are no DDBB packages")
        }
     if (_Orden =="")
       {
            error ("There is no order file for the BBDD part")
        }    
     sh "touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-ESQUEMA"
     _listadoEsquema = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-ESQUEMA")
     if (_listadoEsquema != "") 
        {
            print "There are schema packages"
            _listado= "${_listadoEsquema} ${_listadoBBDD}"
        }
        else
        {
            _listado = _listadoBBDD
        }
    _domain ="AMDOCS-BBDD"
}    

   // print "listado ${_listado}"
    _Tipo=(_domain.split("-")[-1]) 
    _nombreCarpeta="${_CRQ_ID}_${_Tipo}"

    
  //  print "_nombreCarpeta ${_nombreCarpeta}"
    //Lanzo el txeker de extraer aunque no testee
    
    if (_upgrade =="N")
    {
           // print "No es el Upgrade"
            txeker("-x","AMDOCS","PROD",_nombreCarpeta,_listado)
            CleanPaquete "${_nombreCarpeta}","opetst75","PROD"
            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
            getFromPVCS "${_nombreCarpeta}","PROD","opetst75"
    }
    else
    {
          //  print "Es el Upgrade"
            txeker("-x","AMDOCS102","PROD",_nombreCarpeta,_listado)
            CleanPaquete "${_nombreCarpeta}","devopststtools01","PROD"
            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
            getFromPVCS "${_nombreCarpeta}","PROD","devopststtools01"
    }
                                
   // print "${_nombreCarpeta}" 
   // print  "${_CRQ_ID}"
    
    if (_TipoRege =="AMDOCS-ESQUEMA")
    {
        print "WE REVIEW THE INTEGRITY OF THE SCHEME"
        //Lllamamos a la funcion ntegridad esquema
        //IntegridadEsquema( "${_nombreCarpeta}","${_Orden}","${_CRQ_ID}", "N")
        MODSIMU=0
    }
    else
    {
        print "WE CHECK INTEGRITY"
        MODSIMU=IntegridadBBDD2( "${_nombreCarpeta}","${_Orden}","${_CRQ_ID}", "N", "${_upgrade}", "${EntSimulacro}")
        print "value of if there is ${EntSimulacro} modules: ${return  MODSIMU}"
    }
    return  MODSIMU
}    
