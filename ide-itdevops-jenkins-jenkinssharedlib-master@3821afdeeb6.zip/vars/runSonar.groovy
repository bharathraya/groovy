import vfes.utils.VFESALMSDeployment

def call(Map config,VFESALMSDeployment alms){
    withSonarQubeEnv('sonar'){
        dir("${config.extractFolder}"){
            sh """sonar-scanner -Dsonar.host.url=http://195.233.178.75:9000/sonar \
            -Dsonar.projectBaseDir=${WORKSPACE}/${config.extractFolder} \
            -Dsonar.branch.name=${alms.deployEnv} \
            -Dsonar.projectKey=${config.sonarKey}.${alms.squad} \
            -Dsonar.projectName=${config.sonarKey}.${alms.squad} """
        } 
    }
    //QG
    dir("${config.extractFolder}"){
        timeout(time: 20, unit: 'MINUTES') {
            waitForQualityGate abortPipeline: true
        }

    }
}