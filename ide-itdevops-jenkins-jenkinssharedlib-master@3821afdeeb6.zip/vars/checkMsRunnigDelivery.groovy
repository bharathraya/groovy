def call (List mslistdc, String ENTORNO, String oc_cluster,namespace, String _Delivery){
    echo "checkMsRunnigDelivery"
    def result=""
    def APLICACION=""
    openshift.withCluster(oc_cluster) {
    		List msRunning=[]
        echo "Using Cluster: ${openshift.cluster()}"
        mslistdc.each(){
            def ms=it
            _App=ms.application
            APLICACION=_App.toLowerCase()
            if(namespace!=""){
                project_dest=namespace
            }else{
                project_dest="${ms.namespace}-${ENTORNO}"
            }
            openshift.withProject(project_dest) {
                def rcs=openshift.selector('rc',[ app: "${APLICACION}" ]).objects()
                //echo "rcs:[${dcs}]"
                rcs.each(){
                    def rc=it
                    //echo "rc:[${rc}]"
                    //echo "app:${rc.metadata.name}"
                    echo "Pod ${rc.metadata.name} Replicas: Deseadas=${rc.status.replicas} ready=${rc.status.readyReplicas}"
                    if( rc.status.readyReplicas>0){
                    	//account-management-es2103sp-rc.2.b816ccc-1
                    	msRunning.add(rc.metadata.name)
                    }
                }
            }
        }
				msRunning.any(){
					def indexDelivery=APLICACION.size()+1
					def runningDelivery=it.substring(indexDelivery,indexDelivery+6).toLowerCase()
					def currentDelivery=_Delivery.substring(0,6).toLowerCase()
					println "runningDelivery:$runningDelivery currentDelivery:$currentDelivery"
					if (runningDelivery>currentDelivery){
					    result="error"
					    return true
					}
				}
    }
    return result
}
