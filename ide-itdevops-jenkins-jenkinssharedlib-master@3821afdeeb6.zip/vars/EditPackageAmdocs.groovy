def call(String _CRQ_ID, String _user, Boolean _View, String _NomView,  String _pass){
   
  hoy=new Date().format( 'yyyyMMdd' )
  RutaTemp="/home/plataforma/plausr/tmp"
  RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
  //Busco la contraseña
 // (_pass,_user)=findpassword(_user)
  
    print "Editing the packages "
     if (_View == false)
       { //No es vista
           _listapaquetes=readFile(file: "${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt")
        }
     else
      {
          _listapaquetes=""
      }
     
     EditPackage(_CRQ_ID, _View, _listapaquetes, false, false, _NomView,_user,_pass)
     PromotePROD=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PromotePROD.txt")
     Notif=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/Todos.txt")
     
     if (PromotePROD != "")
      { //Paquetes a promocionar
         promoteApi("${_user}","10", '"'+PromotePROD+'"', _pass)
      }
     if (Notif  != "")
       { //Paquetes a promocionar
          notifApi("${_user}",'"'+Notif+'"',_pass)
          promoteApi("${_user}","10", '"'+Notif+'"',_pass)
       }
                           
       EditPackage(_CRQ_ID, _View, _listapaquetes, true,false,_NomView,_user,_pass)
       PaquetesIncorrectos=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PaquetesIncorrectos.txt")
       if (PaquetesIncorrectos != "" )
         {
            print "Check following package that can not be promoted automatically"
            print "${PaquetesIncorrectos}"
          }
     
        print "******************************"
        print "Chosen option 4 of LABELING"
        print "Patch name ${_CRQ_ID} "
        print "******************************"

}
