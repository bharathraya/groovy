// This function parses pckinfo to return params tuple 
def call(String _pckinfo)
{
    def mypckinfo=readJSON(text:_pckinfo)
    def mydeploy_env=""
    def mycommit_id=""
    def myalms_id=mypckinfo.Id.toString()
    def mydelivery=""
    def myproject_id=""
    def mysquad=mypckinfo.EnterpriseName
    def myartifact_id=""
    def mygitserver=""
    def mygithash=""

    
    
    
    if (mypckinfo.containsKey("Application")){
        mydeploy_env=mypckinfo.DeployEnvironment.Name
        mycommit_id=decideCommitId(mypckinfo.Commits,mydeploy_env)
        mydelivery=mypckinfo.Delivery.Name
        myproject_id=mypckinfo.Project.CodProject
        myartifact_id=mypckinfo.Application.Name
        mygithash=pckInfo['Commits'].Repository[0].RepositoryHash
        mygitserver=pckInfo['Commits'].Server[0].ApiEndPoint
    }
    else{
        wbpckinfo=get_workbench_package_info(myalms_id)
        echo "[${wbpckinfo}]"
        mydeploy_env=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
        mycommit_id=decideCommitId(wbpckinfo.Data.Model.Model.Contents.GIT,mydeploy_env)
        mydelivery=wbpckinfo.Data.Model.Model.Base.Project.Delivery.Name
        myproject_id=wbpckinfo.Data.Model.Model.Base.Project.CodProject
        myartifact_id=wbpckinfo.Data.Model.Model.Contents.Repository.Domain.Name
        mygitserver=wbpckinfo.Data.Model.Model.Contents.GIT[0].Repository.Server.ApiEndPoint
        mygithash=wbpckinfo.Data.Model.Model.Contents.GIT[0].Repository.RepositoryHash
    }

    // we return multiple values from this fucntion. later values should be 
    // taken like : (a,b,c,d)=fucntion(param)
    return [mydeploy_env,mycommit_id,myalms_id,mydelivery,myproject_id,mysquad,myartifact_id,mygitserver,mygithash]
   
}
