import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
def call(Map config,VFESALMSDeployment alms)
{
  def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
  def _envConfig=myEnvsConfig[alms.deployEnv]

  if (config.containsKey("deployActions"))
  {
    deployECE_ELKCheckVariables config,alms
  }
  else
  {
    echo "===> Legacy"
    echo "Testing the Deploy of EnvironmentVars ...."
    echo "_envConfig"+_envConfig['deploy_enviromentVars']
    _envConfig['deploy_enviromentVars'].each { item ->
      echo "Server Data:"
      echo "  deploy_server: " + item.deploy_server
      echo "  deploy_user: " + item.deploy_user
      echo "  release_path: " + item.release_path
      echo "  deploy_script_path: " + item.deploy_script_path + "/scripts"
      echo "  deploy Script: " + config.deployScript

      echo "AT: ${item.deploy_server}@${item.deploy_user}"
      echo "RUN: ${item.deploy_script_path}/scripts/${config.deployScript}"
      echo "PARAMETERS: -a ${config.applicationName} -r ${item.release_path}"
      sh "ssh -o StrictHostKeyChecking=no ${item.deploy_user}@${item.deploy_server} 'cd ${item.deploy_script_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.release_path}'"
    }
  }

  //for( String action : config.deployActions.split(',') )
  //{
    //echo "Action=" + action
  //switch(action) {
  //  case 'check_syntax':
          //    if (_envConfig.keySet().contains(action))
  //{
  //////      echo "=============================================="
  ////////v  echo "            ${action}"
  // echo "=============================================="
  //      _envConfigSyntax=_envConfig[action]
  //      echo "_envConfigSyntax: "+_envConfigSyntax
//
  //        _envConfigSyntax.each { item ->
  //        echo "Checking Syntax Variables:"
  //        echo "Server Data:"
  //        echo "  Server: " + item.server
  //        echo "  User: " + item.user
  //        echo "  platafor release_path: " + item.platafor_release_path
  //        echo "  application release_path: " + item.application_release_path
  //echo "Check Data:"
  //////        echo "  Check Syntax script: " + config.checkSyntaxScript
//
  //          echo "AT: ${item.user}@${item.server}"
  //        echo "RUN: ${item.platafor_release_path}/scripts/${config.checkSyntaxScript}"
  //        echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path}"
  //        sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.checkSyntaxScript} -a ${config.applicationName} -r ${item.application_release_path}'"
  //      }
  //      echo "=============================================="
  //      echo "=============================================="
  //      echo "=============================================="
  //    }
          //    else
  //      {
  //      echo "ERROR. Not found ${action} key in ${config.releaseConfig}"
  //      sh ("exit 1")
  //    }
  //    break;
  //    case ['check_alert', 'check_ilm', 'check_indexTemplates', 'check_logstash']:
          //            if (_envConfig.keySet().contains(action))
  //      {
  //        echo "=============================================="
  //        echo "            ${action}"
  //        echo "=============================================="
  //        _envConfigAction=_envConfig[action]
  //        echo "_envConfigAction: "+_envConfigAction

  //        _envConfigAction.each { item ->
  //          echo "Checking Alert Variables:"
  //          echo "Server Data:"
  //          echo "  deploy_server: " + item.server
  //          echo "  deploy_user: " + item.user
  //         echo "  platafor release_path: " + item.platafor_release_path
  //          echo "  application release_path: " + item.application_release_path
  //          echo "Check Data:"
  //          echo "  repository to check: " + item.repo_check
  //          echo "  file pattern to search: " + item.file_pattern
  //          echo "  environment variables vault:" + item.env_vault
  //          echo "  Check Variables script: " + config.checkVarScript

  //          echo "AT: ${item.user}@${item.server}"
  //          echo "RUN: ${item.platafor_release_path}/scripts/${config.checkVarScript}"
  //          echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -b ${item.repo_check} -p ${item.file_pattern} -e ${item.env_vault}"
  //          sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.checkVarScript} -a ${config.applicationName} -r ${item.application_release_path} -b ${item.repo_check} -p ${item.file_pattern} -e ${item.env_vault}'"
  //        }
  //        echo "=============================================="
  //        echo "=============================================="
  //        echo "=============================================="
  //      }
          //      else
  //      {
  //        echo "ERROR. Not found ${action} key in ${config.releaseConfig}"
  //        sh ("exit 1")
  //      }
  //      break;
  //    case 'deploy_enviromentVars':
  //      echo "=============================================="
  //      echo "            ${action}"
  //      echo "=============================================="
  //      echo "Testing the Deploy of EnvironmentVars ...."
  //      echo "_envConfig"+_envConfig[action]
  //      _envConfig[action].each { item ->
  //        echo "Server Data:"
  //        echo "  deploy_server: " + item.deploy_server
  //        echo "  deploy_user: " + item.deploy_user
  //        echo "  release_path: " + item.release_path
  //        echo "  deploy_script_path: " + item.deploy_script_path + "/scripts"
  //        echo "  deploy Script: " + config.deployScript

  //        echo "AT: ${item.deploy_server}@${item.deploy_user}"
  //        echo "RUN: ${item.deploy_script_path}/scripts/${config.deployScript}"
  //        echo "PARAMETERS: -a ${config.applicationName} -r ${item.release_path}"
  //        sh "ssh -o StrictHostKeyChecking=no ${item.deploy_user}@${item.deploy_server} 'cd ${item.deploy_script_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.release_path}'"
  //      }
  //      break;
  //    default:
  //      echo "ERROR. Action ${action} not known ...."
  //      sh ("exit 1")
  //      break;
  //  }
  //}
}
