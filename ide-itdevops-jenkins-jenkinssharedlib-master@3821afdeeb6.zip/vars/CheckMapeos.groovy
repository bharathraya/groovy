def call(String _package,String _env,String _remoteServer,String _Aplicacion){
  //check_mapeos "${_ALMS_ID}","${_DeployEnv}","${_server}", R
  //check_mapeos.sh <alms_pck> GENEVA-ONO-MAPEOS-BILLING <environment>
   exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_package}
    check_mapeos.sh  ${_package} ${_Aplicacion}  ${_env} 
    
    """

    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
