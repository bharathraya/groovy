def call(String option,String PaquetesSinPromote, String AplicacionesFalloTesteoPROD,String AplicacionesFalloTesteoSIT2, String DeliveryMal, Integer iConectividades, String _delivery   ){
 

// print "entro 1"
// print "parametrp1 ${option}"
 //print "parametrp2 ${PaquetesSinPromote}"
 //print "parametrp3 ${AplicacionesFalloTesteoPROD}"
 //print "parametrp4 ${AplicacionesFalloTesteoSIT2}"
 //print "parametrp5 ${DeliveryMal}"
 //print "parametrp6 ${iConectividades}"
 //print "parametrp7 ${_delivery}"
 
if ( option == "1" )
{
    
    if (PaquetesSinPromote == "" && AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 == "" && DeliveryMal == "")
      {
           if (_delivery =="")   
            {
                print "THE PACKAGES HAVE THE CORRECT STATUS AND TESTING CORRECTLY"
            }
            else
            {
                 print "THE PACKAGES HAVE THE CORRECT STATUS AND DELIVERY AND TESTING CORRECTLY"
            }
    }
   else
   {
    if ( DeliveryMal == "")
    {
   
        if (_delivery !="")
        { 
            print("These packages have the correct delivery.")
        }
        if(PaquetesSinPromote != "" && AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 == "")
        {
             error ("Packages in wrong status, but test correct")
        }
        else if (PaquetesSinPromote != "" && AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 == "") {
            error ("Packages in wrong status, incorrect PROD testing")
        }
        else if (PaquetesSinPromote != "" && AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 != "") {
             error ("Packages in wrong status, incorrect SIMULATION environment testing")
        }
        else if (PaquetesSinPromote != "" && AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 != "") {
            error ("Packages in wrong status, incorrect SIMULATION environment and PROD testing")
        }
        else if (PaquetesSinPromote == "" && AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 != "") {
               error ("Packages in correct status. Incorrect SIMULATION environment and PROD testing")
        }
        else if (PaquetesSinPromote == "" && AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 != "") {
                error ("Packages in correct status. Incorrect SIMULATION environment testing")
        }
        else if (PaquetesSinPromote == "" && AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 == "") {
                error ("Packages in correct status. Incorrect PROD testing")
        }
        
    }
    else
    {
        
        if(PaquetesSinPromote != "" && AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 == "")
            {
                 error ("Packages in incorrect status and deliveries, but correct testing.")
            }
            else if (PaquetesSinPromote != "" && AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 == "") {
                error ("Packages in incorrect status and deliveries, Incorrect PROD testing.")
            }
            else if (PaquetesSinPromote != "" && AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 != "") {
                 error ("Packages in incorrect status and deliveries, incorrect SIMULATION environment testing.")
            }
            else if (PaquetesSinPromote != "" && AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 != "") {
                error ("Packages in incorrect status and deliveries, Incorrect SIMULATION environment and PROD testing.")
            }
            else if (PaquetesSinPromote == "" && AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 != "") {
                   error ("Packages in correct status. Incorrect SIMULATION environment and PROD testing. Incorrect deliveries.")
            }
            else if (PaquetesSinPromote == "" && AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 != "") {
                    error ("Packages in correct status. Incorrect SIMULATION environment testing. Incorrect deliveries.")
            }
            else if (PaquetesSinPromote == "" && AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 == "") {
                    error ("Packages in correct status. Incorrect PROD testing. Incorrect deliveries.")
            }
            else if (PaquetesSinPromote == "" && AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 == ""){
                error ("Packages in correct status. Test is correct. Incorrect deliveries.")
            }
    }
  }
}
else if ( option == "2" || option == "3" )
{
    
    if (option == "3" && iConectividades != 0)
    {
      if (PaquetesSinPromote == "" && DeliveryMal == "")
        {
            error("THERE IS SOME FAILURE IN THE CONNECTIVITIES")
        }
        else
        {
           print("THERE IS SOME FAILURE IN THE CONNECTIVITIES")
        }
    }
    
    if (_delivery !="")
    {
        if (PaquetesSinPromote != "" && DeliveryMal =="")
        {
            error ("Packages in incorrect status. Deliverys of the correct packages.")
        }
        else if (PaquetesSinPromote == "" && DeliveryMal !="")
        {
            error ("Incorrect delivery packages. Package statuses OK.")
        }
        else if (PaquetesSinPromote != "" && DeliveryMal !="")
        {
            error ("Packages in delivery and incorrect status.")
        }
        else if (PaquetesSinPromote == "" && DeliveryMal =="")
        {
            print "THE PACKAGES HAVE THE CORRECT STATE AND DELIVERY" 
        }
    }
    else
    {
        if (PaquetesSinPromote != "" )
        {
            error ("Packages in incorrect status.")
        }
        else
        {
            print "THE PACKAGES HAVE THE CORRECT STATUS" 
        }
    }
}


}
