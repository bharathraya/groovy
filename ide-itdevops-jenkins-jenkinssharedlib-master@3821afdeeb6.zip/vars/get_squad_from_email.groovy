def call(String _email){
    String ret="BAU"
    // read json resource
    json_string=libraryResource('DAsourcing.json')
    dasourcing=readJSON(text:json_string)
    // find by email
    def item=null
    item=dasourcing.find{it.email.toUpperCase()==_email.toUpperCase()}
    if (item)
        ret=item.squadid
    return ret
}