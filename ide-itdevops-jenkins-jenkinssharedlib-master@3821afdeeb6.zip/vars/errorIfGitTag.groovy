def call(String _TAG) {
    echo "errorIfGitTag"
    if ("${_TAG}" != ""){
        def existetag=sh returnStdout: true, script: """
            git tag -l ${_TAG}
        """
        if ("${existetag}" != ""){

            error "El tag ${_TAG} ya existe"
        }
    }
}
