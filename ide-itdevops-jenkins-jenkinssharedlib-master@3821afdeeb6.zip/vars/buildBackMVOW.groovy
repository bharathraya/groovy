import vfes.git.VFESGitMergeInfo

def call(Map config,VFESGitMergeInfo mergeInfo){
    def onlyProperties=false
    dir("${config.extractFolder}"){
        def gitPropertiesChanged=sh(returnStdout: true, script: "git diff --name-only  ${mergeInfo.commitBefore}..${mergeInfo.commitAfter} | sed -n '/^WCS-[a-zA-Z0-9]*\\/properties\\//!p'").toString().trim()
        

        echo "gitPropertiesChanged: ${gitPropertiesChanged}"
        echo "Number of gitFilesChanged: ${mergeInfo.filesChanged.size()}"
        if (mergeInfo.filesChanged.size()>0){
            // there are changes involved !
            if (gitPropertiesChanged != ""){
                onlyProperties=false
            }else
            {
                onlyProperties=true
            }
        }else{
            //in case no changes involved , lets recompile all
            onlyProperties=false
        }
    }
    if (onlyProperties){
        echo "There are only property files modified, no need to build!!!"
    }
    else{
        echo "We start build as there are code changes involved in current merge..."

        buildWithScript(config)
    }
    return onlyProperties
}
  