#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever
import groovy.time.TimeCategory

// Parametros necesario

def _server=""
def _serverSVN=""
def _funcion=""
def _funcionEnt=""
def funcConfig=""
def hoy=""
def _funcionAejecutar=""
def _serverAenviar=""
def _WB_ID=""
def envsConfig
def _listapaquetes=""
def _serverPROD=""
def mybuilduser=""

def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            choice(name: 'Application', choices: pipelineParams.applicationChoices, description: 'BW/ADAPTER or HAWK to restart') 
            string(name: 'COMPONENT', defaultValue: '', description: 'Components o Hawk Domain  to restart') 
            choice(name: 'Enviroment',  choices: pipelineParams.environmentChoices , description: 'Enviroment to restart') 
            choice(name: 'Opcion',  choices: pipelineParams.OptionChoices , description: 'Restart or check status') 
             
         } //parameters
         
 stages{              
     stage("Prepare"){
        agent {
              label 'MEDIACION'
              }
        steps{
          script {
                  
                   wrap([$class: 'BuildUser']) {
                         echo "Exec user: ${env.BUILD_USER_ID}"
                         mybuilduser=env.BUILD_USER_ID
                       }
                   
               
                hoy=new Date().format( 'yyyyMMdd' )
                print "La fecha de hoy es ......${hoy}......"
                 _env=params.Enviroment  
                _Component=params.COMPONENT.trim() 
                _App=params.Application
                
                if (_App == "HAWK" || _App == "BW")
                {
                    _Domain="CO-BW"
                }
                else
                {
                        _Domain="CO-Adapter"
                }
                _option=params.Opcion
                    
                   print "Opcion ${_option}"
                   print "Component  ${_Component}"
                if (_App == "HAWK" && _Component ==""  )    
                {
                    //Configuramos el nombre del build y su descripcion
                    currentBuild.displayName = "Hawk ALL Env: ${_env} "
                    currentBuild.description = "Action to do ${_option}"
                }
                else if (_App == "HAWK" && _Component !=""  )    
                {
                        currentBuild.displayName = "Hawk : ${_Component} Env: ${_env} "
                        currentBuild.description = "Action to do ${_option}"
                }
                 else if (_App == "BW" || _App == "ADAPTER"  )    
                {
                        currentBuild.displayName = "APPS : ${_Component} Env: ${_env} "
                        currentBuild.description = "Action to do ${_option}"
                }
                if ((_App == "BW" || _App == "ADAPTER") && _Component =="")
                {
                    error("IT IS NECESSARY COMPONENT")
                }
                
        
                    //leemos el fichero de configuracion
                    pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                    //leemos el fichero de entornos
                    envsConfig=pipelineConfig.envConfig
                    enviroments=readJSON(file: "${envsConfig}")
                    _server=enviroments["${_Domain}"]["${_env}"]["server"][0][0]
                    
                    
          }//Script
       }//steps
     } //Prepare             
    
         stage("Rebotar"){
               agent {
                    node("${_Domain}-${_env}")
                        }

                steps{
                    script {
                        
                    if ("${env.NODE_NAME}" == "${_server}")
                      {
                       _server =""
                         //  borramos el server para no hacer ssh
                     }
                   
                    //Se ha elegido APPS y RESTART
                    if (_App =="BW" && _option =="RESTART")
                    {
                        exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                        if [ "${_env}" = "ppr1" ]
                        then
                            ssh tibppr@vodltq02 ". /home/tibppr/.profile ; cd /home/tibppr/products/DOMAIN/scripts ; ./restartApps ${COMPONENT} "
                            exit
                        fi 
                        if  [ "${_env}" = "sit1" ] 
                        then
                                ssh tibppr@vodltq01 ". /home/tibppr/.profile ; cd /home/tibppr/products/DOMAIN/scripts ; ./restartApps ${COMPONENT} "  
                                exit
                        fi
                        if  [ "${_env}" = "ppr2" ]
                        then
                                ssh tibprd@vodloq01 ". /home/tibprd/.profile ; cd /home/tibprd/products/DOMAIN/scripts ; ./restartApps ${COMPONENT} "  
                                exit
                        fi        
                        if  [ "${_env}" = "hid1" ]
                        then
                                ssh tibprd@vodloq03 ". /home/tibprd/.profile ; cd /home/tibprd/products/DOMAIN/scripts ; ./restartApps ${COMPONENT} "  
                                exit
                        fi

                       
                    
                        """
                    }
                    if (_App =="BW"  &&  _option =="STATUS")
                    {
                         exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                        if [ "${_env}" = "ppr1" ]
                        then
                            ssh tibppr@vodltq02 ". /home/tibppr/.profile ; cd /home/tibppr/products/DOMAIN/scripts ; ./checkApp ${COMPONENT} "
                            exit
                        fi 
                        if  [ "${_env}" = "sit1" ] 
                        then
                                ssh tibppr@vodltq01 ". /home/tibppr/.profile ; cd /home/tibppr/products/DOMAIN/scripts ; ./checkApp ${COMPONENT} "  
                                exit
                        fi
                        if  [ "${_env}" = "ppr2" ]
                        then
                                ssh tibprd@vodloq01 ". /home/tibprd/.profile ; cd /home/tibprd/products/DOMAIN/scripts ; ./checkApp ${COMPONENT} "  
                                exit
                        fi        
                        if  [ "${_env}" = "hid1" ]
                        then
                                ssh tibprd@vodloq03 ". /home/tibprd/.profile ; cd /home/tibprd/products/DOMAIN/scripts ; ./checkApp ${COMPONENT} "  
                                exit
                        fi

                       
                    
                        """
                    }
                    if (_App =="HAWK" && _option =="RESTART")
                    {
                         exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                        if [ "${_env}" = "ppr1" ]
                        then
                            ssh tibppr@vodltq02 ". /home/tibppr/.profile ; cd /home/tibppr/products/DOMAIN/scripts ; ./stopHawkDomain ${COMPONENT} ; echo '**********STOPPED***************'; ./startHawkDomain ${COMPONENT} ; echo '**********STARTED***************'; ./checkHawkDomain ${COMPONENT} "  
                            exit
                        fi 
                        if  [ "${_env}" = "sit1" ] 
                        then
                                ssh tibppr@vodltq01 ". /home/tibppr/.profile ; cd /home/tibppr/products/DOMAIN/scripts ; ./stopHawkDomain ${COMPONENT} ; echo '**********STOPPED***************'; ./startHawkDomain ${COMPONENT} ; echo '**********STARTED***************'; ./checkHawkDomain ${COMPONENT} "  
                                exit
                        fi
                        if  [ "${_env}" = "ppr2" ]
                        then
                                ssh tibprd@vodloq01 ". /home/tibprd/.profile ; cd /home/tibprd/products/DOMAIN/scripts ; ./stopHawkDomain ${COMPONENT} ; echo '**********STOPPED***************'; ./startHawkDomain ${COMPONENT} ; echo '**********STARTED***************'; ./checkHawkDomain ${COMPONENT} "  
                                exit
                        fi        
                        if  [ "${_env}" = "hid1" ]
                        then
                                ssh tibprd@vodloq03 ". /home/tibprd/.profile ; cd /home/tibprd/products/DOMAIN/scripts ; ./stopHawkDomain ${COMPONENT} ; echo '**********STOPPED***************'; ./startHawkDomain ${COMPONENT} ; echo '**********STARTED***************'; ./checkHawkDomain ${COMPONENT} "  
                                exit
                        fi

                       
                    
                        """
                    }
                    
                     if (_App =="HAWK" && _option =="STATUS")
                    {
                         exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                        if [ "${_env}" = "ppr1" ]
                        then
                            ssh tibppr@vodltq02 ". /home/tibppr/.profile ; cd /home/tibppr/products/DOMAIN/scripts ; ./checkHawkDomain ${COMPONENT} "
                            exit
                        fi 
                        if  [ "${_env}" = "sit1" ] 
                        then
                                ssh tibppr@vodltq01 ". /home/tibppr/.profile ; cd /home/tibppr/products/DOMAIN/scripts ; ./checkHawkDomain ${COMPONENT} "  
                                exit
                        fi
                        if  [ "${_env}" = "ppr2" ]
                        then
                                ssh tibprd@vodloq01 ". /home/tibprd/.profile ; cd /home/tibprd/products/DOMAIN/scripts ; ./checkHawkDomain ${COMPONENT} "  
                                exit
                        fi        
                        if  [ "${_env}" = "hid1" ]
                        then
                                ssh tibprd@vodloq03 ". /home/tibprd/.profile ; cd /home/tibprd/products/DOMAIN/scripts ; ./checkHawkDomain ${COMPONENT} "  
                                exit
                        fi

                       
                    
                        """
                    }
                     if (_App =="ADAPTER" && _option =="STATUS")
                    {
                         exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                        if [ "${_env}" = "ppr1" ]
                        then
                            ssh tibppr@ppmw01 ". /home/tibppr/.profile ; cd /home/tibppr/products/ADAPTER/ADTIBTUX/scripts ; ./checktibtux_PPR1 ${COMPONENT} "
                            exit
                        fi 
                        if  [ "${_env}" = "sit1" ] 
                        then
                                ssh tibppr@ppmw01 ". /home/tibppr/.profile ; cd /home/tibppr/products/ADAPTER/ADTIBTUX/scripts ; ./checktibtux_SIT1 ${COMPONENT} "  
                                exit
                        fi
                        if  [ "${_env}" = "ppr2" ]
                        then
                                ssh tibppr@ppmw01 ". /home/tibppr/.profile ; cd /home/tibppr/products/ADAPTER/ADTIBTUX/scripts ; ./checktibtux_PPR2 ${COMPONENT} "  
                                exit
                        fi        
                        if  [ "${_env}" = "hid1" ]
                        then
                                ssh tibprd@pmw05 ". /home/tibprd/.profile ; cd /home/tibprd/products/ADAPTER/ADTIBTUX/scripts ; ./checktibtux ${COMPONENT} "  
                                exit
                        fi

                       
                    
                        """
                    }
                     if (_App =="ADAPTER" && _option =="RESTART")
                    {
                         exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                        if [ "${_env}" = "ppr1" ]
                        then
                            ssh tibppr@ppmw01 ". /home/tibppr/.profile ; cd /home/tibppr/products/ADAPTER/ADTIBTUX/scripts ; ./stoptibtux_PPR1 ${COMPONENT} ; echo '**********STOPPED***************'; ./starttibtux_PPR1 ${COMPONENT} ON;echo '**********TRZ***************';tail -20 /home/tibppr/logs/ADAPTER/ADTIBTUX/PPR1/${COMPONENT}.trz; echo '**********STARTED***************'; ./checktibtux_PPR1 ${COMPONENT} "  
                            exit
                        fi 
                        if  [ "${_env}" = "sit1" ] 
                        then
                                echo "es sit1"
                                ssh tibppr@ppmw01 ". /home/tibppr/.profile ; cd /home/tibppr/products/ADAPTER/ADTIBTUX/scripts ; ./stoptibtux_SIT1 ${COMPONENT} ; echo '**********STOPPED***************'; ./starttibtux_SIT1 ${COMPONENT} ON ;echo '**********TRZ***************';tail -20 /home/tibppr/logs/ADAPTER/ADTIBTUX/SIT1/${COMPONENT}.trz; echo '**********STARTED***************'; ./checktibtux_SIT1 ${COMPONENT} "  
                                exit
                        fi
                        if  [ "${_env}" = "ppr2" ]
                        then
                                ssh tibppr@ppmw01 ". /home/tibppr/.profile ; cd /home/tibppr/products/ADAPTER/ADTIBTUX/scripts ; ./stoptibtux_PPR2 ${COMPONENT} ; echo '**********STOPPED***************'; ./starttibtux_PPR2 ${COMPONENT} ON ;echo '**********TRZ***************';tail -20 /home/tibppr/logs/ADAPTER/ADTIBTUX/PPR2/${COMPONENT}.trz; echo '**********STARTED***************'; ./checktibtux_PPR2 ${COMPONENT} "  
                                exit
                        fi        
                        if  [ "${_env}" = "hid1" ]
                        then
                                ssh tibprd@pmw05 ". /home/tibprd/.profile ; cd /home/tibprd/products/ADAPTER/ADTIBTUX/scripts ; ./stoptibtux ${COMPONENT} ; echo '**********STOPPED***************'; ./starttibtux ${COMPONENT} ; echo '**********STARTED***************'; ./checktibtux ${COMPONENT} "  
                                exit
                        fi

                       
                        """
                    }
                
                
                if (_server !="")
                 {
                          sh "ssh -q ${_server} '${exec}'"
                 }
                else
                 {
                        sh "${exec}"
                 }
                


        }//Script
       }//steps
     } //Rebotar
    }//stages
 }//pipeline
}//map


