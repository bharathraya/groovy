def call(String _NombreCRQ, Boolean _View, String _listapaquetes, Boolean _revisar, Boolean _estados, String _NombreView, String mybuilduser, String _pass){
  _remoteServer ="es036tvr"
   hoy=new Date().format( 'yyyyMMdd' )
   if (_View == false && _listapaquetes != "" )
   {
        get_applicationCRQ(_NombreCRQ,'"' + _listapaquetes + '"',mybuilduser,_pass)
   }
   else
   {
       if (_View == true)
       {
            get_packagesbyview(_NombreView,mybuilduser,_pass)
             if ( "${_NombreCRQ}" != "${_NombreView}" )
                {
               exec="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete  ${_NombreCRQ} >/dev/null 2>&1
                cp  /home/plataforma/plausr/data/paquetes/${hoy}/${_NombreView}/ListaPaquetes.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_NombreCRQ}
                """
                sh "ssh -q es036tvr '${exec}'"
            }

       }   
   }
   
   if (_revisar == false && _estados == false )
   {
       //Lanzo el script para sacar los paquetes a notificar y promocionar
       exec="""
        . \$HOME/.profile >/dev/null 2>&1
        ListaPaquetesTIB.sh -p  ${_NombreCRQ} -W
    """
    }
    else
    {
        if (_revisar == true ){
            //Lanzo el script para revisar si quedan paquetes sin promocionar a PROD
           exec="""
            . \$HOME/.profile >/dev/null 2>&1
            ListaPaquetesTIB.sh -p  ${_NombreCRQ} -W -R
            """
        }
        if (_estados == true ){
            //Lanzo el script para revisar los estados de paquetes
            exec="""
            . \$HOME/.profile >/dev/null 2>&1
            ListaPaquetesTIB.sh -p  ${_NombreCRQ} -W -E
            """
        }
    }
    
    sh "ssh -q ${_remoteServer} '${exec}'"
    sh "if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ} ] ; then mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ} ; fi"
    sh "cd /home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ} ; scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ}/* ."
    
    

}

def call(String _NombreCRQ){
    _remoteServer ="es036tvr"
    hoy=new Date().format( 'yyyyMMdd' )
    //Lanzo el script para revisar los estados de paquetes
            exec="""
            . \$HOME/.profile >/dev/null 2>&1
            ListaPaquetesTIB.sh -p  ${_NombreCRQ} -W -E
            """
            sh "ssh -q ${_remoteServer} '${exec}'"
            sh "if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ} ] ; then mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ} ; fi"
            sh "cd /home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ} ; scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ}/* ."
}
