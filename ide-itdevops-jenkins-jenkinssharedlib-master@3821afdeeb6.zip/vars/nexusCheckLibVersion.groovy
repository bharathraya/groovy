import groovy.json.JsonSlurper;
/**
* this method need below params:
*    NEXUS_URL
*    REPO
*    GID
*    ARTID
*    EXTENSION
*    COMMIT
*/

def call (String _NEXUS_URL,String _REPO,String _GID,String _ARTID,String _EXTENSION,String _VERSION, String _sCredential ) {
    echo "nexusCheckLibVersion"
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${_sCredential}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 

        def SALIDA=sh returnStdout: true, script: """
            curl -u ${USERNAME}:${PASSWORD} -k "${_NEXUS_URL}/service/rest/v1/search?repository=${_REPO}&format=maven2&group=${_GID}&name=${_ARTID}&maven.extension=${_EXTENSION}&version=${_VERSION}"
            """
        def version=""
        def downloadUrl=""
        if (SALIDA !="" ){
            def jsonSlurper = new JsonSlurper()
            def jsonnexusquery = jsonSlurper.parseText(SALIDA)
            jsonnexusquery.items.any{ 
                echo "encontrada version: ${it.version}"
                if( "${it.version}" == "${_VERSION}"){   
                    echo "Ya existe el artefacto en nexus ${_ARTID}:${version}"
                    version=it.version
                    def base="${_NEXUS_URL}/repository/${_REPO}/${_GID}/${_ARTID}/${version}/"
                    it.assets.any{
                        echo "tratando: ${it.downloadUrl}"
                        def artifact="${it.downloadUrl.substring(base.size(),it.downloadUrl.size())}"
                        echo "chequeando: ${artifact} vs ${_ARTID}-${version}.${_EXTENSION}"
                    	if ( "${artifact}" == "${_ARTID}-${version}.${_EXTENSION}"){
                    	    downloadUrl=it.downloadUrl
                    	    return true
                    	}
                    }
                    return true
                }
            }
        }
        return [version,downloadUrl]
    }
}
