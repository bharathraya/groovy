import vfes.utils.VFESALMSDeployment

def call(Map config,VFESALMSDeployment alms,String result){
    echo "slackNotify:alms"

    def color=""
    def notify=true
	def commitShort=alms?.commitID? "${alms.commitID.substring(0,7)}":""
	def deliveryID=alms?.deliveryID? "${alms.deliveryID}":""
	def almsID=alms?.almsID? "${alms.almsID}":""
	def projectID=alms?.projectID? "${alms.projectID}":""
	def deployEnv=alms?.deployEnv? "${alms.deployEnv}":""
	def appName=alms?.appName? "${alms.appName}":""

	def packageMessage    ="Package: ${almsID} (${commitShort}) (${deliveryID}-${projectID})\n"
	def appNameMessage    ="App: ${appName} (${deployEnv})\n"
	if (config.containsKey("applicationType") && config.applicationType!=""){
	  appNameMessage    ="App: ${config.applicationType} ${appName} (${deployEnv})\n"
	}
	//def deployEnvMessage  ="Env: ${alms.deployEnv}\n"
	def resultMessage     =""
	def message=""
	def slackAccountMessage=""
	def jenkingsMessage   ="(<${env.BUILD_URL}|View job>)\n"
	def stage=env.current_stage ? "(${env.current_stage})" : "" //
	if (config.containsKey("slackAccount") && config.slackAccount!=""){
	    if (config.slackAccount =~ "@"){
    	    slackAccountMessage    ="@${config.slackAccount.substring(0,config.slackAccount.lastIndexOf("@"))}\n"
	    }
    	else{
    	    slackAccountMessage    ="@${config.slackAccount}\n"
    	}
	}

	if (config.containsKey("slackChannel") && config.slackChannel!=""){
		switch(result) {
			case "START":
				color="#00FF00" // green
				resultMessage="Start package ..."
				message="${slackAccountMessage}${packageMessage}${appNameMessage}${resultMessage}"
				notify=false
				if (config.containsKey("applicationType") && config.applicationType!=""){
				  switch(config.applicationType) {
  				    case "TIPO-EJEMPLO":
  				      notify=true
  				    break
				  }
				}
			break
			case "OK":
				color="#00FF00" // green
				resultMessage="Finished successfully !!! :smile: "
				message="${slackAccountMessage}${packageMessage}${appNameMessage}${resultMessage}${jenkingsMessage}"
			break
			case "ERROR":
				color="#FF0000" // red
				resultMessage="Failed ${stage} !!! :sweat: "
				message="${slackAccountMessage}${packageMessage}${appNameMessage}${resultMessage}${jenkingsMessage}"
			break
		}
		if (notify){
		  slackSend(channel: config.slackChannel, color: color, message: message)
		  if (config.containsKey("slackChannel2") && config.slackChannel2!=""){
		      slackSend(channel: config.slackChannel2, color: color, message: message)
		  }
		}
	}
}


