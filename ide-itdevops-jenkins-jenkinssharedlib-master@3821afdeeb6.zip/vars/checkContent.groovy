def call (String _Repo, String _Project, String _Origen, String _Commit, String _RamaDestino, String _Fichero, String _User, String _pass){
    node ('es1117yw'){
     checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
			try {
			  ansiColor('xterm') {
						if(_Fichero!=""){ 
							if(_Commit!="" && _RamaDestino==""){  
								bat "python test-bitbucket2.py -r ${_Repo} -p ${_Project} -d ${_Origen} -c ${_Commit} -f ${_Fichero} -u ${_User} -x ${_pass}"
							}else{
								if(_Commit=="" && _RamaDestino!=""){  
									bat "python test-bitbucket2.py -r ${_Repo} -p ${_Project} -d ${_Origen} -b ${_RamaDestino} -f ${_Fichero} -u ${_User} -x ${_pass}"
								}else{
									if(_Commit!="" && _RamaDestino!=""){  
										throw new Exception("No se puede meter commit y rama destino")
									}
								}
							}
						}else{
							if(_Commit!="" && _RamaDestino==""){  
								bat "python test-bitbucket2.py -r ${_Repo} -p ${_Project} -d ${_Origen} -c ${_Commit} -u ${_User} -x ${_pass}"
							}else{
								if(_Commit=="" && _RamaDestino!=""){  
									bat "python test-bitbucket2.py -r ${_Repo} -p ${_Project} -d ${_Origen} -b ${_RamaDestino} -u ${_User} -x ${_pass}"
								}else{
									if(_Commit!="" && _RamaDestino!=""){  
										throw new Exception("No se puede meter commit y rama destino")
									}
								}				
						}
				  }
				}
			}
			catch (Exception e){
			  echo "ERROR: ${e}"
			  error ("Fallo en la comprobacion del contenido")
			}
		}
    }
}