def call(String _environment,String _packageName,String _sanityDate,String _moduleWithPath,String _remoteServer){
   def opt_parameters=""
   def exec=""
   
    if (_sanityDate!=""){
        opt_parameters="-f ${_sanityDate}"
        if (_moduleWithPath!=""){
            opt_parameters="${opt_application} -R"
        }
    }
    else{
        if (_moduleWithPath!=""){
            opt_parameters="-R"
        }
        else{
            opt_parameters=""
        }
    }
    
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    creaOrdenVentanaONO.sh -e ${_environment} -p ${_packageName} ${opt_parameters}
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}