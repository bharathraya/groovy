import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(Map config,VFESALMSDeployment alms)
{
  def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
  def _envConfig=myEnvsConfig[alms.deployEnv]
  echo "Restarting kibana ...."
  echo "_envConfig"+_envConfig['restart_kibana']
  _envConfig['restart_kibana'].each { item ->
    echo "Server Data:"
    echo "  ReStart Server: " + item.restart_server
    echo "  ReStart User: " + item.restart_user
    echo "  ReStart Scripts path: " + item.restart_scripts_path
    echo "  ReStart Script: " + config.restartScript
    echo "AT: ${item.restart_user}@${item.restart_server} RUN: ${item.restart_scripts_path}/${config.restartScript}"
    sh "ssh -o StrictHostKeyChecking=no ${item.restart_user}@${item.restart_server} 'cd ${item.restart_scripts_path}; ./${config.restartScript}'"
    echo ""
  }
}
