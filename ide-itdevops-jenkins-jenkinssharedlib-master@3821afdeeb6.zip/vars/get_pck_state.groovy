def call (String _wbID , String User , String _pass ){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                bat "python get_pck_state.py -u ${User} -c ${_pass} -p  ${_wbID}"
           }
        }
    }
}
def call (String _wbID , String User , String _pass, String _formato ){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
               // print "Formato ${_formato}"
                if (_formato =="SI")
                {
                    bat "python get_pck_state.py -t -u ${User} -c ${_pass} -p  ${_wbID}"
                }
                else{
                    bat "python get_pck_state.py -u ${User} -c ${_pass} -p  ${_wbID}"
                }
           }
        }
    }
}