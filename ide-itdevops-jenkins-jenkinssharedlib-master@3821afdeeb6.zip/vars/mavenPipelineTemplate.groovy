import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo

def deploy_env=""
def commit_id=""
def alms_id=""
def delivery=""
def project_id=""
def artifact_id=""
def squad=""

def almsPackage=null
def gitRepo=null
def pipelineConfig=null
VFESGitMergeInfo mergeInfo=null
def artifacts=null
def gitRepoURL=""

def labelDeploy=""

def detectMavenArtifactsWithProperties(String projectPath){
    def artifacts=[]
    dir("${projectPath}"){
        poms=findFiles glob:"**/pom.xml"
        for (i=0;i<poms.size();i++)
        { 
            def pomfile=poms[i]
            echo "name: ${pomfile.name} path: ${pomfile.path} directory: ${pomfile.directory}"
            def pom = readMavenPom file: pomfile.path
            echo "    packaging:${pom.packaging}"
            if (pom.packaging ==~ /[jwe]ar/){
                echo "    packaging:${pom.packaging}"
                def artifact=[groupId:"${pom.groupId}",artifactId:"${pom.artifactId}",version:"${pom.version}",packaging:"${pom.packaging}",pomfile:"${pomfile.name}"]
                echo "artifact:${artifact}"
                artifacts+=artifact
            }
        }
        
    }
    return artifacts

}
def detectChangedArtifacts(Map config){
    def ret=null
    switch(config.artifactDetection) {
        case 'maven_full_compile':
            echo "Detecting all maven artifacts... "
            ret=detectMavenArtifactsWithProperties(config.extractFolder)
        break
    }
    return ret
}
def call(Map pipelineParams){
    pipeline{
        agent none
        parameters { 
            //09-10-20 meguiza2
            choice(name: 'DeployEnv',  choices: pipelineParams.environmentChoices , description: '') 
            choice(name: 'ArtifactId', choices: pipelineParams.artifactChoices, description: '') 
            //string(name: 'DeployEnv', defaultValue: '', description: 'SIT1CI, SIT2CI, SIT3CI, PPRD1CI, HID1CI, masterCI or master(EDC)') 
            //string(name: 'ArtifactId', defaultValue: '', description: '') 
            //09-10-20 meguiza2
            string(name: 'CommitID', defaultValue: '', description: '') 
            string(name: 'ALMS_ID', defaultValue: '', description: '') 
            string(name: 'Delivery', defaultValue: '', description: '') 
            string(name: 'ProjectId', defaultValue: '', description: '') 
            string(name: 'SQUAD', defaultValue: 'BAU', description: '') 
			booleanParam(name: 'runUT', defaultValue:true,description:'De-activate to skip Unit Testing')
			//booleanParam(name: 'runKiuwan', defaultValue:true,description:'De-activate to skip Kiuwan Audit')
			

            string(name: 'PackageInfo', defaultValue: '', description: '') 
        }
        stages{
            
            stage("Prepare"){
                agent {
                    label "MVOW"
                }
                steps{
                    script {
                        if (params.PackageInfo==""){
                            // executed manually or from ALMS
                            print "DEBUG lanzo manual"
                            deploy_env=params.DeployEnv
                            
                            commit_id=params.CommitID
                            
                            alms_id=params.ALMS_ID
                            delivery=params.Delivery
                            project_id=params.ProjectId
                            artifact_id=params.ArtifactId
                            squad=params.SQUAD
                        }else{
                            echo "PackageInfo: ${params.PackageInfo}"
                            try{
                                (deploy_env,commit_id,alms_id,delivery,project_id,squad,artifact_id)=parsePckInfoWithArtifact(PackageInfo)
                            }catch (e) {
                                error "${e}"
                            }
                            //pckinfo=readJSON(text:PackageInfo)
                            //deploy_env=pckinfo.Environment.Name
                            //commit_id=pckinfo.decideCommitId(pckinfo.Commits,deploy_env)
                            //alms_id=pckinfo.Id
                            //delivery=pckinfo.Delivery.Name
                            //project_id=pckinfo.Project.CodProject
                            //squad=pckinfo.EnterpriseName
                        }
                        echo "    ArtifactId:  ${artifact_id}"
                        echo "    DeployEnv: ${deploy_env}"
                        echo "    CommitID:  ${commit_id}"
                        echo "    PackageID: ${alms_id}"
                        echo "    Delivery:  ${delivery}"
                        echo "    Project:   ${project_id}"
                        echo "    Squad:     ${squad}"

                        /*if (deploy_env == "SIT3CI"){
                            createReject(alms_id,"Hay un problema en el entorno","99")
                            error("Hay un problema en el entorno")
                        }*/

                        //Prueba en PREPRO deshabilitar APP
                        if(artifact_id=="mavenexampleproject"){
                            createReject(alms_id,"Errores en el entorno deshablitamos la app en la configuracion","99")
                            error("Errores en el entorno deshablitamos la app en la configuracion")

                        }

                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
						File fileConfig = new File(pipelineParams.pipelineConfigFile)
						pipelineConfigFolder=fileConfig.getParentFile().getName();
						echo "looking up for additional  configuration for artifact "+pipelineConfigFolder+"/"+artifact_id+".yaml"
						if (fileExists (file:pipelineConfigFolder+"/"+artifact_id+".yaml")){
							echo "Reading "+pipelineConfigFolder+"/"+artifact_id+".yaml"
							def artifactConfig=readYaml(file:pipelineConfigFolder+"/"+artifact_id+".yaml")
							echo "merging pipelineconfig and artifactconfig"
							pipelineConfig=pipelineConfig+artifactConfig

						}
                        //Distinto label deploy segun app
                        //"${pipelineConfig.deployToken}-${deploy_env}"
                        if(artifact_id=="vf-back-tienda" || artifact_id=="vf-back-trastienda"){
                            echo"Es tienda o trastienda, cambiamos label deploy"
                            labelDeploy="${artifact_id}-${deploy_env}"

                        }
                        else{
                            echo "Ponemos el label deploy por defecto"
                            labelDeploy="${pipelineConfig.deployToken}-${deploy_env}"
                        }
                        echo "El label para desplegar es : "+labelDeploy
                        almsPackage= new VFESALMSDeployment(alms_id,artifact_id,deploy_env,commit_id,delivery,project_id,squad)
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
						def addArtifactToExtractFolder=true
						if (pipelineConfig.containsKey("addArtifactToExtractFolder")){
							addArtifactToExtractFolder=pipelineConfig.addArtifactToExtractFolder
						}
						if (addArtifactToExtractFolder){
							echo "Adding the artifact to the extract folder"
                        	pipelineConfig.extractFolder=pipelineConfig.extractFolder+"/"+artifact_id
						}
                        // TODO : when 
                        if (pipelineConfig.gitRepoPath!=""){
                            gitRepoURL=pipelineConfig.gitRepoPath+artifact_id+".git"
                            echo "Git Repo URL: ${gitRepoURL}"
                            gitRepo=new VFESGitRepo("${gitRepoURL}",this)    
                        }else{
                            gitRepo=new VFESGitRepo("${pipelineConfig.gitRepo}",this)
                        }
						env.switchUT=false
						env.BITBUCKETAPIURL = "https://webpre-adm.es.sedc.internal.vodafone.com:42520/bitbucket/rest/api"
						if (gitRepo.repoType==gitRepo.BITBUCKET){
							env.switchUT=checkUnitTest(env.BITBUCKETAPIURL,gitRepo.repoProjectKey,gitRepo.repoName)
						}
						env.switchKiuwan=getRunKiuwan(pipelineConfig,artifact_id)
						echo "SWITCH KIUWAN ${env.switchKiuwan}"

                    }
                    
                }
            }
            stage('Checkout'){
                agent {
                    
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
						echo "pipelineConfig.BranchPolicy: ${pipelineConfig.branchPolicy} almsPackage.deployEnv: ${almsPackage.deployEnv}"
                        if (pipelineConfig.branchPolicy=="SIMPLE" && ! (almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/)){
							echo "SIMPLE branch policy and non-prod or develop env ! doing checkoutCommit"
                            gitRepo.checkoutCommit(pipelineConfig.extractFolder,almsPackage.deployEnv,almsPackage.commitID)
                        }else if (pipelineConfig.branchPolicy==~/(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI)/)
                        {
                            gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,"develop")
                        }else{
                            gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
                        }
                    }
                }
            }
            stage('merge'){
                when{
                    expression { return (!(pipelineConfig.branchPolicy ==~ /SIMPLE/) || (pipelineConfig.branchPolicy ==~ /SIMPLE/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/))}
                }
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy ==~ /(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(master|masterCI)/){
                            echo "Merging to ${almsPackage.deployEnv} we will check for the corresponding tag for ${almsPackage.commitID} in develop branch..."
                            mergeInfo=gitRepo.mergeCommitFromDevelop(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage,almsPackage.almsID)
                        }else{
                            mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
                        }
                        
                    }
                }
            }
            stage('detectChangedArtifacts'){
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    }
                }
                steps{
                    script{
                        artifacts=detectChangedArtifacts(pipelineConfig)
                        echo "Artifacts: ${artifacts}"
                    }
                }
            }
			stage('RunTests'){
				when{
					//expression {return (env.switchUT && params.runUT) } }
					expression {return env.switchUT && params.runUT }					
				}
				agent {
                    label 'maven'
                }
				steps{
					script{
						docker.image("${pipelineConfig.dockerImage}").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr') { c -> 
							if (pipelineConfig.containsKey("testScript")){
								env.DIR_JACOCO='jacoco'
								
								buildWithScript.runScript pipelineConfig,pipelineConfig.testScript
								dir("${pipelineConfig.extractFolder}"){
									//sh "mvn org.jacoco:jacoco-maven-plugin:report"
									jacoco()
								}
								
							}
                        } 
					}

				}
			}
			stage ("Generate Kiuwan reports"){
                when{
                    //expression { return env.switchKiuwan && env.switchUT && params.runUT && params.runKiuwan}
					expression { return env.switchKiuwan && env.switchUT }
                    beforeAgent true
                }
				agent {
                    label 'maven'
                }
				steps{
					script{
						docker.image("harbor.es.sedc.internal.vodafone.com/jenkins-workers/vf-python3-slave:latest").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr') { c -> 
							kiuwanDevOps.Coverage("${WORKSPACE}/${pipelineConfig.extractFolder}")
						}
						
					}
				}

			}
            stage('Compile'){
                agent {
                    label 'maven'
                    //docker {

                        // TODO : revisar si usamos "cache" de npm 
                        //label 'maven'
                        //image "${pipelineConfig.dockerImage}"
                        //args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                        //reuseNode true
                    //}
                }
                steps{
                    // TODO : manejar el caso master/ HID vs resto entornos
                    // TODO : gestionar el empaquetado del resultado 
                    script{
                        docker.image("${pipelineConfig.dockerImage}").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr') { c -> 
                            buildWithScript pipelineConfig
                        }   
                    }
                    
                }            
            }
			
			
            stage('RunKiuwan'){
				when{
                    //expression { return env.switchKiuwan && env.switchUT && params.runUT && params.runKiuwan}
					expression { env.switchKiuwan != 'false' }
                    beforeAgent true
                }
                agent {
					label 'maven'
                }
                steps{
					script{
                        //if (deploy_env != "SIT3CI"){
                    	docker.image("${pipelineConfig.kiuwanImage}").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr') { c -> 
							if (pipelineConfig.branchPolicy ==~ /(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(master|masterCI)/){
                    			//runKiuwan.promoteDevelopBaseline pipelineConfig, almsPackage, gitRepo,mergeInfo.developCommitId,mergeInfo.commitAfter
							}
							else if (pipelineConfig.branchPolicy ==~ /SIMPLE/){
								if (deploy_env ==~ /(?i)(hid|hid1|hidci|hid1ci)/ )
									runKiuwan pipelineConfig, almsPackage, gitRepo,mergeInfo.commitAfter
								else
									runKiuwan pipelineConfig, almsPackage, gitRepo,almsPackage.commitID
							}else{
								runKiuwan pipelineConfig, almsPackage, gitRepo,mergeInfo.commitAfter
							}
						}
                        //}
					}
                }
            }
            

            stage('CopyToRelease'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                }
                agent{
                    //label "deploy-apache-wcs"
                    label 'maven'
                }
                steps{
                    script{
                        if (pipelineConfig.artifactDetection!='maven_full_compile'){
                            echo "Download artifacts from Nexus ..."
                            downloadArtifactsFromNexus pipelineConfig, almsPackage
                        }
                        echo "DeployType: ${pipelineConfig.deployType}"
                        switch(pipelineConfig.deployType) {
                            case ~/^(wcs-app)$/:
                                echo "Copy code to release folder ..."
                                copyToRelease  pipelineConfig,  almsPackage
                            break
                            case ~/^(release|catalogo)$/:
                                echo "Copy code to release folder ..."
                                copyToRelease  pipelineConfig,  almsPackage
                            break
                            case ~/^(wl_redeploy)$/: case ~/^(wl_restart)$/:
                                echo "Do wl_redeploy..."
                                copyToReleaseWL pipelineConfig, almsPackage
                            break
                            case ~/^apache$/:
                                echo "Deploy to apache ..."
                                deployToApacheScript.deploy  pipelineConfig,almsPackage

                            break

							case ~/^download_from_nexus$/:
								echo "Downloading from nexus and copying to release folders"
								checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'CDM']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', url: 'http://eswltbhr:8282/vodafone/CDM.git']]]
								getArtifactsFromNexus("https://nexus-apps.es.sedc.internal.vodafone.com/nexus","releases-maven-repository",artifacts)
								ansibleCopyLocalArtifactsToRelease(pipelineConfig,almsPackage,artifacts,)
							break
                        }
                   
                    }

                }
            }

            stage('Deploy'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                }
                agent{
                    label "${labelDeploy}"
                }
                steps{
                    script{
                        switch(pipelineConfig.deployType) {
                            case ~/^catalogo$/:
                                echo "running deploy step"
                                deployCatalogo pipelineConfig, almsPackage
                            break
                            case ~/^wl_redeploy$/:
                                echo "running deploy step"
                                artifacts=[['artifactId':almsPackage.appName]]
								try
                                {
									ansibleRedeployWl artifacts, pipelineConfig, almsPackage
                                }
								catch(Exception e){
									echo "Exception during Ansible redeploy ${e}"
                                    errText= ""
                                    if(fileExists("/tmp/redeploy_${artifact_id}.log")){
                                        def content = readFile("/tmp/redeploy_${artifact_id}.log")
                                        echo "Content: ${content}"
                                        if (content=="ERROR: Fallo del entorno"){
                                            createReject(alms_id,content,"99")
                                        }
                                        else{
                                            createReject(alms_id,"Fallo adjunto en fichero","3")
                                        }
                                        hoy=new Date().format( 'yyyyMMdd' )
                                        errText="Y"
                                        dir("/tmp"){
                                            stash includes: "redeploy_${artifact_id}.log", name: 'redeploy'
                                        }

                                        node("es036tvr"){
 	                                        dir("/home/plataforma/plausr/data/paquetes/${hoy}/${alms_id}"){
  	                                            unstash name: 'redeploy'
                                                sh "mv redeploy_*.log ${alms_id}_errors.txt"
                                            }
   	                                    }
                                        echo "INFO: copiamos el redeploy.log"
                                        sh "cp /tmp/redeploy_${artifact_id}.log redeploy_${artifact_id}.log.err"
                                    }
									echo "Running rollback of zip file"
									copyToReleaseWLRollback pipelineConfig, almsPackage
									echo "Doing redeploy of application after rollback"
									pipelineConfig.doRollback=true
                                    try{
									    ansibleRedeployWl artifacts, pipelineConfig, almsPackage
                                    }
                                    catch(Exception ee){
                                            echo "Errores en el rollback."
                                            createReject(alms_id,"ERROR: Fallo del entorno","99")
                                    }
                                    echo "----------${errText}--------"
                                    if(errText=="Y"){
                                        echo "-------------------------------------------------"
                                        sh "cat redeploy_${artifact_id}.log.err"
                                        sh "rm redeploy_${artifact_id}.log.err"
                                        echo "-------------------------------------------------"
                                    }
									error "Error during Ansible deployment ${e}"
								}
                                deleteReleaseBackupWL pipelineConfig, almsPackage
                            break
							case ~/^wl_restart$/:
                                echo "running deploy step, restarting weblogic"
								 ansibleRestartWl  pipelineConfig, almsPackage
                            break	
							case ~/^download_from_nexus$/:
                                echo "running deploy step"
                                artifacts=[['artifactId':almsPackage.appName]]
                                ansibleRedeployWl artifacts, pipelineConfig, almsPackage
                            break							
                        }
                    }
                    
                }
            }
            stage('RunSelenium'){
                when{
                    expression { return pipelineConfig.runSelenium == true  && deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                    beforeAgent true
                }
                agent{
                    label 'es1117yw'
                }
                steps{
                    script{
                        //def ret=bat(returnStdout:true , script:"python CDM/Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${deploy_env} ")
                        //echo "${ret}"
                        try{
                            bat "del *.png"
                            bat "python CDM/Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${deploy_env} ${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}"
                        }catch (e) {
                            echo "error when doing Selenium !!!!"
                        }
                        archiveArtifacts artifacts: '*.png', fingerprint: true
                        def myfiles=findFiles glob:"*.png"
                        myfiles.each{ pngfile -> 
                            echo "Selenium Screenshot: <a href='$BUILD_URL/artifact/${pngfile.name}' target='_blank' >${pngfile.name}</a>"
                        }
                        bat "del *${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}*.png"
                    }
                }
            }

            stage('Prepare PAP'){
                agent{
                    //label "deploy-apache-wcs"
                    label 'maven'
                }
                when{
                    expression { return deploy_env ==~ /(?i)(master|masterCI|hid|hid1|hidci|hid1ci)/ }
                }
                steps{
                    script{
                        if (pipelineConfig.artifactDetection!='maven_full_compile'){
                            echo "Download artifacts from Nexus ..."
                            downloadArtifactsFromNexus pipelineConfig, almsPackage
                        }else{
                            // create zip file from extractFolder
                            // Modify config distFile , artifactId, distFolder to be arrays with 
                            // 1 element
                            sh "rm -rf zips;mkdir -p zips;zip -r zips/${artifact_id}.zip ${pipelineConfig.extractFolder}"
                            pipelineConfig.distFile=["${artifact_id}.zip"]
                            pipelineConfig.artifactId=["${artifact_id}"]
                            //pipelineConfig.distFolder=["../../../zips"]
                        }
                        echo "running Prepare PAP step"
                        prepareForProdDeployment pipelineConfig, almsPackage
                    }
                }
            }
            stage('TagAndPush'){
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy=="SIMPLE"){
                            if (almsPackage.deployEnv==~/(?i)(hid1|hid|hidci|hid1ci)/){
                                //caso de Oculto uso rama develop
                                echo "Tag and push to develop branch ..."
                                gitRepo.tagAndPushDevelop pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,"develop",almsPackage.almsID,almsPackage.commitID
                            }else if (almsPackage.deployEnv==~/(?i)(master|masterCI)/){
                                echo "Tag commit and push to git "
                                gitRepo.tagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                            else{
                                echo "Tag and push to git "
                                gitRepo.simpleTagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv,almsPackage.almsID

                            }
                        }else if (pipelineConfig.branchPolicy=="envs_and_develop")
                        {
                            if (almsPackage.deployEnv==~/(?i)(hid1|hid|hidci|hid1ci)/){
                                //caso de Oculto uso rama develop
                                echo "Tag and push to develop branch ..."
                                gitRepo.tagAndPushDevelop pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,"develop",almsPackage.almsID,almsPackage.commitID
                            }else if (almsPackage.deployEnv==~/(?i)(master|masterCI)/){
                                echo "Tag commit and push to git "
                                gitRepo.tagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                            else{
                            echo "Tag commit and push to git "
                            gitRepo.tagAndPush pipelineConfig.extractFolder,
                                almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                        }
                        else
                        {
                            echo "Tag commit and push to git "
                            gitRepo.tagAndPush pipelineConfig.extractFolder,
                                almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                        }
                    }
                }
            }
            stage('PublishChanges'){
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy!="SIMPLE"){
                            echo "Publish changes to ELK  and GitPublish plugin"
                            publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                        }
                    }
                    
                }
            }

        }
        post { 
            always { 
                node('master') {
                    catchError(message:"Error when publishing to InfluxDB") {
                        script{
                            echo 'Publishing to Influx for Pipeline KPI!!!'
                            echo "Squad: ${squad}"
                            sendInfluxMetrics "${deploy_env}", squad
                        }
                    }
                }

            }
			//failure{
				//slackNotify pipelineConfig,almsPackage,"ERROR"
			//}
			//success{
				//slackNotify pipelineConfig,almsPackage,"OK"
			//}

        }

        
    }
}
