    

def call(def strError) {

    //https://www.kiuwan.com/docs/display/K5/Local+Analyzer+Return+Codes

    E12 = "12" // The model specified for the application does not contain rules for the technologies being analyzed
    E10 = "10" // Audit associated to the analyzed application did not pass.
    E14 = "14" // Error in cloud.
    E18 = "18" // No analyzable extensions found
    currentError = strError.drop(strError.size() - 2)
    formattedMessage = ""

    switch(currentError) {
        case E12:
            formattedMessage = "[Kiuwan]: " + strError
          //echo "[Kiuwan]: The model specified for the application does not contain rules for the technologies being analyzed."
        break
        case E10:
          if (env.QUALITYGATEBLOCKS == "true") 
              formattedMessage = "[Kiuwan]: " + strError
          else {
                env.auditFailed = "Audit did not pass"
                formattedMessage = env.auditFailed
          }
      	break
        case E14:
          	formattedMessage = "[Kiuwan]: " + strError
          //echo "[Kiuwan]: Error during analysis processing in the cloud"
        break
        case E18:
          	formattedMessage = "[Kiuwan]: " + strError  
          //echo "[Kiuwan]: No analyzable extensions found."
        break
        default:
            formattedMessage = "[Kiuwan]: " + strError
        break
    }
    
    return [currentError, formattedMessage]
}
