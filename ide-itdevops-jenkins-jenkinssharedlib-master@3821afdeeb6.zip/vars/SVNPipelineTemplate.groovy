#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def almsPackage=null
def callFromWB=true
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _serverSVN=""
def _dataModules=null
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _HayAnexos=""
def _Pvcs=""
def _Anexos=""
def _funcion=""
def _funcionEnt=""
def funcConfig=""
def hoy=""
def pckInfo=null
def _funcionAejecutar=""
def _serverAenviar=""
def _WB_ID=""
def envsConfig
def databaseConfig
def _listapaquetes=""



def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
                    string(name: 'WB_ID', defaultValue: '', description: 'WB ID or CRQ ID') 
                    string(name: 'Application', defaultValue: '', description: 'Application to deploy') 
                    string(name: 'Enviroment', defaultValue: '', description: 'Enviroment to deploy') 
                    string(name: 'List_Packages', defaultValue: '', description: 'List of package for deploy') 
                    string(name: 'PackageInfo', defaultValue: '', description: 'WB info') 

         }
         
         stages{     
             stage("Prepare"){
                agent {
                    label 'MEDIACION'
                        }
                steps{
                script {
               // funcConfig=readJSON(file: CDM/Jenkins/WORKBENCH/ORACLE/MEDIACION/funciones.json)
                hoy=new Date().format( 'yyyyMMdd' )
                print "La fecha de hoy es ......${hoy}......"
                
                //leemos el fichero de configuracion
                pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                //print "pipelineConfig ${pipelineConfig}"
                //leemos el fichero de entornos
                envsConfig=pipelineConfig.envConfig
                //print "envsConfig ${envsConfig}"
                //leemos el fichero de BBDD
                databaseConfig=pipelineConfig.databaseConfig
                     
                if (PackageInfo==""){
                    //LLamada manual
                        print "Llamada manual"
                        callFromWB=false  
                        _DeployEnv=params.Enviroment  
                        _ALMS_ID=params.WB_ID  
                        _Domain=params.Application
                        _listapaquetes=params.List_Packages
                        if (_listapaquetes==""){
                            _listapaquetes=params.WB_ID  
                        }
                             
                        echo "lista paquetes ${_listapaquetes}"   
                        replica_datos(_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                        txeker("",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                    }
                    else{
                        print "Llamada desde WB "
                        callFromWB=true  
                        pckInfo=readJSON(text: "${PackageInfo}")
                        _DeployEnv=pckInfo['EnvironmentName']
                        _Domain=pckInfo['ApplicationName']  
                        _ALMS_ID=pckInfo.Id.toString()
                        _listapaquetes=_ALMS_ID  
                       
                    }

                if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
        	        error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
                    }
                
                  print "llamo a getInfoPackage"
                  //(_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
                  (_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN,_Parametros,_HayParametros)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
                  
                  //Configuramos el nombre del build y su descripcion
                  //Actualizo info del paquete    
                  currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Domain}"
                  currentBuild.description = "Lista: ${_listapaquetes} Entorno: ${_DeployEnv} Aplicación: ${_Domain}"
                 
                 if(_HayModulosDatos == 0 && _HayModulosPVCS == 0 && _HayAnexos == 0) {
                    error("No hay modulos de datos ni de pvcs ni anexos añadidos al paquee")
                    }
                    
                   //Si el entorno es PROD leo el servidor SPPR  
                   enviroments=readJSON(file: "${envsConfig}")
                   
                   if ("${_DeployEnv}" == "PROD")
                   {
                    _serverPROD=_server
                    //Cambiamos al server de SPPR
                    _server=enviroments["${_Domain}"]["${_DeployEnv}"]["serverSPPR"][0][0]
                   }
                   else
                   {
                       _serverPROD=""
                   }
                 }//script
                 }//step
            }//prepare
            
            
            stage("BorraDirectorio"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_serverSVN}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_serverSVN}"
                        }
                        //Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
                        //Borrado del directorio temporal de anexo si existe por haberse promocionado otra vez este dia
                         cleanDirPaquete "${_ALMS_ID}","${_serverAenviar}","${hoy}","${_DeployEnv}","${_Domain}"

                    }//scripts
                }//steps
            }//BorraDirectorio


            stage("checkoutPVCS"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_serverSVN}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_serverSVN}"
                        }
                        if(_HayModulosPVCS != 0){
                            print "DEBUG: hay modulos de pvcs ${_HayModulosPVCS}"
                            print "DEBUG: server de SVN es ${_serverAenviar}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            
                            try{
                                       getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}"
                                        } catch(Exception e){
                                            
                                        echo "No está extaido el codigo, lanzamos el txeker para extraer " 
                                        txeker("",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                                        getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}"
                                        }    

                        }else{
                            print "DEBUG: No hay modulos de pvcs "
                        }

                    }//scripts
                }//steps
            }//checkoutPVCS

               stage("PromoSVN"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                       
                       
                       if (_HayModulosPVCS != 0  ){
                       
                           // print "ver valor variable env.NODE_NAME ${env.NODE_NAME}"
                             if ("${env.NODE_NAME}" == "${_serverSVN}")
                                {
                                 _serverAenviar =""
                                 print "entro por env.NODE_NAME "
                                    //  borramos el server para no hacer ssh
                                 }
                                 else{
                                 _serverAenviar ="${_serverSVN}"
                                  print "entro por serverSVN ${_serverAenviar}"
                                 }
                            
                            //Cargamos la info del paquete en almsPackage para las ejecuciones de funciones
                            //almsPackage= new VFESALMSDataRetriever( _ALMS_ID, _Domain, _DeployEnv, _serverAenviar, _HayModulosPVCS, _dataModules, _HayAnexos, callFromWB, _serverSVN )
                            //Ejecutar el promoSVN
                             //promoSVN(almsPackage) 
                             promoSVN "${_ALMS_ID}","${_DeployEnv}","${_Domain}","${_serverAenviar}"
                         }  //Si haymodulos de pvcs
                        
                    }//scripts
                }//steps
            }//Ejecutar

          }//stages
    
        }//pipeline
    }//map

