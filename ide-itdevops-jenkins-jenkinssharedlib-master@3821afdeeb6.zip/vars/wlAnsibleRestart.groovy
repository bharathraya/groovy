
// jobDeployEnv -> AUX12, PPRD1CI ...
// ansibleDir -> Folder this step should be executed at
// domains -> cs:co:wb ... in Ansible selector form
// clean_cache -> true / false , forces cleaning cache folder
// clean_stage -> true / false , forces cleaning stage folder
// REstarts WL managed nodes
def call(jobDeployEnv,ansibleDir,domains,clean_cache,clean_stage)
{
    dir(ansibleDir){
        sh "ansible-playbook -i inventories/${jobDeployEnv}/hosts -l ${domains} --extra-vars='clean_cache=${clean_cache} clean_stage=${clean_stage}' restart_wl.yml " 
    }
}
return this;