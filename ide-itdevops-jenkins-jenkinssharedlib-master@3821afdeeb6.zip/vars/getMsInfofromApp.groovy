def call(String _App , String _MsInfo){
    echo "getMsInfofromApp"
    def _yaml = readYaml(text: _MsInfo)
    def _ms=""
    def ms=""
    _yaml.ms.any(){
        ms=it
        //echo "ms:${ms}"
        
        if (ms.application.toLowerCase() == _App.toLowerCase()){
            _ms=ms
            return true
        }
    }
    if (_ms == ""){
        error "Aplicacion:${_App} no encontrada"
    }
    return _ms
}