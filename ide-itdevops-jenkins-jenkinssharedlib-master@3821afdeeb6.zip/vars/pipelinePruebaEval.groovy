import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo

def almsPackage=null
def gitRepo=null
def pipelineConfig=null
def mergeInfo=null

def call(){

    pipeline{
        agent{
            label 'eswltahr-platafor'
        }
        stages{
            stage("Prepare"){
                steps{
                    script{
                        mig "CRM" ,"","PPRD","357681k","es616acs","-W"

                    }
                }
            }
        }

    }
}