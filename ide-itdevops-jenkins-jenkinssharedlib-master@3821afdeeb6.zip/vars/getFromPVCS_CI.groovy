def call(String _Alms,String _Env,String _remoteServer,String _date){

    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_Alms}
    scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${_date}/${_Alms}/${_Env} .
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
