def get_credential(String _protocol,String _server, 
    String _context, String _token, 
    String _info_api, String _credentialId){
    def ret="""
urltoken='${_protocol}://${_server}/${_context}/${_token}'
urlpackageinfo='${_protocol}://${_server}/${_context}/${_info_api}'
host='${_server}'
"""
        withCredentials([usernamePassword(credentialsId: _credentialId, 
            usernameVariable: 'USERNAME',passwordVariable:'PASSWORD')]) {
                ret=ret+"""username='${USERNAME}'
password='${PASSWORD}'
"""
    
    return ret
    }    
}

def set_credentials_pprd(){
    return this.get_credential('https','webpre-adm.es.sedc.internal.vodafone.com:42510',
    'WorkBenchtest','Token',"api/Construction/Package/{}/Model?filters.base=true&filters.references=true&filters.dependences=true&filters.dataModules=true&filters.annexes=true&filters.history=false&filters.contents=true",
    'WorkBenchAdmin_PPRD'
    )
}
def set_credentials_prod(){
    return this.get_credential('https','workbench-devops.es.sedc.internal.vodafone.com/WorkBench',
    'WorkBench','Token',"api/Construction/Package/{}/Model?filters.base=true&filters.references=true&filters.dependences=true&filters.dataModules=true&filters.annexes=true&filters.history=false&filters.contents=true",
    'WorkBenchAdmin_PROD'
    )
}
def call (String _package){
    def ret=[]
    node ('eswltbhr'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            // Borrar fichero credenciales
            //sh "rm wbcredentials.py"
            def mybuilduser=""
            wrap([$class: 'BuildUser']) {
                echo "Exec user: ${env.BUILD_USER_ID}"
                mybuilduser=env.BUILD_USER_ID
            }
            echo "Exec user: ${mybuilduser}"
            // Crear fichero credenciales
            if (mybuilduser==~/pprdworkbench/){
                cred=this.set_credentials_pprd()
            }else {
                cred=this.set_credentials_prod()
            }
            //cred=this.set_credentials_pprd()
            writeFile(file: 'wbcredentials.py', text: cred)        
            //bat "pip install -r requirements.txt"
            sh "python get_package_info2.py ${_package} result.json"
            stash includes: 'result.json', name: 'result'
			//archiveArtifacts artifacts: 'result.json'
            sh "rm result.json"
			
        }
    }
    unstash name: 'result'
    ret=readJSON file:"result.json"
    //echo "ret=${ret}"
    fileSuccessfullyDeleted =  new File("result.json").delete()  
    return ret
}