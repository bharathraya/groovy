import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(Map config,VFESALMSDeployment alms)
{
  def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
  def _envConfig=myEnvsConfig[alms.deployEnv]

  //node('BIZ2016'){
  node('BIZ2020'){
      date=new Date().format( 'yyyy-MM-dd' )
      NombreLog="${config.applicationName}_log-${alms.almsID}"
      echo "Nombre  log : ${NombreLog} "

      dir ("C:/home/platafor/release/scripts/Compile"){
        if ("${alms.deployEnv}" != 'master')
        {
          //Deploy in NO PROD
    	    print "EJECUTAMOS C:\\home\\platafor\\release\\scripts\\Compile\\Master-COMP-Elastic.ps1 -t ${config.applicationName} -e ${alms.deployEnv} -p ${alms.almsID}"
          ret=bat(returnStatus: true,script:"powershell.exe -ExecutionPolicy ByPass -File C:\\home\\platafor\\release\\scripts\\Compile\\Master-COMP-Elastic.ps1 -t ${config.applicationName} -e ${alms.deployEnv} -p ${alms.almsID}")
          print "**********************************************************************************"
          print "**********************************************************************************"
          print "**********************LOG***LOG***LOG***LOG*********************************"
          print "**********************LOG***LOG***LOG***LOG*********************************"
          print "**********************************************************************************"
          print "**********************************************************************************"
          bat("powershell.exe -File lastLogName.ps1 c:\\home\\plataforma\\plausr\\logs\\${date} ${NombreLog}* ")
          print "**********************************************************************************"
          print "**********************************************************************************"
          print "**********************FINLOG***FINLOG***FINLOG***FINLOG*********************************"
          print "**********************FINLOG***FINLOG***FINLOG***FINLOG*********************************"
          print "**********************************************************************************"
          print "**********************************************************************************"
        }
        else
        {
          //Deploy in PROD
          ret=0
          print "**********************************************************************************"
          print "***PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD***"
          print "***PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD***"
          print "**********************************************************************************"
          print "THIS DEPLOY IS MANUAL. PLEASE FOLLOW THE NEXT INSTRUCTIONS:"
          print "1.- LOGIN AT SERVER: ${config.prodDeployServer}"
          print "2.- EXECUTE C:\\home\\platafor\\release\\scripts\\Compile\\Master-COMP-Elastic.ps1 -t ${config.applicationName} -e PROD -p ${alms.almsID} -prod_restart ${config.operateInProd} -password \"the_pass_provided_for_CRQ\""
          print "3.- REVIEW LOGS AT c:\\home\\plataforma\\plausr\\logs\\${date} WITH NAME: ${NombreLog}*"
          print "4.- IF ALL IT IS OK. MERGE COMMIT TO MASTER BRANCH"
          print ""
          print "IF IT IS NEEDED TO MAKE A OFFLINE ROLLBACK. YOU CAN EXECUTE:"
          print "0.- PLEASE BE SURE THAT OTHER PACKAGE WAS NOT DEPLOYED AT PROD AFTER THIS PACKAGE"
          print "1.- LOGIN AT SERVER: ${config.prodDeployServer}"
          print "2.- EXECUTE C:\\home\\platafor\\release\\scripts\\Master-deploy-offline-rollback-elastic.ps1 -package ${alms.almsID} -enviroment PROD -application ${config.applicationName} -prod_restart ${config.operateInProd} -password \"the_pass_provided_for_CRQ\""
          print "**********************************************************************************"
          print "***PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD***"
          print "***PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD****PROD***"
          print "**********************************************************************************"
        }
    }
  }
  if (ret != 0 )
  {
    print "**********************ERROR***ERROR***ERROR***ERROR*********************************"
    exit
  }
}
