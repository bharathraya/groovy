def call(String _domain, String _nombreCarpeta, String _listado,  Boolean isBit ){


hoy=new Date().format( 'yyyyMMdd' )
print "Parameters:"
print "Domain: ${_domain}"
print "Folder Name: ${_nombreCarpeta}"
print "List of Packages: ${_listado}"

//Testeamos de nuevo y versionamos en PROD
                                 
    if (!isBit)
    {
        print "****************************************"
        print "TESTING ON PROD APPLICATION: ${_domain} "
        print "****************************************"
        txeker("",_domain,"PROD",_nombreCarpeta,_listado)
        
        
        print "****************************************"
        print "LABELING PROD APPLICATION: ${_domain} "
        print "****************************************"
        txeker("-l",_domain,"PROD",_nombreCarpeta,_listado)
    }
    else
    {
        print "****************************************"
        print "APPLICATION IN BITBUCKET YOU HAVE TO MAKE THE PULLREQUEST TO: ${_domain} "
        print "****************************************"
    
    }

}
