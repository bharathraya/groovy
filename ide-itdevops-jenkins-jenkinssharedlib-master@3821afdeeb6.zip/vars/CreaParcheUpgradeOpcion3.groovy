def call(String _domain, String _TipoRege, String _nombreCarpeta, String _listado, String _CRQ_ID, String _serverSPPPR, String _serverSIMU,String _Orden, Boolean isBit ,String _usuario, String _pass, ArrayList _ExecuteSIMU, ArrayList _ExecutePROD, String _delivery, String EntSimulacro){

def MODSIMU=0
def hoy=""
def hoy_exacta=""
def _upgrade=""
def RutaTemp=""
def RutaPaquete=""
def _listadoEsquema=""
def _listadoBBDD=""
def ExecutionSIMU=""
def ExecutionPROD=""
def pos=0
def Parameter=""
def iParche=0
def iParcheSimu=0
def ExecutionPreview=""
def ExecutionCompPROD=""
def ExecutionCompSimu
def iConflictos=""

//print "parametros:::::::::::::::"
//print "parametros _domain: ${_domain}"
//print "parametros _nombreCarpeta: ${_nombreCarpeta}"
//print "parametros _listado: ${_listado}"
//print "parametros _TipoRege: ${_TipoRege}"
//print "parametros _CRQ_ID: ${_CRQ_ID}"
//print "parametros _serverSPPPR: ${_serverSPPPR}"
//print "parametros _serverSIMU: ${_serverSIMU}"
//print "parametros _Orden: ${_Orden}"
//print "parametros isBit: ${isBit}"
//print "parametros _Execute SIMU: ${_ExecuteSIMU}"
//print "parametros _Execute PROD: ${_ExecutePROD}"
//print "parametros Delivery PROD: ${_delivery}"
//print "parametros Entorno Simulacro: ${EntSimulacro}"

MODSIMU ="0"
hoy=new Date().format( 'yyyyMMdd' )
hoy_exacta=new Date().format( 'yyyyMMddmmss' )
_upgrade="S"

RutaTemp="/home/plataforma/plausr/tmp"
RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"

    if (_domain =="AMDOCS-BBDD" )
    {  //Revisamos si hay vistas
    
        sh ("touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-ESQUEMA")
        _listadoEsquema = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-ESQUEMA")
                                          
        if (_listadoEsquema != "") 
        {
            print "There are SCHEMA packages"
            _listadoBBDD = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
            _listado= "${_listadoEsquema} ${_listadoBBDD}"
        }
        else
        {
            _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
        }
        txeker("","AMDOCS102","PROD",_nombreCarpeta,_listado)
    }
    else if (_TipoRege == "AMDOCS-ESQUEMA")
    {
        sh "touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD"
        _listadoBBDD = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD")
        if (_listadoBBDD != "") 
        {
             print "There are DDBB packages"
            _listado= "${_listadoBBDD} ${_listado}"
        }
        txeker("","AMDOCS102","PROD",_nombreCarpeta,_listado)
    }
    else if (_domain != "AMDOCS-ESQUEMA")
    {   if (isBit)
        {
            
            txeker_git("*", "PROD_HID",'"' + _listado + '"', _usuario,_pass ,_nombreCarpeta)
            iConflictos=CheckBit(_domain,_nombreCarpeta,_CRQ_ID, _usuario,_pass)
            // 0 sin error, 1 error de PR, 2 error de contenido, 3 error en ambos
            if (iConflictos==1)
            {
                error("There are conflicts in ${_domain} in the PR")
            }
            else if (iConflictos==2)
            {
                error("Missing master changes on source branch for ${_domain}")
            }
            else if (iConflictos==3)
            {
                error("For ${_domain} is missing master changes on source branch for and it is failing PR")
            }
        }
        else
        {
            txeker("",_domain,"PROD",_nombreCarpeta,_listado)
        }
    }   
    
    if (_domain == "AMDOCS-UPSD" || _domain == "AMDOCS-CLARIFY")
    {
        replica_datos("",_domain,"PROD",_nombreCarpeta,_listado)
        
        execCopiado="""
            . \$HOME/.profile >/dev/null 2>&1
             export ruta_temp=\$DIR_BASE_TEMPORAL/${hoy}/anexo/${_nombreCarpeta}/PROD/
             if [ -f \$ruta_temp/extras.txt ]
             then
                rm -f \$ruta_temp/extras.txt
             else
                mkdir -p \$ruta_temp
             fi
            scp -qr es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_nombreCarpeta}/PROD/* \$ruta_temp
            
            if [ -f \$DIR_BASE_TEMPORAL/${hoy}/anexo/${_nombreCarpeta}/PROD/DataModules/extras.txt ]
            then
                mv \$DIR_BASE_TEMPORAL/${hoy}/anexo/${_nombreCarpeta}/PROD/DataModules/extras.txt \$DIR_BASE_TEMPORAL/${hoy}/anexo/${_nombreCarpeta}/PROD/extras.txt
            fi
        """
        sh "ssh -q ${_serverSPPPR} '${execCopiado}'"

    }
    
    
    if ( !isBit )
    {
        
        if (_domain == "AMDOCS-ESQUEMA" && _TipoRege != "AMDOCS-ESQUEMA")
        {
            "We do not extract, it is part in BBDD"
        }
        else
        {
         if (_domain != "AMDOCS-COMPROBACIONES")
          {
            //En 7.5 excpecion para AMDOCS-UPSD AMDOCS-CLARIFY porque hay que copiar los ficheros a prod

              //Borramos el .paquete
              CleanPaquete "${_nombreCarpeta}","${_serverSPPPR}", "PROD"
              //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
              CopiaFicheros "${_nombreCarpeta}","PROD","${_serverSPPPR}"

              //Generamos el WB_FILE
              GenerarWBFile "${_nombreCarpeta}","${_nombreCarpeta}","PROD","${_domain}" , false ,"${_upgrade}"

              if (_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM")
              {
                 //print "Executing  SeparaCode ${_nombreCarpeta}, ${_domain},${_serverSPPPR}, PROD"

                  iTipo=SeparaCode "${_nombreCarpeta}", "${_domain}","${_serverSPPPR}", "PROD"
                 // print "Type  ${iTipo}"
              } //Separo codigo
          }//No es comprobaciones   
        } //La parte esquema en BBDD  
    }
    
    //Si NO son las de crear parche en bit sacamos tambien el codigon en SIMU
    if ( _domain != "AMDOCS-BBDD" && _domain != "AMDOCS-ESQUEMA" && _TipoRege != "AMDOCS-ESQUEMA" && !isBit && _domain != "AMDOCS-COMPROBACIONES")
     {
        txeker("",_domain,EntSimulacro,_nombreCarpeta,_listado)
        if (_domain == "AMDOCS-UPSD" || _domain == "AMDOCS-CLARIFY")
        {
             replica_datos("",_domain,EntSimulacro,_nombreCarpeta,_listado)
             MovePVCS "${_nombreCarpeta}","${EntSimulacro}","es036tvr","${_serverSIMU}"
        }
                                                
        //Borramos el .paquete
        CleanPaquete "${_nombreCarpeta}","${_serverSIMU}","${EntSimulacro}"
        //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
        CopiaFicheros "${_nombreCarpeta}","${EntSimulacro}","${_serverSIMU}"
        if (_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM")
        {
            //print "Executing  SeparaCode ${_nombreCarpeta}, ${_domain},${_serverSIMU}, ${EntSimulacro}"
            iTipoSim=SeparaCode "${_nombreCarpeta}", "${_domain}","${_serverSIMU}", "${EntSimulacro}"
            //print "Type of simulation  ${iTipoSim}"
        }  
    
    }
    else
    {   //Hay que subir a bit
        if (_domain == "AMDOCS-BBDD" || _TipoRege == "AMDOCS-VISTAS" )
        { //Lanzamos la funcion de Integridad
            if (_Orden == "")
            {
                error ("There is no order file for the BBDD part")
            }
            else
            {
                print "We prepare the files for IntegridadBBDD2"
                MODSIMU=IntegridadBBDD2( "${_nombreCarpeta}","${_Orden}","${_CRQ_ID}" , "S", "${_upgrade}", "${EntSimulacro}")
     
            } //Integridad sube  a bit
       }
       else if (_domain == "AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
       {
            //Copiamo a es036tvr orden_pre y orden_post y lanazmaos install
             print "We prepare the files for install_schema InstallschemaCreaParche"
             InstallschemaCreaParcheUp "${_nombreCarpeta}","${_CRQ_ID}", "${_delivery}"
        }
      else if (_domain == "AMDOCS-COMPROBACIONES")
      {
        
         replica_datos("","AMDOCS-COMPROBACIONES","PROD",_nombreCarpeta,_listado)
          execCopy="""
            . \$HOME/.profile >/dev/null 2>&1
            export ruta_temp=\$DIR_BASE_TEMPORAL/${hoy}/${_nombreCarpeta}/PROD/DataModules
            . paquete
            if [ -d ${_nombreCarpeta} ]
            then
            	echo "${_nombreCarpeta} exists, so we do a backup"
            	mv ${_nombreCarpeta} ${_nombreCarpeta}_${hoy_exacta}
            fi
            . paquete ${_nombreCarpeta} PROD_o_no
            mkdir -p BBDD/SA/
            scp -qr es036tvr:\$ruta_temp/*sql BBDD/SA/
            find BBDD/SA/ -type f > orden.txt
            cd
            SubidaGIT.sh -a -p ${_nombreCarpeta}
            """
            print "We copy the files "
            sh "${execCopy}"
            
      }
    
    }//Funciones de bit
                                            
    sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
    sh "echo '***************************************************************' >>  ${RutaPaquete}/Instrucciones.txt"
    sh "echo '***************************************************************' >>  ${RutaPaquete}/Instrucciones.txt"
    sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
    
    
    if (!isBit)
        {

                ExecutionSIMU=""
                ExecutionPROD=""
                ExecutionPreview=""
                ExecutionPreviewPROD=""
                iParcheSimu=0
                ExecutionCompPROD=""
                ExecutionCompSimu=""
                //Busco la ejecucion para SIMU
                for (pos = 0; pos < _ExecuteSIMU.size(); pos++) { 
                    
                            Parameter = _ExecuteSIMU[pos]
                           // print "Para ${pos} es el parametro ${Parameter}"
                            
                            if (Parameter =="Parche")
                            {
                                ExecutionSIMU="${ExecutionSIMU}"+' ' +"${_nombreCarpeta}" 
                                iParcheSimu=1
                                if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreview="${ExecutionPreview}"+' ' +"${_nombreCarpeta}" 
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompSimu="${ExecutionCompSimu}"+' ' +"${_nombreCarpeta}_COMP" 
                                }
                                
                            }
                            else if (Parameter =="Entorno")
                            {
                                ExecutionSIMU="${ExecutionSIMU}"+' ' +"${EntSimulacro}"    
                                 if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreview="${ExecutionPreview}"+' ' +"${EntSimulacro}" 
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompSimu="${ExecutionCompSimu}"+' ' +"${EntSimulacro}" 
                                }
                            }
                            else if (Parameter =="Domain")
                            {
                                ExecutionSIMU="${ExecutionSIMU}"+' ' +"${_domain}" 
                                 if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreview="${ExecutionPreview}"+' ' +"AMDOCS-PREVIEW" 
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompSimu="${ExecutionCompSimu}"+' ' +"${_domain}" 
                                }
                            }
                            else if (Parameter =="Delivery")
                            {
                                ExecutionSIMU="${ExecutionSIMU}"+' ' +"${_delivery}"    
                                 if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreview="${ExecutionPreview}"+' ' +"${_delivery}"    
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompSimu="${ExecutionCompSimu}"+' ' +"${_delivery}" 
                                }
                            }
                            else if (Parameter =="Password")
                            {
                                ExecutionSIMU="${ExecutionSIMU}"+' ' +"<Password>"
                                 if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreview="${ExecutionPreview}"+' ' +"<Password>"     
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompSimu="${ExecutionCompSimu}"+' ' +"<Password>"
                                }
                            }
                            else if (Parameter =="Password-SA")
                            {
                                ExecutionSIMU="${ExecutionSIMU}"+' ' +"<Password-SA>"
                            }
                             else 
                            {
                                ExecutionSIMU="${ExecutionSIMU}"+' ' +"${Parameter}"    
                                 if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreview="${ExecutionPreview}"+' ' +"${Parameter}"    
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompSimu="${ExecutionCompSimu}"+' ' +"${Parameter}" 
                                }
                            }
                           // print "Composing ${ExecutionSIMU}"
                    }//for SIMU
                      
                      iParche=0
                     //Busco la ejecucion para PROD
                    for (pos = 0; pos < _ExecutePROD.size(); pos++) { 
                            
                            Parameter = _ExecutePROD[pos]
                           // print "For ${pos} the parameter is ${Parameter}"
                            
                            if (Parameter =="Parche")
                            {
                                ExecutionPROD="${ExecutionPROD}"+' ' +"${_nombreCarpeta}" 
                                 if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreviewPROD="${ExecutionPreviewPROD}"+' ' +"${_nombreCarpeta}" 
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompPROD="${ExecutionCompPROD}"+' ' +"${_nombreCarpeta}_COMP" 
                                }
                                iParche=1
                            }
                            else if (Parameter =="Entorno")
                            {
                                ExecutionPROD="${ExecutionPROD}"+' ' +"PROD"    
                                if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreviewPROD="${ExecutionPreviewPROD}"+' ' +"PROD"    
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompPROD="${ExecutionCompPROD}"+' ' +"PROD"    
                                }
                            }
                            else if (Parameter =="Domain")
                            {
                                ExecutionPROD="${ExecutionPROD}"+' ' +"${_domain}"   
                                if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreviewPROD="${ExecutionPreviewPROD}"+' ' +"AMDOCS-PREVIEW"    
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompPROD="${ExecutionCompPROD}"+' ' +"${_domain}" 
                                }
                            }
                            else if (Parameter =="Delivery")
                            {
                                ExecutionPROD="${ExecutionPROD}"+' ' +"${_delivery}"    
                                if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreviewPROD="${ExecutionPreviewPROD}"+' ' +"${_delivery}"     
                                }
                                 else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompPROD="${ExecutionCompPROD}"+' ' +"${_delivery}" 
                                }
                            }else if (Parameter =="Password")
                            {
                                ExecutionPROD="${ExecutionPROD}"+' ' +"<Password>"   
                                if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreviewPROD="${ExecutionPreviewPROD}"+' ' +"<Password>"     
                                }
                                 else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompPROD="${ExecutionCompPROD}"+' ' +"<Password>"   
                                }
                            }else if (Parameter =="Password-SA")
                            {
                                ExecutionPROD="${ExecutionPROD}"+' ' +"<Password-SA>"   
                            }
                             else 
                            {
                                ExecutionPROD="${ExecutionPROD}"+' ' +"${Parameter}"  
                                if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                {
                                     ExecutionPreviewPROD="${ExecutionPreviewPROD}"+' ' +"${Parameter}"     
                                }
                                else if ((_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") && (iTipo==1 || iTipo==3))
                                {
                                    ExecutionCompPROD="${ExecutionCompPROD}"+' ' +"${Parameter}" 
                                }
                            }
                           // print "Composing ${ExecutionPROD}"
                    }//for PROD
            
                
              if (_domain == "AMDOCS-BBDD" || (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA") || _domain == "AMDOCS-COMPROBACIONES")
              {
                   sh "echo 'To execute ${_domain} you have to do the following:' >>  ${RutaPaquete}/Instrucciones.txt"
                  if ( EntSimulacro == "PET" )
                  {
                     sh "echo '  ssh devopststtools01  (${EntSimulacro}) | ssh  devopsprdtools01 (PROD) ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }
                  else
                     {
                     sh "echo '      ssh devopsprdtools01 ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }
              }
              else if (_domain != "AMDOCS-ESQUEMA" && _domain != "AMDOCS-BBDD" && _TipoRege != "AMDOCS-ESQUEMA" && _domain != "AMDOCS-COMPROBACIONES")
              {
                  sh "echo 'To execute ${_domain} you have to do the following:' >>  ${RutaPaquete}/Instrucciones.txt"
                  sh "echo '      ssh ${_serverSIMU} (${EntSimulacro}) | ssh  ${_serverSPPPR} (PROD)' >>  ${RutaPaquete}/Instrucciones.txt"
              }
              
             
              if (_domain != "AMDOCS-ESQUEMA" &&  _TipoRege != "AMDOCS-ESQUEMA" && _domain !="AMDOCS-BBDD" && _domain != "AMDOCS-COMPROBACIONES")
              {
                  sh "echo 'For ${EntSimulacro} execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                 if (iParcheSimu == 0)
                  {
                      sh "echo '      . paquete ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  } 
               
                 if (_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") 
                    {
                         if (iTipo==1)
                         { //Solo compilable
                             sh "echo '      ${ExecutionCompSimu} ' >>  ${RutaPaquete}/Instrucciones.txt"
                         }
                         else if (iTipo==2)
                         {//solo sin compilar
                            sh "echo '      ${ExecutionSIMU} ' >>  ${RutaPaquete}/Instrucciones.txt"
                         }
                         else if (iTipo==3)
                         {//ambos
                            sh "echo '      ${ExecutionCompSimu} ' >>  ${RutaPaquete}/Instrucciones.txt"
                            sh "echo '      ${ExecutionSIMU} ' >>  ${RutaPaquete}/Instrucciones.txt"
                         }
                    }
                  else
                  {
                        sh "echo '      ${ExecutionSIMU} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }
              }
              else if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
              {        
                       sh "echo 'For ${EntSimulacro} execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                       sh "echo 'PREVIEW->       ${ExecutionPreview} ' >>  ${RutaPaquete}/Instrucciones.txt"
                       sh "echo 'SCHEMA->       ${ExecutionSIMU} ' >>  ${RutaPaquete}/Instrucciones.txt"
              }
              else if (_domain =="AMDOCS-BBDD")
                  {
                        sh "echo 'For ${EntSimulacro} execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                        sh "echo '      ${ExecutionSIMU} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }  
              else if (_domain =="AMDOCS-COMPROBACIONES")
                  {
                        sh "echo 'For SIMULATION ${EntSimulacro} execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                        sh "echo '      ${ExecutionSIMU} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }  
            
               if (iParche == 0)
                  {
                      sh "echo '      . paquete ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  } 
                
                 if (_domain =="AMDOCS-BBDD")
                  {
                       sh "echo 'For PROD execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                       sh "echo '      ${ExecutionPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }
                 else if (_domain =="AMDOCS-COMPROBACIONES")
                  {
                       sh "echo 'For PROD execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                       sh "echo '      ${ExecutionPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }
                else if (_domain == "AMDOCS-SMS" || _domain == "AMDOCS-CONTRATOS" || _domain == "AMDOCS-SPM") 
                   {     
                        sh "echo 'For PROD execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                         if (iTipo==1)
                         { //Solo compilable
                             sh "echo '      ${ExecutionCompPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                         }
                         else if (iTipo==2)
                         {//solo sin compilar
                            sh "echo '      ${ExecutionPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                         }
                         else if (iTipo==3)
                         {//ambos
                            sh "echo '      ${ExecutionCompPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                            sh "echo '      ${ExecutionPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                         }
                   }
                   else if (_domain == "AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                  {   
                       sh "echo 'For PROD execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                       sh "echo 'PREVIEW->      ${ExecutionPreviewPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                       sh "echo 'SCHEMA->      ${ExecutionPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }
                  else if (_domain != "AMDOCS-BBDD" && _domain != "AMDOCS-ESQUEMA"  && _domain != "AMDOCS-SMS" && _domain != "AMDOCS-CONTRATOS" && _domain != "AMDOCS-SPM")
                  {
                       sh "echo 'For PROD execute : ' >>  ${RutaPaquete}/Instrucciones.txt"
                       sh "echo '      ${ExecutionPROD} ' >>  ${RutaPaquete}/Instrucciones.txt"
                  }  
                 
          if ((_domain == "AMDOCS-BBDD"  || _TipoRege == "AMDOCS-VISTAS") && "${MODSIMU}" == "1" )
           { 
                sh "echo 'THERE ARE MODULES WITH TOKEN ${EntSimulacro} WHAT SHOULD BE LAUNCHED AFTER THE DRILL' >>  ${RutaPaquete}/Instrucciones.txt"
                sh "echo 'CHECK IT OUT !!!' >>  ${RutaPaquete}/Instrucciones.txt"
            }//BBDD y maestras
        }
        else
        {    
                sh "mkdir -p /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/"
                sh "rm -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/txeker_git.${_nombreCarpeta}"
                sh "scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/txeker_git.${_nombreCarpeta} /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/"
                sh "echo 'For PROD package to migrate of the type: ${_domain}*************************************' >> ${RutaPaquete}/Instrucciones.txt"
                sh "head -1 /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/txeker_git.${_nombreCarpeta}  >> ${RutaPaquete}/Instrucciones.txt"

        }
   
                                     


//**********FIN***********************************************
}
