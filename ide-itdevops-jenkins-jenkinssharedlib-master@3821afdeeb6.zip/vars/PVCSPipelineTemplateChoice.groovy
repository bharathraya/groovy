#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def almsPackage=null
def callFromWB=true
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _serverSVN=""
def _dataModules=null
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _HayAnexos=""
def _Pvcs=""
def _Anexos=""
def _funcion=""
def _funcionEnt=""
def funcConfig=""
def hoy=""
def pckInfo=null
def _funcionAejecutar=""
def _serverAenviar=""
def _WB_ID=""
def envsConfig
def databaseConfig
def _listapaquetes=""
def _serverPROD=""
def mybuilduser=""
def _NomVista =""
def _Parametros=""
def _HayParametros=""

_EsRollback=0


def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'WB_ID', defaultValue: '', description: 'WB ID or CRQ ID') 
           // string(name: 'Application', defaultValue: '', description: 'Application to deploy') 
            choice(name: 'Application', choices: pipelineParams.applicationChoices, description: 'Application to deploy') 
           // string(name: 'Enviroment', defaultValue: '', description: 'Enviroment to deploy') 
            choice(name: 'Enviroment',  choices: pipelineParams.environmentChoices , description: 'Enviroment to deploy') 
            string(name: 'List_Packages', defaultValue: '', description: 'List of package for deploy') 
            string(name: 'Delivery', defaultValue: '', description: 'Delivery of package') 
            string(name: 'View', defaultValue: '', description: 'Name of the view of packages') 
            choice(name: 'Check_Dependences', choices: ['NO', 'YES'], description: 'Check dependences of the list of packages')
            choice(name: 'PromoteTOPROD', choices: ['NO', 'YES'], description: 'Do you want to promote package to PROD?')
            string(name: 'PackageInfo', defaultValue: '', description: 'WB info') 
            

         }
         
   
         stages{     
         stage("Prepare"){
                agent {
                    label 'MEDIACION'
                        }
                steps{
                script {
                  
                   wrap([$class: 'BuildUser']) {
                         mybuilduser=env.BUILD_USER_ID
                       }
                   echo "Exec user: ${mybuilduser}"
                   //Contraseña
                   (_pass,mybuilduser)=findpassword(mybuilduser)
                   
               // funcConfig=readJSON(file: CDM/Jenkins/WORKBENCH/ORACLE/MEDIACION/funciones.json)
                hoy=new Date().format( 'yyyyMMdd' )
                print "La fecha de hoy es ......${hoy}......"
 
                
                //leemos el fichero de configuracion
                pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                //print "pipelineConfig ${pipelineConfig}"
                //leemos el fichero de entornos
                envsConfig=pipelineConfig.envConfig
               // print "envsConfig ${envsConfig}"
                //leemos el fichero de BBDD
                databaseConfig=pipelineConfig.databaseConfig
                _checkDPD="NO"
                PromoteTOPROD="NO"

                if (PackageInfo==""){
                    //LLamada manual
                        print "Llamada manual"
                        callFromWB=false  
                        _DeployEnv=params.Enviroment  
                        _ALMS_ID=params.WB_ID.trim()  
                        _Domain=params.Application
                        _listapaquetes=params.List_Packages
                        _checkDPD=params.Check_Dependences
                        _PromoteTOPROD=params.PromoteTOPROD
                        _NomVista=params.View.trim()
                        _Delivery=params.Delivery.trim()
                        
                        if (_listapaquetes == "" && _NomVista == ""){
                            //lista de paquetes vacia y vista tambien
                            _listapaquetes=params.WB_ID  
                        }
                        if (_NomVista != "")
                        {//saco los paquetes y los pongo en la lista
                        
                        //llamo a la funcion para sacar los paquetes
                            print "There is view: ${_NomVista}"
                            get_packagesbyview(_NomVista,mybuilduser,_pass)
                            //Copio los fichero a es1385yr
                           execView="""
                            . \$HOME/.profile >/dev/null 2>&1
                            . paquete  ${_NomVista} >/dev/null 2>&1
                            rm -f *
                            touch -f ${_NomVista}_ListaPaquetes.txt
                            scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_NomVista}/ListaPaquetes.txt .
                            cut -d: -f3 ListaPaquetes.txt > ListaPaquetes.txt_tmp
                            cat ListaPaquetes.txt_tmp | tr '\n' ' ' >> ${_NomVista}_ListaPaquetes.txt
                            
                            """
                            sh "${execView}"
                            _listapaquetes=readFile(file: "/opt/SP/plataforma/plausr/data/paquetes/${hoy}/${_NomVista}/${_NomVista}_ListaPaquetes.txt")      

                        }//Han metido una vista
                             
                        echo "lista paquetes ${_listapaquetes}"   
                        print "Valor del revisar dependencias ${_checkDPD}"
                        if (_checkDPD == "YES")
                        { //Revisamos las dependencias
                         print "Llamo a check_dependencies_WB"
                         print "si lanzo el check_dependencies_WB"
                         applicationDependencyCRQ(_ALMS_ID,'"' + _listapaquetes + '"')
                         check_dependencies_WB(_ALMS_ID, _listapaquetes , "es036tvr")
                        }
                        else
                        {
                            print "Valor del revisar dependencias ${_checkDPD}"
                            print "no lanzo el check_dependencies_WB"
                        }
                         
                         //12-01-21 meguiza2
                        
                         //Si es de rollback 
                          if (_Domain.contains("-ROLLBACK") )
                          { 
                            
                             print "He entrado por dominio rollback"
                            _EsRollback=1
                            _DomainRo=_Domain
                            _DomainSinRo=_DomainRo.replaceAll("-ROLLBACK","")
                            _Domain=_DomainSinRo
                            print "Dominio anterior ${_DomainRo}"
                            print "Dominio nuevo sin rollback ${_DomainSinRo}"
                         }
                         else
                          {  
                              print "No es un dominio rollback"
                              _EsRollback=0
                            
                          }
                          print "valor de _EsRollback: ----${_EsRollback}----- "
                              txeker("",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                              replica_datos("",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)

                    }
                    else{
                        _EsRollback=0
                        print "Llamada desde WB "
                        callFromWB=true  
                        pckInfo=readJSON(text: "${PackageInfo}")
                        //print "packageinfo ${PackageInfo}"
                        _DeployEnv=pckInfo['EnvironmentName']
                        _Domain=pckInfo['ApplicationName']
                        _Delivery=pckInfo['DeliveryName']
                        
                       
                        _ALMS_ID=pckInfo.Id.toString()
                        _listapaquetes=_ALMS_ID  
                        _checkDPD="NO"
                        _NomVista =""

                    }

                if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
        	        error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
                    }
                
                //Actualizo info del paquete                       
                  print "llamo a getInfoPackage"
                  //(_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
                  (_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN,_Parametros,_HayParametros)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
               
                //Configuramos el nombre del build y su descripcion
               if (_EsRollback == 0)
               {
                    currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} App: ${_Domain}"
               }
               else
               {   //Como es de rollback ponemos el entorno anterior
                   currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} App: ${_DomainRo}"
               }
                
                if (_NomVista != "")
                {
                        currentBuild.description = "View: ${_NomVista} List: ${_listapaquetes} Env: ${_DeployEnv} App: ${_Domain}"
                }
                else
                {
                    currentBuild.description = "List: ${_listapaquetes} Env: ${_DeployEnv} App: ${_Domain}"
                }
                    
                  if(_HayModulosDatos == 0 && _HayModulosPVCS == 0 && _HayAnexos == 0) {
                    createReject (_ALMS_ID , "No hay modulos de datos ni de pvcs ni anexos en el paquete","5")
                    error("No hay modulos de datos ni de pvcs ni anexos añadidos al paquee")
                    }
                    
                   //Si el entorno es PROD leo el servidor SPPR  
                   enviroments=readJSON(file: "${envsConfig}")
                   
                   if ("${_DeployEnv}" == "PROD" || "${_DeployEnv}" == "prd" )
                   {
                    _serverPROD=_server
                    //Cambiamos al server de SPPR
                    _server=enviroments["${_Domain}"]["${_DeployEnv}"]["serverSPPR"][0][0]
                   }
                   else
                   {
                       //_serverPROD=""
                       _serverPROD=enviroments["${_Domain}"]["PROD"]["server"][0][0]
                   }

                  
                   }//script
                 }//step
            }//prepare
            
            stage("BorraDirectorio"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                      print " node ${env.NODE_NAME}"
                      print "server ${_server}"
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_server}"
                        }
                        //Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
                        //Borrado del directorio temporal de anexo si existe por haberse promocionado otra vez este dia
                         cleanDirPaquete "${_ALMS_ID}","${_serverAenviar}","${hoy}","${_DeployEnv}","${_Domain}"

                    }//scripts
                }//steps
            }//BorraDirectorio

            
            stage("checkoutModulosDatos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        
                        if(_HayModulosDatos!= 0){
                            print "DEBUG: hay modulos de datos ${_HayModulosDatos}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            if ("${env.NODE_NAME}" == "${_server}")
                            {
                                _serverAenviar =""
                                //  borramos el server para no hacer ssh
                            }
                            else{
                                _serverAenviar ="${_server}"
                            }
                            getFromModules "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}","${hoy}","${_Domain}"
                        }else{
                            print "DEBUG: No hay modulos de datos "
                        }

                    }//scripts
                }
            }//checkoutModulosDatos

             stage("checkoutAnexos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if(_HayAnexos!= 0){
                            print "DEBUG: hay anexos"
                            if ("${env.NODE_NAME}" == "${_server}")
                            {
                                _serverAenviar =""
                                //  borramos el server para no hacer ssh
                            }
                            else{
                                _serverAenviar ="${_server}"
                            }
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            getAnnexes "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}","${hoy}"
                     }else{
                         print "DEBUG: No hay anexos "
                        }

                    }//scripts
                }//steps
            }//checkoutAnexos

            stage("checkoutPVCS"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_server}"
                        }
                        if(_HayModulosPVCS!= 0){
                            print "DEBUG: hay modulos de pvcs ${_HayModulosPVCS}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}"
                        }else{
                            print "DEBUG: No hay modulos de pvcs "
                        }

                    }//scripts
                }//steps
            }//checkoutPVCS

            stage("Ejecutar"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                         if ("${env.NODE_NAME}" == "${_server}")
                            {
                             _serverAenviar =""
                                //  borramos el server para no hacer ssh
                             }
                             else{
                             _serverAenviar ="${_server}"
                             }
                        
                      
                        //12-01-21
                        print "valor de _EsRollback: ----${_EsRollback}----- "
                        if (_EsRollback==1)
                        {  //Es de rollback cambio el dominio
                            _Domain =_DomainRo
                        }
                        //    si existe la funcion es la de domain_entorno
                        _funcionEnt=pipelineConfig["${_Domain}-${_DeployEnv}"]
                        
                        // Si no existe domain_<entorno> em quedo con domain
                        if ("${_funcionEnt}" == "null"){
                            //print "es nulo"
                               _funcion=pipelineConfig["${_Domain}"]
                        }
                        else{
                            //print "NO es nulo"
                            _funcion=_funcionEnt
                        }
                        
                        //Cargamos la info del paquete en almsPackage para las ejecuciones de funciones
                        almsPackage= new VFESALMSDataRetriever( _ALMS_ID, _Domain, _DeployEnv,  _serverAenviar, _HayModulosPVCS, _dataModules, _HayAnexos, callFromWB, _serverSVN, _serverPROD , _listapaquetes, _EsRollback , 1, _Delivery,_Parametros,_HayParametros )

                      // print "Parametros: ${_Parametros}"
                       print "HayParametros: ${_HayParametros}"
                        
                        print "ejecutamos ${_funcion}"
                        for (pos = 0; pos < _funcion.size(); pos++) { 
                             _funcionAejecutar=_funcion[pos]
                            print "funciona a ejecutar ${_funcionAejecutar}"
                            def ejecutar="CDM/Jenkins/WORKBENCH/common/${_funcionAejecutar}"
                            def clase=load "${ejecutar}"
                            clase.execute(almsPackage)
                     }//Fin del for
                     if (_EsRollback == 1)
                      {  //Es de rollback cambio el dominio
                        //vuelvo a cambiar el dominio para los siguientes pasos
                        _Domain =_DomainSinRo
                       }
                    }//scripts
                }//steps
            }//Ejecutar

        
          
          stage("Etiquetar"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {//Si hay modulos de pvcs y estamos ejecutando de forma manual etiquetamos y no es AMDOCS-ESQUEMA
                        if(_HayModulosPVCS != 0 && callFromWB == false && _Domain !="AMDOCS-ESQUEMA") {
                            print "DEBUG: hay modulos pvcs y es manual "
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            txeker("-t -l",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                            
                        }else{
                            print "DEBUG: No hay modulos de pvcs o lo ha llamado WB"
                        }
                        if (_HayModulosPVCS != 0 && callFromWB == false && _serverSVN != null ){
                            //Si hay máquina de SVN ejecuto el promoSVN 
                                print "DEBUG: hay modulos pvcs y es manual y tiene SVN"
                                cleanDirPaquete "${_ALMS_ID}","${_serverSVN}","${hoy}","${_DeployEnv}","${_Domain}"
                                getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverSVN}"
                                promoSVN "${_ALMS_ID}","${_DeployEnv}","${_Domain}","${_serverSVN}"
                            }
                            else{
                                print "server SVN ${_serverSVN}"
                            }
                    }//scripts
                }//steps
          }//etiquetar
          stage("EditPackage"){
                agent {
                    node("eswldahr")
                        }

                steps{
                    script {//Si hay modulos de pvcs y estamos ejecutando de forma manual etiquetamos y no es PROD
                        
                         
                        if( (_DeployEnv == "PROD" || _DeployEnv == "prd") && callFromWB == false && _PromoteTOPROD == "YES") {
                            print "******************************"
                            print "Pacakges will be promoted to PROD"
                            print "******************************"
                            //Los edito a promocionado si no lo llama WB
                           // wrap([$class: 'BuildUser']) {
                            // echo "Exec user: ${env.BUILD_USER_ID}"
                             //mybuilduser=env.BUILD_USER_ID
                             //echo "Exec user: ${mybuilduser}"
                           //}
                            print "DEBUG: Paso a produccion "
                            
                            EditPackage(_ALMS_ID, false, _listapaquetes, false, false , "",mybuilduser,_pass)
                            Notif=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_ALMS_ID}/Todos.txt")
                            PromotePROD=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_ALMS_ID}/PromotePROD.txt")
                                   
                            if (PromotePROD != "")
                            { //Paquetes a promocionar
                                promoteApi("${mybuilduser}","10", '"'+PromotePROD+'"', _pass)
                            }
                             if (Notif != "")
                            { //Paquetes a promocionar
                                notifApi("${mybuilduser}",'"'+Notif+'"', _pass)
                                promoteApi("${mybuilduser}","10", '"'+Notif+'"', _pass)
                            }
                            EditPackage(_ALMS_ID, false, _listapaquetes, true, false, "",mybuilduser,_pass)
                            PaquetesIncorrectos=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_ALMS_ID}/PaquetesIncorrectos.txt")
                            if (PaquetesIncorrectos != "" )
                            {
                                print "Check following package that can not be promoted automatically"
                                print "${PaquetesIncorrectos}"
                            }
                        }//SI es para PROD
                    }//scripts
                }//steps
          }//EditPackage
          
         }//stages
        }//pipeline
    }//map

