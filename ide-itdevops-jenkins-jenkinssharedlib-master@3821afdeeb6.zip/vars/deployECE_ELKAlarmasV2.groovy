import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
def call(Map config,VFESALMSDeployment alms, VFESGitMergeInfo_aaresmi mergeInfo, ArrayList ParamItem2Delete)
{

    def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    def _envConfig=myEnvsConfig[alms.deployEnv]

    //////////////////////////////////////////
    /////////CHECK REPOSITORY CHANGES/////////
    //////////////////////////////////////////

    items2DeployConfig=mergeInfo.FilesChangedDetailed.findAll{!(it[1] =~ "Alertas/" || it[1] =~ "KPIs/" || it[1] =~ "Umbrales/")}
    items2Delete=mergeInfo.FilesChangedDetailed.findAll{it[0] == "D" && (it[1] =~ "Alertas/" || it[1] =~ "KPIs/" || it[1] =~ "Umbrales/")}
    items2Rename=mergeInfo.FilesChangedDetailed.findAll{it[0] == "R" && (it[1] =~ "Alertas/" || it[1] =~ "KPIs/" || it[1] =~ "Umbrales/")}
    items2Deploy=mergeInfo.FilesChangedDetailed.findAll{(it[0] == "M" || it[0] == "A") && (it[1] =~ "Alertas/" || it[1] =~ "KPIs/" || it[1] =~ "Umbrales/")}

    echo "=============================================="
    echo "CHANGES FOUNDS IN COMMIT"
    echo "=============================================="
    echo "CHANGES ONLY AT FILESYSTEM LEVEL:"
    echo "Configuration Files to Deploy:  ${items2DeployConfig.size()}"
    echo "CHANGES AT ELASTICSEARCH LEVEL:"
    echo "ElasticSearch Items to Delete:  ${items2Delete.size()}"
    echo "ElasticSearch Items to Rename:  ${items2Rename.size()}"
    echo "ElasticSearch Items to Deploy:  ${items2Deploy.size()}"
    echo "=============================================="

    if (items2Deploy.size() == 0 && items2Delete.size() == 0 && items2Rename.size() == 0 && items2DeployConfig.size() == 0)
    {
        echo "ERROR. There are not any change detected!!!!!. "
        sh ("exit 1")
    }

    if (items2Delete.size() != 0) {
        echo "ElasticSearch Items to Delete detected. Checking with parameter ITEMS2DELETE ....."
        filesItems2Delete = []
        items2Delete.each { filesItems2Delete.add(it[1].value.toString()) }
        listFilesItems2Delete = filesItems2Delete as List
        //echo "listFilesItems2Delete=${listFilesItems2Delete}"

        def diffInFiles = (listFilesItems2Delete - ParamItem2Delete)
        def diffInParam = (ParamItem2Delete - listFilesItems2Delete)

        //echo "diffInFiles=${diffInFiles}"
        //echo "diffInParam=${diffInParam}"

        if (diffInParam.size() != 0) {
            echo "WARN. There are some ElasticSearch Items in the param ITEMS2DELETE that were not detected in the in the commit to be deleted!!!!!. "
            echo "${diffInParam}"
        }

        if (diffInFiles.size() != 0) {
            echo "ERROR. There are some ElasticSearch Items detected to be deleted in the commit that there isn't in the param ITEMS2DELETE!!!!!. We cannot continue"
            echo "${diffInFiles}"
            sh("exit 1")
        }
        echo "OK. ElasticSearch Items to Delete Checked with parameter ITEMS2DELETE Successfully."
        echo "=============================================="
    }

    ///////////////////////////////////
    /////////NEW CHECK ACTIONS/////////
    ///////////////////////////////////
    if (config.containsKey("deployActions"))
    {
        deployECE_ELKCheckVariables config,alms
    }
    ///////////////////////////////////
    /////////NEW CHECK ACTIONS/////////
    ///////////////////////////////////

    echo "Deploying Alerts ...."
    echo "_envConfig"+_envConfig['deploy_alerts']
    _envConfig['deploy_alerts'].each { item ->
        echo "Server Data:"
        echo "  deploy_server: " + item.server
        echo "  deploy_user: " + item.user
        echo "  application_release_path: " + item.application_release_path
        echo "  platafor_release_path: " + item.platafor_release_path + "/scripts"
        echo "  variables repository: " + item.repo_vars
        echo "  deploy Script: " + config.deployScript
        echo "ElasticSearch Data:"
        echo "  elastic_sch: " + item.elastic_sch
        echo "  elastic_host: " + item.elastic_host
        echo "  elastic_port: " + item.elastic_port
        echo "  elastic_credential: " + item.elastic_credential
        echo "  watcher_credential: " + item.watcher_credential
        def _elasticURL=""
        def _watcherCre=""
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.watcher_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
        {
            _watcherCre="${USERNAME}" + ":" + "${PASSWORD}"
        }

        //DELETE
        if ( items2Delete.size() != 0 )
        {
            echo "=========================================="
            echo "DELETE Alerts and/or Threholds and/or KPIs"
            echo "=========================================="
            // ALERTS
            alerts2Delete = []
            items2DeleteAlerts = items2Delete.findAll { it[1] =~ 'Alertas/' }
            items2DeleteAlerts.each { it -> alerts2Delete.add(it[1]) }
            alerts2DeleteString = alerts2Delete.join(",")
            _paramAlerts = ""
            if (alerts2DeleteString != null && alerts2DeleteString != "") {
                _paramAlerts = "-i ${alerts2DeleteString}"
            }
            echo "Alerts to delete: " + alerts2DeleteString

            // THREHOLDS
            threholds2Delete = []
            items2DeleteThresholds = items2Delete.findAll { it[1] =~ 'Umbrales/' }
            items2DeleteThresholds.each { it -> threholds2Delete.add(it[1]) }
            threholds2DeleteString = threholds2Delete.join(",")
            _paramThresholds = ""
            if (threholds2DeleteString != null && threholds2DeleteString != "") {
                _paramThresholds = "-t ${threholds2DeleteString}"
            }
            echo "Threholds to delete: " + threholds2DeleteString

            // KPIS
            kpis2Delete = []
            items2DeleteKPIs = items2Delete.findAll { it[1] =~ 'KPIs/' }
            items2DeleteKPIs.each { it -> kpis2Delete.add(it[1]) }
            kpis2DeleteString = kpis2Delete.join(",")
            _paramKpis = ""
            if (kpis2DeleteString != null && kpis2DeleteString != "") {
                _paramKpis = "-k ${kpis2DeleteString}"
            }
            echo "KPIs to delete: " + kpis2DeleteString

            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -d -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -w ${_watcherCre} -v ${item.repo_vars} ${_paramAlerts} ${_paramThresholds} ${_paramKpis}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -d -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -w ${_watcherCre} -v ${item.repo_vars} ${_paramAlerts} ${_paramThresholds} ${_paramKpis}'"
            }
        }

        //RENAME
        if ( items2Rename.size() != 0 )
        {
            echo "=========================================="
            echo "RENAME Alerts and/or Threholds and/or KPIs"
            echo "=========================================="
            // ALERTS
            alerts2Rename = []
            items2RenameAlerts = items2Rename.findAll { it[1] =~ 'Alertas/' }
            items2RenameAlerts.each { it -> alerts2Rename.add("${it[1]}#${it[2]}") }
            alerts2RenameString = alerts2Rename.join(",")
            _paramAlerts = ""
            if (alerts2RenameString != null && alerts2RenameString != "") {
                _paramAlerts = "-i ${alerts2RenameString}"
            }
            echo "Alerts to rename: " + alerts2RenameString

            // THREHOLDS
            threholds2Rename = []
            items2RenameThresholds = items2Rename.findAll { it[1] =~ 'Umbrales/' }
            items2RenameThresholds.each { it -> threholds2Rename.add("${it[1]}#${it[2]}") }
            threholds2RenameString = threholds2Rename.join(",")
            _paramThresholds = ""
            if (threholds2RenameString != null && threholds2RenameString != "") {
                _paramThresholds = "-t ${threholds2RenameString}"
            }
            echo "Threholds to rename: " + threholds2RenameString

            // KPIS
            kpis2Rename = []
            items2RenameKPIs = items2Rename.findAll { it[1] =~ 'KPIs/' }
            items2RenameKPIs.each { it -> kpis2Rename.add("${it[1]}#${it[2]}") }
            kpis2RenameString = kpis2Rename.join(",")
            _paramKpis = ""
            if (kpis2RenameString != null && kpis2RenameString != "") {
                _paramKpis = "-k ${kpis2RenameString}"
            }
            echo "KPIs to rename: " + kpis2RenameString

            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -x -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -w ${_watcherCre} -v ${item.repo_vars} ${_paramAlerts} ${_paramThresholds} ${_paramKpis}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -x -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -w ${_watcherCre} -v ${item.repo_vars} ${_paramAlerts} ${_paramThresholds} ${_paramKpis}'"
            }
        }

        //UPDATE (ADD/MODIFY)
        if (items2Deploy.size() != 0) {
            echo "================================================="
            echo "UPDATE/CREATE Alerts and/or Threholds and/or KPIs"
            echo "================================================="
            // ALERTS
            alerts2Deploy = []
            items2DeployAlerts = items2Deploy.findAll { it[1] =~ 'Alertas/' }
            items2DeployAlerts.each { it -> alerts2Deploy.add(it[1]) }
            alerts2DeployString = alerts2Deploy.join(",")
            _paramAlerts = ""
            if (alerts2DeployString != null && alerts2DeployString != "") {
                _paramAlerts = "-i ${alerts2DeployString}"
            }
            echo "Alerts to deploy: " + alerts2DeployString

            // THREHOLDS//
            threholds2Deploy = []
            items2DeployThresholds = items2Deploy.findAll { it[1] =~ 'Umbrales/' }
            items2DeployThresholds.each { it -> threholds2Deploy.add(it[1]) }
            threholds2DeployString = threholds2Deploy.join(",")
            _paramThresholds = ""
            if (threholds2DeployString != null && threholds2DeployString != "") {
                _paramThresholds = "-t ${threholds2DeployString}"
            }
            echo "Threholds to deploy: " + threholds2DeployString

            // KPIS
            kpis2Deploy = []
            items2DeployKPIs = items2Deploy.findAll { it[1] =~ 'KPIs/' }
            items2DeployKPIs.each { it -> kpis2Deploy.add(it[1]) }
            kpis2DeployString = kpis2Deploy.join(",")
            _paramKpis = ""
            if (kpis2DeployString != null && kpis2DeployString != "") {
                _paramKpis = "-k ${kpis2DeployString}"
            }
            echo "KPIs to deploy: " + kpis2DeployString

            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -u -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -w ${_watcherCre} -v ${item.repo_vars} ${_paramAlerts} ${_paramThresholds} ${_paramKpis}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -u -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -w ${_watcherCre} -v ${item.repo_vars} ${_paramAlerts} ${_paramThresholds} ${_paramKpis}'"
            }
        }
    }
}