import groovy.json.JsonSlurper;
/**
* this method need below params:
*    NEXUS_URL
*    REPO
*    GID
*    ARTID
*    EXTENSION
*    DELIVERY
*    COMMIT
*/
def call(String _NEXUS_URL,String _REPO,String _GID,String _ARTID,String _EXTENSION,String _DELIVERY,String _COMMIT, String _credential ) {
    echo "getNextVersionNexus"
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${_credential}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
        def continuationToken=0
        def addContinuationToken=""
        def SALIDA=""
        def sec=[0]
        while (continuationToken!=null){
            SALIDA=sh returnStdout: true, script: """
                curl -u ${USERNAME}:${PASSWORD} -k "${_NEXUS_URL}/service/rest/v1/search?repository=${_REPO}&format=maven2&group=${_GID}&name=${_ARTID}&maven.extension=${_EXTENSION}&version=${_DELIVERY}*${addContinuationToken}"
            """
            def version=""
            if (SALIDA != ""){
                def jsonSlurper = new JsonSlurper()
                def jsonnexusquery = jsonSlurper.parseText(SALIDA)
                jsonnexusquery.items.each{ 
                    //echo "encontrada version: ${it.version}"
                    version=it.version
                    def versiontoken=version.tokenize(".")
                    def delivery=versiontoken[0]
                    def secuencial=versiontoken[1].toInteger()
                    //echo "delivery:${delivery}"
                    echo "Existe el artefacto en nexus ${_ARTID}:${it.version}"
                    sec.add(secuencial)
                }
                continuationToken=jsonnexusquery.continuationToken
                addContinuationToken="&continuationToken=${continuationToken}"
            }else{
                continuationToken=null
            }
        }
        def newsec=sec.max()+1
        def newversion="${_DELIVERY}"+"."+newsec.toString()+"."+"${_COMMIT}"
        echo "VERSION:${newversion}"
        return newversion
    }
}
