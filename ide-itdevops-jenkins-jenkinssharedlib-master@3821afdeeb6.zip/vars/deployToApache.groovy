import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(String _htdocsPath,String distFolder,String distFile,String _folderName,VFESALMSDeployment _almsDep,JSONObject _envConfig)
{
    def unzipOper=""
    
    if (distFile.endsWith('.tar.gz'))
    {
        unzipOper="tar  --directory=${_folderName} -xvf  ${distFile}"
    }else if (distFile.endsWith('.zip')){
        unzipOper="unzip ${distFile} -d ${_folderName}"
    }
    echo "Doing BACKUP ..."
    _envConfig.webservers.each { item ->
        //En el caso de entornos no PROD y Oculto hcemos backup automatico
        echo "Backing up on ${item.server} ..."
        def backupfile="backup-"+_almsDep.appName+"-"+_almsDep.almsID+"-"+item.server+"-"+_almsDep.jobTimeStamp+".zip"
        def resBack=sh(returnStdout: true, script:"""ssh -q -o StrictHostKeyChecking=no -l ${item.apacheusername}  ${item.server} '
        cd ${item.apachepath}/${_htdocsPath}; \
        if [ -d ${_folderName} ]; \
        then \
            rm -f backup-${_almsDep.appName}-*.zip; \
            cd ${_folderName}; \
            echo BACKUP_SI; \
            zip -r ../${backupfile} * 2>/dev/null; \
        fi; \
        '
        """).trim()
        if (resBack.contains('BACKUP_SI')){
            sh "scp ${item.apacheusername}@${item.server}:${item.apachepath}/${_htdocsPath}/${backupfile} ${item.server}.${backupfile}  2>/dev/null"
            archiveArtifacts artifacts: "${item.server}.${backupfile}", fingerprint: true
        }
        else{
            echo "Backup not done at ${item.apacheusername}@${item.server} because folder ${item.apachepath}/${_htdocsPath}/${_folderName} does not exist!!!"
        }

    }
     //En el caso de entornos no PROD y Oculto hcemos deploy automatico
    _envConfig.webservers.each { item ->
        echo "Deploying up on ${item.server} ..."
        sh "scp ${distFolder}/${distFile} ${item.apacheusername}@${item.server}:${item.apachepath}/${_htdocsPath} 2>/dev/null"
        sh """
        ssh -o StrictHostKeyChecking=no -l ${item.apacheusername}  ${item.server} \
        'cd ${item.apachepath}/${_htdocsPath};\
        if [ -d ${_folderName} ]; then \
            echo Borrando ${_folderName}; \
            rm -rf ${_folderName}; \
        fi; \
        mkdir -p ${_folderName}; \
        ${unzipOper}; \
        rm ${distFile}'
        """
    }

}
return this;