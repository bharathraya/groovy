def call(String _paquete,String _message,String _id){
   hoy=new Date().format( 'yyyyMMdd' )
   Ruta="/home/plataforma/plausr/data/paquetes"
   RutaPaquete="${Ruta}/${hoy}/${_paquete}"

   node ("es036tvr") {     
      stage ("Delete Files"){
         sh "if [ -f ${RutaPaquete}/${_paquete}_errors.txt ]; then rm -f ${RutaPaquete}/${_paquete}_errors.txt;fi"
         sh "if [ -f ${RutaPaquete}/${_paquete}_reject.id ]; then rm -f ${RutaPaquete}/${_paquete}_reject.id;fi"
      }
      stage ("Create Files"){
         sh "mkdir -p ${RutaPaquete}"
         sh " echo ${_id} >> ${RutaPaquete}/${_paquete}_reject.id"
         sh " echo ${_message} >> ${RutaPaquete}/${_paquete}_errors.txt"
      }
   }
}