def call (String _app, String _env, String _packages ,String _usuario, String _pass){
    node ('es1117yw'){
        checkout scm
        
       
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
             bat "python txeker_git.py -p ${_packages} -e ${_env} -a  ${_app} -u ${_usuario} -c ${_pass} "
             }//wrap
        }
    }
}

def call (String _app, String _env, String _packages ,String _usuario, String _pass, String _directory){
    node ('es1117yw'){
        checkout scm
        
       
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
             bat "python txeker_git.py -p ${_packages} -e ${_env} -a  ${_app} -u ${_usuario} -c ${_pass} -r ${_directory}"
             }//wrap
        }
    }
}