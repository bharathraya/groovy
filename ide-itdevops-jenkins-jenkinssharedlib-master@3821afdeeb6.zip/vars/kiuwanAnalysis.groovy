import groovy.json.JsonSlurperClassic 
import groovy.json.JsonSlurper

/*
results:
    KIUWAN_RESPONSE: return code of analysis
    env.analysisURL:  URL with analysis result
*/
def call(Map obj) {
/*
def obj = [
          typeBranch: typeBranch,
		  tagBranch: tagBranch,
          commitID: CHANGE_REQUEST,
          kiuwanCredentials: KIUWAN_CREDENTIALS_ID,
          kiuwanAppName: KIUWAN_APPNAME,
          kiuwanModel: KIUWAN_MODEL,
          kiuwanLabel: KIUWAN_LABEL,
          saveUTReports: env.switchUT
    ]   
  */
    MASTER = "master"
    FEATURE = "feature"
    DEVELOP = "develop"
    RELEASE = "release"
    VODAFONE = "vodafone"
    analysisURL = null
    KIUWAN_ERROR_RESPONSE = null
    KIUWAN_RESPONSE = null
    isPullRequest = null
    LAST_BASELINE = null
    causedException = false

    try {
        switch(obj.typeBranch) {
            case MASTER:
                isPullRequest = developCommit(obj)
                withCredentials([usernamePassword(credentialsId: obj.kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
                    LAST_BASELINE= sh(returnStdout: true, script: "unset https_proxy http_proxy HTTPS_PROXY HTTP_PROXY ; curl --insecure --user $KUSERNAME:$KPASSWORD https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/applications/last_analysis?application=${obj.kiuwanAppName}")
                }
                analysisURL = new JsonSlurper().parseText(LAST_BASELINE)?.analysisURL
            break
            case DEVELOP:
				echo "Running a completeDelivery (${obj.typeBranch})"
                KIUWAN_RESPONSE = getKiuwanResponse(obj, "completeDelivery")
            break
            case RELEASE: case FEATURE: case VODAFONE:
				echo "Running a partialDelivery (${obj.typeBranch})"
                KIUWAN_RESPONSE = getKiuwanResponse(obj, "partialDelivery")
            break
        }
    } catch(Exception e) {
        causedException = true
        echo "ERROR: Something went wrong."
        KIUWAN_ERROR_RESPONSE=checkKiuwanErrors(e.toString())
        KIUWAN_RESPONSE = KIUWAN_ERROR_RESPONSE[0]

        if (env.QUALITYGATEBLOCKS != "true" && KIUWAN_RESPONSE  == "10") {
            env.auditFailed = "*INFORMATIVE AUDIT DID NOT PASS*"
            echo "${env.auditFailed}"
        } else
            error (KIUWAN_ERROR_RESPONSE[1])

    } finally {
      	env.KIUWAN_RESPONSE = KIUWAN_RESPONSE
        print("Kiuwan Response: ${KIUWAN_RESPONSE}")
        if(isPullRequest == null && obj.typeBranch == "master")
  	        print("[Kiuwan]: Pull request of changes in master not found")

        if (KIUWAN_RESPONSE == "10" || causedException == false) {
          env.analysisURL = getAnalysisUrl(obj.kiuwanAppName, obj.kiuwanCredentials)
          print("[Kiuwan]: Analysis URL: ${env.analysisURL}")
        } else if (LAST_BASELINE != null) {
          env.analysisURL = new JsonSlurper().parseText(LAST_BASELINE).analysisURL
          print("[Kiuwan]: Analysis URL: ${env.analysisURL}")
        }
    }

  //currentBuild.result = 'SUCCESS'
  
  //return KIUWAN_RESPONSE
}

def getAnalysisUrl(def appname, def kiuwanCredentials){
  def result = null
  withCredentials([usernamePassword(credentialsId: kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
    API_DELIVERIES=sh(returnStdout: true, script: "unset https_proxy http_proxy HTTPS_PROXY HTTP_PROXY ; curl --insecure --user $KUSERNAME:$KPASSWORD https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/applications/deliveries?application=${appname}")
    def deliveryCode = new JsonSlurper().parseText(API_DELIVERIES).code[0]
    DELIVERY_INFO=sh(returnStdout: true, script: "unset https_proxy http_proxy HTTPS_PROXY HTTP_PROXY ; curl --insecure --user $KUSERNAME:$KPASSWORD https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/deliveries/${deliveryCode}")
    result = new JsonSlurper().parseText(DELIVERY_INFO).auditResultURL
  }
  return result
}

def getKiuwanResponse(def obj, def deliveryType){
  response = null
  def kiuwanSource=obj.containsKey('kiuwanSource') ? obj.kiuwanSource : WORKSPACE
  def kiuwanBranch=obj.containsKey('kiuwanBranch') ? obj.kiuwanBranch : env.branch
  if(obj.tagBranch == null && deliveryType != "baseline"){
	  echo "Overwriting tagBranch with ${obj.changeReq}"
    obj.tagBranch = obj.changeReq
  }

  //INI cambios para excludes ...
  def basic_excludes = sh(script: 'cat kiuwan/conf/analyzer.properties  | grep exclude.patterns= | sed s/exclude.patterns=//', returnStdout: true).trim().replaceAll("/", '\\\\\\/')
  // extra exclude by IDG-DIDI
  def extra_excludes = "**idg-didi-kiuwan-utils\\/**,**\\/src\\/test\\/**,**\\/target\\/**,configurations\\/**,**\\/build\\/**,documentation\\/**,docs\\/**,doc\\/**,assets\\/**,coverage\\/**,**\\/index.jsp"
  def analysisTimeout = '86400000'
  def memory_max_kiuwan = env?.MEMORY_MAX_KIUWAN ?: '8g'
  sh "sed -i 's/memory.max=1024m/memory.max=${memory_max_kiuwan}/g' kiuwan/conf/analyzer.properties"
  sh "sed -i 's/timeout=3600000/timeout=${analysisTimeout}/g' kiuwan/conf/analyzer.properties"
  sh "sed -i '/^exclude.patterns/ s/\$/,${extra_excludes}/' kiuwan/conf/analyzer.properties"
  //if (env?.RUN_DIFF && deliveryType == "partialDelivery"){
  //	sh "sed -i '/^include.patterns/ s/\$/${gitUtils.getFormattedDiffList()}/' kiuwan/conf/analyzer.properties"
  //}
  //FIN cambios para excludes ...
  withCredentials([usernamePassword(credentialsId: obj.kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
   if(obj.saveUTReports == "true"){
      if(fileExists("${kiuwanSource}/reports")){
         if(deliveryType == "baseline"){
            response = sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", returnStdout: true, script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD -n ${obj.kiuwanAppName} -s ${kiuwanSource} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -x '${kiuwanSource}/reports' -wr").trim()
         }else{
      	    response = sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", returnStdout: true, script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD -as ${deliveryType} -n ${obj.kiuwanAppName} -bn ${kiuwanBranch} -s ${kiuwanSource} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -cr '${obj.changeReq}' -x '${kiuwanSource}/reports' -wr").trim()
         }
      }else{
        error("[Error] Sorry, your project must have unit tests to continue IC.")
      }
    }else{
      if(deliveryType == "baseline"){
            response = sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", returnStdout: true, script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD -n ${obj.kiuwanAppName} -s ${kiuwanSource} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -wr").trim()
      }else{
        response = sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing ${deliveryType} code...", returnStdout: true, script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD -as ${deliveryType} -n ${obj.kiuwanAppName} -bn ${kiuwanBranch} -s ${kiuwanSource} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -cr ${obj.tagBranch} -wr").trim()
      }
    }
  }
  return response
}

def developCommit(def obj){
  latestCommit = 0
  
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'syncReposBitBucket', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
    PR_INFO=sh(returnStdout: true, script: "unset https_proxy http_proxy HTTPS_PROXY HTTP_PROXY ; curl --insecure --user $USERNAME:$PASSWORD https://webpre-adm.es.sedc.internal.vodafone.com:42520/bitbucket/rest/api/1.0/projects/${env.bitbucketKey}/repos/${obj.kiuwanAppName}/commits/${obj.kiuwanLabel}/pull-requests").trim()
    pullRequests = new JsonSlurperClassic().parseText(PR_INFO).values
  }
  
  withCredentials([usernamePassword(credentialsId: obj.kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
    DELIVERIES_API=sh(returnStdout: true, script: "unset https_proxy http_proxy HTTPS_PROXY HTTP_PROXY ; curl --insecure --user $KUSERNAME:$KPASSWORD https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/applications/deliveries?application=${obj.kiuwanAppName}").trim()
    deliveries = new JsonSlurperClassic().parseText(DELIVERIES_API)
  }
  found = 0
  for(int i = 0; i < deliveries.size(); i++){
    for(int j = 0; j < pullRequests.size(); j++){
      if(pullRequests[j].state=='MERGED' && pullRequests[j].fromRef.latestCommit == deliveries[i].label){
        latestCommit=deliveries[i].label
        println("[Kiuwan]: Label of the analysis to be promoted: ${latestCommit}")
        found=1
        break
      }
    }
    if(found){
      break
    }
  }
  
  if(latestCommit == 0){
    response = null
    env.foundDelivery = 0
    getKiuwanResponse(obj, "baseline")
  }else{
    withCredentials([usernamePassword(credentialsId: obj.kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
      response = sh(encoding: 'UTF-8', label: "[Kiuwan]: Promoting delivery...", returnStdout: true, script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD --promote-to-baseline -n ${obj.kiuwanAppName} -cr ${change_request} -l ${latestCommit} -pbl ${obj.kiuwanLabel} -wr").trim()
    }
    env.foundDelivery = 1
  }
  return response
}
