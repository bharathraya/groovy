import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def deploy_env=""
def commit_id=""
def pck_id=""
def delivery=""
def project_id=""
def enterprise=""
def gitRepo=null
def pipelineConfig=null
def annexes=""
def deployConfig=null
def binaryActionStatus=null
def isThereBinaries=null
def hoy=null
def backupPathBinary=null
def envSet=null
def numServers=null
def deploy_status_filename=""
def isNeedActivateMicroServices=""
def URLMicroServiceStart=""
def MicroServicePort=""
def isNeededBinariesRollBack=null

VFESGitMergeInfo mergeInfo=null

def CleanEnvironment(){
    echo "======= Clean the environment ======="
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 3
    remote.retryWaitSec = 2
    remote.timeoutSec = 5
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
            for( server in deployConfig[deploy_env]['servers']) {
                String name=server['name']
                String ip=server['ip']
                remote.host = ip
                remote.name = name
                remote.identityFile = keyfile
                echo "======= Cleaning the environment at ${name} with ip ${ip} ======="
                //Cleaning _tmp directory
                echo "    =======> Cleaning _tmp directory <======="
                sshCommand remote: remote, command:"cd ${pipelineConfig.backupPath}; rm -fr _tmp", failOnError:false
                //Cleaning backups
                echo "    =======> Cleaning backup directory <======="
                sshCommand remote: remote, command:"cd ${pipelineConfig.backupPath};ls -t | awk 'NR>10' | xargs rm -f", failOnError:false
                //Cleaning deployment status files if there is any
                echo "    =======> Cleaning deploy status files <======="
                _deployStatusFileName="deploy_status_" + "${name}" + ".json"
                sh (script:"rm -f ${_deployStatusFileName}", returnStatus:false)
            }
        }
    }
}

def UpdateRelease(){
    if (isThereBinaries == 1)
    {
        echo "======= Updating the release ======="
        def remote = [:]
        remote.user = pipelineConfig.releaseUser
        remote.allowAnyHosts = true
        remote.retryCount = 3
        remote.retryWaitSec = 2
        remote.timeoutSec = 5
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
        {
            withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
                for( server in deployConfig[deploy_env]['servers']) {
                    String name=server['name']
                    String ip=server['ip']
                    echo "======= Updating the release at ${name} with ip ${ip} ======="
                    remote.host = ip
                    remote.name = name
                    remote.identityFile = keyfile
                    echo "    => Deleting obsolete binaries"
                    for (binInPackage in binaryActionStatus.findAll{it.type == "environment" && it.isInPackage == true})
                    {
                        bin = "${binInPackage.full_name}"
                        sshCommand remote: remote, command:"rm -fr ${pipelineConfig.releasePath}/${bin}"
                        echo "        =>${bin} - Status: Deleted from release path"
                    }
                    for (binInPackage in binaryActionStatus.findAll{it.type == "package"})
                    {
                        bin = "${binInPackage.full_name}"
                        compose = "${pipelineConfig.extractFolder}" + "/" + "${bin}"
                        sh("scp -i ${keyfile} ${compose} ${pipelineConfig.releaseUser}@${ip}:${pipelineConfig.releasePath}")
                        echo "        =>${bin} - Status: Copied to the release path"
                    }
                }
            }
        }
    }
}

def BinaryBackup(){
    if (isThereBinaries == 1)
    {
        backupWithDots="${pipelineConfig.backupPath}"+"/"+"WILDFLY_"+"${workbenchPackage.gitTagComment}"+".tar"
        backupPathBinary=backupWithDots.replaceAll(':','_')
        echo "Creating tmp path for Backups"
        def remote = [:]
        remote.user = pipelineConfig.releaseUser
        remote.allowAnyHosts = true
        remote.retryCount = 5
        remote.retryWaitSec = 2
        remote.timeoutSec = 15
        _binarytoBackup=binaryActionStatus.findAll{it.type == "environment" && it.isInPackage == true}
        for( server in deployConfig[deploy_env]['servers']) {
            String name=server['name']
            String ip=server['ip']
            remote.host = ip
            remote.name = name
            withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
                remote.identityFile = keyfile
                sshCommand remote: remote, command:"rm -fr ${pipelineConfig.backupPath}/_tmp", failOnError:false
                sshCommand remote: remote, command:"mkdir ${pipelineConfig.backupPath}/_tmp"
                for( String _obj_bin : _binarytoBackup){
                    echo "Coping binary ${_obj_bin.full_name} to the tmp path ${pipelineConfig.backupPath}/_tmp at server ${name}-${ip}"
                    sshCommand remote: remote, command:"cp -p ${pipelineConfig.releasePath}/${_obj_bin.full_name} ${pipelineConfig.backupPath}/_tmp/."
                }
                echo "Creating backup tar file ${backupPathBinary}"
                sshCommand remote: remote, command:"cd ${pipelineConfig.backupPath}/_tmp; tar cvf ${backupPathBinary} ."
                echo "Deleting tmp path ${pipelineConfig.backupPath}/_tmp at ${name}-${ip}"
                sshCommand remote: remote, command:"rm -fr ${pipelineConfig.backupPath}/_tmp"
            }
        }
    }
}

def returnSplitName (String full_name)
{
    def _name=null
    def _version=null
    def _freeText=null
    def _extension=null

    int sepPos1 = full_name.indexOf('_')
    if (sepPos1 == -1) {
        return [_name,_version,_freeText,_extension]
    }
    _name=full_name.substring(0,sepPos1).trim()

    int sepPos2 = full_name.indexOf('_',sepPos1+1)
    if (sepPos2 == -1) {
        int sepPos3 = full_name.lastIndexOf('.')
        if (sepPos3 == -1) {
            return [_name,_version,_freeText,_extension]
        }
        _version=full_name.substring(sepPos1+1,sepPos3)
        _extension=full_name.substring(sepPos3+1).trim()
        return [_name,_version,_freeText,_extension]
    }
    _version=full_name.substring(sepPos1+1,sepPos2)

    int sepPos3 = full_name.lastIndexOf('.')
    _extension=full_name.substring(sepPos3+1).trim()

    _freeText=full_name.substring(sepPos2+1,sepPos3)
    return [_name,_version,_freeText,_extension]
}

def deployBinaries()
{
    if (isThereBinaries == 1)
    {
        isNeededBinariesRollBack=1
        def remote = [:]
        remote.user = pipelineConfig.releaseUser
        remote.allowAnyHosts = true
        remote.retryCount = 3
        remote.retryWaitSec = 2
        remote.timeoutSec = 5
        echo "======= Upload binaries to deploy tmp path ======="
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
        {
            connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
            for( server in deployConfig[deploy_env]['servers']) {
                echo "Clearing status....."
                binaryActionStatus.each {it.status = ""}
                echo "${binaryActionStatus}"
                String name=server['name']
                String ip=server['ip']
                deploy_status_filename="deploy_status_" + "${name}" + ".json"
                echo "======= Deploy at ${name} with ip ${ip} ======="
                withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
                {
                    remote.host = ip
                    remote.name = name
                    remote.identityFile = keyfile
                    echo "    =======> Create tmp path <======="
                    sshCommand remote: remote, command:"rm -fr ${pipelineConfig.backupPath}/_tmp", failOnError:false
                    sshCommand remote: remote, command:"mkdir ${pipelineConfig.backupPath}/_tmp"
                    echo "    =======> Upload the binaries to the tmp path <======="
                    for (binInPackage in binaryActionStatus.findAll{it.type == "package"})
                    {
                        compose = "${pipelineConfig.extractFolder}" + "/" + "${binInPackage.full_name}"
                        sh("scp -o ConnectTimeout=30 -i ${keyfile} ${compose} ${pipelineConfig.releaseUser}@${ip}:${pipelineConfig.backupPath}/_tmp")
                    }
                    echo "    =======> Disabling old binaries <======="
                    for (binInPackage in binaryActionStatus.findAll{it.type == "environment" && it.isInPackage == true})
                    {
                        bin = "${binInPackage.full_name}"
                        disable=" --command=\"deployment disable ${bin}\""
                        command=connect + disable
                        sshCommand remote: remote, command:"${command}"
                        index=binaryActionStatus.findIndexOf{it.type == "environment" && it.full_name == binInPackage.full_name}
                        binaryActionStatus[index].status = "Disabled"
                        echo "        =>${bin} - Status: Disabled"
                    }
                    echo "    =======> Deploying binaries (Disabled Status) <======="
                    for (binInPackage in binaryActionStatus.findAll{it.type == "package"})
                    {
                        bin = "${binInPackage.full_name}"
                        install=" --command=\"deployment deploy-file ${pipelineConfig.backupPath}/_tmp/${bin} --disabled"
                        replace = ""
                        echo "$binInPackage"
                        if (binInPackage.SameVersionDeployed==true) {
                            replace = " --replace"
                        }
                        command=connect + install + replace + "\""
                        sshCommand remote: remote, command:"${command}"
                        index=binaryActionStatus.findIndexOf{it.type == "package" && it.full_name == binInPackage.full_name}
                        binaryActionStatus[index].status = "Disabled"
                        echo "        =>${bin} - Status: Disabled"
                    }

                    echo "    =======> Enabling binaries <======="
                    for (binInPackage in binaryActionStatus.findAll{it.type == "package"})
                    {
                        bin = "${binInPackage.full_name}"
                        enable=" --command=\"deployment enable ${bin}\""
                        command=connect + enable
                        sshCommand remote: remote, command:"${command}"
                        index=binaryActionStatus.findIndexOf{it.type == "package" && it.full_name == binInPackage.full_name}
                        binaryActionStatus[index].status = "Enabled"
                        echo "        =>${bin} - Status: Enabled"
                    }

                    echo "    =======> Undeploying old binaries <======="
                    for (binInPackage in binaryActionStatus.findAll{it.type == "environment" && it.isInPackage == true})
                    {
                        if (binInPackage.SameVersionDeployed == false)
                        {
                            bin = "${binInPackage.full_name}"
                            undeploy=" --command=\"deployment undeploy ${bin}\""
                            command=connect + undeploy
                            sshCommand remote: remote, command:"${command}"
                            index=binaryActionStatus.findIndexOf{it.type == "environment" && it.full_name == binInPackage.full_name}
                            binaryActionStatus[index].status = "Undeploy"
                            echo "        =>${bin} - Status: Undeploy"
                        }
                    }
                    if (isNeedActivateMicroServices == 'Y')
                    {
                        echo "    =======> Activating MicroServices <======="
                        activate_command="curl -s --location --request POST "
                        url_curl="\"http://${ip}:${MicroServicePort}/"
                        for (binInPackage in binaryActionStatus.findAll{it.type == "package"})
                        {
                            bin = "${binInPackage.name}"
                            command=activate_command + url_curl + bin +  URLMicroServiceStart + "\""
                            echo "        =>Command: ${command}"
                            sshCommand remote: remote, command:"${command}" , failOnError:false
                        }
                    }
                }
                echo "json output: "
                def json_str = JsonOutput.toJson(binaryActionStatus)
                def json_beauty = JsonOutput.prettyPrint(json_str)
                echo "${json_beauty}"
                writeFile([file: deploy_status_filename, text: json_beauty])
            }
            for( server in deployConfig[deploy_env]['servers']) {
                String name=server['name']
                String ip=server['ip']
                echo "======= Clean Environment at ${name} with ip ${ip} ======="
                withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
                    remote.host = ip
                    remote.name = name
                    remote.identityFile = keyfile
                    echo "    ======= Delete tmp path ======="
                    sshCommand remote: remote, command:"rm -fr ${pipelineConfig.backupPath}/_tmp"
                }
            }
        }
    }
}

def rollbackBinaries(){
    if (isThereBinaries == 1 && isNeededBinariesRollBack == 1)
    {
        echo "Wrinting status file of the last actions"
        echo "json output: "
        def json_str = JsonOutput.toJson(binaryActionStatus)
        def json_beauty = JsonOutput.prettyPrint(json_str)
        echo "${json_beauty}"
        writeFile([file: deploy_status_filename, text: json_beauty])


        def remote = [:]
        remote.user = pipelineConfig.releaseUser
        remote.allowAnyHosts = true
        remote.retryCount = 3
        remote.retryWaitSec = 2
        remote.timeoutSec = 5
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
        {
            connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
            for( server in deployConfig[deploy_env]['servers']) {
                String name=server['name']
                String ip=server['ip']
                echo "======= Checking Rollback in ${name} with ip ${ip} ======="
                echo "    => Checking deploy status file"
                filename="deploy_status_" + "${name}" + ".json"
                def exists = fileExists filename
                if (exists){
                    echo "    => Found File ${filename} for server ${name}."
                    echo "    => Loading File ....."
                    RollBackBinaryActionStatus=readJSON(file: filename)
                    echo "    => Checking actions to rollback ....."
                    RollBack=RollBackBinaryActionStatus.findAll{it.status != ""}
                    if (RollBack.size()){
                        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
                        {
                            remote.host = ip
                            remote.name = name
                            remote.identityFile = keyfile
                            echo "    => Actions founds to rollback !!!!"
                            echo "    => ${RollBack}"
                            echo "    => ROLLBACK. Disabling package binaries <="
                            for (binInPackage in RollBackBinaryActionStatus.findAll{it.type == "package" && it.status == "Enabled"})
                            {
                                disable=" --command=\"deployment disable ${binInPackage.full_name}\""
                                command=connect + disable
                                sshCommand remote: remote, command:"${command}"
                                index=RollBackBinaryActionStatus.findIndexOf{it.type == "package" && it.full_name == binInPackage.full_name}
                                RollBackBinaryActionStatus[index].status = "Disabled"
                                echo "        =>${binInPackage.full_name} - Status: Disabled"
                            }
                            echo "    => ROLLBACK. Undeploying package binaries <="
                            for (binInPackage in RollBackBinaryActionStatus.findAll{it.type == "package" && it.status == "Disabled"})
                            {
                                undeploy=" --command=\"deployment undeploy ${binInPackage.full_name}\""
                                command=connect + undeploy
                                sshCommand remote: remote, command:"${command}"
                                index=RollBackBinaryActionStatus.findIndexOf{it.type == "package" && it.full_name == binInPackage.full_name}
                                RollBackBinaryActionStatus[index].status = "Undeploy"
                                if (binInPackage.SameVersionDeployed == true){
                                    index2=RollBackBinaryActionStatus.findIndexOf{it.type == "environment" && it.full_name == binInPackage.full_name}
                                    RollBackBinaryActionStatus[index2].status = "Undeploy"
                                }
                                echo "        =>${binInPackage.full_name} - Status: Undeploy"
                            }
                            echo "    => ROLLBACK. Restoring from backup if needed<="
                            echo "        => ROLLBACK. Cleaning tmp directory<="
                            sshCommand remote: remote, command:"rm -fr ${pipelineConfig.backupPath}/_tmp", failOnError:false
                            sshCommand remote: remote, command:"mkdir ${pipelineConfig.backupPath}/_tmp"
                            echo "        => ROLLBACK. Copy and untar the back file to tmp path<="
                            int i = backupPathBinary.lastIndexOf("/")
                            TarName = backupPathBinary.substring(i+1).trim()
                            sshCommand remote: remote, command:"cp ${backupPathBinary} ${pipelineConfig.backupPath}/_tmp/.; cd ${pipelineConfig.backupPath}/_tmp; tar xvf ${TarName}"

                            for (binInPackage in RollBackBinaryActionStatus.findAll{it.type == "environment" && it.isInPackage == true && it.status== "Undeploy"})
                            {
                                install=" --command=\"deployment deploy-file ${pipelineConfig.backupPath}/_tmp/${binInPackage.full_name} --disabled\""
                                echo "        => ROLLBACK. It's needed to restore from backup ${binInPackage.full_name}<="
                                command=connect + install
                                sshCommand remote: remote, command:"${command}"
                                echo "        =>${binInPackage.full_name} - Status: Disabled"
                                index=RollBackBinaryActionStatus.findIndexOf{it.type == "environment" && it.full_name == binInPackage.full_name}
                                RollBackBinaryActionStatus[index].status = "Disabled"
                            }
                            for (binInPackage in RollBackBinaryActionStatus.findAll{it.type == "environment" && it.isInPackage == true && it.status == "Disabled"})
                            {
                                enable=" --command=\"deployment enable ${binInPackage.full_name}\""
                                command=connect + enable
                                sshCommand remote: remote, command:"${command}"
                                echo "        =>${binInPackage.full_name} - Status: Enabled"
                                index=RollBackBinaryActionStatus.findIndexOf{it.type == "environment" && it.full_name == binInPackage.full_name}
                                RollBackBinaryActionStatus[index].status = "Enabled"
                            }
                            echo "        => ROLLBACK. Cleaning tmp directory<="
                            sshCommand remote: remote, command:"rm -fr ${pipelineConfig.backupPath}/_tmp", failOnError:false
                            if (isNeedActivateMicroServices == 'Y')
                            {
                                echo "    =======> Activating MicroServices <======="
                                activate_command="curl -s --location --request POST "
                                url_curl="\"http://${ip}:${MicroServicePort}/"
                                for (binInPackage in RollBackBinaryActionStatus.findAll{it.type == "environment"})
                                {
                                    bin = "${binInPackage.name}"
                                    command=activate_command + url_curl + bin +  URLMicroServiceStart + "\""
                                    //command=connect + url_curl + bin +  URLMicroServiceStart + "\""
                                    echo "        =>Command: ${command}"
                                    sshCommand remote: remote, command:"${command}" , failOnError:false
                                }
                            }
                        }
                    }
                    else
                    {
                        echo "    => There isn't actions to rollback in the file!!!!"
                    }
                } else {
                    echo "    => There isn't deploy status File ${filename} for server ${name}."
                    echo "    => There isn't rollback action for server ${name}!!!!"
                }
            }
        }
    }
}

def call(Map pipelineParams){
        pipeline{
            agent {label "SCHAMAN-Consolas"}
            parameters{
                string(name: 'DeployEnv', defaultValue: '', description: '')
                string(name: 'CommitID', defaultValue: '', description: '')
                string(name: 'Package_ID', defaultValue: '', description: '')
                string(name: 'Delivery', defaultValue: '', description: '')
                string(name: 'ProjectId', defaultValue: '', description: '')
                string(name: 'enterprise', defaultValue: 'BAU', description: '')
                string(name: 'PackageInfo', defaultValue: '', description: '')
            }
            stages{
                stage("PrepareAndMore"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            echo "!!!!!!!!START PREPARE&MORE PHASE!!!!!!!!"
                            echo "!!!!!!!!START PREPARE&MORE PHASE!!!!!!!!"
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            binaryActionStatus=[]

                            if (params.PackageInfo=="")
                            {
                                // executed manually or from ALMS
                                echo "    Manual or Jenkins GUI execution!!!"
                                deploy_env=params.DeployEnv
                                //commit_id=params.CommitID
                                pck_id=params.Package_ID
                                delivery=params.Delivery
                                project_id=params.ProjectId
                                enterprise=params.enterprise
                            }else{
                                echo "    Workbench execution!!!"
                                echo "PackageInfo: ${params.PackageInfo}"
                                //(deploy_env,commit_id,pck_id,delivery,project_id,enterprise,annexes)= parsePckInfo_WithAnnexes(PackageInfo)
                                (deploy_env,pck_id,delivery,project_id,enterprise,annexes,modules)= parsePckInfo_WithAnnexes_WithoutGit(PackageInfo)
                            }
                            hoy=new Date().format('yyyyMMdd')
                            pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                            deployConfig=readJSON(file: pipelineConfig.deployConfig)
                            commit_id=""
                            workbenchPackage= new VFESALMSDeployment(pck_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,enterprise)
                            currentBuild.displayName = workbenchPackage.jobDisplayName
                            currentBuild.description = workbenchPackage.jobDescription
                            isNeedActivateMicroServices=pipelineConfig.isNeedActivateMicroServices
                            URLMicroServiceStart=pipelineConfig.URLMicroServiceStart
                            URLMicroServiceStop=pipelineConfig.URLMicroServiceStop
                            MicroServicePort=pipelineConfig.MicroServicePort

                            // TODO : when


                            echo "Deploy Info:"
                            echo "    DeployEnv:        ${deploy_env}"
                            echo "    PackageID:        ${pck_id}"
                            echo "    Delivery:         ${delivery}"
                            echo "    Project:          ${project_id}"
                            echo "    Enterprise:       ${enterprise}"


                            echo "Cleaning ${pipelineConfig.extractFolder} directory"
                            sh (script:"rm -fr ${pipelineConfig.extractFolder}", returnStatus:false)
                            sh (script:"mkdir ${pipelineConfig.extractFolder}", returnStatus:true)


                            isThereBinaries=0

                            echo "====> Check Annexes Info"
                            echo "======> Check Annexes Host Name/IP"
                            annexesHostIP = pipelineConfig.annexesServer
                            if (annexesHostIP == null || annexesHostIP == "")
                            {
                                echo "        ERROR. Annexes Host IP not configure at ${pipelineParams.pipelineConfigFile} File"
                                sh "exit 1"
                            }
                            echo "        Annexes Host Name/IP: ${annexesHostIP}"

                            echo "======> Check Annexes User Name"
                            annexesUserName = pipelineConfig.annexesUser
                            if (annexesUserName == null || annexesUserName == "")
                            {
                                echo "        ERROR. Annexes User Name not configure at ${pipelineParams.pipelineConfigFile} File"
                                sh "exit 1"
                            }
                            echo "        Annexes UserName: ${annexesUserName}"

                            echo "======> Check Annexes Base Path"
                            annexesBasePath = pipelineConfig.annexesBasePath
                            if (annexesBasePath == null || annexesBasePath == "")
                            {
                                echo "        ERROR. Annexes Base Path not configure at ${pipelineParams.pipelineConfigFile} File"
                                sh "exit 1"
                            }

                            annexesCompletePath="${annexesBasePath}" + '/' + "${hoy}" + '/' + "${pck_id}" + '/' + "${deploy_env}" + '/' + 'Annexes/'
                            echo "        Annexes Base Path: ${annexesBasePath}"
                            echo "        Annexes Complete Path: ${annexesCompletePath}"

                            echo "====> Check Annexes Data"
                            echo "======> Check Annexes Number"
                            numAnnexes=annexes.size()
                            if (numAnnexes > 1){
                                echo "        Num Annexes: ${numAnnexes}"
                                echo "        Num Annexes must to be <= 1"
                                sh "exit 1"
                            }
                            echo "        Num Annexes: ${numAnnexes}"
                            if (numAnnexes == 1){
                                echo "======> Check Annexes Files Existence"
                                AnnexesNameWithPath="${annexesCompletePath}" + "${annexes.Annexe.FileName}"
                                AnnexesNameWithPath = AnnexesNameWithPath.replace('[','').replace(']','')
                                exist = sh(script:"ssh ${annexesUserName}@${annexesHostIP} \"ls -1 ${AnnexesNameWithPath}\"",  returnStatus: true)
                                if (exist!=0){
                                    echo "        ERROR. ${AnnexesNameWithPath} not found at server " + "${annexesHostIP}"
                                    sh "exit 1"
                                }
                                echo "        ${AnnexesNameWithPath}: OK!"
                            }


                            echo "====> Load Annexes In-Memory HashMap List for start/stop actions"
                            binariesToDeploy = sh(script:"ssh ${annexesUserName}@${annexesHostIP} \"cat ${AnnexesNameWithPath}\"",  returnStatus: false, returnStdout: true)
                            binariesToDeploy = binariesToDeploy.trim()

                            echo "====> Get Binaries and check format"
                            for (bin in binariesToDeploy.split(System.getProperty("line.separator")))
                            {
                                isThereBinaries=1
                                bin=bin.trim()
                                compose="${pipelineConfig.nexusRepo}" + "/" + "${bin}"
                                echo "======>Trying to Download: ${bin}"
                                sh "cd ${pipelineConfig.extractFolder}; wget -nv --progress=dot --no-check-certificate ${compose}"
                                (AppName_toDeploy,Version_toDeploy,FreeText_toDeploy,Extension_toDeploy) = returnSplitName(bin)
                                if (AppName_toDeploy == null || Version_toDeploy == null || Extension_toDeploy == null)
                                {
                                    echo "Binary File Name $bin Malformed"
                                    echo "Must to be:"
                                    echo '{context_path}_{version}[_modificadores-libres (cliente, funcionalidad, fecha, hash...)].{extension}'
                                    sh "exit 1"
                                }

                                echo "AppName: ${AppName_toDeploy}"
                                echo "Version: ${Version_toDeploy}"
                                echo "Free Text: ${FreeText_toDeploy}"
                                echo "Extension: ${Extension_toDeploy}"
                                _binaryActionStatus = [full_name: "${bin}", type: "package", name: "${AppName_toDeploy}", version: "${Version_toDeploy}", FreeText: "${FreeText_toDeploy}", extension: "${Extension_toDeploy}", status:"", isInPackage:false, SameVersionDeployed:false]
                                binaryActionStatus+=_binaryActionStatus
                            }

                            if (isThereBinaries == 0)
                            {
                                echo "ERROR. Nothing to do. No changes detected in the commit"
                                sh "exit 1"
                            }
                            echo "Binaries: ${binaryActionStatus}"


                            if (isThereBinaries == 1)
                            {
                                //Check Already Deployed Binary (search in the release path)
                                def remote = [:]
                                remote.user = pipelineConfig.releaseUser
                                remote.allowAnyHosts = true
                                remote.retryCount = 3
                                server=deployConfig[deploy_env]['servers'].first()
                                String name=server['name']
                                String ip=server['ip']
                                echo "Check binaries deployed at ${name}-${ip}"
                                def String [] _binaryNowDeployed
                                withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
                                    remote.host = ip
                                    remote.name = name
                                    remote.identityFile = keyfile
                                    composebinaries = sshCommand remote: remote, command:"ls ${pipelineConfig.releasePath} | tr '\n' '#'"
                                    _binaryNowDeployed = composebinaries.split("#");
                                }

                                //Load the list of Maps of the binaries already deployed in the environment
                                for ( String NowDeploy_bin : _binaryNowDeployed ){
                                    bin=NowDeploy_bin.trim()
                                    echo "      => ${bin}"

                                    (AppName_NowDeploy,Version_NowDeploy,FreeText_NowDeploy,Extension_NowDeploy) = returnSplitName(bin)
                                    if (AppName_toDeploy == null || Version_toDeploy == null || Extension_toDeploy == null)
                                    {

                                        echo "Binary File Name $bin Malformed"
                                        echo "Must to be:"
                                        echo '{context_path}_{version}[_modificadores-libres (cliente, funcionalidad, fecha, hash...)].{extension}'
                                        sh "exit 1"
                                    }
                                    echo "AppName: ${AppName_NowDeploy}"
                                    echo "Version: ${Version_NowDeploy}"
                                    echo "Free Text: ${FreeText_NowDeploy}"
                                    echo "Extension: ${Extension_NowDeploy}"

                                    _binaryActionStatus = [full_name: "${NowDeploy_bin}", type: "environment", name: "${AppName_NowDeploy}", version: "${Version_NowDeploy}", FreeText: "${FreeText_NowDeploy}", extension: "${Extension_NowDeploy}", status:"", isInPackage:false, SameVersionDeployed:false]
                                    binaryActionStatus+=_binaryActionStatus
                                }

                                for (binInPackage in binaryActionStatus.findAll{it.type == "package"})
                                {
                                    //deployed in the environment with the same version?
                                    index=binaryActionStatus.findIndexOf{it.type == "environment" && it.full_name == binInPackage.full_name}
                                    if (index != -1) {
                                        binaryActionStatus[index].isInPackage = true
                                        binaryActionStatus[index].SameVersionDeployed = true
                                        index2=binaryActionStatus.findIndexOf{it.type == "package" && it.name == binInPackage.name && it.extension == binInPackage.extension}
                                        if (index2 != -1) {
                                            binaryActionStatus[index2].isInPackage = true
                                            binaryActionStatus[index2].SameVersionDeployed = true
                                        }
                                    } else {
                                        //Deployed distint version in the environment?
                                        index=binaryActionStatus.findIndexOf{it.type == "environment" && it.name == binInPackage.name && it.extension == binInPackage.extension}
                                        if (index != -1) {
                                            binaryActionStatus[index].isInPackage = true
                                            binaryActionStatus[index].SameVersionDeployed = false
                                        }
                                    }
                                }
                                echo "CleanDeploymentStatus"
                                for( server in deployConfig[deploy_env]['servers']) {
                                    String name2=server['name']
                                    _deployStatusFileName="deploy_status_" + "${name2}" + ".json"
                                    sh (script:"rm -f ${_deployStatusFileName}", returnStatus:false)
                                }
                            }
                        echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                        echo "!!!!!!!!END PREPARE&MORE PHASE!!!!!!!!"
                        echo "!!!!!!!!END PREPARE&MORE PHASE!!!!!!!!"
                        echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                        }
                    }
                }

                stage('ReleaseBackup'){
                    //when{expression { return deploy_env ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/ }}
                    agent{label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            echo "!!!!!!!!START RELEASE BACKUP PHASE!!!!!!!!"
                            echo "!!!!!!!!START RELEASE BACKUP PHASE!!!!!!!!"
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            BinaryBackup ()
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            echo "!!!!!!!!END RELEASE BACKUP PHASE!!!!!!!!"
                            echo "!!!!!!!!END RELEASE BACKUP PHASE!!!!!!!!"
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                        }
                    }
                }
                stage('Deploy') {
                    //when{expression { return deploy_env ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/ }}
                    agent{label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try
                            {
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                                echo "!!!!!!!!START DEPLOY PHASE!!!!!!!!"
                                echo "!!!!!!!!START DEPLOY PHASE!!!!!!!!"
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                                isNeededBinariesRollBack=0
                                deployBinaries()
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                                echo "!!!!!!!!END DEPLOY PHASE!!!!!!!!"
                                echo "!!!!!!!!END DEPLOY PHASE!!!!!!!!"
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            }
                            catch (err)
                            {
                                echo "#########################################"
                                echo "########ERROR IN THE DEPLOY PHASE########"
                                echo "########ERROR IN THE DEPLOY PHASE########"
                                echo "#########################################"

                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                                echo "!!!!!!!!STARTING THE ROLLBACK!!!!!!!!"
                                echo "!!!!!!!!STARTING THE ROLLBACK!!!!!!!!"
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                                echo "Error Details: ${err}"
                                rollbackBinaries()
                                currentBuild.result = Result.FAILURE
                                error('!!!!!!!!AUTOMATED ROLLBACK ENDED SUCCESSFULLY!!!!!!!!')
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                                echo "!!!!!!!!END THE ROLLBACK!!!!!!!!"
                                echo "!!!!!!!!END THE ROLLBACK!!!!!!!!"
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            }
                        }
                    }
                }

                stage('Update release') {
                    //when{expression { return deploy_env ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/ }}
                    agent {label "SCHAMAN-Consolas"}
                    steps {
                        script{
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            echo "!!!!!!!!START UPDATE RELEASE PHASE!!!!!!!!"
                            echo "!!!!!!!!START UPDATE RELEASE PHASE!!!!!!!!"
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            UpdateRelease()
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            echo "!!!!!!!!END UPDATE RELEASE PHASE!!!!!!!!"
                            echo "!!!!!!!!END UPDATE RELEASE PHASE!!!!!!!!"
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                        }
                    }
                }

                stage('Clean Environment') {
                    agent {label "SCHAMAN-Consolas"}
                    steps {
                        script{
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            echo "!!!!!!!!START CLEAN ENVIRONMENT PHASE!!!!!!!!"
                            echo "!!!!!!!!START CLEAN ENVIRONMENT PHASE!!!!!!!!"
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            CleanEnvironment()
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                            echo "!!!!!!!!END CLEAN ENVIRONMENT PHASE!!!!!!!!"
                            echo "!!!!!!!!END CLEAN ENVIRONMENT PHASE!!!!!!!!"
                            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                        }
                    }
                }
            }
        }
    }
