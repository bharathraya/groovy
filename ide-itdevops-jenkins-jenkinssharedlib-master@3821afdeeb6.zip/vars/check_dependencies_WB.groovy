def call(String _packageName,String _PackagesList,String _remoteServer){
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    checkDependencies_WB.sh -p ${_packageName} ${_PackagesList}
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
