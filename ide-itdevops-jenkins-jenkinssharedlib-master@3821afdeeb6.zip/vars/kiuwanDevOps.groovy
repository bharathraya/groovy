import groovy.json.JsonSlurper
import groovy.json.JsonSlurperClassic

def getCoverageFromJavaXML(it_path){
	echo "getCoverageFromJavaXML -- reading file ${it_path} "
    def xmlFile = readFile "${it_path}"
    def xmlParser = new XmlParser()
    xmlParser.setFeature("http://apache.org/xml/features/disallow-doctype-decl",false)
    xmlParser.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
    jacocoXML = xmlParser.parseText(xmlFile)
    def counters = jacocoXML.counter
    def count_lines = counters.find{it.attributes()['type'].equals('LINE')}
    def missed =  count_lines.attributes()['missed'].toInteger()
    def covered = count_lines.attributes()['covered'].toInteger()
    return [missed,covered]
}

def roundCoverage() {
    echo "Branch coverage: ${env.PCT_COVERAGE}"
    double db_coverageBranch = Double.parseDouble(env.PCT_COVERAGE).round(0)
    coverageBranch = db_coverageBranch.toInteger()
    env.PCT_COVERAGE = coverageBranch
    echo "Branch rounded coverage: $PCT_COVERAGE %"
}

def blockWhenNoCoverage() {
    if(env.PCT_COVERAGE == "0"){
        echo "[COVERAGE] This application does not have unit tests. The minimum requirement is 1% coverage"
        env.no_tests = true
        env.CODE_ERROR="-11"
        error("[COVERAGE] This application does not have unit tests. The minimum requirement is 1% coverage")
    }
}

def Coverage(report_workspace="${WORKSPACE}") {
    try{
        echo "---------------------------------------Into kiuwan.coverage function---------------------------------------"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'syncReposBitBucket', usernameVariable: 'USERNAME',
                        passwordVariable: 'PASSWORD']]) {
            script{

                if (fileExists('idg-didi-kiuwan-utils')) {
					sh "rm -rf idg-didi-kiuwan-utils"
                }
				sh 'git clone https://$USERNAME:$PASSWORD@webpre-adm.es.sedc.internal.vodafone.com:42520/bitbucket/scm/idg-didi/idg-didi-kiuwan-utils.git -b master'
                sh 'pip install -r idg-didi-kiuwan-utils/requirements.txt'
                defaultJacocoPath = "${report_workspace}/target/site/${env.DIR_JACOCO}/jacoco.xml"

                def rootJacocoFiles = getRootJacocoReport("${report_workspace}")

                def jacocoFiles = resolveJacocoFiles("${report_workspace}")

                rootJacocoFile = null
                if (rootJacocoFiles.size() >= 1){

                    rootJacocoFile = rootJacocoFiles[0]
                }

                if (rootJacocoFile == null){ // if not extis rootJacocoFile
                    echo "[COVERAGE] Not found Jacoco XML report file root directory. By default, you must generate it in the $defaultJacocoPath"
                    if(jacocoFiles.size() >= 1) {//is multimodule project
                        def total_missed = 0
                        def total_covered = 0
                        jacocoFiles.each { 
                            if (!it.startsWith("target/")){
								def int missed=100
								def int covered=0
								dir (report_workspace){
									echo "Reading CoverageFromJavaXML ${it}"
									archiveArtifacts artifacts: "${it}"
                                	(missed,covered) = getCoverageFromJavaXML(it)
								}
                                total_missed = total_missed + missed
                                total_covered = total_covered + covered
                                echo "For module $it: missed-lines = $missed and covered-lines = $covered"
                            }else{
                                echo "[COVERAGE] Warning - An aggregate-report has been detected that does not comply with the nomenclature and routing. Must be allocate in target/site/${env.DIR_JACOCO}/jacoco.xml "
                            }
                        }
                        echo "[COVERAGE] Multi-module project without aggregate-report. Sum each jacoco.xml report module: total-missed-lines = $total_missed and total-covered-lines = $total_covered"
                        env.PCT_COVERAGE = (total_covered*100/(total_missed+total_covered))
                    }
                    else (jacocoFiles.size() == 0) {
                        env.no_tests = true
                        env.CODE_ERROR="-11"
                        error("[COVERAGE] This application does not have unit tests")      
                    }     

                }else{ //multimodule projects with aggregate report or simple java projects
                
                    if(jacocoFiles.size() > 1 && rootJacocoFile!= null) {//is multimodule project
                        echo "[COVERAGE] Multi-module project with Jacoco aggregate-report. Get coverage from root path: $rootJacocoFile"
                    }else{
                        echo "[COVERAGE] Default project with Jacoco report. Get coverage from root path: $rootJacocoFile"
                    }
					dir(report_workspace){
						echo "Reading CoverageFromJavaXML (multimodule) ${rootJacocoFile}"
						archiveArtifacts artifacts: "${rootJacocoFile}"
                    	def (int missed, int covered) = getCoverageFromJavaXML(rootJacocoFile)
						env.PCT_COVERAGE = (covered*100/(missed+covered))
					}
                    
                    
                }

                roundCoverage()

                blockWhenNoCoverage()
				//sh "ls -lrt"
				//sh "ls -lrt idg-didi-kiuwan-utils"
                def lines = sh(script: "python3 -u idg-didi-kiuwan-utils/generate_reports_delivery_java.py --workspace=${report_workspace}/ --branch=${GIT_BRANCH} --coverage=$env.PCT_COVERAGE",
                            returnStdout: true).split("\r?\n")
                lines.each { echo "$it"}

                jacocoFiles = jacocoFiles?.join(' ')
                echo "[COVERAGE] JacocoFiles $jacocoFiles"
                sh "find ${report_workspace}/reports -print"
            }
        }
        echo "---------------------------------------End kiuwan.coverage function---------------------------------------"
    }catch(Exception e){
        env.CODE_ERROR="-11"
        error("Error in GenerateKiuwanReports -> Coverage() | $e")
    }
}

// Get coverage result from file in cobertura
def getCoberturaResult(Map functionParams = [:]){
 
    if (!fileExists("coverage/clover.xml")){
         try {
            // def buildArgs = functionParams?.EXTRA_ARGS_BUILD? " ${functionParams.EXTRA_ARGS_BUILD}":""

            coberturaPath = functionParams?.coberturaFile? "${functionParams.coberturaFile}" : "coverage/cobertura-coverage.xml"
            
            def xmlFile = readFile "${coberturaPath}"
            def xmlParser = new XmlParser()
            xmlParser.setFeature("http://apache.org/xml/features/disallow-doctype-decl",false)
            xmlParser.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            coberturaXml = xmlParser.parseText(xmlFile)
            env.PCT_COVERAGE = ( coberturaXml.attributes()['lines-covered'].toInteger() * 100 ) / coberturaXml.attributes()['lines-valid'].toInteger() 
        } catch (Exception ex) {
            echo "SOMETHING WENT WRONG"
            echo ex.toString()
            env.PCT_COVERAGE = 0
            env.CODE_ERROR="-12"
        }
    }else{
        echo "Exist, clover coverage result from Stencil-Jest"
        try {

            coberturaPath = functionParams?.coberturaFile? "${functionParams.coberturaFile}" : "coverage/clover.xml"

            def xmlFile = readFile "${coberturaPath}"
            def xmlParser = new XmlParser()
            xmlParser.setFeature("http://apache.org/xml/features/disallow-doctype-decl",false)
            xmlParser.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            coberturaXml = xmlParser.parseText(xmlFile)
            env.PCT_COVERAGE = ( coberturaXml.project.metrics[0].@coveredstatements.toInteger() * 100 ) / coberturaXml.project.metrics[0].@statements.toInteger()
        } catch (Exception ex) {
            echo "SOMETHING WENT WRONG"
            echo ex.toString()
            env.PCT_COVERAGE = 0
            env.CODE_ERROR="-12"
        }
       
    }

    roundCoverage()
}

def getRootJacocoReport(Directory){
    echo "---------------------------------------Into kiuwan.getRootJacocoReport function---------------------------------------"
    def returnFiles = []
    dir("${Directory}"){
        def rootFiles = findFiles glob:"target/**/*jacoco*.xml"?:['']
        echo "Jacoco Report found in root : ${rootFiles.collect { it.path }}"
        returnFiles = rootFiles.collect { it.path }
    }
    echo "---------------------------------------End kiuwan.getRootJacocoReport function---------------------------------------"
    return returnFiles
}

def resolveJacocoFiles(Directory) {
    echo "---------------------------------------Into kiuwan.resolveJacocoFiles function---------------------------------------"
    def returnXmlFiles = []
    dir("${Directory}"){
        def xmlFiles = findFiles glob:"**/*jacoco*.xml"?:['']
        echo "XML FILES : ${xmlFiles.collect { it.path }}"
        returnXmlFiles = xmlFiles.collect { it.path }
    }
    echo "---------------------------------------End kiuwan.resolveJacocoFiles function---------------------------------------"
    return returnXmlFiles

}

def CoverageAngular(report_workspace="${WORKSPACE}") {
    try{
        echo "---------------------------------------Into kiuwan.coverageAngular function---------------------------------------"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'syncReposBitBucket', usernameVariable: 'USERNAME',
                          passwordVariable: 'PASSWORD']]) {
          script {

              blockWhenNoCoverage()

             if (!fileExists('idg-didi-kiuwan-utils')) {
                    sh 'git clone https://$USERNAME:$PASSWORD@webpre-adm.es.sedc.internal.vodafone.com:42520/bitbucket/scm/idg-didi/idg-didi-kiuwan-utils.git -b master'
                }
                sh 'pip install -r idg-didi-kiuwan-utils/requirements.txt'
                    
            	def lines = sh(script: "python3 -u idg-didi-kiuwan-utils/generate_reports_delivery_angular.py --workspace=${report_workspace}/ --branch=${GIT_BRANCH} --coverage=$env.PCT_COVERAGE",
                        returnStdout: true).split("\r?\n")
                lines.each { echo "$it"}

          }
        }
    }catch(Exception e){
        env.CODE_ERROR="-11"
        error("Error in GenerateKiuwanReports -> CoverageAngular()")
    }
}

def CoveragePython(report_workspace="${WORKSPACE}") {
    try{
        echo "---------------------------------------Into kiuwan.coverageAngular function---------------------------------------"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'syncReposBitBucket', usernameVariable: 'USERNAME',
                          passwordVariable: 'PASSWORD']]) {
          script {

              blockWhenNoCoverage()
              
             if (!fileExists('idg-didi-kiuwan-utils')) {
                    sh 'git clone https://$USERNAME:$PASSWORD@webpre-adm.es.sedc.internal.vodafone.com:42520/bitbucket/scm/idg-didi/idg-didi-kiuwan-utils.git -b master'
                }
                sh 'pip install -r idg-didi-kiuwan-utils/requirements.txt'

            	def lines = sh(script: "python3 -u idg-didi-kiuwan-utils/generate_reports_delivery_python.py --workspace=${report_workspace}/ --branch=${GIT_BRANCH} --coverage=$env.PCT_COVERAGE",
                        returnStdout: true).split("\r?\n")
                lines.each { echo "$it"}

          }
        }
    }
    catch(Exception e){
        env.CODE_ERROR="-11"
        error("Error in GenerateKiuwanReports -> CoveragePython()")
    }
}

def chekOnlyKiuwanAnalysis(env) {
    echo "---------------------------------------Into kiuwan.chekOnlyKiuwanAnalysis function---------------------------------------"
    def check = env?.ONLY_KIUWAN_ANALYSIS?.toLowerCase() == 'true'
    if(check) echo "Exclude Step. Configured only Kiuwan analysis"
    echo "---------------------------------------End kiuwan.chekOnlyKiuwanAnalysis function---------------------------------------"
    return check
}

def checkBaselineExists(kiuwanCredentials, kiuwanAppName) {
    def analyses = []
    withCredentials([usernamePassword(credentialsId: kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
        def ANALYSES_API = sh(returnStdout: true, script: "curl --insecure --user $KUSERNAME:$KPASSWORD https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/applications/analyses?application=${kiuwanAppName}").trim()
        analyses = new JsonSlurperClassic().parseText(ANALYSES_API)
        def analyses_result = "$analyses"
        echo "DEBUG: $analyses_result"
        if (analyses_result.contains("Baseline")){
            env.baselineExists = true
            echo "Exists baseline: ${env.baselineExists}"
        } else {
            env.baselineExists = false
            echo "Exists baseline: ${env.baselineExists}"
            env.COVERAGE_BL=null
        }
    }
}

def getQualityMetrics(kiuwanCredentials, kiuwanAppName) {
    getBaselineCode(kiuwanCredentials, kiuwanAppName)
    getCoverageBaseline(kiuwanCredentials, kiuwanAppName)
    setAuditName()
    setGroupsQG()
    if(env.baselineExists){
        checkTargetCoverageQG()
        checkTargetDefects()
    }else{
        env.TARGET_COVERAGE = null
        env.TARGET_DEFECTS = null
    }
        

}


def getBaselineCode(kiuwanCredentials, kiuwanAppName){
    withCredentials([usernamePassword(credentialsId: kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
        def BASELINES_API = sh(returnStdout: true, script: "curl --insecure --user $KUSERNAME:$KPASSWORD https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/applications/analyses?application=${kiuwanAppName}").trim()
        BASELINES = new JsonSlurperClassic().parseText(BASELINES_API)
        def baselines_result = "$BASELINES"
        if (baselines_result.contains("Baseline")){
            echo "BASELINE TRUE"
            env.baselineExists=true
            env.BASELINE_CODE=BASELINES[0].code
            veryhigh_defects=BASELINES[0].metrics["com.optimyth.CQM.defectsByPriority.Priority 1"].toInteger()
            high_defects=BASELINES[0].metrics["com.optimyth.CQM.defectsByPriority.Priority 2"].toInteger()
            env.VERYHIGH_DEFECTS_BASELINE=veryhigh_defects
            env.HIGH_DEFECTS_BASELINE=high_defects
            env.TOTAL_VERYHIGH_HIGH_DEFECTS_BASELINE= veryhigh_defects + high_defects
            echo "BASELINE VERYHIGH DEFECTS:${env.VERYHIGH_DEFECTS_BASELINE}"
            echo "BASELINE HIGH DEFECTS:${env.HIGH_DEFECTS_BASELINE}"
            echo "BASELINE TOTAL HIGH & VERYHIGH DEFECTS:${env.TOTAL_VERYHIGH_HIGH_DEFECTS_BASELINE}"
        }
        else{
            echo "NO BASELINES DETECTED"
            env.BASELINE_CODE = null
            env.COVERAGE_BL = null
        }
    }
}


def getCoverageBaseline(kiuwanCredentials, kiuwanAppName){
    if(env.baselineExists){
        withCredentials([usernamePassword(credentialsId: kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
            technologies_list_js = ["ANGULAR","JAVASCRIPT","NODE","NODEJS","REACT","LIBDSL","REACTNATIVE"]
            technologies_list_python = ["PYTHON", "DJANGO", "IAC"]
            technologies_list_java = ["JAVA-", "ANDROID"]
            if(technologies_list_java.findAll{env.JOB_NAME.contains(it)}){
                ruleCode="ES.CORP.VODAFONE.JAVA.PCT_COVERAGE"
                echo "${ruleCode}"
            }
            else if(technologies_list_js.findAll{env.JOB_NAME.contains(it)}){
                ruleCode="ES.CORP.VODAFONE.ANGULAR.PCT_COVERAGE"
                echo "${ruleCode}"
            }
            else if(technologies_list_python.findAll{env.JOB_NAME.contains(it)}){
                ruleCode="ES.CORP.VODAFONE.PYTHON.PCT_COVERAGE" 
                echo "${ruleCode}"
            }
            def LAST_BASELINE_DATA = sh(returnStdout: true, script: "curl --insecure --user $KUSERNAME:$KPASSWORD 'https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/violatedrules/files?analysisCode=${env.BASELINE_CODE}&application=${kiuwanAppName}&ruleCode=${ruleCode}'").trim()
            if(LAST_BASELINE_DATA.contains("errors") || LAST_BASELINE_DATA=="[]"){
                env.COVERAGE_BL=0
            }
            else{
                defects_coverage = new JsonSlurperClassic().parseText(LAST_BASELINE_DATA)
                defectsCovered=defects_coverage[0].defectsCount
                env.COVERAGE_BL=(int)(100-defectsCovered)
            }
        }
    }
}

def getAnalysisDefects(kiuwanCredentials) {
    withCredentials([usernamePassword(credentialsId: kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
        def ANALYSIS_API = sh(returnStdout: true, script: "curl --insecure --user $KUSERNAME:$KPASSWORD https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/metrics?code=${env.ANALYSIS_CODE}").trim()
        ANALYSIS = new JsonSlurperClassic().parseText(ANALYSIS_API)
        def analysis_result = "$ANALYSIS"
        veryhigh_defects_analysis=ANALYSIS["com.optimyth.CQM.defectsByPriority.Priority 1"].toInteger()
        high_defects_analysis=ANALYSIS["com.optimyth.CQM.defectsByPriority.Priority 2"].toInteger()
        env.VERYHIGH_DEFECTS_ANALYSIS=veryhigh_defects_analysis
        env.HIGH_DEFECTS_ANALYSIS=high_defects_analysis
        env.TOTAL_VERYHIGH_HIGH_DEFECTS_ANALYSIS= veryhigh_defects_analysis + high_defects_analysis
        echo "${env.TOTAL_VERYHIGH_HIGH_DEFECTS_ANALYSIS}"
    }
}

def setAuditName() {
    if (env.baselineExists == "true") {
        coverageBaseline = env.COVERAGE_BL.toInteger()
        if (env.NEW_REPO != "true") {
            if (coverageBaseline < 15)
                env.KIUWAN_AUDIT = '.kiuwan.analysis.audit="VFES - Digital Audit_Sensibilidad_0"'
            else if (coverageBaseline >= 15 & coverageBaseline < 75)
                env.KIUWAN_AUDIT = '.kiuwan.analysis.audit="VFES - Digital Audit_Sensibilidad_1"' 
            else if (coverageBaseline >= 75) 
                env.KIUWAN_AUDIT = '.kiuwan.analysis.audit="VFES - Digital Audit_Sensibilidad_2"'   
        } else if (env.NEW_REPO == "true") {
            if (coverageBaseline < 75)
                env.KIUWAN_AUDIT = '.kiuwan.analysis.audit="VFES - Digital Audit_Sensibilidad_0_NewRepos"'
            else if (coverageBaseline >= 75)
                env.KIUWAN_AUDIT = '.kiuwan.analysis.audit="VFES - Digital Audit_Sensibilidad_2_NewRepos"'
        }
    } else if (env.baselineExists != "true") {
        env.KIUWAN_AUDIT = '.kiuwan.analysis.audit="VFES - Digital Audit_Sensibilidad_0_NewRepos"'
    }    
    echo "${env.KIUWAN_AUDIT}"
}

def setGroupsQG() {
    def group1 =  ["IDG-CSEOF", "IDG-CMS", "IDG-ITDPWEB", "IDG-NTOL", "IDG-WEBBAJAS", "IDG-DIDI" ,"IDG-DXL"]
    def group2 =  ["IDG-MOBILE", "IDG-ANALYTICS", "IDG-CGNFB", "IDG-EDC", "IDG-ODCO"]
    if (group1.contains(env.bitbucketKey)) {
        env.NEW_QG = "informative"
    //} else if (group2.contains(env.bitbucketKey)) { 
    } else {
        env.NEW_QG = "false"
    }
    echo "New quality gates: ${env.NEW_QG}"
}

def checkQualityGates() {
    if (env.branch != "master") {
        if (env.baselineExists == "true" & env.NEW_QG == "informative") { 
            if (env.SKIP_TEST != "true") {    
                blockCoverageQG()
                blockTargetDefects()
            } else {
                echo("[Check Quality Gates] The coverage quality gate is not checked because the tests are skipped") 
                blockTargetDefects()
            }
        }  else 
            echo "The new quality gates are not checked"
    } else 
        echo "The new quality gates are not checked in the master branch"
}
def checkTargetCoverageQG() {
    coverageBaseline = env.COVERAGE_BL.toInteger()
    if (coverageBaseline < 15) {
        env.TARGET_COVERAGE = coverageBaseline + 1
    } else if (coverageBaseline >= 75) {
        env.TARGET_COVERAGE = coverageBaseline
    } else if (coverageBaseline >= 15 & coverageBaseline < 75) {
        env.TARGET_COVERAGE = coverageBaseline + 1
    }
}

def blockCoverageQG() {
    double db_coverageBranch = Double.parseDouble(env.PCT_COVERAGE).round(0)
    double db_coverageTarget = Double.parseDouble(env.TARGET_COVERAGE).round(0)
    coverageBranch = db_coverageBranch.toInteger()
    coverageTarget = db_coverageTarget.toInteger()
    env.PCT_COVERAGE = coverageBranch
    env.TARGET_COVERAGE = coverageTarget
    coverageBaseline = env.COVERAGE_BL.toInteger()
    echo "[Check Quality Gates] CURRENT COVERAGE: ${env.PCT_COVERAGE}%"
    echo "[Check Quality Gates] TARGET COVERAGE: ${env.TARGET_COVERAGE}%"

    switch (env.NEW_QG) {
        case "informative":
            if (coverageBaseline < 15 && db_coverageBranch < db_coverageTarget) {
                env.CODE_ERROR="30"
                echo("[Check Quality Gates] Current coverage is less than target coverage")
            } else if ((coverageBaseline >= 15 & coverageBaseline < 75) && (db_coverageBranch < db_coverageTarget)) {
                env.CODE_ERROR="30"
                echo("[Check Quality Gates] Current coverage is less than target coverage")
            } else if (coverageBaseline >= 75) {
                echo "[Check Quality Gates] Congratulations, your current branch has more than 75% unit test coverage."
            }else{
                echo "[Check Quality Gates] Congratulations, your current branch has more coverage than the target coverage."
            }
            break
        case "block1":
            if (coverageBaseline < 15 && db_coverageBranch < db_coverageTarget) {
                env.CODE_ERROR="30"
                if (env.branch?.toLowerCase().contains("feature"))
                    unstable ("[Check Quality Gates] Current coverage is less than target coverage")
                else
                    error("[Check Quality Gates] Current coverage is less than target coverage")
            } else if ((coverageBaseline >= 15 & coverageBaseline < 75) && (db_coverageBranch < db_coverageTarget)) {
                env.CODE_ERROR="30"
                echo("[Check Quality Gates] Current coverage is less than target coverage")
            } else if (coverageBaseline >= 75) {
                echo "[Check Quality Gates] Congratulations, your current branch has more than 75% unit test coverage."
            }else{
                echo "[Check Quality Gates] Congratulations, your current branch has more coverage than the target coverage."
            }
            break
        case "block2":
            if (coverageBaseline < 15 && db_coverageBranch < db_coverageTarget) {
                env.CODE_ERROR="30"
                if (env.branch?.toLowerCase().contains("feature"))
                    unstable ("[Check Quality Gates] Current coverage is less than target coverage")
                else
                    error("[Check Quality Gates] Current coverage is less than target coverage")
            } else if ((coverageBaseline >= 15 & coverageBaseline < 75) && (db_coverageBranch < db_coverageTarget)) {
                env.CODE_ERROR="30"
                 if (env.branch?.toLowerCase().contains("feature"))
                    unstable ("[Check Quality Gates] Current coverage is less than target coverage")
                else
                    error("[Check Quality Gates] Current coverage is less than target coverage")
            } else if (coverageBaseline >= 75) {
                echo "[Check Quality Gates] Congratulations, your current branch has more than 75% unit test coverage."
            }else{
                echo "[Check Quality Gates] Congratulations, your current branch has more coverage than the target coverage."
            }
            break
    }
}

def checkTargetDefects() {
    if (env.baselineExists == "true") { 
        defectsBaseline = env.TOTAL_VERYHIGH_HIGH_DEFECTS_BASELINE.toInteger()
        if (env.TOTAL_VERYHIGH_HIGH_DEFECTS_BASELINE == "0") 
            env.TARGET_DEFECTS = 0
        else 
            env.TARGET_DEFECTS = defectsBaseline - 1
    }
}

def blockTargetDefects() {
    echo "[Check Quality Gates] TARGET HIGH AND VERY HIGH DEFECTS: ${env.TARGET_DEFECTS}"
    if (env.TOTAL_VERYHIGH_HIGH_DEFECTS_ANALYSIS != null)
        echo "[Check Quality Gates] CURRENT HIGH AND VERY HIGH DEFECTS ${env.TOTAL_VERYHIGH_HIGH_DEFECTS_ANALYSIS}"
    else
        echo "[Check Quality Gates] CURRENT HIGH AND VERY HIGH DEFECTS [NODATA]"
    switch (env.NEW_QG) {
        case "informative":
            if (env.TOTAL_VERYHIGH_HIGH_DEFECTS_ANALYSIS > env.TARGET_DEFECTS) {
                env.CODE_ERROR="31"
                echo("[Check Quality Gates] A high or very high defect has not been reduced with respect to the baseline")
            }
            break

        case "block1":
        case "block2":
            if (env.TOTAL_VERYHIGH_HIGH_DEFECTS_ANALYSIS > env.TARGET_DEFECTS) {
                env.CODE_ERROR="31"
                if (env.branch?.toLowerCase().contains("feature"))
                    echo("[Check Quality Gates] A high or very high defect has not been reduced with respect to the baseline")
                else
                    error("[Check Quality Gates] A high or very high defect has not been reduced with respect to the baseline")
            }
            break
    }
}

def getNameBranch(def branch) {
    echo "---------------------------------------Into kiuwan.getNameBranch function---------------------------------------"
    echo "Resolve Name branch ${branch}"
    if (branch.startsWith("PR-")) {
        branch = "PR-${env.CHANGE_TARGET}"
    }
    if(branch.startsWith("release/production")) {
        branch = 'master'
    } else if(branch.startsWith("masterCI")){
        branch = 'master'
    } else if (branch.startsWith("release/preproduction") || branch.startsWith("preproduction")) {
        branch = 'develop'
    } else if(branch.startsWith("development")){
        branch = 'feature/development'
    } else if(branch.startsWith("kiuwan/onboarding") && (env.baselineExists == "false" || env.FORCEBASELINE == "true")) {
        branch = 'master'
    }
    echo "---------------------------------------End kiuwan.getNameBranch function---------------------------------------"
    return branch

}

private def propertiesExist() {
    def exitCode = sh script: 'find /tmp/apps/ -name "*.properties" | egrep .', returnStatus: true
    return exitCode == 0   
}

def prepareConfigFiles() {
    // copy config file
    sh 'cp /tmp/kiuwan/* /home/kiuwan/KiuwanLocalAnalyzer/conf'

    sh 'mkdir -p /home/kiuwan/KiuwanLocalAnalyzer/conf/apps'
    if (propertiesExist())
        sh 'cp /tmp/apps/*.properties /home/kiuwan/KiuwanLocalAnalyzer/conf/apps'
  	if (fileExists(".kiuwan"))
    	sh "rm -rf .kiuwan"
}

def Analysis() {
    echo "---------------------------------------Into kiuwan.Analysis function---------------------------------------"
    echo '\n\n----------------------------Workspace Directories------------------------------------------\n'
    // sh "find ${WORKSPACE} -type d -print"
  
  	if (env.SKIP_KIUWAN == "true" && env.OVERRIDE_SKIP_KIUWAN != "true") {
        return
    } 

    def obj = [
            changeReq        : env.CHANGE_REQUEST,
            kiuwanCredentials: env.KIUWAN_CREDENTIALS_ID,
            kiuwanAppName    : env.KIUWAN_APPNAME,
            kiuwanModel      : env.KIUWAN_MODEL,
            kiuwanLabel      : env.KIUWAN_LABEL,
            saveUTReports    : env.switchUT,
            kiuwanPath       : env.KIUWAN_PATH,
            kiuwanBranch     : env.branch
    ]
    
    KIUWAN_RESPONSE = AnalysisCore(obj)

    getAnalysisDefects(obj.kiuwanCredentials)

    if ((KIUWAN_RESPONSE.responseMap[0] == "10") && (env.QUALITYGATEBLOCKS == "false" || env.branch?.toLowerCase().contains("feature"))) {
        env.CODE_ERROR="10"
        env.auditFailed = "*INFORMATIVE KIUWAN AUDIT DID NOT PASS*"
        unstable(env.auditFailed)
    } else if (!["0", "12","18"].contains(KIUWAN_RESPONSE.responseMap[0]) || env.QUALITYGATESBLOCKS == "true") {
        echo "KIUWAN: ERROR DE AUDITORIA"
        env.CODE_ERROR=KIUWAN_RESPONSE.responseMap[0]
        error(KIUWAN_RESPONSE.responseMap[1])
    }
  	
    echo "---------------------------------------End kiuwan.Analysis function---------------------------------------"
}

def AnalysisCore(obj) {
    echo "---------------------------------------Into kiuwan.Analysis ${obj.kiuwanLabel}function---------------------------------------"
    echo '\n\n----------------------------Workspace Directories------------------------------------------\n'
    // sh "find ${WORKSPACE} -type d -print"

    def MASTER = "master"
    def DEVELOP = "develop"
    def KIUWAN_RESPONSE = ''

     prepareConfigFiles()

    switch (obj.kiuwanBranch) {
        case MASTER:
            def deliveryKiuwan = resolveDeliveryToPromoveInKiuwan(obj.kiuwanCredentials, obj.kiuwanAppName, env.resolveMergeCommit)
            if (deliveryKiuwan) {
                KIUWAN_RESPONSE = promoveDelivery(obj,deliveryKiuwan.changeRequest,env.resolveMergeCommit)
                env.baselineURL = getAnalysisUrl(obj.kiuwanLabel)
            } else {
                KIUWAN_RESPONSE = executeKiuwanLocalAnalyzer(obj, "baseline")
                env.baselineURL = getAnalysisUrl(obj.kiuwanLabel)
                env.CREATED_NEW_BASELINE = "true"
            }
            break
        case DEVELOP:
            KIUWAN_RESPONSE = executeKiuwanLocalAnalyzer(obj, "completeDelivery")
            break
        default:
            KIUWAN_RESPONSE = executeKiuwanLocalAnalyzer(obj, "partialDelivery")
            break
    }

    echo "Kiuwan Response: $KIUWAN_RESPONSE"

    if (!env?.baselineURL) {
        env.analysisURL = getAnalysisUrl(obj.kiuwanLabel)
        echo "[Kiuwan]: Analysis URL: ${env.analysisURL}"
    }

    echo "---------------------------------------End kiuwan.Analysis ${obj.kiuwanLabel}function---------------------------------------"
  	return KIUWAN_RESPONSE
}

def AnalysisWB(Map request) {
    

    def obj = [
            changeReq        : "${env.KIUWAN_APPNAME}#${request.targetBranch.branchName}",
            kiuwanCredentials: env.KIUWAN_CREDENTIALS_ID,
            kiuwanAppName    : env.KIUWAN_APPNAME,
            kiuwanModel      : env.KIUWAN_MODEL,
            kiuwanLabel      : request.sourceBranch.commitId,
            saveUTReports    : env.switchUT,
            kiuwanPath       : env.KIUWAN_PATH,
            kiuwanBranch     : request.targetBranch.branchName
    ]
	if (env.SKIP_KIUWAN == "true" && env.OVERRIDE_SKIP_KIUWAN != "true") {
        return ["analisisResult":"OK","auditResult":"OK","analisisCode":""]
    }

    return AnalysisCore(obj)
}

def promoveDelivery(Map obj, change_request, label) {
    echo "---------------------------------------Into kiuwan.promoveDelivery function---------------------------------------"
    response = null
    withCredentials([usernamePassword(credentialsId: obj.kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
      	def response = sh(encoding: 'UTF-8', label: "[Kiuwan]: Promoting delivery...", returnStdout: true, script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD --promote-to-baseline -n ${obj.kiuwanAppName} -cr ${change_request} -l ${label} -pbl ${label} -wr -c 2>&1 | tee outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log")
        echo "Response Kiuwan ........ \n$response\nFin Response Kiuwan"
        def promotedDeliveryUrl = "${((response =~ /Analysis results URL:.*(https?.*)/) ?: [['', '']])[0][1]}"
        echo "Promoted delivery Url $promotedDeliveryUrl"
      	env.foundDelivery = 1
        echo "---------------------------------------End kiuwan.promoveDelivery function---------------------------------------"
        //return promotedDeliveryUrl
    }
        env.ANALYSIS_CODE = getPromoteAnalysisCode(obj.kiuwanLabel)
      	response = readFile "outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log"
    	result=parseRawResult(response)
    	return result
}


def getAnalysisUrl(String kiuwanLabel) {
    logFile = readFile "outfile${env.BUILD_NUMBER}.${kiuwanLabel}.log"
    def arrayList = logFile.readLines().reverse()
    def kiuwanUrl = ""
    
    for (line in arrayList){
        if (line.contains('Analysis results URL')){
            kiuwanUrl = line.replace('Analysis results URL: ','')
            break
        }
    }
    return kiuwanUrl
}

def getWaitingTime(String kiuwanLabel) {
    logFile2 = readFile "outfile${env.BUILD_NUMBER}.${kiuwanLabel}.log"
    def arrayList = logFile2.readLines().reverse()
    def count = 0
    
    for (line in arrayList){
        if (line.contains('Waiting 15 seconds')){
            count++
        }
    }
    count = count/4
    return count
}

def getAnalysisCode(String kiuwanLabel) {
    logFile = readFile "outfile${env.BUILD_NUMBER}.${kiuwanLabel}.log"
    def arrayList = logFile.readLines().reverse()
    def kiuwanCode = ""
    
    for (line in arrayList){
        if (line.contains('Analysis created in Kiuwan with code')){
            kiuwanCode = line.replace('Analysis created in Kiuwan with code: ','')
            break
        }
    }
    return kiuwanCode
}

def getPromoteAnalysisCode(String kiuwanLabel) {
    logFile = readFile "outfile${env.BUILD_NUMBER}.${kiuwanLabel}.log"
    def arrayList = logFile.readLines().reverse()
    def kiuwanCode = ""
    
    for (line in arrayList){
        if (line.contains('Delivery promoted. New baseline analysis code')){
            kiuwanCode = line.replace('Delivery promoted. New baseline analysis code = ','')
            break
        }
    }
    return kiuwanCode
}

def executeKiuwanLocalAnalyzer(obj, deliveryType) {
    echo "---------------------------------------Into kiuwan.executeKiuwanLocalAnalyzer function---------------------------------------"
	def analysisFolder=obj?.ANALYSIS_FOLDER ? "${obj.ANALYSIS_FOLDER}" :"${WORKSPACE}"
    response = null
  	//portfolios in Kiuwan
  	def portfolioProject = ".kiuwan.application.portfolio.Projects=${env.bitbucketKey}"
  	def portfolioIDG = ".kiuwan.application.portfolio.IDG=${env.bitbucketKey}"
    // base exclude by kiuwan    
    def basic_excludes = sh(script: 'cat /home/kiuwan/KiuwanLocalAnalyzer/conf/analyzer.properties  | grep exclude.patterns= | sed s/exclude.patterns=//', returnStdout: true).trim().replaceAll("/", '\\\\\\/')
    // extra exclude by IDG-DIDI
    def extra_excludes = "**idg-didi-kiuwan-utils\\/**,configurations\\/**,**\\/build\\/**,documentation\\/**,docs\\/**,doc\\/**,**\\/assets\\/**,coverage\\/**,**\\/index.jsp"
    def analysisTimeout = '86400000'
    def memory_max_kiuwan = env?.MEMORY_MAX_KIUWAN ?: '8g'
    withCredentials([usernamePassword(credentialsId: obj.kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
        sh "sed -i 's/memory.max=1024m/memory.max=${memory_max_kiuwan}/g' /home/kiuwan/KiuwanLocalAnalyzer/conf/analyzer.properties"
        sh "sed -i 's/timeout=3600000/timeout=${analysisTimeout}/g' /home/kiuwan/KiuwanLocalAnalyzer/conf/analyzer.properties"
      	sh "sed -i 's/javascript=js,xsjs,ts,tsx/javascript=js,xsjs,ts,tsx,jsx/g' /home/kiuwan/KiuwanLocalAnalyzer/conf/LanguageInfo.properties"
        sh "sed -i 's/xml=/xml=xml/g' /home/kiuwan/KiuwanLocalAnalyzer/conf/LanguageInfo.properties"
        sh "sed -i 's/ignore=/ignore=insights/g' /home/kiuwan/KiuwanLocalAnalyzer/conf/analyzer.properties"
        sh "sed -i '/^exclude.patterns/ s/\$/,${extra_excludes}/' /home/kiuwan/KiuwanLocalAnalyzer/conf/analyzer.properties"
        if (env?.RUN_DIFF && deliveryType == "partialDelivery"){
            sh "sed -i '/^include.patterns/ s/\$/${gitUtils.getFormattedDiffList()}/' /home/kiuwan/KiuwanLocalAnalyzer/conf/analyzer.properties"
        }
        if (propertiesExist())
            sh "sed -i '/^exclude.patterns/ s/\$/,${basic_excludes},${extra_excludes}/' /home/kiuwan/KiuwanLocalAnalyzer/conf/apps/*.properties"
        
        if (fileExists("${analysisFolder}/reports")) {
            // skip android unit tests analysis until further improvements
            // env?.JENKINS_NAME ==~ /(?i)(android)/
            if (deliveryType == "baseline") {
                if(env?.NODE_VERSION || env?.ONLY_KIUWAN_ANALYSIS || env?.JENKINS_NAME ==~ /(?i)(android)/ ) {
                    sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD ${portfolioProject} ${portfolioIDG} -n ${obj.kiuwanAppName} -s ${analysisFolder} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -x '${analysisFolder}/reports' -wr -c 2>&1 | tee outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log")
                    
                } else {
                    sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD ${portfolioProject} ${portfolioIDG} -n ${obj.kiuwanAppName} -s ${analysisFolder} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -x '${analysisFolder}/reports' -wr -c 2>&1 | tee outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log")
                    
                }
            } else {
                if(env?.NODE_VERSION || env?.ONLY_KIUWAN_ANALYSIS || env?.JENKINS_NAME ==~ /(?i)(android)/ ) {
                    sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD -as ${deliveryType} -n ${obj.kiuwanAppName} -bn ${obj.kiuwanBranch} -s ${analysisFolder} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -cr ${obj.changeReq} -x '${analysisFolder}/reports' -wr 2>&1 | tee outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log")
                    
                } else {
                    sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD -as ${deliveryType} -n ${obj.kiuwanAppName} -bn ${obj.kiuwanBranch} -s ${analysisFolder} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -cr ${obj.changeReq} -x '${analysisFolder}/reports' -wr 2>&1 | tee outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log")
                    
                }
            }
        } else {
            echo "No hay ficheros en ${analysisFolder}/reports"
            if (deliveryType == "baseline") {
                sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD ${portfolioProject} ${portfolioIDG} -n ${obj.kiuwanAppName} -s ${analysisFolder} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -wr -c 2>&1 | tee outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log")
                
            } else {
                sh(encoding: 'UTF-8', label: "[Kiuwan]: Analyzing code...", script: "${obj.kiuwanPath} --user $KUSERNAME --pass $KPASSWORD -as ${deliveryType} -n ${obj.kiuwanAppName} -bn ${obj.kiuwanBranch} -s ${analysisFolder} -m '${obj.kiuwanModel}' -l ${obj.kiuwanLabel} -cr ${obj.changeReq} -wr 2>&1 | tee outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log")
            }
        }

    }

    
    response = readFile "outfile${env.BUILD_NUMBER}.${obj.kiuwanLabel}.log"

    env.WAITING_KIUWAN = getWaitingTime(obj.kiuwanLabel)
    env.ANALYSIS_CODE = getAnalysisCode(obj.kiuwanLabel)

    result=parseRawResult(response)

    return result

}

def checkResult(kiuwanLabel) {
    response = readFile "outfile${env.BUILD_NUMBER}.${kiuwanLabel}.log"
    result=parseRawResult(response)

    def responseList = response.readLines()
    if (responseList.last().contains("Promotion done")){
        response = ["0", "Analysis Success"]
        metricKO(1, "0")
    } else {
        response = checkKiuwanErrors(responseList.last())
  		echo "$response"
    }
    echo "---------------------------------------End kiuwan.checkResult function---------------------------------------"
    return response
}

def resolveDeliveryToPromoveInKiuwan(kiuwanCredentials, kiuwanAppName, mergeCommit) {
        echo "---------------------------------------Into kiuwan.resolveDeliveryLabelKiuwan function---------------------------------------"
        def deliveries = []

        withCredentials([usernamePassword(credentialsId: kiuwanCredentials, passwordVariable: 'KPASSWORD', usernameVariable: 'KUSERNAME')]) {
            def DELIVERIES_API = sh(returnStdout: true, script: "curl --insecure --user $KUSERNAME:$KPASSWORD https://kiuwan.es.sedc.internal.vodafone.com/saas/rest/v1/applications/deliveries?application=${kiuwanAppName}").trim()
            deliveries = new JsonSlurperClassic().parseText(DELIVERIES_API)
        }
            def deliveries_result = "$deliveries"
            if (deliveries_result.contains("Application not found")){
                echo "Application not found"
            } else {
                def delivery = deliveries.find { mergeCommit == it.label && it.changeRequest  == "${kiuwanAppName}#develop"}?: deliveries.find { mergeCommit == it.label && it.branchName  == "develop"}
                echo "---------------------------------------End kiuwan.resolveDeliveryLabelKiuwan function result $delivery---------------------------------------"
                return delivery
            }
}

def resolveMergeCommit(branch) {
    if(branch=='master') {
        def result = sh(script: "git log -6", returnStdout: true)
        echo "<<$result>>"
        def mergeCommit = "${(( result =~ /'(.*)':/) ?: [['', 'No se encontro un commit de Merge']])[0][1]}"
        echo "Resolve Merge Commit : $mergeCommit"
        return mergeCommit
    }
    return false
}

// @NonCPS
def parseRawResult(kiuwanRawResult){
    result=[
        "analisisCode":"",
        "auditResult":"FAIL",
        "analisisResult":"ERROR",
        "responseMap":[]
    ]

    def responseList = kiuwanRawResult.readLines()
    // if last line, whether it was delivery or baseline, didn't finish, check errors
    if ( !responseList.last().contains("Analysis finished") && !responseList.last().contains("Promotion done"))
        result.responseMap = checkKiuwanErrors(responseList.last())
    else {
        result.responseMap = ["0", "Analysis Success"]
        metricKO(1, "0")
    }
        
    if (kiuwanRawResult.contains("Analysis results URL: ")){
        println("contiene analisis result URL")
        result.analisisResult="OK"
    }
    regex=/(?m)^Analysis created in Kiuwan with code: (A-[a-zA-Z0-9-]*)/

    if (kiuwanRawResult.contains("Analysis created in Kiuwan with code: ")){
		def m = (kiuwanRawResult=~regex)
		result.analisisCode=m ? m[0][1] : ""
		println ("Code:" +m[0][1])

    }

    if (kiuwanRawResult.contains("Audit passed: true")){
        result.auditResult="OK"
    }

    return result
}

    

def checkKiuwanErrors(strError) {

    //https://www.kiuwan.com/docs/display/K5/Local+Analyzer+Return+Codes

    E12 = "12" // The model specified for the application does not contain rules for the technologies being analyzed
    E10 = "10" // Audit associated to the analyzed application did not pass.
    E14 = "14" // Error in cloud.
    E18 = "18" // No analyzable extensions found
    currentError = strError.drop(strError.size() - 2)
    formattedMessage = ""

    // metricKO
    // 0 -> KO
    // 1 -> OK

    switch(currentError) {
        case E12:
            formattedMessage = "[Kiuwan]: The model specified for the application does not contain rules for the technologies being analyzed"
            metricKO(1, currentError)
          //echo "[Kiuwan]: The model specified for the application does not contain rules for the technologies being analyzed."
        break
        case E10:
          if (env.QUALITYGATEBLOCKS == "true") 
              formattedMessage = "[Kiuwan]: Audit did not pass"
          else {
                env.auditFailed = "Audit did not pass"
                formattedMessage = env.auditFailed
          }
          metricKO(1, currentError)
      	break
        case E14:
          	formattedMessage = "[Kiuwan]: Error during analysis processing in the server"
            metricKO(0, currentError)
          //echo "[Kiuwan]: Error during analysis processing in the server"
        break
        case E18:
          	formattedMessage = "[Kiuwan]: No analyzable extensions found."  
            metricKO(1, currentError)
          //echo "[Kiuwan]: No analyzable extensions found."
        break
        default:
            formattedMessage = "[Kiuwan]: " + strError
            metricKO(0,currentError)
        break
    }
    
    return [currentError, formattedMessage]
}

// Sends metric to PushGateway 
def metricKO(Integer isOK, String currentError){
  try{
    print("kiuwan_kla_result")
  } catch(Exception) {
    echo "Did not send metrics"
  }
}
