import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(Map config,VFESALMSDeployment alms){
    for (i=0;i<config.artifactId.size();i++){
        sh """
            mkdir -p ${config.extractFolder}/${config.distFolder[i]}
            cd ${config.extractFolder}
            rm -f  ${config.distFolder[i]}/${config.distFile[i]}
            zip -r ${config.distFolder[i]}/${config.distFile[i]} *  | awk 'BEGIN {ORS=" "} {if(NR%10==0)print "."}'
            """
    }
}
