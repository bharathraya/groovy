import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
def call(Map config,VFESALMSDeployment alms, VFESGitMergeInfo_aaresmi mergeInfo, ArrayList ParamItem2Delete)
{

    def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    def _envConfig=myEnvsConfig[alms.deployEnv]

    //////////////////////////////////////////
    /////////CHECK REPOSITORY CHANGES/////////
    //////////////////////////////////////////

    items2DeployConfig=mergeInfo.FilesChangedDetailed.findAll{!(it[1] =~ "RollupJobs/")}
    items2Delete=mergeInfo.FilesChangedDetailed.findAll{it[0] == "D" && it[1] =~ "RollupJobs/"}
    items2Rename=mergeInfo.FilesChangedDetailed.findAll{it[0] == "R" && it[1] =~ "RollupJobs/"}
    items2Deploy=mergeInfo.FilesChangedDetailed.findAll{(it[0] == "M" || it[0] == "A") && it[1] =~ "RollupJobs/"}

    echo "=============================================="
    echo "CHANGES FOUNDS IN COMMIT"
    echo "=============================================="
    echo "CHANGES ONLY AT FILESYSTEM LEVEL:"
    echo "Configuration Files to Deploy:  ${items2DeployConfig.size()}"
    echo "CHANGES AT ELASTICSEARCH LEVEL:"
    echo "ElasticSearch Items to Delete:  ${items2Delete.size()}"
    echo "ElasticSearch Items to Rename:  ${items2Rename.size()}"
    echo "ElasticSearch Items to Deploy:  ${items2Deploy.size()}"
    echo "=============================================="

    if (items2Deploy.size() == 0 && items2Delete.size() == 0 && items2Rename.size() == 0 && items2DeployConfig.size() == 0)
    {
        echo "ERROR. There are not any change detected!!!!!. "
        sh ("exit 1")
    }

    if (items2Delete.size() != 0) {
        echo "ElasticSearch Items to Delete detected. Checking with parameter ITEMS2DELETE ....."
        filesItems2Delete = []
        items2Delete.each { filesItems2Delete.add(it[1].value.toString()) }
        listFilesItems2Delete = filesItems2Delete as List
        //echo "listFilesItems2Delete=${listFilesItems2Delete}"

        def diffInFiles = (listFilesItems2Delete - ParamItem2Delete)
        def diffInParam = (ParamItem2Delete - listFilesItems2Delete)

        //echo "diffInFiles=${diffInFiles}"
        //echo "diffInParam=${diffInParam}"

        if (diffInParam.size() != 0) {
            echo "WARN. There are some ElasticSearch Items in the param ITEMS2DELETE that were not detected in the in the commit to be deleted!!!!!. "
            echo "${diffInParam}"
        }

        if (diffInFiles.size() != 0) {
            echo "ERROR. There are some ElasticSearch Items detected to be deleted in the commit that there isn't in the param ITEMS2DELETE!!!!!. We cannot continue"
            echo "${diffInFiles}"
            sh("exit 1")
        }
        echo "OK. ElasticSearch Items to Delete Checked with parameter ITEMS2DELETE Successfully."
        echo "=============================================="
    }

    ///////////////////////////////////
    /////////NEW CHECK ACTIONS/////////
    ///////////////////////////////////
    if (config.containsKey("deployActions"))
    {
        deployECE_ELKCheckVariables config,alms
    }
    ///////////////////////////////////
    /////////NEW CHECK ACTIONS/////////
    ///////////////////////////////////

    echo "Deploying Rollup Jobs ...."
    echo "_envConfig"+_envConfig['deploy_rollupJob']
    _envConfig['deploy_rollupJob'].each { item ->
        echo "Server Data:"
        echo "  deploy_server: " + item.server
        echo "  deploy_user: " + item.user
        echo "  application_release_path: " + item.application_release_path
        echo "  platafor_release_path: " + item.platafor_release_path + "/scripts"
        echo "  variables repository: " + item.repo_vars
        echo "  deploy Script: " + config.deployScript
        echo "ElasticSearch Data:"
        echo "  elastic_sch: " + item.elastic_sch
        echo "  elastic_host: " + item.elastic_host
        echo "  elastic_port: " + item.elastic_port
        echo "  elastic_credential: " + item.elastic_credential
        def _elasticURL=""

        //DELETE
        if ( items2Delete.size() != 0 )
        {
            echo "=========================================="
            echo "DELETE Rollup Jobs"
            echo "=========================================="
            // ROLLUPJOBS
            rollupJobs2Delete = []
            items2DeleteRollupJobs = items2Delete.findAll { it[1] =~ 'RollupJobs/' }
            items2DeleteRollupJobs.each { it -> rollupJobs2Delete.add(it[1]) }
            rollupJobs2DeleteString = rollupJobs2Delete.join(",")
            _paramRollupJobs = ""
            if (rollupJobs2DeleteString != null && rollupJobs2DeleteString != "") {
                _paramRollupJobs = "-j ${rollupJobs2DeleteString}"
            }
            echo "RollupJobs to delete: " + rollupJobs2DeleteString


            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -d -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramRollupJobs}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -d -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramRollupJobs}'"
            }
        }

        //RENAME
        if ( items2Rename.size() != 0 )
        {
            echo "=========================================="
            echo "RENAME Rollup Jobs"
            echo "=========================================="
            // ROLLUPJOBS
            rollupJobs2Rename = []
            items2RenameRollupJobs = items2Rename.findAll { it[1] =~ 'RollupJobs/' }
            items2RenameRollupJobs.each { it -> rollupJobs2Rename.add("${it[1]}#${it[2]}") }
            rollupJobs2RenameString = rollupJobs2Rename.join(",")
            _paramRollupJobs = ""
            if (rollupJobs2RenameString != null && rollupJobs2RenameString != "") {
                _paramRollupJobs = "-j ${rollupJobs2RenameString}"
            }
            echo "RollupJobs to rename: " + rollupJobs2RenameString

            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -x -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramRollupJobs}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -x -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramRollupJobs}'"
            }
        }

        //UPDATE (ADD/MODIFY)
        if (items2Deploy.size() != 0) {
            echo "================================================="
            echo "UPDATE/CREATE Rollup Jobs"
            echo "================================================="
            // ROLLUPJOBS
            rollupJobs2Deploy = []
            items2DeployRollupJobs = items2Deploy.findAll { it[1] =~ 'RollupJobs/' }
            items2DeployRollupJobs.each { it -> rollupJobs2Deploy.add(it[1]) }
            rollupJobs2DeployString = rollupJobs2Deploy.join(",")
            _paramRollupJobs = ""
            if (rollupJobs2DeployString != null && rollupJobs2DeployString != "") {
                _paramRollupJobs = "-j ${rollupJobs2DeployString}"
            }
            echo "RollupJobs to deploy: " + rollupJobs2DeployString

            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -u -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramRollupJobs}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -u -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramRollupJobs}'"
            }
        }
    }
}