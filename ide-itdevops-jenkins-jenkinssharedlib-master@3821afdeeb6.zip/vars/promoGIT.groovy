def call(String _TipoObsoletos, String _GenerarFichCambios, String _domain, String _Env, String _Alms, String _remoteServer){
	
	_date=new Date().format( 'yyyyMMdd' )
	_OPCS=""
	
	print "The domain is ${_domain}"
	
	if(_TipoObsoletos == "SI"){
		_OPCS="-o"
	}
	
	if(_GenerarFichCambios == "SI"){
		if(_OPCS == ""){
			_OPCS="-f"
		}
		else{
			_OPCS="${_OPCS} -f"
		}
	}
	
	print "las opciones son ${_OPCS}"
	//AMDOCS
	if(_domain == "AMDOCS-BBDD" ||
		_domain == "AMDOCS-MAESTRAS" || 
		_domain == "AMDOCS-ESQUEMA" || 
		_domain == "AMDOCS-SERVER" ||  
		_domain == "AMDOCS-CLIENT" || 
		_domain == "AMDOCS-BPM_APM" || 
		_domain == "AMDOCS-AIF_APM" || 
		_domain == "AMDOCS-SMS_Resumen_Compra" || 
		_domain == "AMDOCS-ImpresionContratos" || 
		_domain == "AMDOCS-PM" || 
		_domain == "AMDOCS-APM" || 
		_domain == "AMDOCS-SPM" || 
		_domain == "AMDOCS-SPM_Java" || 		
		_domain == "AMDOCS-CLARIFY" || 
		_domain == "AMDOCS-CustActionBeans" || 
		_domain == "AMDOCS-IntegracionTOA" || 
		_domain == "AMDOCS-UPSD")
	{
		_domain = "AMDOCS"
		
		exec="""
		. \$HOME/.profile >/dev/null 2>&1
		. paquete ${_Alms}
		promoGIT.sh ${_OPCS} -d ${_domain} -e ${_Env} -p ${_Alms}
		"""
		if (_remoteServer!="")
            {
                sh "ssh -q ${_remoteServer} '${exec}'"
            }
            else
            {
                sh "${exec}"
            }
	}
	else
	{
		print "It not needs to be updated in Bitbucket"
	}
	

}