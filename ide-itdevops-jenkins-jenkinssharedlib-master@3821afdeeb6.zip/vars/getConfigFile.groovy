def call(String config){
	echo "getConfigFile"
    def SALIDA=""
    try {
        SALIDA=sh returnStdout: true, script: " find ${config} -type f"
    } catch(Exception ex) {
         println("WARNING:No existe  ${config}");
         SALIDA=""
    }
	def lista = SALIDA.split("\n").collect{it}
	return lista
}