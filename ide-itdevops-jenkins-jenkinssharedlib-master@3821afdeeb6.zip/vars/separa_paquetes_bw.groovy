def call(String _Application, String CRQ_ID, String _server){
 hoy=new Date().format( 'yyyyMMdd' )
 
 print " Parametros ${_Application} ${CRQ_ID}    "
  
 //Reviso que archives y paquetes hay
       exec="""
        . \$HOME/.profile >/dev/null 2>&1
        cd /home/plataforma/plausr/data/temporal/${hoy}/${CRQ_ID}/prd/DataModules
        find . -type f -name "*archive*" > /home/plataforma/plausr/data/temporal/${hoy}/${CRQ_ID}/prd/ListadoArchives.txt
        touch -f /home/plataforma/plausr/data/temporal/${hoy}/${CRQ_ID}/prd/archive_paq.txt
       
        cat /home/plataforma/plausr/data/temporal/${hoy}/${CRQ_ID}/prd/ListadoArchives.txt | while read linea
            do
                echo "La linea leida: \$linea"
                ArchiveTotal=\$(basename \$linea)
                echo "el fichero a partir: \$ArchiveTotal"
                Numero=\$(echo \$ArchiveTotal | cut -d_ -f2)
                echo "El paquete es: \$Numero"
                compo=\$(cat \$ArchiveTotal | grep "<name>" | cut -d">" -f2 | cut -d "<" -f1)
                echo "El componente es \$compo "
                echo "\$Numero:\$compo" >> /home/plataforma/plausr/data/temporal/${hoy}/${CRQ_ID}/prd/archive_paq.txt
                
            done
       
        """
        
        sh "ssh -q es036tvr '${exec}'"
        
         

             
                if (_Application == "BW_AMX")
                {
                     sh ". \$HOME/.profile >/dev/null 2>&1 ; . paquete ${CRQ_ID} ; scp es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${CRQ_ID}/prd/archive_paq.txt paquetes_engines.txt ;separa_bw_paq_virtuales -e prd -p ${CRQ_ID} -f Paq_${CRQ_ID}.txt -W "
                }
                else
                {
                    execSep="""
                    . \$HOME/.profile >/dev/null 2>&1
                    . paquete ${CRQ_ID}
                    scp es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${CRQ_ID}/prd/archive_paq.txt .
                    mv archive_paq.txt paquetes_engines.txt
                    separa_bw_paq_virtuales -e prd -p ${CRQ_ID} -f Paq_${CRQ_ID}.txt -W
                    """
                    
                      sh "ssh -q ${_server} '${execSep}'"
                }

}
