#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever
import groovy.time.TimeCategory

// Parametros necesario

def _server=""
def _serverSVN=""
def _funcion=""
def _funcionEnt=""
def funcConfig=""
def hoy=""
def _funcionAejecutar=""
def _serverAenviar=""
def _WB_ID=""
def envsConfig
def _listapaquetes=""
def _serverPROD=""
def mybuilduser=""
def _type=""

def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            choice(name: 'Application', choices: pipelineParams.applicationChoices, description: 'Application to restart') 
            string(name: 'COMPONENT', defaultValue: '', description: 'Components to restart') 
            choice(name: 'TypeOfComponent',  choices: pipelineParams.typeComponente , description: 'For TIBCOES/TIBCOIT: IM or ADAPTER') 
            choice(name: 'Enviroment',  choices: pipelineParams.environmentChoices , description: 'Enviroment to restart') 
            string(name: 'List_Machines', defaultValue: '', description: 'Machines which we will restart')
            choice(name: 'Opcion',  choices: pipelineParams.OptionChoices , description: '1. Check Status 2. Reboot with loss of service') 
             
         } //parameters
         
 stages{              
     stage("Prepare"){
        agent {
              label 'MEDIACION'
              }
        steps{
          script {
                  
                   wrap([$class: 'BuildUser']) {
                         echo "Exec user: ${env.BUILD_USER_ID}"
                         mybuilduser=env.BUILD_USER_ID
                       }
                   
               
                hoy=new Date().format( 'yyyyMMdd' )
                print "La fecha de hoy es ......${hoy}......"
                 _env=params.Enviroment  
                _Component=params.COMPONENT.trim()  
                _Domain=params.Application
                _listmachines=params.List_Machines
                _Opcion=params.Opcion
                _type=params.TypeOfComponent  
                    
                    if (_Opcion == "1")
                    {
                        _optionRE ="-t"
                        _Variable ="STATUS"
                        print "STATUS"
                    }
                    else 
                    {
                         if (_Domain == "BW" || _Domain == "BW_AMX")
                         {
                             _optionRE =""
                         }
                         else
                         {
                            _optionRE ="-i"
                        
                         }
                        _Variable ="REBOOT"
                        print "REBOOT"
                    }
                    
                    //Configuramos el nombre del build y su descripcion
                    if (_Domain == "TIBCOES" || _Domain == "TIBCOIT")
                    {
                        currentBuild.displayName = "App: ${_Domain} ${_type}: ${_Component} Env: ${_env} "
                    }
                    else
                    {
                        currentBuild.displayName = "App: ${_Domain} BW: ${_Component} Env: ${_env} "
                    }
                    
                    currentBuild.description = "Maquinas: ${_listmachines}  ${_Variable} "

        if (_Component =="")
        {
            error("IT IS NECESSARY COMPONENT")
        }
        
        if  ((_Domain =="TIBCOES" ||_Domain =="TIBCOIT") && _listmachines=="")
        {
            error("MACHINES ARE NECESSARY ")
        }
                    //leemos el fichero de configuracion
                    pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                    //leemos el fichero de entornos
                    envsConfig=pipelineConfig.envConfig
                                
                    enviroments=readJSON(file: "${envsConfig}")
                    _server=enviroments["${_Domain}"]["${_env}"]["server"][0][0]
                    
                    
          }//Script
       }//steps
     } //Prepare             
    
         stage("Rebotar"){
               agent {
                    node("${_Domain}-${_env}")
                        }

                steps{
                    script {
                        
                    if ("${env.NODE_NAME}" == "${_server}")
                      {
                       _server =""
                         //  borramos el server para no hacer ssh
                     }
                   
                    if (_Domain == "TIBCOES" ||_Domain == "TIBCOIT")
                    {
                       
                       if (_type == "IM")
                       {
                            exec="""
                            . \$HOME/.profile >/dev/null 2>&1
                            rebotarIM -SL  ${_optionRE}  -c ${_Component} -e ${_env} ${_listmachines}
                    
                            """
                       }
                       else
                       {
                            exec="""
                            . \$HOME/.profile >/dev/null 2>&1
                            rebotarADAPTER -SL  ${_optionRE}  -c ${_Component} -e ${_env} ${_listmachines}
                        
                            """
                       }
                    }
                    else
                    {
                         if (_Domain !="BW_AMX")
                         {
                             exec="""
                            . \$HOME/.profile >/dev/null 2>&1
                            rebotarBW -L ${_optionRE}  -c ${_Component} -e ${_env} 
                        
                            """
                         }
                         else
                         {
                              exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                            rebotarBW_AMX -L ${_optionRE}  -c ${_Component} -e ${_env} 
                    
                        """
                         }
                    }
                
                if (_server !="")
                 {
                      sh "ssh -q ${_server} '${exec}'"
                 }
                else
                 {
                    sh "${exec}"
                 }


        }//Script
       }//steps
     } //Rebotar
    }//stages
 }//pipeline
}//map


