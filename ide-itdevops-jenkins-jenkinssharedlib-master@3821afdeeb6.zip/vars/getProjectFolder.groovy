def call (String _pomstring, String _Aplicacion){
    echo "getProjectFolder"
    def project = new XmlSlurper().parseText(_pomstring)
    def parent=""
    def _rutamodulo=""
    echo "POM:${_pomstring}"
    if (project.parent.size() > 0){
        parent=project.parent.artifactId
        echo "Parent: ${parent}"
        if (project.modules.size() > 0 ){
            project.modules.module.any(){
                def rutamodulo=it
                echo "modulo: ${rutamodulo}"
                def tokens=rutamodulo.toString().tokenize("/")
                def ruta=tokens[0]
                def modulo=tokens[1]
                def lowerAplicacion=_Aplicacion.toLowerCase()
                if (lowerAplicacion != modulo){
                    echo "El modulo:${modulo} no concuerda con: ${lowerAplicacion}"
                    _rutamodulo=""
                    return true
                }
                _rutamodulo=rutamodulo
                return true
            }
        }
    }
    return _rutamodulo
}
