def call(String _App , String _MsInfo, Map _ms){
    echo "getMsInfofromApp1 (${_App},..."
    def _yaml = readYaml(text: _MsInfo)
    def application=""
    _yaml.ms.any(){
        //echo "ms:${ms}"
        application=it.application?"${it.application}":""
        if (application != ""){
            if (application.toLowerCase() == _App.toLowerCase()){
                it.each(){key, value ->
                    echo "field:${key}: ${value}"
                    _ms.put(key, value)
                }
                return true
            }
        }
    }
    if (_ms.application == ""){
        error "Aplicacion:${_App} no encontrada"
    }
}