import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def call (String _CADENAJSON, List _BranchList)
{
	def _jsonnentregas =new JsonSlurper().parseText(_CADENAJSON)
	def _jsonnsalida =new JsonSlurper().parseText("[]")
	def release=""
   	_BranchList.each{
		def newbranch=""
	   	def branch=it
		//echo "Tratando: ${branch}"
	   	//newbranch=_jsonnentregas.find{ it.release == "${branch}" }
	   	_jsonnentregas.any{ 
	   		if(it.release == "${branch}"){
	   			newbranch="${branch}"
	   			//echo "Existe la branch ${branch} en el json"
	   			_jsonnsalida<< [release: "${branch}", fecha: "${it.fecha}", entorno: "${it.entorno}"]
	   			return true
	   		}

	   	}
	   	if ( newbranch == "" ){
			//echo "No existe la branch ${branch} en el json"
			//_jsonnentregas<< [release: "${branch}", fecha: ""]
			_jsonnsalida<< [release: "${branch}", fecha: ""]
		}
	}
	
	//def _NEWCADENAJSON =JsonOutput.toJson(_jsonnentregas)
	def _NEWCADENAJSON =JsonOutput.toJson(_jsonnsalida)
	echo "${_NEWCADENAJSON}"
	return _NEWCADENAJSON
}
