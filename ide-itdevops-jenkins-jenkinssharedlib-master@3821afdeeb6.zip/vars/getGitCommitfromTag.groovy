import vfes.git.VFESGitRepo

def call(String tag){
    echo "getGitCommitfromTag"
    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
            git show-ref -d ${tag}
    """
    def lista = SALIDA.split("\n").collect{it}
    def commit=""
    def commitaux=""
    lista.any(){
        def token=""
        token=it.tokenize(' ')
        commitaux=token[0]
        if (it =~ "}"){
            commit=commitaux
            return true
        }
    }
    if (commit == ""){
        commit=commitaux
    }
	return commit
}
def call(String tag,VFESGitRepo _repo){
    echo "getGitCommitfromTag"
    final String GITLAB="Gitlab"
    vfRepoPath=_repo.repoPath
    if (_repo.repoType==GITLAB){
        vfRepoPath=(_repo.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
    }    
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${_repo.pushCred}",
            usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
        sh """
            git remote set-url origin ${_repo.protocol}://${USERNAME}:${PASSWORD}@${_repo.server}/${vfRepoPath}/${_repo.repoName}
            git fetch --tags
        """
    }

    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
            git show-ref -d ${tag}
    """
    def lista = SALIDA.split("\n").collect{it}
    def commit=""
    def commitaux=""
    lista.any(){
        def token=""
        token=it.tokenize(' ')
        commitaux=token[0]
        if (it =~ "}"){
            commit=commitaux
            return true
        }
    }
    if (commit == ""){
        commit=commitaux
    }
	return commit
}

