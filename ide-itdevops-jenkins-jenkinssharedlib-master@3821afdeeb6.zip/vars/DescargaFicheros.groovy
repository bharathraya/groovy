def call(String _NombreCRQ, String _listapaquetes, String _Orden, Boolean _esquema){
   
   def hoy=""
   def iLista=0
   def iOrden=0
   def exec=""
   def prueba=""
   def myfile=""
   def fileInfo=""
   def tamano=0
   def pruebaorden=""
   
   hoy=new Date().format( 'yyyyMMdd' )
   iLista=0
   iOrden=0
   //print "CRQ -> ${_NombreCRQ}"
   //print "Lista paquetes -> ${_listapaquetes}"
   //print "Orden -> ${_Orden}"
   //print "Regenerar Esquema -> ${_esquema}"
   
   //Primero descago el parche en la maquina devoptoos
   //Busco el fichero de paquetes.
   exec="""
        . \$HOME/.profile >/dev/null 2>&1
        SubidaGIT.sh -c -p  ${_NombreCRQ}
    """
    
   sh "${exec}"
   
   RutaTemp="/home/plataforma/plausr/tmp/${hoy}"
   RutaPaquete="/home/plataforma/plausr/data/paquetes/${hoy}/${_NombreCRQ}"
   
  if (_listapaquetes !="")
  {
       //Reviso si existe el fichero con los paquetes
        sh ("touch -f ${RutaPaquete}/hayFile.txt")
        sh ( "if [ -f ${RutaPaquete}/${_listapaquetes} ] ; then echo 1 >> ${RutaPaquete}/hayFile.txt ; fi ")
        prueba=readFile(file: "${RutaPaquete}/hayFile.txt")
        
        if ( prueba != "")
         {
              myfile=readFile(file: "${RutaPaquete}/${_listapaquetes}")
              iLista=0
              
              fileInfo=myfile.split()
              tamano= fileInfo.size()
              print " HAY  ${tamano} PAQUETES "
              
              //Pongo en linea los paquetes
              sh "sort -u ${RutaPaquete}/${_listapaquetes} > ${RutaPaquete}/${_listapaquetes}_tmp"
              sh "mv  ${RutaPaquete}/${_listapaquetes}_tmp  ${RutaPaquete}/${_listapaquetes}"
              sh "cat ${RutaPaquete}/${_listapaquetes} | tr '\n' ' ' >> ${RutaPaquete}/${_NombreCRQ}_ListaPaquetes.txt"
              sh "cp ${RutaPaquete}/${_NombreCRQ}_ListaPaquetes.txt ${RutaTemp}/${_NombreCRQ}"
         }
        else
         {
              iLista=1
         }
        
         
  }
  if (_esquema)
  {
      print "Copy to ${RutaTemp} files orden_pre.txt orden_post.txt"    
      sh " if [ -f ${RutaPaquete}/orden_pre.txt ] ; then cp ${RutaPaquete}/orden_pre.txt ${RutaTemp}/${_NombreCRQ}/orden_pre.txt ;fi"
      sh " if [ -f ${RutaPaquete}/orden_post.txt ] ; then cp ${RutaPaquete}/orden_post.txt ${RutaTemp}/${_NombreCRQ}/orden_post.txt ;fi"
  }
  if (_Orden !="")
  {
      //Reviso si existe el fichero con los paquetes
        sh ("touch -f ${RutaPaquete}/hayorden.txt")
        sh ( "if [ -f ${RutaPaquete}/${_Orden} ] ; then echo 1 >> ${RutaPaquete}/hayorden.txt ; fi ")
        pruebaorden=readFile(file: "${RutaPaquete}/hayorden.txt")
        
        if ( pruebaorden == "")
         {
              iOrden=1
         }
         else
         {
              //Copio el fichero orden
              sh "cp ${RutaPaquete}/${_Orden} ${RutaTemp}/${_NombreCRQ}"
              iOrden=0
         }
  }
  if ( iOrden==1 && iLista==1)
  {
       error("The order file does not exist: ${_Orden} There is no list of packages: ${_listapaquetes}")

  }
  else if ( iOrden==0 && iLista==1)
  {
       error("There is no list of packages: ${_listapaquetes}")
  }
  else if ( iOrden==1 && iLista==0)
  {
       error("The order file does not exist: ${_Orden} ")
  }
}
