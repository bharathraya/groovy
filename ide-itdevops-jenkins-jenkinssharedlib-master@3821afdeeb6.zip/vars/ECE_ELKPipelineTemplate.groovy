import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo_aaresmi
import vfes.git.VFESGitMergeInfo_aaresmi

def deploy_env=""
def commit_id=""
def alms_id=""
def delivery=""
def project_id=""
def squad=""

def almsPackage=null
def gitRepo=null
def gitOtherRepo=null
def pipelineConfig=null
boolean NO_RESTART=null
def ParamItem2Delete=null
VFESGitMergeInfo_aaresmi mergeInfo=null

def call(Map pipelineParams){
    pipeline{
        agent none
        parameters {
            choice(name: 'DeployEnv',  choices: pipelineParams.environmentChoices , description: '')
            string(name: 'CommitID', defaultValue: '', description: '')
            string(name: 'ALMS_ID', defaultValue: '', description: '')
            string(name: 'Delivery', defaultValue: '', description: '')
            string(name: 'ProjectId', defaultValue: '', description: '')
            string(name: 'SQUAD', defaultValue: 'BAU', description: '')
            string(name: 'PackageInfo', defaultValue: '', description: '')
        }
        stages{

            stage("Prepare"){
                agent {
                    label "ECE_ELK"
                }
                steps{
                    script {
                      echo "########################################"
                      echo "###########START PREPARE PHASE##########"
                      echo "########################################"
                      echo "Start TimeStamp:  ${new Date()}"
                        env.current_stage=env.STAGE_NAME
                        NO_RESTART=false
                        ParamItem2Delete=[]
                        if (params.PackageInfo==""){
                            // executed manually or from ALMS
                            deploy_env=params.DeployEnv
                            commit_id=params.CommitID
                            alms_id=params.ALMS_ID
                            delivery=params.Delivery
                            project_id=params.ProjectId
                            squad=params.SQUAD
                        }else{
                            echo "PackageInfo: ${params.PackageInfo}"
                            (deploy_env,commit_id,alms_id,delivery,project_id,squad)=parsePckInfo(PackageInfo)
                            wbpckinfo=get_workbench_package_info(alms_id)
                            if (wbpckinfo.Data.Model.Model.Params.findAll{it.Key == "NO_RESTART"}.size() != 0)
                            {
                                NO_RESTART=true
                            } else {
                                NO_RESTART=false
                            }
                            if (deploy_env == "master") {
                                ITEMS2DELETE="ITEMS2DELETE_PROD"
                            } else
                            {
                                ITEMS2DELETE="ITEMS2DELETE_PPRD"
                            }

                            if (wbpckinfo.Data.Model.Model.Params.findAll{it.Key == "${ITEMS2DELETE}"}.size() != 0)
                            {
                                //echo "Items to delete Param found!!!!"
                                ParamItem2DeleteNoTrimmed=wbpckinfo.Data.Model.Model.Params.findAll{it.Key == "${ITEMS2DELETE}"}.Value.toString().replaceAll("\\[|\\]", "").split(",") as List
                                ParamItem2DeleteNoTrimmed.each{ParamItem2Delete.add(it.trim())}
                                //echo "${ParamItem2Delete}"
                            }
                        }

                        echo "    DeployEnv: ${deploy_env}"
                        echo "    CommitID:  ${commit_id}"
                        echo "    PackageID: ${alms_id}"
                        echo "    Delivery:  ${delivery}"
                        echo "    Project:   ${project_id}"
                        echo "    Squad:     ${squad}"
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        almsPackage= new VFESALMSDeployment(alms_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,squad)
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
                        // TODO : when
                        gitRepo=new VFESGitRepo_aaresmi("${pipelineConfig.gitRepo}",this)
                        echo "End TimeStamp:  ${new Date()}"
                        echo "########################################"
                        echo "############END PREPARE PHASE###########"
                        echo "########################################"
                    }
                }
            }

            stage('Checkout'){
                agent {
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                    script{
                      echo "#########################################"
                      echo "###########START CHECKOUT PHASE##########"
                      echo "#########################################"
                      echo "Start TimeStamp:  ${new Date()}"
					  env.current_stage=env.STAGE_NAME
                      gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
                      if(pipelineConfig.gitOtherRepo?.trim()){
                          // Hacer el checkout en carpeta extractOtherFolder
                          echo "Do checkout of other folder"
                          gitOtherRepo=new VFESGitRepo_aaresmi("${pipelineConfig.gitOtherRepo}",this)
                          gitOtherRepo.cloneBranchToLocalFolder(pipelineConfig.extractOtherFolder,almsPackage.deployEnv)
                      }
                      echo "End TimeStamp:  ${new Date()}"
                      echo "#########################################"
                      echo "############END CHECKOUT PHASE###########"
                      echo "#########################################"
                    }
                }
            }

            stage('merge'){
                agent {
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                    script{
                      echo "######################################"
                      echo "###########START MERGE PHASE##########"
                      echo "######################################"
                      echo "Start TimeStamp:  ${new Date()}"
                      env.current_stage=env.STAGE_NAME
                      mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
                      echo "MergeInfo: ${mergeInfo.filesChanged}"
                      echo "MergeInfo Detailed: ${mergeInfo.FilesChangedDetailed}"
                      echo "End TimeStamp:  ${new Date()}"
                      echo "######################################"
                      echo "############END MERGE PHASE###########"
                      echo "######################################"
                    }
                }
            }

            stage('CopyToRelease'){
                agent{
                    label "${pipelineConfig.releaseAgent}"
                }
                when{
          				expression {"${pipelineConfig.deployType}" !='winlogbeat-config' && "${pipelineConfig.deployType}" != 'filebeat-config-windows' && "${pipelineConfig.deployType}" != 'k8s-beat'}
          			}
                steps{
                    script{
                      echo "################################################"
                      echo "###########START COPY TO RELEASE PHASE##########"
                      echo "################################################"
                      echo "Start TimeStamp:  ${new Date()}"
                      env.current_stage=env.STAGE_NAME
                      giveExecutePermissionsECE_ELK pipelineConfig,almsPackage
                      createZipFromPackage pipelineConfig,almsPackage
                      if ("${deploy_env}" != "master")
                      {
                        echo "Deploy at env: ${deploy_env}. Copy to release for ${pipelineConfig.deployType} type ..."
                        copyToReleaseECE_ELK  pipelineConfig,almsPackage
                      } else {
                        if (pipelineConfig.directProdDeployment == 'Y') {
                        echo "Deploy at env: ${deploy_env} and directProdDeployment is activated. Copy to release for ${pipelineConfig.deployType} type ..."
                        copyToReleaseECE_ELK  pipelineConfig,almsPackage
                        } else {
                          echo "Deploy at env: ${deploy_env} and directProdDeployment is deactivated. Copy to release for ${pipelineConfig.deployType} type ..."
                          copyToInfraServerECE_ELK  pipelineConfig,almsPackage
                        }
                      }
                      echo "End TimeStamp:  ${new Date()}"
                      echo "################################################"
                      echo "############END COPY TO RELEASE PHASE###########"
                      echo "################################################"
                    }
                }
            }

            stage('CopyToDataPackage'){
                agent{
                    label "${pipelineConfig.releaseAgent}"
                }
                when{
          				expression {"${pipelineConfig.deployType}" == 'winlogbeat-config' || "${pipelineConfig.deployType}" == 'filebeat-config-windows'}
          			}
                steps{
                    script{
                      echo "#####################################################"
                      echo "###########START COPY TO DATA PACKAGE PHASE##########"
                      echo "#####################################################"
                      echo "Start TimeStamp:  ${new Date()}"
					  env.current_stage=env.STAGE_NAME
                      copyToDataPackageECE_ELK  pipelineConfig,almsPackage
                      echo "End TimeStamp:  ${new Date()}"
                      echo "################################################"
                      echo "############END COPY TO DATA PACKAGE PHASE###########"
                      echo "################################################"
                    }
                }
            }

            stage('Deploy'){
                agent{
                    label "${pipelineConfig.deployAgent}"
                }
                steps{
                    script{
                      try {
                        echo "###############################################"
                        echo "###############START DEPLOY PHASE##############"
                        echo "###############################################"
                        echo "Start TimeStamp:  ${new Date()}"
						env.current_stage=env.STAGE_NAME
                        echo "running deploy step for ${pipelineConfig.deployType}"
                        switch(pipelineConfig.deployType) {
                          case ~/^backend$/:
                            deployECE_ELKBackEnd pipelineConfig,almsPackage,mergeInfo,NO_RESTART
                            break
                          case ~/^autocreate-backend$/:
                            deployECE_ELKBackEndAutoCreate pipelineConfig,almsPackage,mergeInfo,NO_RESTART,ParamItem2Delete
                            break
                          case ~/^environment-vars$/:
                            deployECE_ELKEnvironmentVars  pipelineConfig,almsPackage
                            break
                          case ~/^logstash-config$/:
                            deployECE_ELKLogstashConfig  pipelineConfig,almsPackage,NO_RESTART
                            break
                          case ~/^filebeat-config$/:
                            deployECE_ELKFilebeatConfig  pipelineConfig,almsPackage,NO_RESTART
                                /////////////////////////
                                //////OLD RESTART///////
                                ////////////////////////
                            //if ("${deploy_env}" != "master")
                                //{
                                //deployECE_ELKFilebeatConfig  pipelineConfig,almsPackage,NO_RESTART
                                //} else {
                                //if ("${pipelineConfig.operateInProd}" == 'N')
                                //{
                                //echo "This is a PROD Deployment and the operateInProd Flag is disabled."
                                //echo "The Start/Stop must to be done by AO after we finish our deployment steps."
                                //echo "Please, Review the log of the stage CopyToRelease and manually launch all the commands of the output if needed"
                                //} else {
                                //deployECE_ELKFilebeatConfig  pipelineConfig,almsPackage,NO_RESTART
                                //}
                                //}
                            break
                          case ~/^alarmas$/:
                            //deployECE_ELKAlarmas  pipelineConfig,almsPackage,mergeInfo
                            deployECE_ELKAlarmasV2  pipelineConfig,almsPackage,mergeInfo,ParamItem2Delete
                            break
                          case ~/^global-utilities$/:
                            //deployECE_ELKGlobalUtilities  pipelineConfig,almsPackage,mergeInfo
                            deployECE_ELKGlobalUtilitiesV2  pipelineConfig,almsPackage,mergeInfo,ParamItem2Delete
                            break
                          case ~/^metricbeat-config$/:
                            deployECE_ELKMetricbeatConfig  pipelineConfig,almsPackage,NO_RESTART
                                /////////////////////////
                                //////OLD RESTART///////
                                ////////////////////////
                            //if ("${deploy_env}" != "master")
                            //{
                                //deployECE_ELKMetricbeatConfig  pipelineConfig,almsPackage,NO_RESTART
                            //} else {
                              //if ("${pipelineConfig.operateInProd}" == 'N')
                              //{
                                //echo "This is a PROD Deployment and the operateInProd Flag is disabled."
                                //echo "The Start/Stop must to be done by AO after we finish our deployment steps."
                                //echo "Please, Review the log of the stage CopyToRelease and manually launch all the commands of the output if needed"
                                //} else {
                                //deployECE_ELKMetricbeatConfig  pipelineConfig,almsPackage,NO_RESTART
                                //}
                                //}
                            break
                          case ~/^winlogbeat-config$/:
                            deployECE_ELKWinlogbeatConfig  pipelineConfig,almsPackage
                            break
                          case ~/^filebeat-config-windows$/:
                            deployECE_ELKFilebeatConfigWindows  pipelineConfig,almsPackage
                            break
                          case ~/^heartbeat-config$/:
                            deployECE_ELKHeartbeatConfig  pipelineConfig,almsPackage,NO_RESTART
                            break
                          case ~/^kibana-objects$/:
                            deployECE_ELKKibanaObjects  pipelineConfig,almsPackage,mergeInfo
                            break
                          case ~/^triage$/:
                             deployECE_ELKTriage  pipelineConfig,almsPackage,NO_RESTART
                             break
                          case ~/^roles$/:
                             //deployECE_ELKRoles  pipelineConfig,almsPackage,mergeInfo
                             deployECE_ELKRolesV2  pipelineConfig,almsPackage,mergeInfo,ParamItem2Delete
                             break
                          case ~/^global-jobs$/:
                             echo "Nothig to do for ${pipelineConfig.deployType} at deploy phase."
                             break
                          case ~/^rollup-jobs$/:
                              deployECE_ELKRollupJob  pipelineConfig,almsPackage,mergeInfo,ParamItem2Delete
                              break
                          case ~/^mappings$/:
                              deployECE_ELKMappings  pipelineConfig,almsPackage,mergeInfo,ParamItem2Delete
                              break
                          case ~/^k8s-beat$/:
                              deployECE_ELKK8s_beat  pipelineConfig,almsPackage,mergeInfo
                              break
                        }
                        echo "End TimeStamp:  ${new Date()}"
                        echo "###############################################"
                        echo "################END DEPLOY PHASE###############"
                        echo "###############################################"
                      }
                      catch (err){
                          echo "############################################"
                          echo "########ERROR IN DEPLOY VISION PHASE########"
                          echo "########ERROR IN DEPLOY VISION PHASE########"
                          echo "############################################"
                          deployECE_ELKRollBack pipelineConfig,almsPackage
                          deployECE_ELKRestart pipelineConfig,almsPackage,NO_RESTART
                          //echo err
                          sh ("exit 1")
                      }
                    }
                }
            }

            stage('TagAndPush'){
                agent {
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                    script{
                      echo "###################################################"
                      echo "###############START TAG & PUSH PHASE##############"
                      echo "###################################################"
                      echo "Start TimeStamp:  ${new Date()}"
                      env.current_stage=env.STAGE_NAME
                      if ("${pipelineConfig.deployType}" == 'winlogbeat-config' || "${pipelineConfig.deployType}" == 'filebeat-config-windows')
                      {
                        if ("${deploy_env}" != 'master')
                        {
                          echo "Tag commit and push to git "
                          gitRepo.tagAndPush pipelineConfig.extractFolder,
                              almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                        }
                        else
                        {
                            echo "Deploy type is winlogbeat-config or filebeat-config-windows and the environment is PROD."
                            echo "THE TAG & PUSH WILL BE DONE AT PROMOTE STAGE IN WORKBENCH"
                            echo "PLEASE WAIT TO PROMOTE IN WORKBENCH UNTIL THE CONFIRMATION THAT THE DEPLOY HAS FINISHED SUCCESSFULLY"
                        }
                      } else {
                        echo "Tag commit and push to git "
                        gitRepo.tagAndPush pipelineConfig.extractFolder,
                            almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                      }
                      echo "End TimeStamp:  ${new Date()}"
                      echo "###################################################"
                      echo "################END TAG & PUSH PHASE###############"
                      echo "###################################################"
                    }
                }
            }

            stage('PublishChanges'){
                agent {
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                  script{
                    echo "########################################################"
                    echo "###############START PUBLISH CHANGES PHASE##############"
                    echo "########################################################"
                    echo "Start TimeStamp:  ${new Date()}"
                    env.current_stage=env.STAGE_NAME
                    if ("${pipelineConfig.deployType}" == 'winlogbeat-config' || "${pipelineConfig.deployType}" == 'filebeat-config-windows')
                    {
                      if ("${deploy_env}" != 'master')
                      {
                        echo "Publish changes to ELK and GitPublish plugin"
                        publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                      }
                      else
                      {
                          echo "Deploy type is winlogbeat-config or filebeat-config-windows and the environment is PROD."
                          echo "THE PUBLISHCHANGES STAGE WILL BE DONE AT PROMOTE STAGE IN WORKBENCH"
                      }
                    }
                    else{
                      echo "Publish changes to ELK and GitPublish plugin"
                      publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                    }

                    echo "End TimeStamp:  ${new Date()}"
                    echo "########################################################"
                    echo "################END PUBLISH CHANGES PHASE###############"
                    echo "########################################################"
                  }
                }
            }
        }
    }
}
