String getBasicAuthFromCredential(String credential){
    String ret=""
    withCredentials([usernamePassword(credentialsId: credential, usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
        String userpass = USERNAME + ":" + PASSWORD
        ret = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
    }
    ret
}
return this