def call(String _bitbucket){
	echo "getBranchList"
    	def SALIDA=""
    	SALIDA=sh returnStdout: true, script: """
	    	    #git branch -r
                if [ "${_bitbucket}" != "bitbucket" ]
                then
	    	        git branch -r | cut -c3- |cut -d"/" -f2 |grep ^ES
                else
	    	        git branch -r | cut -c3- |egrep "(origin/vodafone/ES|origin/release/ES)" |cut -d"/" -f3 
                fi
		    """
	def lista = SALIDA.split("\n").collect{it}
	return lista
}