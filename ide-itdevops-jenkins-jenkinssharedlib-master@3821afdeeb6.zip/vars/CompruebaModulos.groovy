def call(String _ALMS_ID, String _DeployEnv){

hoy=new Date().format( 'yyyyMMdd' )

sh "if [ -d CompruebaModulos ]; then rm -rf CompruebaModulos ; fi ; mkdir CompruebaModulos; cd CompruebaModulos ; scp platafor@es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_ALMS_ID}/${_DeployEnv}/modules.json . "

}
