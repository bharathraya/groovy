def call (String _params,String _dominio,String _entorno,String _package,String _wbID){
    node ('workbenchPPRD'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python replica_datos_pruebas.py ${_params} -d ${_dominio} -e ${_entorno} -p ${_package} ${_wbID}"
        }
    }
}

def call (String _dominio,String _entorno,String _package,String _wbID){
    node ('workbenchPPRD'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python replica_datos_pruebas.py -d ${_dominio} -e ${_entorno} -p ${_package} ${_wbID}"
        }
    }
}