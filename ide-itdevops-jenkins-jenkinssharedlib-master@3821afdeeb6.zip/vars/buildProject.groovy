
def call(String projectFolder,String buildScriptFolder,String buildScriptFile)
{
    sh "cp ${WORKSPACE}/${buildScriptFolder}/${buildScriptFile} ${WORKSPACE}/${projectFolder};chmod 755 "
    sh "chmod 755 ${WORKSPACE}/${projectFolder}/${buildScriptFile}"
    dir("${WORKSPACE}/${projectFolder}"){
        sh "${buildScriptFile}"
    }
}
return this;