
def call(String localPath,String commitBefore,String commitAfter)
{
    dir("${localPath}")   {
        def publisher = LastChanges.getLastChangesPublisher "PREVIOUS_REVISION", "SIDE", "LINE", true, true, "", "${commitBefore}", "", "", ""
        publisher.publishLastChanges()
        //def changes = publisher.getLastChanges()
        //println(changes.getEscapedDiff())
        //for (commit in changes.getCommits()) {
            //println(commit)
            //def commitInfo = commit.getCommitInfo()
            //println(commitInfo)
            //println(commitInfo.getCommitMessage())
            //println(commit.getChanges())
        //}
    }
}
return this;