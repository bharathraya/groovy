def call(String sharedFlow, Object env_config){
    echo "getSharedFlowLastRevision"
    def REVISION=""
    def SALIDA=""
    def maxrev=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
                                credentialsId: "${env_config.credentialid}", 
                                usernameVariable: 'USERNAME', 
                                passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            https_proxy="${env_config.proxyurl}"
            export https_proxy
            no_proxy="${env_config.noproxy}"
            export no_proxy
            curl -X GET --header "Accept: application/json" -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/sharedflows/${sharedFlow}"
        """
        if (SALIDA != ""){
            SFInfo=readJSON(text: "${SALIDA}")
            echo "SFInfo:${SFInfo}"
            if (SFInfo.revision !=null){
                maxrev=SFInfo.revision.max{it.toInteger()}
            }else{
                maxrev="0"
            }
        }else{
            error "curl"
        }
    }
    echo "Maxima revision:[${maxrev}]"
    return maxrev
}