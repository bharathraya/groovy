import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo_aaresmi
import vfes.git.VFESGitMergeInfo_aaresmi

def deploy_env=""
def commit_id=""
def alms_id=""
def delivery=""
def project_id=""
def squad=""

def almsPackage=null
def gitRepo=null
def gitOtherRepo=null
def pipelineConfig=null
VFESGitMergeInfo_aaresmi mergeInfo=null

def call(Map pipelineParams){
    pipeline{
        agent none
        parameters {
            choice(name: 'DeployEnv',  choices: pipelineParams.environmentChoices , description: '')
            string(name: 'CommitID', defaultValue: '', description: '')
            string(name: 'ALMS_ID', defaultValue: '', description: '')
            string(name: 'Delivery', defaultValue: '', description: '')
            string(name: 'ProjectId', defaultValue: '', description: '')
            string(name: 'SQUAD', defaultValue: 'BAU', description: '')
            string(name: 'PackageInfo', defaultValue: '', description: '')
        }
        stages{

            stage("Prepare"){
                agent {
                    label "ECE_ELK"
                }
                steps{
                    script {
                      echo "########################################"
                      echo "###########START PREPARE PHASE##########"
                      echo "########################################"
                      echo "Start TimeStamp:  ${new Date()}"
						            env.current_stage=env.STAGE_NAME
                        if (params.PackageInfo==""){
                            // executed manually or from ALMS
                            deploy_env=params.DeployEnv
                            commit_id=params.CommitID
                            alms_id=params.ALMS_ID
                            delivery=params.Delivery
                            project_id=params.ProjectId
                            squad=params.SQUAD
                        }else{
                            echo "PackageInfo: ${params.PackageInfo}"
                            (deploy_env,commit_id,alms_id,delivery,project_id,squad)=parsePckInfo(PackageInfo)
                        }

                        echo "    DeployEnv: ${deploy_env}"
                        echo "    CommitID:  ${commit_id}"
                        echo "    PackageID: ${alms_id}"
                        echo "    Delivery:  ${delivery}"
                        echo "    Project:   ${project_id}"
                        echo "    Squad:     ${squad}"
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        almsPackage= new VFESALMSDeployment(alms_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,squad)
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
                        // TODO : when
                        gitRepo=new VFESGitRepo_aaresmi("${pipelineConfig.gitRepo}",this)
                        echo "End TimeStamp:  ${new Date()}"
                        echo "########################################"
                        echo "############END PREPARE PHASE###########"
                        echo "########################################"
                    }
                }
            }

            stage('Checkout'){
                agent {
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                    script{
                      echo "#########################################"
                      echo "###########START CHECKOUT PHASE##########"
                      echo "#########################################"
                      echo "Start TimeStamp:  ${new Date()}"
						          env.current_stage=env.STAGE_NAME
                      gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
                      echo "End TimeStamp:  ${new Date()}"
                      echo "#########################################"
                      echo "############END CHECKOUT PHASE###########"
                      echo "#########################################"
                    }
                }
            }

            stage('merge'){
                agent {
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                    script{
                      echo "######################################"
                      echo "###########START MERGE PHASE##########"
                      echo "######################################"
                      echo "Start TimeStamp:  ${new Date()}"
						          env.current_stage=env.STAGE_NAME
                      mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
                      echo "MergeInfo: ${mergeInfo.filesChanged}"
                      echo "MergeInfo Detailed: ${mergeInfo.FilesChangedDetailed}"
                      echo "End TimeStamp:  ${new Date()}"
                      echo "######################################"
                      echo "############END MERGE PHASE###########"
                      echo "######################################"
                    }
                }
            }

            stage('TagAndPush'){
                agent {
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                    script{
                      echo "###################################################"
                      echo "###############START TAG & PUSH PHASE##############"
                      echo "###################################################"
                      echo "Start TimeStamp:  ${new Date()}"
                      env.current_stage=env.STAGE_NAME
                      echo "Tag commit and push to git "
                      gitRepo.tagAndPush pipelineConfig.extractFolder,almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                      echo "End TimeStamp:  ${new Date()}"
                      echo "###################################################"
                      echo "################END TAG & PUSH PHASE###############"
                      echo "###################################################"
                    }
                }
            }

            stage('PublishChanges'){
                agent {
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                  script{
                    echo "########################################################"
                    echo "###############START PUBLISH CHANGES PHASE##############"
                    echo "########################################################"
                    echo "Start TimeStamp:  ${new Date()}"
                    env.current_stage=env.STAGE_NAME
                    echo "Publish changes to ELK and GitPublish plugin"
                    publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                    echo "End TimeStamp:  ${new Date()}"
                    echo "########################################################"
                    echo "################END PUBLISH CHANGES PHASE###############"
                    echo "########################################################"
                  }
                }
            }
        }
    }
}
