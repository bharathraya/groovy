import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario

def _CRQ_ID=""
def _NomVista=""
def _Env=""
def _FechaSanity=""
def _Ventana
def _upgrade=""
def hoy=""
def passUsrPlata=""
def RutaTemp=""
def RutaPaquete=""
def _Orden=""
def pos=0
def _domain=""
def _listado=""
def Testeo
def _Tipo=""
def _nombreCarpeta=""
def fichero_e=""
def fichero_por=""
def fichero_e_backout=""
def _FechaSanityVentana=""
def execCO=""
def exec=""
def AplicacionesFalloTesteo=""


def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            //Nos hace falta nombre de la vista y entorno fecha sanitu?
           //CreaVISTA =No porque ya esta creada
           //Crea_paqeute =SI
           //Crq y lista nada            
            string(name: 'Vista', defaultValue: '', description: 'Name for view with packages')            
            choice(name: 'Entorno',  choices: pipelineParams.environmentChoices , description: 'Environment for window') 
            string(name: 'FechaSanity', defaultValue: '', description: 'Sanity Date <yymmddhhmm>')
         }
         
         stages{     
         stage("Prepare"){
                agent {
                    label 'AMDOCS-PARCHE'
                        }
                steps{
                script {
                        //Leo los parametros
                      
                        _NomVista=params.Vista
                        _Env=params.Entorno
                        _CrearPaquete="SI"
                        _Ventana = true
                        _upgrade="S"
                        hoy=new Date().format( 'yyyyMMdd' )
                        print "Today's date is ......${hoy}......"
                        _FechaSanity=new Date().format( 'yyyyMMddHHmm' )
                  
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        
                        _NomVista = _NomVista.trim()
                                               
                        //Errores de parametros
                         if (_NomVista == "" ){
                           error("View name are required.")
                        }
                       
                        if ( _Env == "" ) { 
                	        error("Environment is required.")
                        }
                        if ( _Env != "SIT1" && _Env != "PPRD" && _Env != "SIT3") { 
                	        error("Environment must to be SIT1 or PPRD or SIT3.")
                        }                                                                         
                       
                        //Saco los datos del que ejecuta la ventana
                         
                        wrap([$class: 'BuildUser']) {
                             //  echo "Exec user: ${env.BUILD_USER_ID}"
                               mybuilduser=env.BUILD_USER_ID
                          }
                               //Contraseña
                           (_pass,mybuilduser)=findpassword(mybuilduser)
                        
                         //Configuramos el nombre del build y su descripcion
                       
                            currentBuild.displayName = "View: ${_NomVista} Date: ${hoy} Environment ${_Env}"
                            currentBuild.description = "View: ${_NomVista} "                                               
                            _CRQ_ID="${_NomVista}"
                            _View = true                                                                      
                        
                        RutaTemp="/home/plataforma/plausr/tmp"
                        RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
                        sh "if [ -d ${RutaPaquete} ] ; then rm -rf ${RutaPaquete} ; fi ; mkdir -p ${RutaPaquete} "
                                               
                        SeparaPaquete2 "${_CRQ_ID}" , _View, _Ventana, _NomVista ,mybuilduser , _pass , _upgrade

                   }//script
                 }//step
            }//prepare
            
            stage("Testeo"){ //Testeo los paquetes
                agent {
                    node("AMDOCS-PARCHE")
                        }

                steps{
                script {
                        print "We test the packages"                                                    
                        sh "touch -f ${RutaPaquete}/AplicacionesFalloTesteo.txt"
                        _domain = "AMDOCS-BBDD"
                        _Tipo=(_domain.split("-")[-1])                                                                                                                       
                       _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")                                                        
                  
                    if (  _listado != "")
                      { //Si hay paquetes de BBDD
                         
                        Testeo = true                                                                    
                        _nombreCarpeta="${_CRQ_ID}_${_Tipo}"
                              
                        //Solo testeamos y extraemos para obtener el e
                        print "****************************************"
                        print "TESTING ON ${_Env} APP: ${_domain} "
                        print "****************************************"
                                        
                        try{
                            txeker("",_domain,_Env,_nombreCarpeta,_listado)
                        } catch(Exception e){
                                                
                        echo "Testing failes on ${_Env} Environment on ${_domain} error: ${e}" 
                        sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteo.txt  "
                        sh " scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${_nombreCarpeta}.${_Env}.errores_testeo  ${RutaPaquete}/ "
                        sh " cat ${RutaPaquete}/${_nombreCarpeta}.${_Env}.errores_testeo >> ${RutaPaquete}/AplicacionesFalloTesteo.txt  "
                        Testeo = false
                                        }
                        if (Testeo == true)
                          {
                              //Llamamos funcio que genera el fichero WB
                              GenerarWBFile "${_CRQ_ID}" , "${_nombreCarpeta}", "${_Env}", "${_domain}" ,true ,  "${_upgrade}"
                              fichero_e="${_nombreCarpeta}.${_Env}.deploy"
                              fichero_por="${_nombreCarpeta}.${_Env}.por_paquete"
                              fichero_e_backout="${_nombreCarpeta}.${_Env}.rollback"                                    
                                   
                              //Copio los fichero a crm50tst02
                              exec="""
                                        . \$HOME/.profile >/dev/null 2>&1
                                        . paquete ${_nombreCarpeta} ${_Env}
                                         export fichero_e="${_nombreCarpeta}.${_Env}.deploy"
                                         export fichero_e_backout="${_nombreCarpeta}.${_Env}.rollback"
                                         export fichero_por="${_nombreCarpeta}.${_Env}.por_paquete"
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_e} e
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_e_backout} e_backout
                                         scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/${fichero_por} ../e_por_paquete
                                         """
                               
                              sh "ssh -q crm50tst02 '${exec}'"
                                        
                              _FechaSanityVentana="${_FechaSanity}00"
                              print "Sanity for windowtime: ${_FechaSanityVentana}"
                              creaOrdenVentanaONO "${_Env}" , "${_CRQ_ID}" , "${_FechaSanityVentana}" , "" ,"devopststtools01"
                                     
                              
                              execCO="""
                                        . \$HOME/.profile >/dev/null 2>&1
                                        . paquete ${_nombreCarpeta} 
                                         scp  crm50tst02:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/orden.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}
                                         scp  crm50tst02:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/orden.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}
                                         touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/Rollback.sql
                                         touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Rollback.sql
                                         """
                                       
                              sh "${execCO}"
                                                                           
                                    
                        }//No ha fallado el testeo
                          
                            
                        //Revisar si han fallado
                        AplicacionesFalloTesteo= readFile(file: "${RutaPaquete}/AplicacionesFalloTesteo.txt")
                        if (AplicacionesFalloTesteo != "" )
                          {
                            print "****************************************"
                            print "        INCORRECT TESTING"
                            print "****************************************"
                            
                            print "These types have been treated ${Tipos}"  
                            print "It is failing on ${_Env} these apps:"
                            print "${AplicacionesFalloTesteo}"
                            error("Test failures. Review")
                          }
                         else
                           {
                            print "********************************************"

                            print "CORRECT TESTING OF APPLICATIONS"
                            
                                //Copiamos en es036tvr los ficheros
                                exec="""
                                . \$HOME/.profile >/dev/null 2>&1 
                                ssh -q es036tvr " . \$HOME/.profile ; . paquete ; if [ -d ${_CRQ_ID} ] ; then  rm -Rf ${_CRQ_ID}/ ; fi ; . paquete ${_CRQ_ID} "
                                . paquete ${_CRQ_ID}
                                scp * es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}
                                
                                """
                                
                               sh "${exec}"
                           
                                print "********************************************"
                                print "         CREATING PACKAGES"
                                print "********************************************"
                                if (_Env =="SIT1")
                                { // DROP ES2225FR
                                     wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                                        create_package(mybuilduser,_pass,_CRQ_ID,_Env,"CM_Ventana_SAT", _upgrade , "Y" )
                                     }//wrap
                                }//SIT1
                                else if (_Env =="SIT3")
                                { // DROP ES2225FR 
                                     wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                                        create_package(mybuilduser,_pass,_CRQ_ID,_Env,"CM_Ventana_SAT", _upgrade , "Y" )
                                     }//wrap
                                }//SIT3
                                else if (_Env =="PPRD")
                                { // DROP  ES2230FR 
                                    wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                                        create_package(mybuilduser,_pass,_CRQ_ID,_Env,"CM_Ventana_SIT", _upgrade , "Y" )
                                    }//wrap
                                }//PPRD
                              
                               //Añadimos los paquetes como oow
                                print "********************************************"
                                print "         Packages will be OOW"
                                print "********************************************"                             
                             
                           }//Si hay paquetes de BBDD                       
                    }//scripts
                }//steps
            }//Testeo
          
         }//stages
        }//pipeline
    }//map
  }//map
