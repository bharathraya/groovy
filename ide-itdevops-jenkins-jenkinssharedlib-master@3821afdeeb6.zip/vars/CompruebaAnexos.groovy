def call(String _ALMS_ID, String _DeployEnv){

hoy=new Date().format( 'yyyyMMdd' )

sh "if [ -d CompruebaAnexos ]; then rm -rf CompruebaAnexos ; fi ; mkdir CompruebaAnexos; cd CompruebaAnexos ; scp platafor@es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_ALMS_ID}/${_DeployEnv}/anexos.json . "

}
