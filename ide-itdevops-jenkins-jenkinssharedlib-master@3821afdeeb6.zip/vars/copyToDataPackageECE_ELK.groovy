import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo

def call(Map config,VFESALMSDeployment alms)
{

  for (i=0;i<config.artifactId.size();i++){
      def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
      def _envConfig=myEnvsConfig[alms.deployEnv]
      echo "_envConfig"+_envConfig['copyToDataPaquete']

      _envConfig['copyToDataPaquete'].each { item ->
        def env=""
        if ("${alms.deployEnv}" != 'master')
        {
          env="${alms.deployEnv}"
        } else {
          env="PROD"
        }
        def dataPaquetePath="${item.dataPaquete_path}/${alms.jobDate}/${alms.almsID}/${env}"
        echo "==> Creating data paquete path"
        sh "ssh platafor@${item.server} 'rm -fr ${dataPaquetePath}/* 2>/dev/null'"
        sh "ssh platafor@${item.server} 'mkdir -p ${dataPaquetePath}'"
        echo "==> Check if there is files for this env"
        def count_env=sh(script:"ls -1 ./${config.extractFolder}/*_${env} | wc -l", returnStdout: true).trim()
        if ("${count_env}" != "0")
        {
          echo "==> Moving file(s) from ${config.extractFolder} to .env ${dataPaquetePath} ..."
          sh "cp -rp ./${config.extractFolder}/* ${dataPaquetePath}"
          echo "==> Renaming file for the env without _${env} ..."
          sh """
            cd ${dataPaquetePath}
            for file in *_${env}; do
            mv "\${file}" "\${file/_${env}/}"
            done
          """
        } else {
          echo "ERROR. There's not files _${env} for this environment ${env} in the package"
          sh ("exit 1")
        }
      }
    }
}
