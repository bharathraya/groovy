import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.json.JsonBuilder

def _DeployEnv=""
def _ALMS_ID=""
def _Domain=""
def _listapaquetes=""
def pipelineConfig=null
def modulesUserName=""
def modulesHostIP=""
def modulesPackageBasePath=""
def proxyUserName=""
def proxyPackageBasePath=""
def deployConfig=null
def ModulesJSON=null
def hoy=null
def LocalBasePath=null
def LocalHostName=""
def AR_StartStop=null
def contextPathToRestart=""
def proxyServers=""
def URLMicroServiceStart=""
def MicroServicePort=""
def keyfilePath=""
def keyfileName=""

def returnSplitName (String full_name){
    def _order=null
    def _package=null
    def _context=null
    def _free=null
    def _extension=null

    int sepPos1 = full_name.indexOf('_')
    if (sepPos1 == -1) {
        return [_order,_package,_context,_free,_extension]
    }
    _order=full_name.substring(0,sepPos1).trim()


    int sepPos2 = full_name.indexOf('_',sepPos1+1)
    if (sepPos2 == -1) {
        return [_order,_package,_context,_free,_extension]
    }
    _package=full_name.substring(sepPos1+1,sepPos2).trim()


    int sepPos3 = full_name.indexOf('_',sepPos2+1)
    if (sepPos3 == -1) {
        return [_order,_package,_context,_free,_extension]
    }
    _context=full_name.substring(sepPos2+1,sepPos3).trim()


    int sepPos4 = full_name.lastIndexOf('.')
    if (sepPos4 == -1) {
        return [_order,_package,_context,_free,_extension]
    }
    _free=full_name.substring(sepPos3+1,sepPos4).trim()
    _extension=full_name.substring(sepPos4+1).trim()


    return [_order,_package,_context,_free,_extension]
}

def getContextPath (String Name)
{
    (_order,_package,_context,_free,_extension)=returnSplitName(Name)
    return _context
}

def getProxyServer (String Name)
{
    _context=Name + '_'
    _proxy=deployConfig[_DeployEnv]["DataBases"][_context].ip
    return _proxy
}

def findRollBackModuleFileName (String Module)
{
    goModuleJSON=ModulesJSON['Modules'].find{it.IsRollback == 0 && it.FileName == Module}
    RollBackModulesJSON=ModulesJSON['Modules'].find{it.IsRollback == 1 && it.ModuleDependenceWorkBenchId == goModuleJSON.WorkBenchId}

    return RollBackModulesJSON.FileName
}

def findBinaryFromContext(String context, String ip, String name){
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 3
    remote.retryWaitSec = 2
    remote.timeoutSec = 5
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
        connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
        {
            remote.host = ip
            remote.name = name
            remote.identityFile = keyfile
            compose_ret=" --command=\"deployment-info\" | grep \"${context}\" | awk '{print \$1\" \"\$4}'| grep \"true\"| wc -l"
            command=connect + compose_ret
            echo "        =>Command: ${command}"
            ret=sshCommand remote: remote, command:"${command}"
            if (ret != "1")
            {
                return
            }
            compose_bin=" --command=\"deployment-info\" | grep \"${context}\" | awk '{print \$1\" \"\$4}'| grep \"true\" | awk '{print \$1}'"
            command=connect + compose_bin
            bin_name=sshCommand remote: remote, command:"${command}"
            return bin_name
        }
    }
}

def extractKeyFile ()
{
  sh (script: "rm -fr ${keyfilePath}", returnStatus: false)
  sh ("mkdir -p ${keyfilePath}")
  withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
    niceKeyFile="${keyfile}"
    sh ("cp ${niceKeyFile} ${keyfilePath}/.")
  }
}

def call(Map pipelineParams){
        pipeline{
            agent {label "SCHAMAN-Consolas"}
            parameters {
                string(name: 'WB_ID', defaultValue: '', description: 'WB ID or CRQ ID')
                string(name: 'Application', defaultValue: '', description: 'Application to deploy')
                string(name: 'Enviroment', defaultValue: '', description: 'Enviroment to deploy')
                string(name: 'List_Packages', defaultValue: '', description: 'List of package for deploy')
                string(name: 'PackageInfo', defaultValue: '', description: 'WB info')
                string(name: 'UserDB', defaultValue: '', description: 'DB USer')
                string(name: 'PasswordDB', defaultValue: '', description: 'DB Password USer')
            }
            stages{
                stage("Prepare"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "===================PREPARE==================="
                            echo "============================================="
                            echo "============================================="

                            if (PackageInfo==""){
                               //LLamada manual

                               _DeployEnv=params.Enviroment
                               _ALMS_ID=params.WB_ID
                               _Domain=params.Application
                               _listapaquetes=params.List_Packages
                               _UsuarioBD=params.UserDB
                               _PasswordDB=params.PasswordDB
                              if (_listapaquetes==""){
                                  _listapaquetes=params.WB_ID
                              }

                              echo "lista paquetes ${_listapaquetes}"
                              replica_datos(_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                            }else{
                                error(" WorkBench execution is not allowed !!!!")
                            }

                            if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="" || _UsuarioBD == "" || _PasswordDB == "") {
                                error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] are mandatories.")
                            }

                            if(_DeployEnv != "PROD") {
                                error("Only allowed for PROD!!!.")
                            }

                            hoy=new Date().format('yyyyMMdd')
                            pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                            deployConfig=readJSON(file: pipelineConfig.deployConfig)

                            currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Domain}"
                            currentBuild.description = "Lista: ${_listapaquetes} Entorno: ${_DeployEnv} Aplicación: ${_Domain}"

                            echo "Deploy Info:"
                            echo "    Package Name:      ${_ALMS_ID}"
                            echo "    Domain:            ${_Domain}"
                            echo "    DeployEnv:         ${_DeployEnv}"
                            echo "    Packages IDs:      ${_listapaquetes}"
                            echo "    DB User:           ${_UsuarioBD}"
                            echo "    DB Password:       **********"
                            modulesUserName=pipelineConfig.annexesUser
                            modulesHostIP=pipelineConfig.annexesServer
                            modulesPackageBasePath=pipelineConfig.annexesBasePath + '/' + hoy + '/' + _ALMS_ID +  '/'+ _DeployEnv
                            proxyUserName=pipelineConfig.releaseUser
                            proxyPackageBasePath=pipelineConfig.packagesPath + '/' + hoy + '/' + _ALMS_ID +  '/'+ _DeployEnv
                            URLMicroServiceStart=pipelineConfig.URLMicroServiceStart
                            MicroServicePort=pipelineConfig.MicroServicePort
                            LocalHostName="hostname".execute().text
                            LocalUserName="id -u -n".execute().text
                            LocalBasePath=sh(script:"pwd",returnStdout: true).trim()
                            LocalPackageBasePath = LocalBasePath + '/' + hoy + '/' + _ALMS_ID + '/'+ _DeployEnv
                            keyfilePath=LocalBasePath + '/' + hoy + '/' + _ALMS_ID + '/' + ".secretFiles"
                            keyfileName="ssh-key-keyfile"
                        }
                    }
                }
                stage("Previous Checks"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            AR_StartStop=[]
                            echo "============================================="
                            echo "============================================="
                            echo "===============PREVIOUS CHECKS==============="
                            echo "============================================="
                            echo "============================================="
                            echo "==> Main Servers Info <=="
                            echo "   ==> Remote Server info:"
                            echo "       Modules User Name:             ${modulesUserName}"
                            echo "       Modules Server:                ${modulesHostIP}"
                            echo "       Modules Package Base Path:     ${modulesPackageBasePath}"

                            echo "   ==> Local Server info:"
                            echo "       Modules User Name:             ${LocalUserName}"
                            echo "       Modules Server:                ${LocalHostName}"
                            echo "       Modules Package Base Path:     ${LocalPackageBasePath}"

                            echo "   ==> Proxy Server info:"
                            echo "       Proxy User Name:               ${proxyUserName}"
                            echo "       Proxy Package Base Path:       ${proxyPackageBasePath}"

                            echo "==> Extract keyfile to connection to SCHAMAN servers <=="
                            extractKeyFile()

                            echo "==> Get Modules to local server <=="
                            echo "   ==> Clean Local Modules Package Base Path"
                            sh(script:"rm -fr ${LocalPackageBasePath};exit 0")
                            sh(script:"mkdir -p ${LocalPackageBasePath}")
                            echo "   ==> Get Modules from Remote Server to the LocalServer"
                            sh("scp -r -o ConnectTimeout=30 ${modulesUserName}@${modulesHostIP}:${modulesPackageBasePath}/* ${LocalPackageBasePath}/.")
                            echo "   ==> Read Modules.json"
                            ModulesJSONFile=LocalPackageBasePath + '/'+ "modules.json"
                            ModulesJSON=readJSON(file: ModulesJSONFile)

                            echo "==> Checking Name Format, and context and Database info in the configuration file"
                            _contextPathToRestart=[]
                            _proxyServers=[]

                            for( goModule in ModulesJSON['Modules'].findAll{it.IsRollback == 0})
                            {
                                goModuleName = goModule.FileName
                                (_order,_package,_context,_free,_extension)=returnSplitName(goModuleName)

                                if (_extension == null || _context == null || _free == null || _order == null || _package == null)
                                {
                                  echo "        ERROR. Module ${goModuleName} with incorrect naming"
                                  echo "               The naming must to be {order}_{package}_{contextPath}_{FreeText}.sql"
                                  sh "exit 1"
                                }

                                if (_extension == "" || _context == "" || _free == "" || _order == "" || _package == "")
                                {
                                  echo "        ERROR. Module ${goModuleName} with incorrect naming"
                                  echo "               The naming must to be {order}_{package}_{contextPath}_{FreeText}.sql"
                                  sh "exit 1"
                                }

                                if (_extension != "sql")
                                {
                                  echo "        ERROR. Module ${goModuleName} with incorrect naming"
                                  echo "               The naming must to be {order}_{package}_{contextPath}_{FreeText}.sql"
                                  sh "exit 1"
                                }

                                _context=_context+"_"
                                _existe=deployConfig[_DeployEnv]["Environment"][_context]
                                if (_existe == null)
                                {
                                    echo "        ERROR. Context ${_context} not found at deploy config file for the env ${_DeployEnv} at Environment Section"
                                    sh "exit 1"
                                }

                                _existeDBInfo=deployConfig[_DeployEnv]["DataBases"][_context]
                                if (_existeDBInfo == null)
                                {
                                    echo "        ERROR. Context ${_context} not found at deploy config file for the env ${_DeployEnv} at DataBases Section"
                                    sh "exit 1"
                                }

                                _proxyServers+=deployConfig[_DeployEnv]["DataBases"][_context].ip
                                _contextPathToRestart+=_context
                                echo "  ==> For file ${goModuleName} and context ${_context}:"
                                echo "      Naming => OK"
                                echo "      Configuration at Environment Section => OK"
                                echo "      Configuration at DataBases Section => OK"
                            }

                            proxyServers=new LinkedHashSet<String>(_proxyServers)
                            contextPathToRestart=new LinkedHashSet<String>(_contextPathToRestart)

                            echo "==> Load In-Memory HashMap List for Start/Stop Actions <=="
                            for (_context in contextPathToRestart)
                            {
                              _existeFirst=deployConfig[_DeployEnv]["Environment"][_context].first()
                              _BinaryName=findBinaryFromContext(_context,_existeFirst.ip,_existeFirst.name)
                              if (_BinaryName == null){
                                echo "          Context ${_context} without Binary"
                                _AR_StartStop=[context: "${_context}", binaryName: ""]
                              }
                              else{
                                echo "          Context ${_context} corresponds to the Binary ${_BinaryName}"
                                _AR_StartStop=[context: "${_context}", binaryName: "${_BinaryName}"]
                              }

                              AR_StartStop+=_AR_StartStop
                            }
                            echo "AR_StartStop=${AR_StartStop}"

                            echo "==> Check RollBack Modules"
                            for (ModuleJSON in ModulesJSON['Modules'].findAll{it.IsRollback == 0})
                            {
                                RollBackModuleFileName=findRollBackModuleFileName(ModuleJSON.FileName)
                                if (RollBackModuleFileName=="" || RollBackModuleFileName==null){
                                    error("Module ${ModuleJSON.FileName} without RollBack Module. We cannot continue!!!!!")
                                }
                            }
                        }
                    }
                }
                stage("Upload Modules"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "================UPLOAD MODULES==============="
                            echo "============================================="
                            echo "============================================="

                            def remote = [:]
                            remote.user = pipelineConfig.releaseUser
                            remote.allowAnyHosts = true
                            remote.retryCount = 3
                            remote.retryWaitSec = 2
                            remote.timeoutSec = 5

                            echo "==> Order Files to upload in group for each proxyserver"
                            for (proxy in proxyServers)
                            {
                              echo "  ==> Creating path ${LocalPackageBasePath}/${proxy}"
                              sh(script:"mkdir ${LocalPackageBasePath}/${proxy}")
                            }

                            echo "==> Move Files to the path created by each proxyserver"
                            for( goModule in ModulesJSON['Modules'].findAll{it.IsRollback == 0})
                            {
                              goModuleName = goModule.FileName
                              context=getContextPath(goModuleName)
                              proxy=getProxyServer(_context)
                              RollBackModuleFileName=findRollBackModuleFileName(goModuleName)
                              echo "  ==> Moving ${goModuleName}//${RollBackModuleFileName} to ${LocalPackageBasePath}/${proxy}"
                              sh(script:"mv ${LocalPackageBasePath}/DataModules/${goModuleName} ${LocalPackageBasePath}/${proxy}/.")
                              sh(script:"mv ${LocalPackageBasePath}/DataModules/${RollBackModuleFileName} ${LocalPackageBasePath}/${proxy}/.")
                            }

                            echo "==> Upload Modules to proxies"
                            for (proxy in proxyServers)
                            {
                              remote.host = proxy
                              remote.name = proxy
                              echo "  ==> Upload Modules to ${proxy}"
                              withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
                              {
                                remote.identityFile = keyfile
                                echo "    ==> Cleaning ${proxyPackageBasePath}"
                                sshCommand remote: remote, command:"rm -fr ${proxyPackageBasePath}", failOnError:false
                                sshCommand remote: remote, command:"mkdir -p ${proxyPackageBasePath}"
                                echo "    ==> Uploading ...."
                                sh("scp -r -o ConnectTimeout=30 -i ${keyfile} ${LocalPackageBasePath}/${proxy}/* ${proxyUserName}@${proxy}:${proxyPackageBasePath}/.")
                              }
                            }
                        }
                    }
                }

                stage("Print Stop Actions"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "=============================================="
                            echo "==============PRINT STOP ACTIONS=============="
                            echo "==============PRINT STOP ACTIONS=============="
                            echo "=============================================="

                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
                            {
                                user="${USERNAME}"
                                pass="${PASSWORD}"
                            }
                            connectJBOSS="${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=${user} -p=${pass}"

                            for (_context in contextPathToRestart)
                            {
                                _ar=AR_StartStop.find{it.context == _context}
                                _binaryName=_ar.binaryName
                                if (_binaryName != "")
                                {
                                    disable=" --command=\\\"deployment disable ${_binaryName}\\\""
                                    _arEnv=deployConfig[_DeployEnv]["Environment"][_context]
                                    echo "  ==> Actions to DISABLE MicroService ${_binaryName}"
                                    for (_server in _arEnv)
                                    {
                                        connectSSH="ssh -i${keyfilePath}/${keyfileName} ${proxyUserName}@${_server.ip} "
                                        command=connectSSH + connectJBOSS + disable
                                        echo "    FROM:              ${LocalHostName}"
                                        echo "    EXECUTE DISABLE:   ${command}"
                                    }
                                }
                                else
                                {
                                    echo "Context:${_context} found without binary. Maybe is a new binary. Nothing to do"
                                }
                            }
                        }
                    }
                }

                stage("Print DB Actions"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "=============================================="
                            echo "===============PRINT DB ACTIONS==============="
                            echo "===============PRINT DB ACTIONS==============="
                            echo "=============================================="

                            schamanDBproxyCommand="java -jar ${pipelineConfig.schamanDBproxyPath}/${pipelineConfig.schamanDBproxyJar} -u ${_UsuarioBD} -p ${_PasswordDB}"

                            for (ModuleJSON in ModulesJSON['Modules'].findAll{it.IsRollback == 0})
                            {
                                (_Order,_Package,_Context,_Free,_Extension)=returnSplitName(ModuleJSON.FileName)
                                _Context=_Context+'_'
                                _DBInfo=deployConfig[_DeployEnv]["DataBases"][_Context]
                                GOModuleFileName=" -f ${proxyPackageBasePath}/${ModuleJSON.FileName}"
                                RollBackModuleFileName=" -f ${proxyPackageBasePath}/" + findRollBackModuleFileName(ModuleJSON.FileName)
                                DBproxyServer=" -S ${_DBInfo.databaseServer}"
                                DBproxyDBName=" -D ${_DBInfo.database}"
                                DBproxyPort=" -P ${_DBInfo.Port}"
                                DBproxyConnParam= " -C \"${_DBInfo.Parameters}\""
                                command=schamanDBproxyCommand + DBproxyServer + DBproxyPort + DBproxyDBName + DBproxyConnParam + GOModuleFileName
                                commandRollBack=schamanDBproxyCommand + DBproxyServer + DBproxyPort + DBproxyDBName + DBproxyConnParam + RollBackModuleFileName
                                echo "    FROM:      ${LocalHostName}"
                                echo "    AT :       ssh -i${keyfilePath}/${keyfileName} ${pipelineConfig.releaseUser}@${_DBInfo.ip}"
                                echo "    GO :       ${command}"
                                echo "    ROLLBACK:  ${commandRollBack}"
                                echo " "
                            }
                        }
                    }
                }

                stage("Print Start Actions"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "==============================================="
                            echo "==============PRINT START ACTIONS=============="
                            echo "==============PRINT START ACTIONS=============="
                            echo "==============================================="
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
                            {
                                user="${USERNAME}"
                                pass="${PASSWORD}"
                            }
                            connectJBOSS="${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=${user} -p=${pass}"
                            activate_command="curl -s --location --request POST "
                            for (_context in contextPathToRestart)
                            {
                                _context_to_start=_context.substring(0, _context.length() - 1)
                                _ar=AR_StartStop.find{it.context == _context}
                                _binaryName=_ar.binaryName
                                if (_binaryName != "")
                                {
                                    enable=" --command=\\\"deployment enable ${_binaryName}\\\""
                                    _arEnv=deployConfig[_DeployEnv]["Environment"][_context]
                                    echo "  ==> Actions to ENABLE and ACTIVATE MicroService ${_binaryName}"
                                    for (_server in _arEnv)
                                    {
                                        url_curl="\"http://${_server.ip}:${MicroServicePort}/"
                                        connectSSH="ssh -i${keyfilePath}/${keyfileName} ${proxyUserName}@${_server.ip} "
                                        command=connectSSH + connectJBOSS + enable
                                        echo "    FROM:             ${LocalHostName}"
                                        echo "    EXECUTE ENABLE:   ${command}"
                                        command=connectSSH + activate_command + url_curl + _context_to_start + "${URLMicroServiceStart}" + "\""
                                        echo "    EXECUTE ACTIVATE: ${command}"
                                    }
                                }
                                else
                                {
                                    echo "Context:${_context} found without binary. Maybe is a new binary. Nothing to do"
                                }
                            }
                        }
                    }
                }

            }
        }
    }
