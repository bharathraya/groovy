
def report(report_workspace="${WORKSPACE}") {
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'syncReposBitBucket', usernameVariable: 'USERNAME',
                      passwordVariable: 'PASSWORD']]) {
        script{
            if (!fileExists('idg-didi-kiuwan-utils')) {
                sh 'git clone https://$USERNAME:$PASSWORD@webpre-adm.es.sedc.internal.vodafone.com:42520/bitbucket/scm/idg-didi/idg-didi-kiuwan-utils.git -b master'
            }
            sh 'pip install -r idg-didi-kiuwan-utils/requirements.txt'

            def jacocoFiles = resolveJacocoFiles("${report_workspace}").collect { "-f $it" }

            if(jacocoFiles.size() > 1) {
				dir ("${report_workspace}"){
					def result = sh(script: "python3 -u ${WORKSPACE}/idg-didi-kiuwan-utils/jacoco_aggregate.py ${jacocoFiles.join(' ') }",
							returnStdout: true).split("\r?\n")
					result.each { echo "$it"}
				}


            }

            if (!fileExists("${report_workspace}/target/site/${env.DIR_JACOCO}/jacoco.xml")){
                echo "No existe fichero en ${report_workspace}/target/site/${env.DIR_JACOCO}/jacoco.xml"
                env.switchUT = "false"
            }

            def lines = sh(script: "python3 -u ${WORKSPACE}/idg-didi-kiuwan-utils/generate_reports_delivery.py --dir_jacoco=$env.DIR_JACOCO --workspace=${report_workspace}/",
                    returnStdout: true).split("\r?\n")
            lines.each { echo "$it"}
            println "${env.switchUT}"
            jacocoFiles = resolveJacocoFiles("${report_workspace}").join(' ')
            echo "JacocoFiles $jacocoFiles"
        }
    }
}

def resolveJacocoFiles(Directory) {
    echo "---------------------------------------Into kiuwan.resolveJacocoFiles function---------------------------------------"
    def returnXmlFiles = []
    dir("${Directory}"){
        def xmlFiles = findFiles glob:"**/*jacoco*.xml"?:['']
        echo "XML FILES : ${xmlFiles.collect { it.path }}"
        returnXmlFiles = xmlFiles.collect { it.path }
    }
    echo "---------------------------------------End kiuwan.resolveJacocoFiles function---------------------------------------"
    return returnXmlFiles

}

def mergeJacocoFiles(files) {

}