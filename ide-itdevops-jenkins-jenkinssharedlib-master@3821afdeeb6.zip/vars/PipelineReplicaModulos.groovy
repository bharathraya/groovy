#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

def call(Map pipelineParams){
    pipeline{
         agent none
        parameters { 
            string(name: 'WB_ID', defaultValue: '', description: 'WB ID or CRQ ID') 
            string(name: 'Application', defaultValue: '', description: 'Application to deploy: GENEVA-ONO-BILLING, GENEVA-ONO-MAPEOS-BILLING,GENEVA-ONO-MAPEOS-RATING') 
            string(name: 'Enviroment', defaultValue: '', description: 'Enviroment to deploy: SIT1, SIT2, PPRD, PROD') 
            string(name: 'List_Packages', defaultValue: '', description: 'List of package for deploy') 
         }

        stages{     
         stage("Prepare"){
                agent {
                    label 'MEDIACION'
                        }
                    steps{
                    script {
                   
                    hoy=new Date().format( 'yyyyMMdd' )
                    print "La fecha de hoy es ......${hoy}......"
                    
                    //leemos el fichero de configuracion
                    pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                    //leemos el fichero de entornos
                    envsConfig=pipelineConfig.envConfig
                   
                    _DeployEnv=params.Enviroment  
                    _ALMS_ID=params.WB_ID  
                    _Domain=params.Application
                    _listapaquetes=params.List_Packages
                    if (_listapaquetes==""){
                        _listapaquetes=params.WB_ID  
                    }
                             
                    //echo "lista paquetes ${_listapaquetes}"   
                    //Ejecutamos el replica_datos
                    replica_datos(_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                    //Funcion que lee los modulos de datos
                    CompruebaModulos "${_ALMS_ID}", "${_DeployEnv}"
                    mydataModulesMap= readJSON(file: "CompruebaModulos/modules.json")
                    
                    if(mydataModulesMap.Modules == "null"){
                         _dataModules=""    
                     }else{
                         _dataModules=mydataModulesMap.Modules
                     }
                
                    if({_dataModules}==""){
                         _HayModulosDatos=0  
                    }
                    else{
                          _HayModulosDatos=_dataModules.size()
                    }

                    //Leo el server donde ejecutar  
                    enviroments=readJSON(file: "${envsConfig}")
                    
                    
                    if ("${_DeployEnv}" == "PROD")
                        {
                            _serverPROD=_server
                            //Cambiamos al server de SPPR
                            _server=enviroments["${_Domain}"]["${_DeployEnv}"]["serverSPPR"][0][0]
                       }
                       else
                       {
                           _serverPROD=""
                           _server=enviroments["${_Domain}"]["${_DeployEnv}"]["server"][0][0]
                       }
                    //inicializamos variables
                    _HayAnexos=0
                    _HayModulosPVCS=0
                    callFromWB=true
                    _serverSVN=""
                    //Actualizo info del paquete    
                    currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Domain}"
                    currentBuild.description = "Lista: ${_listapaquetes} Entorno: ${_DeployEnv} Aplicación: ${_Domain}"
                    
                }//script
         }//step
    }//prepare
    
    stage("ReplicaModulosDatos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_server}"
                        }
                    //Cargamos la info del paquete en almsPackage para las ejecuciones de funciones
                    almsPackage= new VFESALMSDataRetriever( _ALMS_ID, _Domain, _DeployEnv,  _serverAenviar, _HayModulosPVCS, _dataModules, _HayAnexos, callFromWB, _serverSVN, _serverPROD, _listapaquetes )
                    if ("${_DeployEnv}" == "PROD")
                    {
                      //  funcion copiar modulos a PROD
                         _funcionAejecutar="CopiaModulosPROD.groovy"
                     }
                    else{
                        //Copio los modulos a la ruta 
                        _funcionAejecutar="getFromAnexosCat.groovy" 
                    }
                    print "funciona a ejecutar ${_funcionAejecutar}"
                    def ejecutar="CDM/Jenkins/WORKBENCH/common/${_funcionAejecutar}"
                    def clase=load "${ejecutar}"
                    clase.execute(almsPackage)

                    }//scripts
                }//steps
            }//OrdenBBDD


                    
        }//stages
        }//pipeline
    }//map

