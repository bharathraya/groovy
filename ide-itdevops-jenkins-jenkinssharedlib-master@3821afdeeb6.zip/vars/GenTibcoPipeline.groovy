#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever
import groovy.time.TimeCategory
//ansicolor-plugin

// Parametros necesario
def _CRQ_ID=""
def _listapaquetes=""
def _opcion=""
def _NomVista=""
def _Application=""
def _nodo=""
def _env=""
def hoy=""
def pipelineConfig=""
def envsConfig=""
def enviroments=""
def _serverPPRD=""
def RutaTemp=""
def RutaPaquete=""
def Tipos=""
def TipoDespliegues=""
def tamanoDesp=""
def _domain=""
def _listado =""
def _Tipo=""
def _nombreCarpeta=""
def ListaMod=""
def TamSQL=""
def posi=""
def pos=""
def Paquete=""
def mybuilduser=""

def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'CRQ_ID', defaultValue: '', description: 'CRQ ID') 
            string(name: 'List_Packages', defaultValue: '', description: 'List of packages for CRQ')
            string(name: 'View', defaultValue: '', description: 'Name of the view with the packages to deploy') 
            choice(name: 'Application', choices: pipelineParams.applicationChoices, description: 'Application to deploy') 
            choice(name: 'Option',  choices: pipelineParams.OptionChoices , description: 'Choice option:1. Test Code 2. Prepare Deployment 3. Label Code and Promote packages') 
         }
    stages{
        
        stage("Definition") {
             agent {
                    label 'eswltbhr'
                        }

            steps{
                script {
                    
                    //Saco el que lo ejecuta
                     wrap([$class: 'BuildUser']) {
                     echo "Exec user: ${env.BUILD_USER_ID}"
                         mybuilduser=env.BUILD_USER_ID
                       }
                     //Busco la contraseña
                     (_pass,mybuilduser)=findpassword(mybuilduser)
                              

                      //Leo los parametros
                       _CRQ_ID=params.CRQ_ID.trim()  
                       _listapaquetes=params.List_Packages
                       _opcion=params.Option
                       _NomVista=params.View.trim()
                       _Application=params.Application
                       
                      if (_Application == "BW_AMX")
                      {
                         _nodo="tibap19p"
                      }
                      else {
                         _nodo="eswltbhr"
                      }
                }//script
            }//Step
        }//Definition
        
         stage("Prepare"){
                agent {
                    node("${_nodo}")
                        }
                steps{
                script {
                        _env ="prd"
                        hoy=new Date().format( 'yyyyMMdd' )
                        tomorrow =  new Date().plus(1).format( 'yyyyMMdd' )
                         
                        print "Date for today ......${hoy}......"
                
                        //leemos el fichero de configuracion
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        //leemos el fichero de entornos
                        envsConfig=pipelineConfig.envConfig
                        enviroments=readJSON(file: "${envsConfig}")
                        if (_Application != "BW_AMX" && _Application != "BW" )
                        {   
                            _serverPPRD=enviroments["${_Application}"]["ppr"]["server"][0][0]
                        }
                        else{ 
                             if (_Application == "BW_AMX")
                             {
                                    _serverPPRD="tibap19p"
                             }
                             else if (_Application == "BW")
                             {
                                 _serverPPRD="tib-bd5-p"
                             }
                             
                        }
                        print "Server which we were execute ${_serverPPRD} "
                        
                       //Miramos si los parametros están bien
                        if (_CRQ_ID == "" && _NomVista == "" ){
                           error("Nombre del CRQ o Nombre de la vista son obligatorios.")
                        }
                       
                       if(_CRQ_ID != "" && _listapaquetes == "" && _NomVista == "" ) { 
                	        error("Es necesaria una lista de paquetes para este CRQ ${_CRQ_ID}.")
                        }
                        if(_CRQ_ID != "" && (_listapaquetes != "" && _NomVista != "" ) ) { 
                	        error("Los paquetes vienen en la lista o en la vista.")
                        }

                        if (_opcion == "" || (_opcion != "1" && _opcion != "2" && _opcion != "3" ) ){
                            error("Hay que indicar una opcion entre 1 y 3.")
                        }
                        
                        
                         if (_CRQ_ID != "")
                        {
                            currentBuild.displayName = "CRQ: ${_CRQ_ID} Application: ${_Application} Opcion ${_opcion}"
                            if (_listapaquetes != "")
                            {
                                currentBuild.description = "CRQ: ${_CRQ_ID} Lista Paquetes: ${_listapaquetes} "
                            }
                            else if (_NomVista!= "")
                            {
                                currentBuild.description = "CRQ: ${_CRQ_ID} Vista: ${_NomVista} "
                            }
                            
                        }
                        else
                        {
                            currentBuild.displayName = "Vista: ${_NomVista} Dia: ${hoy} Opcion ${_opcion}"
                            currentBuild.description = "Vista: ${_NomVista} "
                        }
                        
                        
                        if (_CRQ_ID == "" &&  _NomVista != "")
                        {  //No hay CRQ
                            _CRQ_ID="${_NomVista}"
                            _View = true
                        }
                        else if (_CRQ_ID != "" &&  _NomVista != "")
                        {  //Hay crq y lista de paquetes en la vista
                            _View = true
                        }
                        else if ( _NomVista == "")
                        {  //NO hay vista
                            _View = false
                        }

                        //Escribo las opciones
                        //'Elige las opciones:1. Separa y Testeo 2. Ejecuciones 3. Versionar'
                        if ( _opcion=="2" ) 
                        {
                            print "******************************"
                            print "Option 2: Prepare Deployment"
                            print "Name of deployment package ${_CRQ_ID} "
                            print "******************************"
                        }  
                         if ( _opcion=="1" ) 
                        {
                            print "******************************"
                            print "Option 1: Test Code"
                            print "Name of deployment package ${_CRQ_ID} "
                            print "******************************"
                        }  
                        if ( _opcion=="3" ) 
                        {
                            print "******************************"
                            print "Option 3: Label Code"
                            print "Name of deployment package ${_CRQ_ID} "
                            print "******************************"
                        } 
                        RutaTemp="/home/plataforma/plausr/tmp"
                        RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
                        sh "if [ -d ${RutaPaquete} ] ; then rm -rf ${RutaPaquete} ; fi ; mkdir -p ${RutaPaquete} "
                       
                        //Reviso si los paquetes estan promocionados
                        if (_View == true)
                        {
                            _listapaquetes=""
                            //Lanzo sacar paquete de la vista
                            if ( "${_CRQ_ID}" != "${_NomVista}" )
                            {   //Hay vista y CRQ
                                get_packagesbyview(_NomVista,mybuilduser,_pass)
                                
                                //lo muevo al directorio del nombre del CRQ
                                exec="""
                                . \$HOME/.profile >/dev/null 2>&1
                                . paquete  ${_CRQ_ID} >/dev/null 2>&1
                                cp  /home/plataforma/plausr/data/paquetes/${hoy}/${_NomVista}/ListaPaquetes.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}
                                """
                                sh "ssh -q es036tvr '${exec}'"
                            }
                            else{
                                 get_packagesbyview(_CRQ_ID,mybuilduser,_pass)
                            }
                        }
                        else
                        {   //saco la info del listado
                             get_applicationCRQ(_CRQ_ID,'"' + _listapaquetes + '"',mybuilduser,_pass)
                        }
                        //Reviso los que no estan promoted en entornos no productivos
                        EditPackageTIB(_CRQ_ID)
                        PaquetesSinPromote=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PaquetesSin.txt")
                        
                        print "Separate packages"
                        exec="""
                        . \$HOME/.profile >/dev/null 2>&1
                            SeparaPaquetesTIBCO.sh -p  ${_CRQ_ID} -a ${_Application} -W
                            . paquete  ${_CRQ_ID}
                            cp  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}/* ${RutaPaquete}/
                        """
                        sh "${exec}"
                        //lanzo en eswltbhr o tibap19p

                   }//script
                 }//step
            }//prepare

    stage("Opciones"){ //Testeo los paquetes
                agent {
                   node("${_nodo}")
                        }
                steps{
                    script {//Elige las opciones:1. Separa y Testeo 2. Ejecuciones 3. Versionar
                        //Si solo se elige opcion 1 solo testear y separar
                        //Si se elige opcion 2 testear y extraer 
                        //Si se elige opcion 3 se testea y versiona
                       // print "Testeamos los paquetes"
                        Tipos=readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")
                        TipoDespliegues=Tipos.split()
                        print "Applications to analize  ${TipoDespliegues}"
                        tamanoDesp= TipoDespliegues.size()
                        print "Size of deployment ${tamanoDesp}"
                        sh "touch -f ${RutaPaquete}/AplicacionesFalloTesteo.txt"
                            amxconfig=0 //Variable de amxconfig
                            for (pos = 0; pos < TipoDespliegues.size() && amxconfig==0 ; pos++) {
                                _domain = TipoDespliegues[pos]
                                _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
                                if (_domain == "TIBCOES" || _domain =="TIBCOIT")
                                {
                                    _nombreCarpeta="${_CRQ_ID}"
                                }
                                else 
                                {  if (_domain =="BW_AMX")
                                    {
                                        _nombreCarpeta="${_CRQ_ID}_AMX"
                                    }
                                    else
                                    {
                                        _nombreCarpeta="${_CRQ_ID}_${_domain}"
                                    }
                                }    
                              
                            //Solo testeamos
                                 if ( _opcion == "1" )
                                 {
                                        
                                        print "****************************************"
                                        print "TEST APPLICATION: ${_domain}  "
                                        print "****************************************"
                                        
                                        
                                        try{ 
                                                txeker("-t",_domain,_env,_nombreCarpeta,_listado)
                                        } catch(Exception e){
                                        echo "Fail testing enviroment ${_env} in ${_domain} error: ${e}" 
                                        sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteo.txt  "
                                        fichero_errores="${_nombreCarpeta}.${_env}.errores_testeo"
                                        exec="""
                                        . \$HOME/.profile  >/dev/null 2>&1
                                        if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
                                        then
                                             mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
                                        fi 

                                        echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                        echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                        echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                        getInfoErrores -p  ${_nombreCarpeta} -f ${fichero_errores} >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                        echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt
                                        """

                                        sh "ssh -q es036tvr '${exec}'"
                                        
                                        }//Si falla
                                    
                                }//opcion 1
                             
                             //Testeamos de nuevo y versionamos en PROD
                               if ( _opcion == "3")
                                 {
                                  
                                    print "****************************************"
                                    print "TEST APPLICATION: ${_domain}  "
                                    print "****************************************"
                                    txeker("",_domain,_env,_nombreCarpeta,_listado)
                                    
                                 
                                    print "****************************************"
                                    print "LABEL  ON ${_env} APLICACION: ${_domain} "
                                    print "****************************************"
                                    txeker("-l",_domain,_env,_nombreCarpeta,_listado)
                                    
                                    
                                 }//OPCION 3
                                 
                                 if ( _opcion == "2")
                                 {
                                    
                                         // testeamos y extraemos
                                        print "****************************************"
                                        print "TEST APPLICATION: ${_domain}  "
                                        print "****************************************"
                                        txeker("",_domain,_env,_nombreCarpeta,_listado)
                                        //Traemos el codigo a server
                                        
                                        print "Deleting directory ${_nombreCarpeta}/${_env} "
                                        CleanPaquete "${_nombreCarpeta}","${_serverPPRD}", "${_env}"
                                        print "Copying directory ${_nombreCarpeta}/${_env} "
                                        CopiaFicheros "${_nombreCarpeta}","${_env}","${_serverPPRD}"
                                        
                                      if (_domain != "AMX-CONFIG" && _domain != "BW-CONFIG")
                                      {
                                           //Hacmeos el replica_datos a cada paquete  para cada paquete
                                           
                                            replica_datos("-ro",_domain,_env,_nombreCarpeta,_listado)
                                             execZip="""
                                                . \$HOME/.profile  >/dev/null 2>&1
                                                cd /home/plataforma/plausr/data/temporal/${hoy}
                                                find ${_listado} -exec zip -ru ${_nombreCarpeta}.zip  {} \\;
                                                """
                                            sh "ssh -q es036tvr '${execZip}'"
                                            
                                            if (_domain =="BW_AMX")
                                            {
                                                sh "mkdir -p /home/plataforma/plausr/data/temporal/${hoy}/anexo/ ; cd /home/plataforma/plausr/data/temporal/${hoy}/anexo/; scp es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_nombreCarpeta}.zip . ; rm -rf ${_nombreCarpeta} ; unzip -o ${_nombreCarpeta}.zip"    
    
                                            }
                                            else
                                            {
                                                 execCop="""
                                                . \$HOME/.profile  >/dev/null 2>&1
                                                mkdir -p /home/plataforma/plausr/data/temporal/${hoy}/anexo/ 
                                                cd /home/plataforma/plausr/data/temporal/${hoy}/anexo/ 
                                                rm -rf ${_nombreCarpeta}
                                                scp es036tvr:/home/plataforma/plausr/data/temporal/${hoy}/${_nombreCarpeta}.zip . 
                                                unzip -o ${_nombreCarpeta}.zip
                                                """
                                                sh "ssh -q ${_serverPPRD} '${execCop}'"
                                            }
                                            
                                        
                                             if (_domain == "TIBCOES" || _domain =="TIBCOIT")
                                             { 
                                                 //EJECUTAMOS el gen_tibco_release
                                                print "EXECUTING GEN_TIBCO_RELEASE"
                                              //  print "Parametros ${_Application} , ${_nombreCarpeta} , ${_serverPPRD} , ${_listado}"
                                                gen_tibco(_Application , _nombreCarpeta , _serverPPRD , _listado)
                                             }
                                             else
                                             {
                                                  if (_domain == "BW_AMX" || _domain =="BW")
                                                { //Hacemos un replicadatos total
                                                   
                                                   if (_domain == "BW_AMX")
                                                   {
                                                    sh " if [ -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt ] ; then  rm -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt* ; fi"
                                                    sh "touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt ; touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt_tmp"
                                                    sh "cp ${RutaPaquete}/${_CRQ_ID}_${_domain} /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt_tmp "
                                                    sh "cat /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt_tmp | sed 's/ /\\n/g' >> /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt "
                                                    sh "rm -f /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt_tmp"
                                                   }
                                                   else
                                                   {
                                                        sh " if [ -f ${RutaPaquete}/Paq_${_nombreCarpeta}.txt ] ; then  rm -f ${RutaPaquete}/Paq_${_nombreCarpeta}.txt* ; fi"
                                                        sh "touch -f ${RutaPaquete}/Paq_${_nombreCarpeta}.txt ; touch -f ${RutaPaquete}/Paq_${_nombreCarpeta}.txt_tmp"
                                                        sh "cp ${RutaPaquete}/${_CRQ_ID}_${_domain} ${RutaPaquete}/Paq_${_nombreCarpeta}.txt_tmp "
                                                        sh "cat ${RutaPaquete}/Paq_${_nombreCarpeta}.txt_tmp | sed 's/ /\\n/g' >> ${RutaPaquete}/Paq_${_nombreCarpeta}.txt "
                                                        sh "scp ${RutaPaquete}/Paq_${_nombreCarpeta}.txt ${_serverPPRD}:/home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Paq_${_nombreCarpeta}.txt"
                                                   }
                                                   //Replicadatos para hacer el separa_paquetes
                                                    replica_datos("",_domain,_env,_nombreCarpeta,_listado)
                                                    separa_paquetes_bw(_domain,_nombreCarpeta,_serverPPRD)
                                                    ejecutaGenBW(_nombreCarpeta,_domain,_serverPPRD,true)
                                                }
                                             }
                                         
    
                                        if (_Application == "BW_AMX" || _Application == "BW" )
                                        {
                                            print "***************************************************************"
                                            print "THIS IS THE RESULT OF PREPARATION"
                                            print "RUN MANUALLY STEPS THAT HAVE FAILED "
                                          //  print "_Application ${_Application} tamaño ${tamanoDesp}"
                                            if ( _Application != "AMX_BW" && tamanoDesp == 2)
                                            {
                                                  //Hay config de BW 
                                                  sh "cat ${RutaPaquete}/InstruccionesConfig.txt"
                                                  print "***************************************************************"
                                                  print "***************************************************************"
                                            }
                                                sh "cat /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/Instrucciones.txt"
                                                print "***************************************************************"
                                                print "***************************************************************"
                                                print "THESE ARE PENTI THAT WE HAVE TO RUN FOR BACKUP"
                                                sh "cat /home/plataforma/plausr/data/paquetes/${hoy}/${_nombreCarpeta}/PENTI.txt"
                                           
                                              print "***************************************************************"
    
                                        }
                                  } //Si no es _domain != "AMX-CONFIG" o BW-CONFIG
                                  else
                                    {  if (_domain =="AMX-CONFIG")
                                        {  //Si es AMX-CONFIG me salgo y no sigo
                                            amxconfig=1
                                        
                                        echo "**************************************************************************************************"
                                        echo "**************************************************************************************************"
                                        echo "INFO   IMPORTANT: It is necesary to execute CONFIG package PREVIOUS:"
                                        echo "INFO   IMPORTANT: Connect ${_serverPPRD} machine with tibprd user"
                                        echo "INFO   IMPORTANT: run follow command:"
                                        echo "INFO   :   /home/tib${_env}/entorno/PENTIAdministrator/PENTIADMIN_AE5.sh -i ${_nombreCarpeta} -e ${_env} -v "
                                        echo "***************************************************************************************************"
                                        echo "INFO   IMPORTANT:AFTER run this execute the rest of package to run gen_bw_release+nivela_deploy****"
                                        echo "***************************************************************************************************"
                                    
                                        }
                                        else
                                        { //BW CONFIG
                                          sh "touch -f ${RutaPaquete}/InstruccionesConfig.txt" 
                                          sh "echo '****************************************************************************************** ' >>  ${RutaPaquete}/InstruccionesConfig.txt"
                                          sh "echo '****************************************************************************************** ' >>  ${RutaPaquete}/InstruccionesConfig.txt"
                                          sh "echo 'INFO   IMPORTANT: It is necesary to execute CONFIG package PREVIOUS:* ' >>  ${RutaPaquete}/InstruccionesConfig.txt"        
                                          sh "echo 'INFO   IMPORTANT: Connect ${_serverPPRD} machine with tibprd user ' >>  ${RutaPaquete}/InstruccionesConfig.txt"        
                                          sh "echo 'INFO   IMPORTANT: run follow command:' >>  ${RutaPaquete}/InstruccionesConfig.txt"
                                          sh "echo 'INFO   :   /home/tib${_env}/entorno/PENTIAdministrator/PENTIADMIN_AE5.sh -i ${_nombreCarpeta} -e ${_env} -v ' >>  ${RutaPaquete}/InstruccionesConfig.txt"        
                                         if (tamanoDesp==1)        
                                         { //No hay mas paquetes
                                              print "***************************************************************"
                                              print "THIS IS THE RESULT OF PREPARATION"
                                              sh "cat ${RutaPaquete}/InstruccionesConfig.txt"
                                         }
                                        }
                                        
                                    }     //No son config
                                    
                                 }//OPCION 2
                            
                        }//for apliaciones
                        
                        
                        if ( _opcion == "1")
                              { //Revisar si han fallado
                                  AplicacionesFalloTesteo = readFile(file: "${RutaPaquete}/AplicacionesFalloTesteo.txt")
                                    
                                  
                                  if (AplicacionesFalloTesteo != "" && PaquetesSinPromote == "" )
                                  {
                                    sh "scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt ${RutaPaquete}"
                                    InfoErroresTesteo= readFile(file: "${RutaPaquete}/InfoErroresTesteo.txt")
                                  
                                    print "****************************************"
                                    print "         TEST INCORRECT"
                                    print "****************************************"
                                    print "We have analyzed following applications:"
                                    print "${Tipos}"
                                    print "These applications has failed :"
                                    print "${AplicacionesFalloTesteo}"
                                    
                                    print "INFO of PROVEEDORS with ERRORS in TESTING "
                                    print "${InfoErroresTesteo}"
                                    error ("Failing testing")
                                            
                                  }
                                  
                                   
                                   
                                   if (PaquetesSinPromote != "" &&  AplicacionesFalloTesteo == "")
                                    {
                                     print "****************************************************************"
                                     print "These packages are not promoted on previous enviroment"
                                     print "${PaquetesSinPromote}"
                                     print "****************************************************************"
                                     error ("Packages in incorrect status, but test is correct")
                                    }
                                    if (PaquetesSinPromote != "" &&  AplicacionesFalloTesteo != "")
                                    {
                                        print "****************************************************************"
                                        print "These packages are NOT promoted on previous enviroment "
                                        print "${PaquetesSinPromote}"
                                        print "****************************************************************"
                                         
                                        sh "scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo.txt ${RutaPaquete}"
                                        InfoErroresTesteo= readFile(file: "${RutaPaquete}/InfoErroresTesteo.txt")
                                  
                                        print "****************************************"
                                        print "         TEST INCORRECT"
                                        print "****************************************"
                                        print "We have analyzed following applications:"
                                        print "${Tipos}"
                                        print "These applications has failed:"
                                        print "${AplicacionesFalloTesteo}"
                                        
                                        print "INFO of PROVEEDORS with ERRORS in TESTING"
                                        print "${InfoErroresTesteo}"
                                        error ("Failing testing and packages in incorrect status")
                                         
                                    }
                                    if  (AplicacionesFalloTesteo == "" )
                                   {
                                    print "********************************************"
                                    print "         TESTEO CORRECTO"
                                    print "********************************************"
                                   }
                                   
                              }//opcion 1
                              
                              if  ( _opcion == "2")
                              {
                                   if (PaquetesSinPromote != "" )
                                    {
                                     print "****************************************************************"
                                     print "These packages are not promoted on previous enviroment"
                                     print "${PaquetesSinPromote}"
                                     print "****************************************************************"
                                    error ("Packages in incorrect status")
                                    }
                              }

                   } //scripts
                }//steps
            }//Testeo
            stage("EditPackage"){
                agent {
                   node("${_nodo}")
                        }

                steps{
                    script {
                                                
                          if(_opcion=="3" ) {
                               
                            print "Edito los paquetes "
                            
                            EditPackageTIB(_CRQ_ID, _View, _listapaquetes, false, false,_NomVista,mybuilduser,_pass)
                            PromotePROD=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PromotePROD.txt")
                            Notif=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/Todos.txt")
                            if (PromotePROD != "")
                            { //Paquetes a promocionar
                                //promote("${mybuilduser}","10", PromotePROD)
                                promoteApi("${mybuilduser}","10", '"'+PromotePROD+'"',_pass)
                            }
                            if (Notif  != "")
                            { //Paquetes a promocionar
                                notifApi("${mybuilduser}",'"'+Notif+'"',_pass)
                                promoteApi("${mybuilduser}","10", '"'+Notif+'"',_pass)
                            }
                            
                            EditPackageTIB(_CRQ_ID, _View, _listapaquetes, true,false,_NomVista,mybuilduser,_pass)
                            PaquetesIncorrectos=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PaquetesIncorrectos.txt")
                            if (PaquetesIncorrectos != "" )
                            {
                                print "Check following package that can not be promoted automatically"
                                print "${PaquetesIncorrectos}"
                            }
                                print "******************************"
                                print "Elegida opcion 3 de VERSIONADO"
                                print "Nombre del parche ${_CRQ_ID} "
                                print "******************************"
                             
                        }//SI es opcion 3

                    }//scripts
                }//steps
          }//etiquetar

            
        
          
         }//stages
        }//pipeline
    }//map
