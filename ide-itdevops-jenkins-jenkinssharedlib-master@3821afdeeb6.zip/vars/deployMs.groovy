def call(Map salidaMs,String oc_cluster, String project, Integer deployTimeout, List mslistdc ,String BASEDIR, String ENTORNO, String scuad){
    echo "deployMs("+salidaMs+","+oc_cluster+","+project+","+deployTimeout+","+mslistdc+","+BASEDIR+","+ENTORNO+","+scuad+")"
    def rollback=false
    openshift.withCluster(oc_cluster) {
        echo "Using Cluster: ${openshift.cluster()}"
        //openshift.verbose()
        openshift.logLevel(0)
        def APP=""
        def status=""
        listrollbackresource=[]
        listdeleteresource=[]
        mslistdc.each(){
            def ms=it
            _App=ms.application
            APLICACION=_App.toLowerCase()
            namespace=ms.namespace
            if (project!=""){
                namespace=namespace+"-"+project
            }
            LOWERVERSION=ms.version.toLowerCase()
            VERSION=ms.version
            openshift.withProject(namespace) {
                echo "Crear: resources ${APLICACION}"
                def sTemplate="TemplateCD/${ms.template}"
                def sTemplateExtra=""
                def templateList=[]
                if (ms.hasProperty('template_extra')){
                    sTemplateExtra="TemplateCD/${ms.template_extra}"
                    templateList.add(sTemplateExtra)
                }
                templateList.add(sTemplate)
                def sCert=""
                def pCA=""
                def pCERT=""
                def pKEY=""
                def scuadparam=""
                if (scuad !="" ){
                    scuadparam="-p ENV=${scuad}"
                    echo "scuadparam=-p ENV=${scuad}"
                }
                if (ms.cert !="" && ms.cert != null){
                    def CERT=readFile("${BASEDIR}/CDM/Jenkins/DXL/routecerts/${ENTORNO}/${ms.cert}.cert")
                    def CA=readFile("${BASEDIR}/CDM/Jenkins/DXL/routecerts/${ENTORNO}/${ms.cert}.ca")
                    def KEY=readFile("${BASEDIR}/CDM/Jenkins/DXL/routecerts/${ENTORNO}/${ms.cert}.key")
                    pCA="-p CA=${CA}"
                    pCERT="-p CERT=${CERT}"
                    pKEY="-p KEY=${KEY}"
                }
                def prevdcs=[]
                def rc = openshift.selector('rc', [ app: "${APLICACION}" ]).objects()
                rc.each(){
                    def rcMap = it
                    if (rcMap.status.replicas>0){
                        def rcname=rcMap.metadata.name
                        def matcher1 = (LOWERVERSION =~ /((es[0-9]{4}[a-z]*(-rc)?)\.([0-9]*)\.([a-z0-9]{7,11}))/)
                        def newDcName=matcher1[0][1]
                        def newDelivery=matcher1[0][2] 
                        def newSec=matcher1[0][4]
                        
                        println "newDcName=${newDcName} newDelivery:$newDelivery newSec:$newSec"
                    
                        def matcher = (rcname =~ /(([a-z0-9-]*)-((es[0-9]{4}[a-z]*(-rc)?)\.([0-9]*)\.([a-z0-9]{7,11})))-[0-9]*/)
                        println "rcname=${rcname}"
                        def currentDcName=matcher[0][1]
                        def appVersion=matcher[0][3]                        
                        def appName=matcher[0][2]
                        def currentDelivery=matcher[0][4] 
                        def currentSec=matcher[0][6]
                        println "currentDc:${currentDcName} currentDelivery:$currentDelivery currentSec:$currentSec replicas=${rcMap.status.replicas}"
                        println "----- currentDelivery:$currentDelivery.$currentSec vs newDelivery:$newDelivery.$newSec"
                        if(ENTORNO=="sit1"||ENTORNO=="sit2"|ENTORNO=="pprd"){
                            if(newDelivery.substring(0,6)<currentDelivery.substring(0,6)){
                                rollback=true
                                salidaMs.status="ERROR: Pod already running has different Delivery (${currentDelivery}.${currentSec}) from the new one (${newDelivery}.${newSec}). Request to stop current pod to deploy previous delivery version (if allignment package, don't deploy)"
                                println salidaMs
                        
                            }else{
                                if (newDelivery.substring(0,6) == currentDelivery.substring(0,6)){
                                    if(newDelivery.substring(0,8) == currentDelivery.substring(0,8)){
                                        if(newDelivery > currentDelivery){
                                            println "CurrentDelivery:$currentDelivery < newDelivery:${newDelivery}"
                                        }
                                        if (newDelivery == currentDelivery){
                                            if(newSec.toInteger() >= currentSec.toInteger()){
                                                println "CurrentDelivery:${currentDelivery}.${currentSec} <= newDelivery:${newDelivery}.${newSec}"
                                            }else{
                                                rollback=true
                                                salidaMs.status="ERROR: Pod already running has different Delivery (${currentDelivery}.${currentSec}) from the new one (${newDelivery}.${newSec}). Request to stop current pod to deploy previous delivery version (if allignment package, don't deploy)"
                                                println salidaMs
                                            }
                                        }
                                            
                                    }
                                    else{
                                        rollback=true
                                        salidaMs.status="ERROR: Pod already running has different Delivery (${currentDelivery}.${currentSec}) from the new one (${newDelivery}.${newSec}). Request to stop current pod to deploy previous delivery version (if allignment package, don't deploy)"
                                        println salidaMs
                                    }
                                }else{
                                    println "CurrentDelivery:$currentDelivery < newDelivery:${newDelivery}"
                                }
                            }
                        }

                        prevdcs.add(currentDcName)
                    }
                }
                if (openshift.selector("service", "${APLICACION}").exists()){
                    echo "serviceExiste"
                    serviceExiste=true
                }
                templateList.each(){
                    (DC_SUM,DC_PropGen,DC_PropSpec,DC_PropTemp,paramsstring1,paramsstring2,paramsstring3)=getTemplatesInfo(it,ENTORNO,APLICACION,ms)
                    //si hay propiedades repetidas en ficheros coge las del primero
                    processed = openshift.process("-f", "${sTemplate}", "-p","APP_NAME=${APLICACION}",
                        "-p","NAMESPACE=${namespace}",
                        "-p","APP_VERSION=${VERSION}",
                        "-p","LOWER_APP_VERSION=${LOWERVERSION}",
                        "${scuadparam}",
                        "${paramsstring1}","${paramsstring2}","${paramsstring3}",
                        "${pCA}","${pCERT}","${pKEY}",
                        "-p","DC_SUM=${DC_SUM}",
                        "-p","DC_PropSpec=${DC_PropSpec}",
                        "-p","DC_PropGen=${DC_PropGen}",
                        "-p","DC_PropTemp=${DC_PropTemp}",
                        "--ignore-unknown-parameters") 
                    echo "Recursos"
                    echo "${processed}"
                    def serviceExiste=false
                    processed.each(){
                        def resourcetype=it.kind
                        def resourcename=it.metadata.name
                        def resourcenamespace=it.metadata.namespace
                        openshift.withProject(resourcenamespace) {
                            echo "Tratando recurso:${resourcetype} ${resourcename} "
                            openshift.logLevel(1)
                            if (rollback==false){
                                try {
                                    if (openshift.selector("${resourcetype}", "${resourcename}").exists()){
                                        if (resourcetype == "DeploymentConfig"){
                                            echo "el recurso ya existe"
                                            prevdcs.remove(resourcename)
                                        }
                                        if (resourcetype == "HorizontalPodAutoscaler"){
                                            def hpa=openshift.selector("${resourcetype}", "${resourcename}").object()
                                            if (hpa.status.currentReplicas >=3){
                                                hpa.spec.minReplicas=2
                                                hpa.spec.maxReplicas=3
                                                openshift.apply(hpa)
                                                sleep 10
                                                hpa=openshift.selector("${resourcetype}", "${resourcename}").object()
                                                echo "HPA: ${hpa.metadata.name} deseaadas:${hpa.status.desiredReplicas} current: ${hpa.status.currentReplicas}"
                                            }
                                        }
                                        salidaMs.listrollbackresource.add(it)
                                        //echo "Borrando recurso:${resourcetype} ${resourcename} "
                                        //openshift.selector("${resourcetype}", "${resourcename}").delete()
                                        try{
                                            openshift.apply(it)
                                            echo "recurso ${resourcetype}/${resourcename} update"
                                        }
                                        catch(e){
                                            echo "warning haciendo update, lo borro y lo creo"
                                            openshift.delete(it)
                                            openshift.create(it)
                                        }
                                    }else{
                                        salidaMs.listdeleteresource.add(it)
                                        openshift.create(it)
                                        echo "recurso ${resourcetype}/${resourcename} create"
                                    }
                                }
                                catch(e){
                                    rollback=true
                                    salidaMs.status="ERROR procesando recurso ${resourcetype}/${resourcename}"
                                    echo salidaMs.status
                                }
                                openshift.logLevel(0)
                            }
                        }
                    }
                }
                //def rm = openshift.selector("dc", "${APLICACION}").rollout()
                if (rollback==false){
                    def dc=openshift.selector("dc", "${APLICACION}-${LOWERVERSION}")
                    def latestDeploymentVersion = dc.object().status.latestVersion
                    def rctocheck = openshift.selector('rc', "${APLICACION}-${LOWERVERSION}-${latestDeploymentVersion}")
                    echo "rctocheck:[${rctocheck}]"
                    try{
                        timeout(deployTimeout){
                            rctocheck.untilEach(1){
                                def rcMap1 = it.object()
                                replicas=rcMap1.status.replicas.equals(rcMap1.status.readyReplicas)
                                //replicas=rcMap1.status.readyReplicas>=1
                                echo "Object:${rcMap1.metadata.name} ready_replicas:${rcMap1.status.readyReplicas}"
                                try{
                                    def pod=openshift.selector('pod', [ app: "${APLICACION}" , version: "${VERSION}"])
                                    echo "pod:${pod}"
                                    //sleep 20
                                    pod.logs("--since=200s", " -c ${APLICACION}")
                                } 
                                catch(j){
                                    echo "WARNING pod.logs:${j}"
                                }
                                return (replicas)
                            }
                        }
                    }
                    catch(e){
                        rollback=true
                        echo "ERROR:${e}"
                        return true
                    }
                    //bajar replicas del pod antiguo a 0.
                    prevdcs.each(){
                        echo "scale ${it} --replicas=0"
                        openshift.selector("dc","${it}").scale('--replicas=0')
                        
                    }
                }
            }
        }
    }
    return rollback
}
