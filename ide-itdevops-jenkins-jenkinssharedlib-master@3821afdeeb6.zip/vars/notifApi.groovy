def call (String _usuario, String _paquete){
    node ('es1117yw'){
      //Buscar contraseña del user
     (_pass,_usuario)=findpassword(_usuario)
     checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
             bat "python notif.py -u ${_usuario} -p ${_paquete} -c ${_pass}"
           }//wrap
        }
    }
}

def call (String _usuario, String _paquete, String _pass){
    node ('es1117yw'){
            checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
            bat "python notif.py -u ${_usuario} -p ${_paquete} -c ${_pass}"
           }//wrap
        }
    }
}


def call (String _usuario, String _paquete, String _pass, String _Entorno ){
    node ('workbenchPPRD'){
            checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
            bat " notif.py -u ${_usuario} -p ${_paquete} -c ${_pass} -e ${_Entorno}"
           }//wrap
        }
    }
}