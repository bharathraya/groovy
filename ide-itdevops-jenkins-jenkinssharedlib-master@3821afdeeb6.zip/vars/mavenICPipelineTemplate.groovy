import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo

def almsPackage=null
def gitRepo=null
def pipelineConfig=null
VFESGitMergeInfo mergeInfo=null

def call(Map pipelineParams){
    pipeline{
        agent none
        stages{
            
            stage("Prepare"){
                agent any
                steps{
                    // Print env commit id and others ...
                    echo "Env: ${DeployEnv}"
                    echo "CommitId: ${CommitId}"
                    // prepare info and displayname
                    
                    script {
                        // read pipelineConfig
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        almsPackage= new VFESALMSDeployment(ALMS_ID,pipelineConfig.applicationName,DeployEnv,CommitId,Delivery,ProjectId)
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
                        // TODO : when 
                        gitRepo=new VFESGitRepo("${pipelineConfig.gitRepo}",this)
                    }
                    
                }
            }
            stage('Checkout'){
                agent {
                    
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
                        }
                    }
            }
            stage('merge'){
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    }
                }
                steps{
                    script{
                        mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
                    }
                }
            }
            stage('Compile'){
                agent {
                    docker {
                        // TODO : revisar si usamos "cache" de npm 
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                        reuseNode true
                    }
                }
                steps{
                    // TODO : manejar el caso master/ HID vs resto entornos
                    // TODO : gestionar el empaquetado del resultado 
                    
                    buildWithScript pipelineConfig
                    
                }            
            }
            stage('PushToNexus'){
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    pushToNexus pipelineConfig, almsPackage
                }

            }
            stage('CopyToRelease'){
                when{
                    expression { return DeployEnv ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/ }
                }
                agent{
                    //label "deploy-apache-wcs"
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                    script{
                        echo "Download artifact from Nexus ..."
                        sh "mkdir -p ${pipelineConfig.extractFolder}/${pipelineConfig.distFolder};wget -nv -O ${pipelineConfig.extractFolder}/${pipelineConfig.distFolder}/${pipelineConfig.distFile} http://es004dxr:8080/nexus/repository/${pipelineConfig.nexusRepo}/\$( echo ${pipelineConfig.groupId} | sed -e 's/\\./\\//g')/${pipelineConfig.artifactId}/SNAPSHOT-${DeployEnv}/${pipelineConfig.artifactId}-SNAPSHOT-${DeployEnv}.zip"
                        echo "DeployType: ${pipelineConfig.deployType}"
                        switch(pipelineConfig.deployType) {
                            case ~/^(release|catalogo)$/:
                                echo "Copy code to release folder ..."
                                copyToRelease  pipelineConfig,  almsPackage
                            break
                            case ~/^apache$/:
                                echo "Deploy to apache ..."
                                deployToApacheScript.deploy  pipelineConfig,almsPackage

                            break

                        }
                   
                    }

                }
            }

            stage('Deploy'){
                when{
                    expression { return DeployEnv ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/ }
                }
                agent{
                    label "${pipelineConfig.deployAgent}"
                }
                steps{
                    script{
                        switch(pipelineConfig.deployType) {
                            case ~/^catalogo$/:
                                echo "running deploy step"
                                deployCatalogo pipelineConfig, almsPackage
                            break
                        }
                    }
                    
                }
            }
            stage('Prepare PAP'){
                agent{
                    //label "deploy-apache-wcs"
                    label "${pipelineConfig.releaseAgent}"
                }
                when{
                    expression { return DeployEnv ==~ /(?i)(master|masterCI|hid|hid1|hidci|hid1ci)/ }
                }
                steps{
                    echo "running Prepare PAP step"
                }
            }
            stage('TagAndPush'){
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        echo "Tag commit and push to git "
                        gitRepo.tagAndPush pipelineConfig.extractFolder,
                            almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                    }
                }
            }
            stage('PublishChanges'){
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    echo "Publish changes to ELK  and GitPublish plugin"
                    publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                }
            }



        }
        
    }
}