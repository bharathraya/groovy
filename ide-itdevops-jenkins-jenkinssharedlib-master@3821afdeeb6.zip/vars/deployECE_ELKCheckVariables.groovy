package vars
import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi
import vfes.utils.VFESALMSDeployment

def call(Map config, VFESALMSDeployment alms)
{
    def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    def _envConfig=myEnvsConfig[alms.deployEnv]

    for( String action : config.deployActions.split(',') ) {
        //echo "Action=" + action
        switch(action) {
            case 'check_syntax':
                if (_envConfig.keySet().contains(action)) {
                    echo "=============================================="
                    echo "            NEW: ${action}"
                    echo "=============================================="
                    _envConfigSyntax=_envConfig[action]
                    echo "_envConfigSyntax: "+_envConfigSyntax

                    _envConfigSyntax.each { item ->
                        serverData_Server=item.server
                        serverData_User=item.user
                        serverData_Platafor_Release_Path=item.platafor_release_path
                        serverData_Application_Release_Path=item.application_release_path
                        checkData_Repository_Envs_Vars=config.applicationName
                        config_checkSyntaxScript=config.checkSyntaxScript

                        echo "Checking Syntax Variables:"
                        echo "Server Data:"
                        echo "  Server: ${serverData_Server}"
                        echo "  User: ${serverData_User}"
                        echo "  platafor release_path: ${serverData_Platafor_Release_Path}"
                        echo "  application release_path: ${serverData_Application_Release_Path}"
                        echo "Check Data:"
                        echo "  env vars repository: ${checkData_Repository_Envs_Vars}"
                        echo "  check syntax script: ${config_checkSyntaxScript}"

                        echo "AT: ${serverData_User}@${serverData_Server}"
                        echo "RUN: ${serverData_Platafor_Release_Path}/scripts/${config.checkSyntaxScript}"
                        echo "PARAMETERS: -a ${checkData_Repository_Envs_Vars} -r ${serverData_Application_Release_Path}"
                        sh "ssh -o StrictHostKeyChecking=no ${serverData_User}@${serverData_Server} 'cd ${serverData_Platafor_Release_Path}/scripts; ./${config_checkSyntaxScript} -a ${checkData_Repository_Envs_Vars} -r ${serverData_Application_Release_Path}'"
                    }
                    echo "=============================================="
                    echo "=============================================="
                    echo "=============================================="
                } else {
                    echo "ERROR. Not found ${action} key in ${config.releaseConfig}"
                    sh ("exit 1")
                }
                break;
            case ['check_alert', 'check_ilm', 'check_indexTemplates', 'check_logstash', 'check_mappings', 'check_rollups']:
                if (_envConfig.keySet().contains(action)) {
                    echo "=============================================="
                    echo "            NEW: ${action}"
                    echo "=============================================="
                    _envConfigAction=_envConfig[action]
                    echo "_envConfigAction: "+_envConfigAction

                    _envConfigAction.each { item ->
                        if (!item.keySet().contains("repo_vars") && !item.keySet().contains("repo_check")) {
                            echo "ERROR. Configure missmatch. Action: ${action} Must to have defined \"repo_vars\" or \"repo_check\" or both"
                        }
                        if (item.keySet().contains("repo_vars") && item.keySet().contains("repo_check")) {
                            checkData_Repository_To_Check=item.repo_check
                            checkData_Repository_Envs_Vars=item.repo_vars
                        }
                        else if (!item.keySet().contains("repo_vars") && item.keySet().contains("repo_check"))
                        {
                            checkData_Repository_To_Check=item.repo_check
                            checkData_Repository_Envs_Vars=config.applicationName
                        } else {
                            checkData_Repository_To_Check=config.applicationName
                            checkData_Repository_Envs_Vars=item.repo_vars
                        }
                        serverData_Server=item.server
                        serverData_User=item.user
                        serverData_Platafor_Release_Path=item.platafor_release_path
                        serverData_Application_Release_Path=item.application_release_path
                        checkData_File_Pattern_To_Search=item.file_pattern
                        checkData_Environment_Variables_Vault=item.env_vault
                        config_checkVariables=config.checkVariables

                        echo "Checking Variables:"
                        echo "Server Data:"
                        echo "  deploy_server: ${serverData_Server}"
                        echo "  deploy_user: ${serverData_User}"
                        echo "  platafor release_path: ${serverData_Platafor_Release_Path}"
                        echo "  application release_path: ${serverData_Application_Release_Path}"
                        echo "Check Data:"
                        echo "  repository to check: ${checkData_Repository_To_Check}"
                        echo "  env vars repository: ${checkData_Repository_Envs_Vars}"
                        echo "  file pattern to search: ${checkData_File_Pattern_To_Search}"
                        echo "  environment variables vault: ${checkData_Environment_Variables_Vault}"
                        echo "  check variables script: ${config_checkVariables}"

                        echo "AT: ${serverData_User}@${serverData_Server}"
                        echo "RUN: ${serverData_Platafor_Release_Path}/scripts/${config_checkVariables}"
                        echo "PARAMETERS: -a ${checkData_Repository_Envs_Vars} -r ${serverData_Application_Release_Path} -b ${checkData_Repository_To_Check} -p ${checkData_File_Pattern_To_Search} -e ${checkData_Environment_Variables_Vault}"
                        sh "ssh -o StrictHostKeyChecking=no ${serverData_User}@${serverData_Server} 'cd ${serverData_Platafor_Release_Path}/scripts; ./${config_checkVariables} -a ${checkData_Repository_Envs_Vars} -r ${serverData_Application_Release_Path} -b ${checkData_Repository_To_Check} -p ${checkData_File_Pattern_To_Search} -e ${checkData_Environment_Variables_Vault}'"
                    }
                    echo "=============================================="
                    echo "=============================================="
                    echo "=============================================="
                } else {
                    echo "ERROR. Not found ${action} key in ${config.releaseConfig}"
                    sh ("exit 1")
                }
                break;
            case 'deploy_enviromentVars':
                echo "=============================================="
                echo "            LEGACY: ${action}"
                echo "=============================================="
                echo "Testing the Deploy of EnvironmentVars ...."
                echo "_envConfig"+_envConfig[action]
                _envConfig[action].each { item ->
                    echo "Server Data:"
                    echo "  deploy_server: " + item.deploy_server
                    echo "  deploy_user: " + item.deploy_user
                    echo "  release_path: " + item.release_path
                    echo "  deploy_script_path: " + item.deploy_script_path + "/scripts"
                    echo "  deploy Script: " + config.deployScript

                    echo "AT: ${item.deploy_server}@${item.deploy_user}"
                    echo "RUN: ${item.deploy_script_path}/scripts/${config.deployScript}"
                    echo "PARAMETERS: -a ${config.applicationName} -r ${item.release_path}"
                    sh "ssh -o StrictHostKeyChecking=no ${item.deploy_user}@${item.deploy_server} 'cd ${item.deploy_script_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.release_path}'"
                }
                break;
            case 'check_vars' :
                echo "=============================================="
                echo "            LEGACY: ${action}"
                echo "=============================================="
                echo "Checking Variables ...."
                echo "_envConfig"+_envConfig['check_vars']
                _envConfig['check_vars'].each { item ->
                    echo "Server Data:"
                    echo "  check_vars_server: " + item.server
                    echo "  check_vars_user: " + item.user
                    echo "  application_release_path: " + item.application_release_path
                    echo "  platafor_release_path: " + item.platafor_release_path
                    echo "  repo_vars: " + item.repo_vars

                    echo "AT: ${item.user}@${item.server}"
                    echo "RUN: ${item.platafor_release_path}/scripts/${config.checkVarScript}"
                    echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -b ${item.repo_vars}"
                    sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.checkVarScript} -a ${config.applicationName} -r ${item.application_release_path} -b ${item.repo_vars}'"
                }
                break;
            default:
                echo "ERROR. Action ${action} not known ...."
                sh ("exit 1")
                break;
        }
    }
}

