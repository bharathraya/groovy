def call(String RutaPaquete, String _CRQ_ID, String _Upgrade){
  
  def  iError=0
  def TiposApp=""
  def exec_COMP_CONECT_SMART=""
  
  iError=0
 if (_Upgrade =="N")
 { //No es del upgrade
      TiposApp = readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")
     
        if (TiposApp.contains("AMDOCS-SERVER") || TiposApp.contains("AMDOCS-CLIENT"))
           {
               print "*****************************************************************"
               print " Comprobramos las conectividades de SMART necesarias para el CRQ "
               print "*****************************************************************"
               exec_COMP_CONECT_SMART="""
               cd /home/plataforma/release/scripts
               ./check_conections_prod -d CRMSmart
               """
               
                 try{
                          sh "ssh -q platafor@smartapptst05 '${exec_COMP_CONECT_SMART}'" //platafor
                    } catch(Exception e){
                        iError=1
                    }
           }
    
    
           print "****************************************************************"
           print " Comprobramos las conectividades de CRM necesarias para el CRQ  "
           print "****************************************************************"
           exec_COMP_CONECT_CRM="""
           cd /home/plataforma/release/scripts
           ./check_conections_prod -d AMDOCS
           """
           try{
                sh "ssh -q platafor@smartapptst05 '${exec_COMP_CONECT_CRM}'" //platafor
              } catch(Exception e){
                        iError=1
                }
     }
     else
     {//Es del upgrade
           print "****************************************************************"
           print " Comprobramos las conectividades de CRM necesarias para el CRQ  "
           print "****************************************************************"
           exec_COMP_CONECT_CRM="""
               . \$HOME/.profile >/dev/null 2>&1
               check_ssh_prod_upgrade.sh -d ALL
               """
           
           try{
                 sh "ssh devopsprdtools01  '${exec_COMP_CONECT_CRM}'"
              } catch(Exception e){
                        iError=1
                }
     }
     
    return iError
            
}