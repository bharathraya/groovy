import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

def _App=""
def _CRQ_ID=""
def _Date=""
def _delivery=""
def _env=""
def _envExe=""
def _enviroment=""
def _Execution=""
def exec=""
def iCopia=0
def hoy=""
def mybuilduser=""
def NodoAgent=""
def Parameter=""
def pipelineConfig
def pos=0
def _Scripts=""
def _iSimulacro=0
def iParcheSimu=0



def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'WB_ID', defaultValue: '', description: 'Name of package') 
            choice(name: 'Application',  choices: pipelineParams.TypesChoices , description: 'Application to deploy') 
            string(name: 'Delivery', defaultValue: '', description: 'Delivery to find dependencies') 
            string(name: 'Date', defaultValue: '', description: 'Date when package was generated YYYYMMDD') 
            choice(name: 'Enviroment',  choices: pipelineParams.EnvChoices , description: 'Enviroment to run compilation') 
            
         }
         
 stages{     
         stage("Prepare"){
                agent {
                    label 'AMDOCS-PARCHE'
                        }
                steps{
                script {

                     //Leo los parametros
                    _CRQ_ID=params.WB_ID.trim()  
                    _Date=params.Date.trim()
                    _delivery=params.Delivery.trim()
                    _App=params.Application
                    _env=params.Enviroment
                    
                    wrap([$class: 'BuildUser']) {
                             echo "Exec user: ${env.BUILD_USER_ID}"
                             mybuilduser=env.BUILD_USER_ID
                        }//wrap
                    
                    if (_env != "PROD")
                    {
                        _iSimulacro=1
                        _enviroment=_env
                        _envExe=_env

                    }
                    else
                    {
                        _iSimulacro=0
                        _enviroment="PPRD"
                        _envExe="PROD"
                    }
                        hoy=new Date().format( 'yyyyMMdd' )
                        print "**********Hoy es : ${hoy}  ******"
                        print "**********Parametros**********"
                        print "Nombre del parche: ${_CRQ_ID}"
                        print "Fecha del parche: ${_Date}"
                        print "Aplicacion del despliegue: ${_App}"
                        print "Entorno para ejecutar: ${_env}" 
                        print "Delivery para ejecutar: ${_delivery}"
                        
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        
                        if (_CRQ_ID == "")
                        {
                            error ("Es necesario el nombre del parche")
                        }
                        if (_delivery =="" && ( _App == "AMDOCS-ESQUEMA" || _App == "AMDOCS-CAB"  || _App == "AMDOCS-AIF")) { 
                	        error("Es obligatorio la Delivery para los artefactos de nexus.")
                        } 

                        if (_Date == "" )
                        {
                            print "Usaremos como fecha la de hoy: ${hoy}"
                            iCopia=0
                            _Date=hoy
                        }
                        else
                        {  if (_Date != hoy)
                            {
                                iCopia=1
                            }
                            else
                            {
                                iCopia=0
                            }
                        }
                        
                    if (_iSimulacro == 1)
                    {
                        currentBuild.displayName = "PARCHE: ${_CRQ_ID} App: ${_App} Enviroment: ${_env}"
                        currentBuild.description = "PARCHE: ${_CRQ_ID} App: ${_App} Enviroment -> Simulacro: ${_env}"
                    }
                    else
                    {
                        currentBuild.displayName = "PARCHE: ${_CRQ_ID} App: ${_App} Enviroment: ${_env}"
                        currentBuild.description = "PARCHE: ${_CRQ_ID} App: ${_App} Enviroment -> Compilation for: ${_env}"
                    }
                    if (_App != "AMDOCS-BBDD" && _App != "AMDOCS-ESQUEMA" && _App != "AMDOCS-PREVIEW" && _App != "AMDOCS-BusinessRules" )
                       {
                            NodoAgent="${_App}-${_enviroment}"
                       }
                       else
                       {
                           NodoAgent="devopsprdtools01"
                       }
                      // print " NodoAgent ${NodoAgent}"
                      
                    }//Script
                 }//step
            }//prepare
            
            stage("Execution"){ //Testeo los paquetes
                agent { //Lo ejecutamos en la maquina de sppr(ppr) o en la del simulacro
                    node("${NodoAgent}")
                     }
                steps{
                    script {
                     
                        //Saco el ejecutor
                        print "Cual es la app y el enviroment ->  ${_App}-${_envExe}"
                        _Scripts=pipelineConfig["${_App}-${_envExe}"]
                        print "Hemos leido ${_Scripts}"
                        _Execution=""
                        iParcheSimu=0
                        for (pos = 0; pos < _Scripts.size(); pos++) { 
                            Parameter = _Scripts[pos]
                           // print "Para ${pos} es el parametro ${Parameter}"
                            
                            if (Parameter =="Parche")
                            {
                                 iParcheSimu=1
                                _Execution="${_Execution}"+' ' +"${_CRQ_ID}" 
                            }
                            else if (Parameter =="Entorno")
                            {
                                _Execution="${_Execution}"+' ' +"${_envExe}"    
                            }
                            else if (Parameter =="Domain")
                            {
                                _Execution="${_Execution}"+' ' +"${_App}"    
                            }
                             else if (Parameter =="Delivery")
                            {
                                _Execution="${_Execution}"+' ' +"${_delivery}"    
                            }
                             else 
                            {
                                _Execution="${_Execution}"+' ' +"${Parameter}"    
                            }
                          //  print "Componiendo ${_Execution}"
                        }//for
                        
                       if (iCopia==1 && iParcheSimu == 0)
                       { //Copia_paquete y .paquete
                           exec="""
                                . \$HOME/.profile >/dev/null 2>&1
                                . paquete  ${_CRQ_ID}
                                 copia_paquete_fecha -f ${hoy} -F ${_Date} ${_CRQ_ID}
                                ${_Execution}
                            """
                       }
                       else if (iCopia==1 && iParcheSimu == 1)
                       {//Copia_paquete pero sin .paquete
                           exec="""
                                . \$HOME/.profile >/dev/null 2>&1
                                 copia_paquete_fecha -f ${hoy} -F ${_Date} ${_CRQ_ID}
                                ${_Execution}
                            """
                       }
                       else if (iCopia==0 && iParcheSimu == 1)
                       {//No Copia_paquete y sin .paquete
                           exec="""
                                . \$HOME/.profile >/dev/null 2>&1
                                ${_Execution}
                            """
                       }
                       else if (iCopia==0 && iParcheSimu == 0)
                       {//No Copia_paquete y con .paquete
                           exec="""
                                . \$HOME/.profile >/dev/null 2>&1
                                . paquete  ${_CRQ_ID}
                                ${_Execution}
                            """
                       }
                       
                   
                   if (_App != "AMDOCS-BBDD" && _App != "AMDOCS-ESQUEMA" && _App != "AMDOCS-PREVIEW" && _App != "AMDOCS-BusinessRules" )
                   {
                        print "Se ejecuta en ${env.NODE_NAME} esto: "
                        print "************************************"
                        print "${exec}"
                        print "************************************"
                        //sh "${exec}"
                   }
                   else
                   {
                       if (_envExe=="PROD")
                       {
                            print "Para ${_App} y PROD se ejecuta en el CRQ"
                       }
                       else
                       {
                            print "Se ejecuta en devopsprdtools01 esto: "   
                            print "************************************"
                            print "${exec}"
                            print "************************************"
                            //sh "${exec}"
                       }
                   }
                  
                   
         }// scripts
        }//steps
  }//Stage execution
}//stages

}//pipeline
}//map
