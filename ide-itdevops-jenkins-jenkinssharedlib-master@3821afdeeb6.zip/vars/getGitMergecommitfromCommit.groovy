def call(String _SortCommit, String ENTORNO){
    echo "getGitMergecommitfromCommit"
    def SALIDA=""
    def commit=""
    SALIDA=sh returnStdout: true, script: """
            git tag -l "es*${_SortCommit}*" 
            git tag -l "ES*${_SortCommit}*"
    """
    def lista = SALIDA.split("\n").collect{it.trim()}
    echo "mergecommit:${lista}"
    def tag=""
    if (lista.size() >1){
        lista.any(){
            if(it =~ "${ENTORNO}"){
                tag=it
                return true
            }
        }
    }else{
        lista.any(){
            if(it != ""){
                tag=it
                return true
            }
        }
    }
    SALIDA=sh returnStdout: true, script: """
            git rev-list -n 1  ${tag}
    """
    commit = SALIDA.trim()
    if (commit.substring(0,7) == _SortCommit){
        error ("El commit del CI ${commit} no es un mergecommit")
    }
    echo "Mergecommit:${commit}"
	return commit
}
def call(String _SortCommit, String ENTORNO, String DELIVERY){
    echo "getGitMergecommitfromCommit"
    def SALIDA=""
    def commit=""
    def delivery=DELIVERY.toLowerCase()
    SALIDA=sh returnStdout: true, script: """
            git tag -l "${delivery}\\.*${_SortCommit}*" 
            git tag -l "${DELIVERY}\\.*${_SortCommit}*"
    """
    def lista = SALIDA.split("\n").collect{it.trim()}
    echo "mergecommit:${lista}"
    def tag=""
    if (lista.size() >1){
        lista.any(){
            if(it =~ "${ENTORNO}"){
                tag=it
                return true
            }
        }
    }else{
        lista.any(){
            if(it != ""){
                tag=it
                return true
            }
        }
    }
    SALIDA=sh returnStdout: true, script: """
            git rev-list -n 1  ${tag}
    """
    commit = SALIDA.trim()
    if (commit.substring(0,7) == _SortCommit){
        error ("El commit del CI ${commit} no es un mergecommit")
    }
    echo "Mergecommit:${commit}"
	return commit
}