def call(String _NombrePaquete,String _OrdenBBDD, String _NombreCRQ, String _ParametroSVN, String _Upgrade, String EntSimulacro){

def hoy=""
def MODSIMU=0
def rutapaquete=""
def RutaTemp=""
def exec=""
def FalloOrden=""
def FalloPaquete=""
def ModulosSIMU=""

//print "EntSimulacro ${EntSimulacro}"
   hoy=new Date().format( 'yyyyMMdd' )
   MODSIMU=0
   rutapaquete="/home/plataforma/plausr/data/paquetes/${hoy}/${_NombrePaquete}"
   RutaTemp="/home/plataforma/plausr/tmp/${hoy}"
   sh "if [ ! -d ${rutapaquete} ] ; then mkdir -p ${rutapaquete} ; fi "
   
   if (_Upgrade=="S" && "${_ParametroSVN}" == "N")  
   {
      // print "Es del upgrade"
       script="Integridad_upgrade.sh -e ${EntSimulacro}"
       //print "script: ${script}"
       sh "cp ${RutaTemp}/${_NombreCRQ}/${_OrdenBBDD} ${rutapaquete}/"
   }
   else if (_Upgrade=="S" && "${_ParametroSVN}" == "S")  
   {
      // print "Es del upgrade"
       script="Integridad_upgrade.sh -e ${EntSimulacro} "
       //print "script: ${script}"
       sh "cp ${RutaTemp}/${_NombreCRQ}/${_OrdenBBDD} ${rutapaquete}/"
   }
   else
   {
       //print "No es del upgrade"
       script="Integridad.sh"
       sh "scp CDM/DOCUMENTATION/${_NombreCRQ}/${_OrdenBBDD} opetst75:${rutapaquete}/"
   }
  
   if ( "${_ParametroSVN}" == "N" )
   { //No se sube a SVN
       exec="""
        . \$HOME/.profile >/dev/null 2>&1
        ${script} -p ${_NombrePaquete} -o ${_OrdenBBDD} -W 
   
          """
   }
   else
   {
          exec="""
        . \$HOME/.profile >/dev/null 2>&1
        ${script} -p ${_NombrePaquete} -o ${_OrdenBBDD} -W -S
   
          """
          
   }
     if (_Upgrade == "S")  
   {
      // print "Es del upgrade"
         sh "${exec}"
   }
   else
   {
       //print "No es del upgrade"
       sh "ssh -q opetst75 '${exec}'"
   }
   
   //veo que ha fallado
   FalloOrden=readFile(file: "${rutapaquete}/FaltanEnOrden.txt" )
   FalloPaquete=readFile(file: "${rutapaquete}/FaltanEnPaquete.txt")
   ModulosSIMU=readFile(file: "${rutapaquete}/ModulosSIT2.txt")
   
   if ( "${_ParametroSVN}" == "N" )
   {//No sube a SVN es solo revisar la integridad
       if (FalloOrden != "" || FalloPaquete != "" )
       {
           print "****************************************"
           print "         INCORRECT INTEGRITY"
           print "****************************************"
       }
       if (FalloOrden == "" && FalloPaquete == "" )
       {
           print "****************************************"
           print "         CORRECT INTEGRITY"
           print "****************************************"
       }
       if (FalloOrden != "")
       {
           print "****************************************"
           print "         MISSING IN ORDER"
           print "****************************************"
           print "${FalloOrden}"
       }
       else
       {
           sh " rm -f  ${rutapaquete}/FaltanEnOrden.txt"
       }
       if (FalloPaquete != "")
       {
           print "****************************************"
           print "         MISSING IN PACKAGES"
           print "****************************************"
           print "${FalloPaquete}"
       }
       else
       {
           sh " rm -f  ${rutapaquete}/FaltanEnPaquete.txt"
       }
   }
   else
   { //Hemo spedido subir a SVN si ha fallado salimos por error
       if (FalloOrden != "" || FalloPaquete != "" )
       {
           print "****************************************"
           print "         INCORRECT INTEGRITY"
           print "****************************************"
           
            if (FalloPaquete != "")
             {
               print "****************************************"
               print "         MISSING IN PACKAGES"
               print "****************************************"
               print "${FalloPaquete}"
            }
        if (FalloOrden != "")
            {
               print "****************************************"
               print "         MISSING IN ORDER"
               print "****************************************"
               print "${FalloOrden}"
            }
            error("We cannot continue due to failures of INTEGRITY")
       }
   }
   //Modulos de Simulacro
   if (ModulosSIMU != "")
    {
        print "********************************************************************************"
        print "THERE ARE MODULES WITH TOKEN ${EntSimulacro} WHAT SHOULD BE LAUNCHED AFTER THE DRILL"
        print "THESE ARE:"
        print "${ModulosSIMU}"
        print "****************************************************************"
        MODSIMU=1
    }
   
   //Para que salga por error
    if (FalloOrden != "" || FalloPaquete != "" )
    {
       error("INCORRECT INTEGRITY")
    }
    return  MODSIMU
}
