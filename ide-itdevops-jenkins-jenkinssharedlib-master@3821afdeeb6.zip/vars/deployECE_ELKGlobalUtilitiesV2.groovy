mport vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi
import vfes.utils.VFESALMSDeployment

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
def call(Map config, VFESALMSDeployment alms, VFESGitMergeInfo_aaresmi mergeInfo, ArrayList ParamItem2Delete)
{

    def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    def _envConfig=myEnvsConfig[alms.deployEnv]

    //////////////////////////////////////////
    /////////CHECK REPOSITORY CHANGES/////////
    //////////////////////////////////////////
    items2DeployConfig=mergeInfo.FilesChangedDetailed.findAll{!(it[1] =~ "scripts/" || it[1] =~ "policies/")}
    items2Delete=mergeInfo.FilesChangedDetailed.findAll{it[0] == "D" && (it[1] =~ "scripts/" || it[1] =~ "policies/")}
    items2Rename=mergeInfo.FilesChangedDetailed.findAll{it[0] == "R" && (it[1] =~ "scripts/" || it[1] =~ "policies/")}
    items2Deploy=mergeInfo.FilesChangedDetailed.findAll{(it[0] == "M" || it[0] == "A") && (it[1] =~ "scripts/" || it[1] =~ "policies/")}

    echo "=============================================="
    echo "CHANGES FOUNDS IN COMMIT"
    echo "=============================================="
    echo "CHANGES ONLY AT FILESYSTEM LEVEL:"
    echo "Configuration Files to Deploy:  ${items2DeployConfig.size()}"
    echo "CHANGES AT ELASTICSEARCH LEVEL:"
    echo "ElasticSearch Items to Delete:  ${items2Delete.size()}"
    echo "ElasticSearch Items to Rename:  ${items2Rename.size()}"
    echo "ElasticSearch Items to Deploy:  ${items2Deploy.size()}"
    echo "=============================================="

    if (items2Deploy.size() == 0 && items2Delete.size() == 0 && items2Rename.size() == 0 && items2DeployConfig.size() == 0)
    {
        echo "ERROR. There are not any change detected!!!!!. "
        sh ("exit 1")
    }

    if (items2Delete.size() != 0) {
        echo "ElasticSearch Items to Delete detected. Checking with parameter ITEMS2DELETE ....."
        filesItems2Delete = []
        items2Delete.each { filesItems2Delete.add(it[1].value.toString()) }
        listFilesItems2Delete = filesItems2Delete as List
        //echo "listFilesItems2Delete=${listFilesItems2Delete}"

        def diffInFiles = (listFilesItems2Delete - ParamItem2Delete)
        def diffInParam = (ParamItem2Delete - listFilesItems2Delete)

        //echo "diffInFiles=${diffInFiles}"
        //echo "diffInParam=${diffInParam}"

        if (diffInParam.size() != 0) {
            echo "WARN. There are some ElasticSearch Items in the param ITEMS2DELETE that were not detected in the in the commit to be deleted!!!!!. "
            echo "${diffInParam}"
        }

        if (diffInFiles.size() != 0) {
            echo "ERROR. There are some ElasticSearch Items detected to be deleted in the commit that there isn't in the param ITEMS2DELETE!!!!!. We cannot continue"
            echo "${diffInFiles}"
            sh("exit 1")
        }
        echo "OK. ElasticSearch Items to Delete Checked with parameter ITEMS2DELETE Successfully."
        echo "=============================================="
    }

    ///////////////////////////////////
    /////////NEW CHECK ACTIONS/////////
    ///////////////////////////////////
    if (config.containsKey("deployActions"))
    {
        deployECE_ELKCheckVariables config,alms
    }
    ///////////////////////////////////
    /////////NEW CHECK ACTIONS/////////
    ///////////////////////////////////

    echo "Deploying Utilities ...."
    echo "_envConfig"+_envConfig['deploy_utilities']
    _envConfig['deploy_utilities'].each { item ->
        echo "Server Data:"
        echo "  deploy_server: " + item.server
        echo "  deploy_user: " + item.user
        echo "  application_release_path: " + item.application_release_path
        echo "  platafor_release_path: " + item.platafor_release_path + "/scripts"
        echo "  variables repository: " + item.repo_vars
        echo "  deploy Script: " + config.deployScript
        echo "ElasticSearch Data:"
        echo "  elastic_sch: " + item.elastic_sch
        echo "  elastic_host: " + item.elastic_host
        echo "  elastic_port: " + item.elastic_port
        echo "  elastic_credential: " + item.elastic_credential
        def _elasticURL=""

        //DELETE
        if ( items2Delete.size() != 0 )
        {
            echo "=============================="
            echo "DELETE Scripts and/or Policies"
            echo "=============================="
            // SCRIPTS
            scripts2Delete = []
            items2DeleteScripts = items2Delete.findAll { it[1] =~ 'scripts/' }
            items2DeleteScripts.each { it -> scripts2Delete.add(it[1]) }
            scripts2DeleteString = scripts2Delete.join(",")
            _paramScripts = ""
            if (scripts2DeleteString != null && scripts2DeleteString != "") {
                _paramScripts = "-s ${scripts2DeleteString}"
            }
            echo "Scripts to delete: " + scripts2DeleteString

            // POLICIES
            policies2Delete = []
            items2DeletePolicies = items2Delete.findAll { it[1] =~ 'policies/' }
            items2DeletePolicies.each { it -> policies2Delete.add(it[1]) }
            policies2DeleteString = policies2Delete.join(",")
            _paramPolicies = ""
            if (policies2DeleteString != null && policies2DeleteString != "") {
                _paramPolicies = "-p ${policies2DeleteString}"
            }
            echo "Policies to delete: " + policies2DeleteString

            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -d -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} ${_paramScripts} ${_paramPolicies}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -d -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramScripts} ${_paramPolicies}'"
            }
        }

        //RENAME
        if ( items2Rename.size() != 0 )
        {
            echo "=============================="
            echo "RENAME Scripts and/or Policies"
            echo "=============================="
            // SCRIPTS
            scripts2Rename = []
            items2RenameScripts = items2Rename.findAll { it[1] =~ 'scripts/' }
            items2RenameScripts.each { it -> scripts2Rename.add("${it[1]}#${it[2]}") }
            scripts2RenameString = scripts2Rename.join(",")
            _paramScripts = ""
            if (scripts2RenameString != null && scripts2RenameString != "") {
                _paramScripts = "-s ${scripts2RenameString}"
            }
            echo "Scripts to rename: " + scripts2RenameString

            // POLICIES
            policies2Rename = []
            items2RenamePolicies = items2Rename.findAll { it[1] =~ 'policies/' }
            items2RenamePolicies.each { it -> policies2Rename.add("${it[1]}#${it[2]}") }
            policies2RenameString = policies2Rename.join(",")
            _paramPolicies = ""
            if (policies2RenameString != null && policies2RenameString != "") {
                _paramPolicies = "-p ${policies2RenameString}"
            }
            echo "Policies to rename: " + policies2RenameString

            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -x -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} ${_paramScripts} ${_paramPolicies}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -x -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramScripts} ${_paramPolicies}'"
            }
        }

        //UPDATE (ADD/MODIFY)
        if (items2Deploy.size() != 0) {
            echo "====================================="
            echo "UPDATE/CREATE Scripts and/or Policies"
            echo "====================================="
            // SCRIPTS
            scripts2Deploy = []
            items2DeployScripts = items2Deploy.findAll { it[1] =~ 'scripts/' }
            items2DeployScripts.each { it -> scripts2Deploy.add(it[1]) }
            scripts2DeployString = scripts2Deploy.join(",")
            _paramScripts = ""
            if (scripts2DeployString != null && scripts2DeployString != "") {
                _paramScripts = "-s ${scripts2DeployString}"
            }
            echo "Scripts to deploy: " + scripts2DeployString

            // POLICIES
            policies2Deploy = []
            items2DeployPolicies = items2Deploy.findAll { it[1] =~ 'policies/' }
            items2DeployPolicies.each { it -> policies2Deploy.add(it[1]) }
            policies2DeployString = policies2Deploy.join(",")
            _paramPolicies = ""
            if (policies2DeployString != null && policies2DeployString != "") {
                _paramPolicies = "-p ${policies2DeployString}"
            }
            echo "Policies to deploy: " + policies2DeployString

            echo "AT: ${item.user}@${item.server}"
            echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
            {
                _elasticURL = item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
                echo "PARAMETERS: -u -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramScripts} ${_paramPolicies}"
                sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -u -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -v ${item.repo_vars} ${_paramScripts} ${_paramPolicies}'"
            }
        }
    }
}