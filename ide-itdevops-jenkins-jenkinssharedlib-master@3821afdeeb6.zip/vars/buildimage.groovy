def call(String APLICACION,String VERSION,Object env_config_dev, String namespace){
	echo "buildimage"
    openshift.withCluster(env_config_dev.oc_cluster) {
        openshift.withProject(namespace) {
            openshift.logLevel(3)
            if (openshift.selector("bc","${APLICACION}").exists()){
                openshift.selector("bc","${APLICACION}").delete()
            }
            openshift.newBuild("--name=${APLICACION}", "-l APP=${APLICACION}", "--env='HOSTNAME=${APLICACION}'", "--binary ","--strategy=docker", "--to=${APLICACION}:${VERSION}")
            openshift.startBuild(APLICACION,"--from-dir='.'", )
            def bc=openshift.selector('bc', APLICACION)
            def builds = bc.related('builds')
            echo 'Waiting for the container build to be started...'
            timeout(5) { // 5 min
                builds.watch {
                    echo "So far, ${bc.name()} has created builds: ${it.names()}"

                    // End the watch only once a build object has been created.
                    return it.count() > 0
                }
                builds.watch {
                    if ( it.count() == 0 ) return false

                    // A robust script should not assume that only one build has been created, so
                    // we will need to iterate through all builds.
                    def allDone = true
                    it.withEach {
                        // 'it' is now bound to a Selector selecting a single object for this iteration.
                        // Let's model it in Groovy to check its status.
                        def buildModel = it.object()
                        if ( it.object().status.phase != "Complete" ) {
                            allDone = false
                        }
                    }
                    return allDone;
                }
                builds.untilEach(1) { 
                    return it.object().status.phase == "Complete"
                }
            }
        }
    }
}