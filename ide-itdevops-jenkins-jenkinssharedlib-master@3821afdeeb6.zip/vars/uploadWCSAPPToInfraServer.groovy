import vfes.utils.VFESALMSDeployment

def call(Map config,Map env_config,VFESALMSDeployment alms){
    def myenvd=alms.deployEnv
    def plataforpath=""
    def zipname=""
    if (alms.deployEnv == 'HID1CI' || alms.deployEnv == 'masterCI')   
    {
          
        switch  (alms.deployEnv){
            case 'HID1CI':
                myenvd='HID1'
                break
            case 'masterCI':
                myenvd='PROD'
                break
            case 'HID1':
                myenvd='HID1'
                break
            case 'master':
                myenvd='PROD'
                break

        }
        plataforpath="/home/plataforma/plausr/data/temporal/${alms.jobDate}/anexo/${alms.almsID}/${myenvd}"
        zipname="${alms.almsID}-${alms.appName}"
    }
    else
    {
        plataforpath="/home/plataforma/plausr/data/temporal/${alms.jobDate}/anexos/${alms.almsID}"
        zipname="${alms.almsID}-${alms.deployEnv}.${alms.appName}-${alms.jobTimeStamp}"
    }
    echo "Create zip file..."
    dir(config.extractFolder){
        if (!alms.onlyProperties){
            echo "Bundling WAR files in ZIP as there are code changes involved..."
            sh """

                find pom.xml assembly.xml WCS-CAS WCS-COA WCS-Coherence WCS-DescargaFicheros \
                    WCS-Facturacion WCS-Libraries/cas-vodafone/4.0/project WCS-Libraries/cas-ws-client/4.0/project \
                    WCS-Libraries/mivodafone-api/4.0/project \
                    WCS-Libraries/mivodafone-cache/4.0/project WCS-Libraries/mivodafone-coh-api/4.0/project \
                    WCS-Libraries/mivodafone-core/4.0/project WCS-Libraries/mivodafone-dao/4.0/project \
                    WCS-Libraries/mivodafone-download-core/4.0/project WCS-Libraries/mivodafone-ws-client/4.0/project \
                    WCS-Logo WCS-MiVF -type f -name "*.war" | grep -v target | zip -r ../${zipname}.zip -@;
                    """
        }
        echo "Bundling property files in ZIP ..."
        sh """
            find pom.xml assembly.xml WCS-CAS WCS-COA WCS-Coherence WCS-DescargaFicheros \
                WCS-Facturacion WCS-Libraries/cas-vodafone/4.0/project WCS-Libraries/cas-ws-client/4.0/project \
                WCS-Libraries/mivodafone-api/4.0/project \
                WCS-Libraries/mivodafone-cache/4.0/project WCS-Libraries/mivodafone-coh-api/4.0/project \
                WCS-Libraries/mivodafone-core/4.0/project WCS-Libraries/mivodafone-dao/4.0/project \
                WCS-Libraries/mivodafone-download-core/4.0/project WCS-Libraries/mivodafone-ws-client/4.0/project \
                WCS-Logo WCS-MiVF -type d -name "properties" | zip -r ../${zipname}.zip -@
                """
    }    
    echo "Deleting the files under target folders ..."
    sh 'find project -name "target" -type d -exec rm -rf {} \\; || true'
    
    env_config["wcs-app"].each { item ->
            echo "Preparing for ${item.server} ..."
            echo "create .env file for deployment ..."
            sh "echo export REL_ROOT=${item.path} >> ${zipname}.${item.server}.env"
            sh "echo export USER_REL=${item.username} >> ${zipname}.${item.server}.env"
            echo "create path in remote server"
            sh "ssh platafor@${item.server} 'mkdir -p ${plataforpath}'"
            echo "upload .sh, .zip and .env files"
            sh "scp ${zipname}.${item.server}.env platafor@${item.server}:${plataforpath}/${zipname}.env"
            sh "scp ${zipname}.zip platafor@${item.server}:${plataforpath}/${zipname}.zip"
            sh "scp ${WORKSPACE}/CDM/CommonTools/scripts/ROLLBACK_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.bak.sh"
            sh "scp ${WORKSPACE}/CDM/CommonTools/scripts/DEPLOY_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.sh"
            sh "ssh platafor@${item.server} 'chmod 777 ${plataforpath}; chmod 755 ${plataforpath}/*.sh'"
    }
    echo ""
    echo ""
    echo "************************************************************************"
    echo "************************************************************************"
    echo "Execute:"
    currentBuild.description = currentBuild.description+"\n\r\n\rExecute:"
    env_config["wcs-app"].each { item ->
        echo "${item.username}@${item.server}:${plataforpath}/${zipname}.sh"
        currentBuild.description = currentBuild.description+"\n\r${item.username}@${item.server}:${plataforpath}/${zipname}.sh"
    }
    echo "************************************************************************"
    echo "************************************************************************"
    echo ""
    echo ""
}