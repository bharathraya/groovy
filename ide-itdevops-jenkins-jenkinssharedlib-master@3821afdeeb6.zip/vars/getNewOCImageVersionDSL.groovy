def call(String clusterName, String _ARTID,String commit, String _ENTORNO, String noproxy, String  _Delivery) {
    echo "getNewOCImageVersionDSL"
    def version=""
    def versionaux=""
    def lowerARTID=_ARTID.toLowerCase()
    withEnv(["PATH+OC=${tool 'occli-jenkins'}","KUBECONFIG=$HOME/.kube/config"]) {
        openshift.withCluster(clusterName) {
    	    echo "Using Cluster: ${openshift.cluster()}"
    	    openshift.withProject("${_ENTORNO}") {
    	        echo "Using project: ${openshift.project()}"
    	        if(openshift.selector('is', "${lowerARTID}").exists()){
        	        def tags = openshift.selector('is', "${lowerARTID}").object().status.tags
                	List versions=[]
                    tags.any{
                	    versionaux=it.tag
                        echo "Found tag:${versionaux}"
                        def token=versionaux.tokenize(".")
                        if( token[2] == commit){   
                            version=versionaux
                            echo "Ya existe la imagen ${_ARTID}:${version} para el commit ${commit}"
                            return true
                        }
                        if( token[0].toLowerCase() == _Delivery.toLowerCase()){
                            versions.add(token[1].toInteger())
                        }
                    }
                	if ( version == "")
                	{
                	    echo "Existe la imagen en el repositorio, pero no el commit ${commit}"
                	}else{

                        def newsec=versions.max().toInteger()+1
                        version="${_Delivery}"+"."+newsec.toString()+"."+"${commit}"
                        echo "VERSION:${version}"
                    }
    	        }else{
    	            echo "No existe la imagen en el repositorio"
                    version="${_Delivery}.1.${commit}"
    	        }
            }
        }
    }
    return version
}