import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo

def deploy_env=""
def commit_id=""
def alms_id=""
def delivery=""
def project_id=""
def artifact_id=""
def squad=""

def almsPackage=null
def gitRepo=null
def pipelineConfig=null
VFESGitMergeInfo mergeInfo=null
def artifacts=null
def gitRepoURL=""


def call(Map pipelineParams){
    pipeline{
        agent none
        parameters { 
            choice(name: 'DeployEnv',  choices: pipelineParams.environmentChoices , description: '') 
            choice(name: 'ArtifactId', choices: pipelineParams.artifactChoices, description: '') 
            string(name: 'CommitID', defaultValue: '', description: '') 
            string(name: 'ALMS_ID', defaultValue: '', description: '') 
            string(name: 'Delivery', defaultValue: '', description: '') 
            string(name: 'ProjectId', defaultValue: '', description: '') 
            string(name: 'SQUAD', defaultValue: 'BAU', description: '') 
            string(name: 'PackageInfo', defaultValue: '', description: '') 
        }
        stages{
            
            stage("Prepare"){
                agent {
                    label "MVOW"
                }
                steps{
                    script {
                        if (params.PackageInfo==""){
                            // executed manually or from ALMS
                            deploy_env=params.DeployEnv
                            
                            commit_id=params.CommitID
                            
                            alms_id=params.ALMS_ID
                            delivery=params.Delivery
                            project_id=params.ProjectId
                            artifact_id=params.ArtifactId
                            squad=params.SQUAD
                        }else{
                            echo "PackageInfo: ${params.PackageInfo}"

                            (deploy_env,commit_id,alms_id,delivery,project_id,squad,artifact_id)=parsePckInfoWithArtifact(PackageInfo)
                            //pckinfo=readJSON(text:PackageInfo)
                            //deploy_env=pckinfo.Environment.Name
                            //commit_id=pckinfo.decideCommitId(pckinfo.Commits,deploy_env)
                            //alms_id=pckinfo.Id
                            //delivery=pckinfo.Delivery.Name
                            //project_id=pckinfo.Project.CodProject
                            //squad=pckinfo.EnterpriseName
                        }
                        echo "    ArtifactId:  ${artifact_id}"
                        echo "    DeployEnv: ${deploy_env}"
                        echo "    CommitID:  ${commit_id}"
                        echo "    PackageID: ${alms_id}"
                        echo "    Delivery:  ${delivery}"
                        echo "    Project:   ${project_id}"
                        echo "    Squad:     ${squad}"  

                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
						def pipeLineConfigPath = new File(pipelineParams.pipelineConfigFile).parent
						if ( fileExists (pipeLineConfigPath+"/"+artifact_id+".yml") ){
							echo "loading artifact config: "+pipeLineConfigPath+"/"+artifact_id+".yml"
							def artifactConfig=readYaml(file: pipeLineConfigPath+"/"+artifact_id+".yml")
							echo "Merging artifact config into pipeline config ..."
							pipelineConfig=pipelineConfig+artifactConfig
						}
                        almsPackage= new VFESALMSDeployment(alms_id,artifact_id,deploy_env,commit_id,delivery,project_id,squad)
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
						def addArtifactToExtractFolder=true
						if (pipelineConfig.containsKey("addArtifactToExtractFolder")){
							addArtifactToExtractFolder=pipelineConfig.addArtifactToExtractFolder
						}
						if (addArtifactToExtractFolder){
							echo "Adding the artifact to the extract folder"
                        	pipelineConfig.extractFolder=pipelineConfig.extractFolder+"/"+artifact_id
						}
                        // TODO : when 
                        if (pipelineConfig.gitRepoPath!=""){
                            gitRepoURL=pipelineConfig.gitRepoPath+artifact_id+".git"
                            echo "Git Repo URL: ${gitRepoURL}"
                            gitRepo=new VFESGitRepo("${gitRepoURL}",this)    
                        }else{
                            gitRepo=new VFESGitRepo("${pipelineConfig.gitRepo}",this)
                        }
						env.switchUT=false
						env.BITBUCKETAPIURL = "https://webpre-adm.es.sedc.internal.vodafone.com:42520/bitbucket/rest/api"
						if (gitRepo.repoType==gitRepo.BITBUCKET){
							env.switchUT=checkUnitTest(env.BITBUCKETAPIURL,gitRepo.repoProjectKey,gitRepo.repoName)
						}
						env.switchKiuwan=getRunKiuwan(pipelineConfig,artifact_id)
						env.compile=false
						if (pipelineConfig.containsKey("doCompile")){
							env.compile=pipelineConfig.doCompile.toBoolean()
							echo "env.compile: ${env.compile}"
							
						}

                    }
                    
                }
            }
            stage('Checkout'){
                agent {
                    
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy=="SIMPLE" && ! (almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/)){
                            gitRepo.checkoutCommit(pipelineConfig.extractFolder,almsPackage.deployEnv,almsPackage.commitID)
                        }else if (pipelineConfig.branchPolicy==~/(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI)/)
                        {
                            gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,"develop")
                        }else{
                            gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
                        }
                    }
                }
            }
            stage('merge'){
                when{
                    expression { return (!(pipelineConfig.branchPolicy ==~ /SIMPLE/) || (pipelineConfig.branchPolicy ==~ /SIMPLE/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/))}
                }
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy ==~ /(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(master|masterCI)/){
                            echo "Merging to ${almsPackage.deployEnv} we will check for the corresponding tag for ${almsPackage.commitID} in develop branch..."
                            mergeInfo=gitRepo.mergeCommitFromDevelop(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage,almsPackage.almsID)
                        }else{
                            mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
                        }
                        
                    }
                }
            }

            stage('Deploy'){
                
                agent{
                    docker {
                        label 'maven'
                        image "${pipelineConfig.deployDockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
						// copy env cmd to local path
						dir (pipelineConfig.extractFolder){
							deployscript="ls"
							if (deploy_env ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/){
								deployscript="pre.cmd"
							} else if (deploy_env ==~ /(?i)PROD|master/) {
								deployscript="pro.cmd"
							}
							sh """if [ -f deploy/${deployscript} ]
								then
									cp deploy/${deployscript} .
								else
									cp trash/${deployscript} .
								fi
								chmod 750 ${deployscript}
							"""
							// execute ibmcloud login
							withCredentials([string(credentialsId: 'ibmcloud-key', variable: 'apikey')]) {
								sh "ibmcloud login --apikey ${apikey} -r eu-de "
							}
							sh "echo ibmcloud cf install"

							// execute ibmcloud deploy
							sh "./${deployscript}" 
						}
                    }
                    
                }
            }
            stage('TagAndPush'){
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy=="SIMPLE"){
                            if (almsPackage.deployEnv==~/(?i)(hid1|hid|hidci|hid1ci)/){
                                //caso de Oculto uso rama develop
                                echo "Tag and push to develop branch ..."
                                gitRepo.tagAndPushDevelop pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,"develop",almsPackage.almsID,almsPackage.commitID
                            }else if (almsPackage.deployEnv==~/(?i)(master|masterCI)/){
                                echo "Tag commit and push to git "
                                gitRepo.tagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                            else{
                                echo "Tag and push to git "
                                gitRepo.simpleTagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv,almsPackage.almsID

                            }
                        }else if (pipelineConfig.branchPolicy=="envs_and_develop")
                        {
                            if (almsPackage.deployEnv==~/(?i)(hid1|hid|hidci|hid1ci)/){
                                //caso de Oculto uso rama develop
                                echo "Tag and push to develop branch ..."
                                gitRepo.tagAndPushDevelop pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,"develop",almsPackage.almsID,almsPackage.commitID
                            }else if (almsPackage.deployEnv==~/(?i)(master|masterCI)/){
                                echo "Tag commit and push to git "
                                gitRepo.tagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                            else{
                            echo "Tag commit and push to git "
                            gitRepo.tagAndPush pipelineConfig.extractFolder,
                                almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                        }
                        else
                        {
                            echo "Tag commit and push to git "
                            gitRepo.tagAndPush pipelineConfig.extractFolder,
                                almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                        }
                    }
                }
            }
            stage('PublishChanges'){
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy!="SIMPLE"){
                            echo "Publish changes to ELK  and GitPublish plugin"
                            publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                        }
                    }
                    
                }
            }

        }
        post { 
            always { 
                node('master') {
                    catchError(message:"Error when publishing to InfluxDB") {
                        script{
                            echo 'Publishing to Influx for Pipeline KPI!!!'
                            echo "Squad: ${squad}"
                            sendInfluxMetrics "${deploy_env}", squad
                        }
                    }
                }

            }
			//failure{
				//slackNotify pipelineConfig,almsPackage,"ERROR"
			//}
			//success{
				//slackNotify pipelineConfig,almsPackage,"OK"
			//}

        }

        
    }
}