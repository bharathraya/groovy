def call(String oc_cluster,List listRollbackProjects, List listConfigmap, List listSecrets, List listResourceDel, List listRollbackDeployment, List jsonDc, String ENTORNO){
    echo "doRollbackConfig"
    openshift.withCluster(oc_cluster) {
        echo "Using Cluster: ${openshift.cluster()}"
        listRollbackProjects.each(){
            project_dest=it
            echo "Tratando projecto:${project_dest}"
            openshift.withProject(project_dest) {
                //rollback configmap
                listConfigmap.each(){
                    if(it!=""){
                        echo "Tratando configmap: ${it.metadata.name}"
                        def cmapback=it
                        def project=cmapback.metadata.namespace
                        def name=cmapback.metadata.name
                        if (project == project_dest){
                            echo "Borrando configmap:${name}"
                            try{
                                openshift.selector('configmap', "${name}").delete()
                            }
                            catch(e){
                                echo "No ha podido borrar el configmap ${name}"
                            }
                            echo "Creando configmap:${name}"
                            openshift.create(cmapback)
                        }
                    }
                }
                //rollback secrets
                listSecrets.each(){
                    if(it!=""){
                        echo "Tratando secret: ${it.metadata.name}"
                        def secretback=it
                        def project=it.metadata.namespace
                        def name=it.metadata.name
                        if (project == project_dest){
                            echo "Borrando secret:${name}"
                            try{
                                openshift.selector('secret', "${name}").delete()
                            }
                            catch(e){
                                echo "No ha podido borrar el secret ${name}"
                            }
                            echo "Creando secret:${name}"
                            openshift.create(secretback)
                        }
                    }
                }
                //delete resources
                listResourceDel.each(){
                    if(it!=""){
                        if (it.namespace == project_dest){
                            openshift.selector("${it.type}", "${it.name}").delete()
                            echo "Borrado it.type:${it.name} en ${it.namespace}"
                        }
                    }
                }
                //redeploy dc
                def errorRollback=false
                listRollbackDeployment.each(){
                    if(it!=""){
                        def ms=it
                        _App=ms.application
                        APLICACION=_App.toLowerCase()
                        echo "Rollback: ${APLICACION}"
                        app_project_dest="${ms.namespace}-${ENTORNO}"
                        if (app_project_dest == project_dest){
                            echo "Rollback ${APLICACION} en: ${openshift.project()}"
                            def listDeployment=getListJsonDC(jsonDc,APLICACION)
                            listDeployment.each(){
                                def prevDeployment="${it.name}"
                                if (it.version != "latest"){
                                    def token1=it.version.tokenize(".")
                                    def LOWERVERSION="${token1[0].toLowerCase()}.${token1[1]}.${token1[2]}"
                                    prevDeployment="${prevDeployment}-${LOWERVERSION}"
                                }
                                openshift.selector("deployment", "${prevDeployment}").rollout().undo()
                                def latestDeploymentVersion = openshift.selector("deployment", "${prevDeployment}").object().status.latestVersion
                                def replicasetToCheck = openshift.selector('replicaset', "${prevDeployment}-${latestDeploymentVersion}")
                                echo "replicasetToCheck:[${replicasetToCheck}]"
                                try{
                                    timeout(3){
                                        replicasetToCheck.untilEach(1){
                                            def replicasetMap1 = it.object()
                                            replicas=replicasetMap1.status.replicas.equals(replicasetMap1.status.readyReplicas)
                                            return (replicas)
                                        }
                                    }
                                }
                                catch(all){
                                    echo "Error rollback dc: ${it.name}-${it.version}"
                                    errorRollback=true
                                }
                            }
                        }
                    }
                }
                if (errorRollback){
                    error "Error haciendo rollback"
                }
            }
        }
    }
}