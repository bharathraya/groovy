def call(Map salidaMs,String oc_cluster, String k8s_cluster, String project, Integer deployTimeout, List msListDeployment ,String BASEDIR, String ENTORNO, Map parameters){
    echo "deployMsParams1("+salidaMs+","+oc_cluster+","+k8s_cluster+","+project+","+deployTimeout+","+msListDeployment+","+BASEDIR+","+ENTORNO+","+parameters+")"
    def rollback=false
    def APP=""
    def status=""
    listrollbackresource=[]
    listdeleteresource=[]
    msListDeployment.each(){
        def ms=it
        _App=ms.application
        APLICACION=_App.toLowerCase()
        namespace=ms.namespace
        if (project!=""){
            namespace=namespace+"-"+project
        }
        def LOWERVERSION=ms.version.toLowerCase()
        echo "LOWERVERSION: ${LOWERVERSION}"
        def VERSION=ms.version
        echo "Crear: resources ${APLICACION}"
        def sTemplate="TemplateCD/${ms.template}"
        def sTemplateExtra=""
        def templateList=[]
        if (ms.hasProperty('template_extra')){
            sTemplateExtra="TemplateCD/${ms.template_extra}"
            templateList.add(sTemplateExtra)
        }
        templateList.add(sTemplate)
        def sCert=""
        def pCA=""
        def pCERT=""
        def pKEY=""
        def aditionalparams=""
        parameters.each(){
            aditionalparams+=" -p $it"
            echo "aditionalparam: -p $it"
        }
        if (ms.cert !="" && ms.cert != null){
            def CERT=readFile("${BASEDIR}/CDM/Jenkins/DXL/routecerts/${ENTORNO}/${ms.cert}.cert")
            def CA=readFile("${BASEDIR}/CDM/Jenkins/DXL/routecerts/${ENTORNO}/${ms.cert}.ca")
            def KEY=readFile("${BASEDIR}/CDM/Jenkins/DXL/routecerts/${ENTORNO}/${ms.cert}.key")
            pCA="-p CA=${CA}"
            pCERT="-p CERT=${CERT}"
            pKEY="-p KEY=${KEY}"
        }
        def prevDeployments=[]
        openshift.withCluster(k8s_cluster) {
            openshift.withProject(namespace) {
                echo "Using Cluster: ${openshift.cluster()}"
                //openshift.verbose()
                openshift.logLevel(0)
                def rs = openshift.selector('replicaset', [ app: "${APLICACION}" ]).objects()
                rs.each(){
                    def rsMap = it
                    if (rsMap.status.replicas>0){
                        def rsName=rsMap.metadata.name
                        def currentDeploymentName=rsName.substring(0,rsName.lastIndexOf("-"))
                        def matcher1 = (LOWERVERSION =~ /((es[0-9]{4}[a-z]*(-rc)?)\.([0-9]*)\.([a-z0-9]{7,11}))/)
                        if (matcher1.size()==1){
                            def newDeploymentName=matcher1[0][1]
                            def newDelivery=matcher1[0][2] 
                            def newSec=matcher1[0][4]
                            
                            println "newDeploymentName=${newDeploymentName} newDelivery:$newDelivery newSec:$newSec"
                        
                            def matcher = (rsName =~ /(([a-z0-9-]*)-((es[0-9]{4}[a-z]*(-rc)?)\.([0-9]*)\.([a-z0-9]{7,11})))-[0-9]*/)
                            println "rsName=${rsName}"
                            def appVersion=matcher[0][3]                        
                            def appName=matcher[0][2]
                            def currentDelivery=matcher[0][4] 
                            def currentSec=matcher[0][6]
                            println "currentDeploymentName:${currentDeploymentName} currentDelivery:$currentDelivery currentSec:$currentSec replicas=${rsMap.status.replicas}"
                            println "----- currentDelivery:$currentDelivery.$currentSec vs newDelivery:$newDelivery.$newSec"
                            if(ENTORNO=="sit1"||ENTORNO=="sit2"|ENTORNO=="pprd"){
                                if(newDelivery.substring(0,6)<currentDelivery.substring(0,6)){
                                    rollback=true
                                    salidaMs.status="ERROR: Pod already running has different Delivery (${currentDelivery}.${currentSec}) from the new one (${newDelivery}.${newSec}). Request to stop current pod to deploy previous delivery version (if allignment package, don't deploy)"
                                    println salidaMs
                            
                                }else{
                                    if (newDelivery.substring(0,6) == currentDelivery.substring(0,6)){
                                        if(newDelivery.substring(0,8) == currentDelivery.substring(0,8)){
                                            if(newDelivery > currentDelivery){
                                                println "CurrentDelivery:$currentDelivery < newDelivery:${newDelivery}"
                                            }
                                            if (newDelivery == currentDelivery){
                                                if(newSec.toInteger() >= currentSec.toInteger()){
                                                    println "CurrentDelivery:${currentDelivery}.${currentSec} <= newDelivery:${newDelivery}.${newSec}"
                                                }else{
                                                    rollback=true
                                                    salidaMs.status="ERROR: Pod already running has different Delivery (${currentDelivery}.${currentSec}) from the new one (${newDelivery}.${newSec}). Request to stop current pod to deploy previous delivery version (if allignment package, don't deploy)"
                                                    println salidaMs
                                                }
                                            }
                                                
                                        }
                                        else{
                                            rollback=true
                                            salidaMs.status="ERROR: Pod already running has different Delivery (${currentDelivery}.${currentSec}) from the new one (${newDelivery}.${newSec}). Request to stop current pod to deploy previous delivery version (if allignment package, don't deploy)"
                                            println salidaMs
                                        }
                                    }else{
                                        println "CurrentDelivery:$currentDelivery < newDelivery:${newDelivery}"
                                    }
                                }
                            }
                        }

                        prevDeployments.add(currentDeploymentName)
                    }
                }
                if (openshift.selector("service", "${APLICACION}").exists()){
                    echo "serviceExiste"
                    serviceExiste=true
                }
            }
        }

        templateList.each(){
            processed=null
            def serviceExiste=false
            openshift.withCluster(oc_cluster) {
                echo "Using Cluster: ${openshift.cluster()}"
                (DC_SUM,DC_PropGen,DC_PropSpec,DC_PropTemp,paramsstring1,paramsstring2,paramsstring3)=getTemplatesInfo(it,ENTORNO,APLICACION,ms)
                //si hay propiedades repetidas en ficheros coge las del primero
                processed = openshift.process("-f", "${sTemplate}", "-p","APP_NAME=${APLICACION}",
                    "-p","NAMESPACE=${namespace}",
                    "-p","APP_VERSION=${VERSION}",
                    "-p","APP_VERSION_CANARY=${VERSION.replaceAll("\\.","-")}",
                    "-p","LOWER_APP_VERSION=${LOWERVERSION}",
                    "${aditionalparams}",
                    "${paramsstring1}","${paramsstring2}","${paramsstring3}",
                    "${pCA}","${pCERT}","${pKEY}",
                    "-p","DC_SUM=${DC_SUM}",
                    "-p","DC_PropSpec=${DC_PropSpec}",
                    "-p","DC_PropGen=${DC_PropGen}",
                    "-p","DC_PropTemp=${DC_PropTemp}",
                    "--ignore-unknown-parameters") 
                echo "Recursos"
                echo "${processed}"
            }
            openshift.withCluster(k8s_cluster) {
                processed.each(){
                    def resourceType=it.kind
                    def resourceName=it.metadata.name
                    def resourceNamespace=it.metadata.namespace
                    openshift.withProject(resourceNamespace) {
                        echo "Tratando recurso:${resourceType} ${resourceName} "
                        openshift.logLevel(1)
                        if (rollback==false){
                            try {
                                if (openshift.selector("${resourceType}", "${resourceName}").exists()){
                                    if (resourceType == "Deployment"){
                                        echo "el recurso ya existe"
                                        prevDeployments.remove(resourceName)
                                    }
                                    if (resourceType == "HorizontalPodAutoscaler"){
                                        def hpa=openshift.selector("${resourceType}", "${resourceName}").object()
                                        if (hpa.status.currentReplicas >=3){
                                            hpa.spec.minReplicas=2
                                            hpa.spec.maxReplicas=3
                                            openshift.apply(hpa)
                                            sleep 10
                                            hpa=openshift.selector("${resourceType}", "${resourceName}").object()
                                            echo "HPA: ${hpa.metadata.name} deseadas:${hpa.status.desiredReplicas} current: ${hpa.status.currentReplicas}"
                                        }
                                    }
                                    salidaMs.listrollbackresource.add(it)
                                    //echo "Borrando recurso:${resourceType} ${resourceName} "
                                    //openshift.selector("${resourceType}", "${resourceName}").delete()
                                    try{
                                        openshift.apply(it)
                                        echo "recurso ${resourceType}/${resourceName} update"
                                    }
                                    catch(e){
                                        echo "warning haciendo update, lo borro y lo creo"
                                        openshift.delete(it)
                                        openshift.create(it)
                                    }
                                }else{
                                    salidaMs.listdeleteresource.add(it)
                                    openshift.create(it)
                                    echo "recurso ${resourceType}/${resourceName} create"
                                }
                            }
                            catch(e){
                                rollback=true
                                salidaMs.status="ERROR procesando recurso ${resourceType}/${resourceName}"
                                echo salidaMs.status
                            }
                            openshift.logLevel(0)
                        }
                    }
                }
            }
        }
                //def rm = openshift.selector("dc", "${APLICACION}").rollout()
        openshift.withCluster(k8s_cluster) {
            openshift.withProject(namespace) {
                if (rollback==false){
                    def deployment=openshift.selector("deployment", "${APLICACION}-${LOWERVERSION}")
                    def latestDeploymentVersion = deployment.object().status.latestVersion
                    def replicasetToCheck = openshift.selector('replicaset', "${APLICACION}-${LOWERVERSION}-${latestDeploymentVersion}")
                    echo "replicasetToCheck:[${replicasetToCheck}]"
                    try{
                        timeout(deployTimeout){
                            replicasetToCheck.untilEach(1){
                                def replicasetMap1 = it.object()
                                replicas=replicasetMap1.status.replicas.equals(replicasetMap1.status.readyReplicas)
                                //replicas=rcMap1.status.readyReplicas>=1
                                echo "Object:${replicasetMap1.metadata.name} ready_replicas:${replicasetMap1.status.readyReplicas}"
                                try{
                                    def pod=openshift.selector('pod', [ app: "${APLICACION}" , version: "${VERSION}"])
                                    echo "pod:${pod}"
                                    timeout(time: 60, unit: 'SECONDS'){
                                        pod.logs( " -c ${APLICACION}", "--limit-bytes=100000", "--since=60s", "-f")
                                    }
                                } 
                                catch(j){
                                    echo "WARNING pod.logs:${j}"
                                    return (replicas)
                                }
                                return (replicas)
                            }
                        }
                    }
                    catch(e){
                        rollback=true
                        echo "ERROR:${e}"
                        return true
                    }
                    //bajar replicas del pod antiguo a 0.
                    prevDeployments.each(){
                        echo "scale ${it} --replicas=0"
                        openshift.selector("deployment","${it}").scale('--replicas=0')
                        
                    }
                }
            }
        }
    }
    return rollback
}