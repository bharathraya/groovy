def call(String _Alms,String _remoteServer,String _date){

    ruta_temp=${DIR_BASE_TEMPORAL}/${_date}/anexo/

    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    cd ${ruta_temp} >/dev/null 2>&1
    if [ -d ${_Alms} ]
    then
        echo 'Existe el directorio ${_Alms} lo borramos.'
        rm -Rf ${_Alms} 
    fi
    """
    
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
