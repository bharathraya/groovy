def call(String _Repo , String _MsInfo){
    echo "getMsInfofromRepo"
    def _yaml = readYaml(text: _MsInfo)
    def _ms=""
    def ms=""
    _yaml.ms.any(){
        ms=it
        //echo "ms:${ms}"
        if (ms.repo != ""){
            if (ms.repo.toLowerCase() == _Repo.toLowerCase()){
                _ms=ms
                return true
            }
        }
    }
    if (_ms == ""){
        error "Repo:${_Repo} no encontrado"
    }
    return _ms
}
