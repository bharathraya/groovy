def call (String _usuario, String _estado, String _paquete, String _pass){
   //Buscar contraseña del user
  // (_pass,_usuario)=findpassword(_usuario)

    node ('es1117yw'){
        checkout scm
        
       
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {

             bat "python promote.py -u ${_usuario} -e ${_estado} -p ${_paquete} -c ${_pass} "
             }//wrap
        }
    }
}

def call (String _usuario, String _estado, String _paquete){
   //Buscar contraseña del user
   (_pass,_usuario)=findpassword(_usuario)

    node ('es1117yw'){
        checkout scm
        
       
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {

             bat "python promote.py -u ${_usuario} -e ${_estado} -p ${_paquete} -c ${_pass} "
             }//wrap
        }
    }
}