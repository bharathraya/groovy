def call(String RepoAppInfoCsv, String separator){
    echo "getYamlFromCsv"
    def lines=RepoAppInfoCsv.split("\n")
    def linea=0
    def tokens=""
    def dataList=""
    def lineCounter = 0
    def headers = []
    def headerSize=0
    def rowSize=0
    lines.each() { line ->
        if (lineCounter == 0) {
            headers = line.split(separator).collect{it.trim()}.collect{it}
            headerSize=line.split(separator).size()
        } else {
            def dataItem = [:]
            def row = line.split(separator).collect{it.trim()}.collect{it}
            rowSize=line.split(separator).size()
            if (headerSize == rowSize){
                dataList+="- ms:\n"
                //echo "- ms:\n"
                headers.eachWithIndex() { header, index ->
                    dataList+="    ${header}: ${row[index]}\n"
                    //echo "linea:    ${header}: ${row[index]}\n"
                }
            }
        }
        lineCounter = lineCounter + 1
    }
    //echo "dataList:${dataList}"
    return dataList
}