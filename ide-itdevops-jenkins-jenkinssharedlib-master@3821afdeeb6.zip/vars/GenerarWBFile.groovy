def call(String _CRQ,String _NombreCarpeta, String _env, String _domain, Boolean _Ventana, String _Upgrade){
    def hoy=""
    def _remoteServer=""
    def _remoteServerONO=""
    def exec=""
    def execTraer=""
    
  hoy=new Date().format( 'yyyyMMdd' )
  _remoteServer = "es036tvr"
  if (_Upgrade=="N")
   {
        _remoteServerONO = "opetst75"
   }
  else
   {
        _remoteServerONO = "devopststtools01"
   }
    
     exec="""
        . \$HOME/.profile >/dev/null 2>&1

        etoWB.sh -p ${_NombreCarpeta} -e ${_env}
    
    """
    
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
    
    //copio el extras en caso ventana si es parche_ono no lo copio
    if ((_domain == "AMDOCS-UPSD" || _domain == "AMDOCS-CLARIFY") && _Ventana == true)
    {//Copiamos tb el extras.txt

     execTraer="""
         . \$HOME/.profile >/dev/null 2>&1
         . paquete ${_CRQ}
         scp ${_remoteServer}:/home/plataforma/plausr/data/paquetes/${hoy}/${_NombreCarpeta}/WB_FILE .
         scp ${_remoteServer}:/home/plataforma/plausr/data/temporal/${hoy}/${_NombreCarpeta}/${_env}/DataModules/* .
         mv WB_FILE WB_"${_NombreCarpeta}".txt
         if [ -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/extras.txt ]
         then
            if  [ "${_domain}" == "AMDOCS-UPSD" ]
            then
                mv extras.txt UPSD_extras.txt
            else
                mv extras.txt CLARIFY_extras.txt
            fi
         fi
    
    """
    }
    else
    {
         execTraer="""
         . \$HOME/.profile >/dev/null 2>&1
         . paquete ${_CRQ}
         scp ${_remoteServer}:/home/plataforma/plausr/data/paquetes/${hoy}/${_NombreCarpeta}/WB_FILE .
         mv WB_FILE WB_"${_NombreCarpeta}".txt
    
        """
    }
    
    if (_remoteServerONO!="")
    {
        sh "ssh -q ${_remoteServerONO} '${execTraer}'"
    }
    else
    {
        sh "${execTraer}"
    }
    
}
