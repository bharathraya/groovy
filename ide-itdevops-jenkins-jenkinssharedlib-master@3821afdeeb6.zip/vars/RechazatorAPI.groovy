def call (String _usuario, String _mensaje, String _paquete ){
    node ('es1117yw'){
      //Buscar contraseña del user
        (_pass,_usuario)=findpassword(_usuario)
          checkout scm
          dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
           // bat "python rejector_api.py -p ${_paquete} -m \"${_mensaje}\" -u ${_usuario}  -c ${_pass}"
           bat "python rejector.py -p ${_paquete} -m \"${_mensaje}\" -u ${_usuario}  -c ${_pass}"
           }//wrap
    }//dir
  }//node
}

def call (String _usuario, String _mensaje, String _paquete, Integer _motivo ){
    node ('es1117yw'){
      //Buscar contraseña del user
        (_pass,_usuario)=findpassword(_usuario)
          checkout scm
          dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
           // bat "python rejector_api.py -p ${_paquete} -m \"${_mensaje}\" -t ${_motivo} -u ${_usuario}  -c ${_pass}"
            bat "python rejector.py -p ${_paquete} -m \"${_mensaje}\" -t ${_motivo} -u ${_usuario}  -c ${_pass}"
           }//wrap
    }//dir
  }//node
}

def call (String _usuario, String _mensaje, String _paquete, Integer _motivo, String _fichero ){
    node ('es1117yw'){
      //Buscar contraseña del user
        (_pass,_usuario)=findpassword(_usuario)
          checkout scm
          dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
          //  bat "python rejector_api.py -p ${_paquete} -m \"${_mensaje}\" -t ${_motivo} -f ${_fichero} -u ${_usuario}  -c ${_pass}"
           bat "python rejector.py -p ${_paquete} -m \"${_mensaje}\" -t ${_motivo} -f ${_fichero} -u ${_usuario}  -c ${_pass}"
           }//wrap
    }//dir
  }//node
}