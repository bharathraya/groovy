def call (String _usuario, String _origen,String _destino,String _paquete,String _option){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python notif.py -u ${_usuario} -o ${_origen} -d ${_destino} -f ${_paquete} ${_option}"
        }
    }
}
