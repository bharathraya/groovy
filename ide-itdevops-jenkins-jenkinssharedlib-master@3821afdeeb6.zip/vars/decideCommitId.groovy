def call(net.sf.json.JSONArray commits,String _deploy_env){
  
    String ret=""
    String bitbucketBranchPrefix="release/"
    String branchPrefix=""
    echo "commits.size: ${commits.size()}"
    if (commits.size()==0){
        // if we have just one commit, we just take that one
        error("There are no commits on the package !!!")
    }
    
    if (commits[0].Server.ApiEndPoint.contains('bitbucket'))
    {
        // if server is bitbucket we should adhere to naming convention defined
        // for bitbucket where the "delivery" branches start with "integration/"
        echo "bitbucket repo"
        branchPrefix=bitbucketBranchPrefix
    }

    if (commits.size()==1){
        // if we have just one commit, we just take that one
        ret=commits[0].CommitId
    }else if (commits.size()==2){
        // if we have 2 commits, we check if any of them is pre<env> and we take that one
        // else we take the one that does not start by "pre.."
        def branch0=commits[0].BranchHash
        def branch1=commits[1].BranchHash
        if (commits[0].Server.ApiEndPoint.contains('bitbucket')){
            if (_deploy_env==~/(SIT1|SIT2|PPRD|PPRD1|SIT1CI|SIT2CI|PPRDCI|PPRD1CI)/)
            {
                if (branch0.endsWith('IN')){
                    ret=commits[0].CommitId
                }
                else if (branch1.endsWith('IN')){
                    ret=commits[1].CommitId
                }
                else {
                    error ("Two commits in package for Bitbucket Server but none end with IN ..")
                }
            }else{
                if (!branch0.endsWith('IN')){
                    ret=commits[0].CommitId
                }
                else if (!branch1.endsWith('IN')){
                    ret=commits[1].CommitId
                }
                else {
                    error ("Two commits in package for Bitbucket Server but both end with IN ..")
                }

            }
        }else{
            if (branch0==branchPrefix+"pre"+_deploy_env || 
                    branch1.startsWith(branchPrefix+"pre")){
                ret=commits[0].CommitId
            }else if (branch1==branchPrefix+"pre"+_deploy_env || 
                    branch0.startsWith(branchPrefix+"pre")){
                ret=commits[1].CommitId
            }
        }

    }else {
        // if there are more than 2 commits, somenthing is wrong :S
        error("There are more than 2 commits on the package !!!")
    }
    if (ret=="") error "If we have two commits in package one of them should be preENV!!!"
    return ret
   
}


def call(List commits,String _deploy_env){
  
    String ret=""
    String bitbucketBranchPrefix="release/"
    String branchPrefix=""
    echo "commits.size: ${commits.size()}"
    if (commits.size()==0){
        // if we have just one commit, we just take that one
        error("There are no commits on the package !!!")
    }
    if (commits[0].Server.ApiEndPoint.contains('bitbucket'))
    {
        // if server is bitbucket we should adhere to naming convention defined
        // for bitbucket where the "delivery" branches start with "integration/"
        echo "bitbucket repo"
        branchPrefix=bitbucketBranchPrefix
    }

    if (commits.size()==1){
        // if we have just one commit, we just take that one
        ret=commits[0].CommitId
    }else if (commits.size()==2){
        // if we have 2 commits, we check if any of them is pre<env> and we take that one
        // else we take the one that does not start by "pre.."
        def branch0=commits[0].BranchHash
        def branch1=commits[1].BranchHash
        if (commits[0].Server.ApiEndPoint.contains('bitbucket')){
            if (_deploy_env==~/(SIT1|SIT2|PPRD|PPRD1|SIT1CI|SIT2CI|PPRDCI|PPRD1CI)/)
            {
                if (branch0.endsWith('IN')){
                    ret=commits[0].CommitId
                }
                else if (branch1.endsWith('IN')){
                    ret=commits[1].CommitId
                }
                else {
                    error ("Two commits in package for Bitbucket Server but none end with IN ..")
                }
            }else{
                if (!branch0.endsWith('IN')){
                    ret=commits[0].CommitId
                }
                else if (!branch1.endsWith('IN')){
                    ret=commits[1].CommitId
                }
                else {
                    error ("Two commits in package for Bitbucket Server but both end with IN ..")
                }

            }
        }else{
            if (branch0==branchPrefix+"pre"+_deploy_env || 
                    branch1.startsWith(branchPrefix+"pre")){
                ret=commits[0].CommitId
            }else if (branch1==branchPrefix+"pre"+_deploy_env || 
                    branch0.startsWith(branchPrefix+"pre")){
                ret=commits[1].CommitId
            }
        }

    }else {
        // if there are more than 2 commits, somenthing is wrong :S
        error("There are more than 2 commits on the package !!!")
    }
    if (ret=="") error "If we have two commits in package one of them should be preENV!!!"
    return ret
   
}


def getFullCommit(net.sf.json.JSONArray commits,String _deploy_env){
  
    def ret=[:]
    String bitbucketBranchPrefix="release/"
    String branchPrefix=""
    echo "commits.size: ${commits.size()}"
    if (commits[0].Server.ApiEndPoint.contains('bitbucket'))
    {
        // if server is bitbucket we should adhere to naming convention defined
        // for bitbucket where the "delivery" branches start with "integration/"
        echo "bitbucket repo"
        branchPrefix=bitbucketBranchPrefix
    }

    if (commits.size()==1){
        // if we have just one commit, we just take that one
        ret=commits[0]
    }else if (commits.size()==2){
        // if we have 2 commits, we check if any of them is pre<env> and we take that one
        // else we take the one that does not start by "pre.."
        def branch0=commits[0].BranchHash
        def branch1=commits[1].BranchHash
        if (commits[0].Server.ApiEndPoint.contains('bitbucket')){
            if (_deploy_env==~/(SIT1|SIT2|PPRD|PPRD1|SIT1CI|SIT2CI|PPRDCI|PPRD1CI)/)
            {
                if (branch0.endsWith('IN')){
                    ret=commits[0]
                }
                else if (branch1.endsWith('IN')){
                    ret=commits[1]
                }
                else {
                    error ("Two commits in package for Bitbucket Server but none end with IN ..")
                }
            }else{
                if (!branch0.endsWith('IN')){
                    ret=commits[0]
                }
                else if (!branch1.endsWith('IN')){
                    ret=commits[1]
                }
                else {
                    error ("Two commits in package for Bitbucket Server but both end with IN ..")
                }

            }
        }else{
            if (branch0==branchPrefix+"pre"+_deploy_env || 
                    branch1.startsWith(branchPrefix+"pre")){
                ret=commits[0]
            }else if (branch1==branchPrefix+"pre"+_deploy_env || 
                    branch0.startsWith(branchPrefix+"pre")){
                ret=commits[1]
            }
        }

    }else {
        // if there are more than 2 commits, somenthing is wrong :S
        error("There are more than 2 commits on the package !!!")
    }
    if (ret.containsKey("BranchHash")) error "If we have two commits in package one of them should be preENV!!!"
    return ret
   
}