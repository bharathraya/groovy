def call(List sChangeList, Object env_config ,String _Aplicacion, String REVISION ){
    echo "undeployApigeeProxy:"
    def goal=""
    def config_option=""
    def deploymenttype=""
    def token1=""
    def install_goal=""
    def test_goal=""
    def config_option_compile="validate"
    def rollback=false
    def configchange=false
    def index=""
    def errorcode=""
    def DEPLOYEDREVISION=""
    def cambios=false
    withCredentials([usernamePassword(credentialsId: "${env_config.credentialid}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
        sChangeList.any(){
            token1=it.tokenize("/")
            if (token1[0] =='apiproxy' ||token1[0] =='pom.xml'){
                if (REVISION !=""){
                    SALIDA=sh returnStdout: true, script: """
                        https_proxy="${env_config.proxyurl}"
                        export https_proxy
                        curl --silent --write-out "HTTPSTATUS:%{http_code}" -X DELETE -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  --header "Content-type:application/x-www-form-urlencoded" \
                        "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/environments/${env_config.env}/apis/${_Aplicacion}/revisions/${REVISION}/deployments?delay=15" \
                         -d "override=true" |tr -d '\n' 
                    """
                    index=SALIDA.indexOf('HTTPSTATUS:')+11
                    errorcode=SALIDA.substring(index,index+3)
                    echo "DELETE status:${errorcode}"
                    if (errorcode !="200" && errorcode !="400"){
                        echo "ERROR:${SALIDA}"
                        error "Undeploy de la version nueva:${REVISION}"
                    }

                    echo "Undeploy la version:${REVISION}"
                }
                cambios=true
                return true
            }
        }
        if (cambios==false){
            echo "No hay cambios de api en:${sChangeList}"
        }

    }
    return rollback
}
