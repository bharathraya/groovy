def call (String User, String passw, String view ){
    node ('es1117yw'){
        checkout scm
      
      print "User ${User}"
      print "passw ${passw}"
      print "view ${view}"
      
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){           
                bat 'python add_packages_from_view_to_oow.py -u ${User} -c ${passw} -v ${view} '                          
        }
    }
}
