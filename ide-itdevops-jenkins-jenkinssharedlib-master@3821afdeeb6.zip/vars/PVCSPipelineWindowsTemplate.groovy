#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def almsPackage=null
def callFromWB=true
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _serverSVN=""
def _dataModules=null
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _HayAnexos=""
def _Pvcs=""
def _Anexos=""
def _funcion=""
def funcConfig=""
def hoy=""
def pckInfo=null
def _funcionAejecutar=""
def _serverAenviar=""
def _WB_ID=""
def envsConfig
def databaseConfig
def _listapaquetes=""
def _serverPROD=""


def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'WB_ID', defaultValue: '', description: '') 
            string(name: 'Application', defaultValue: '', description: '') 
            string(name: 'Enviroment', defaultValue: '', description: '') 
            string(name: 'List_Packages', defaultValue: '', description: '') 
            string(name: 'PackageInfo', defaultValue: '', description: '') 
         }
         
         stages{     
         stage("Prepare"){
                agent {
                    label 'MEDIACION'
                        }
                steps{
                script {
               // funcConfig=readJSON(file: CDM/Jenkins/WORKBENCH/ORACLE/MEDIACION/funciones.json)
                hoy=new Date().format( 'yyyyMMdd' )
                print "La fecha de hoy es ......${hoy}......"
                
                //leemos el fichero de configuracion
                pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                
                //leemos el fichero de entornos
                envsConfig=pipelineConfig.envConfig
                //leemos el fichero de BBDD
                databaseConfig=pipelineConfig.databaseConfig
                
                
                
                if (PackageInfo==""){
                    //LLamada manual
                        print "Llamada manual"
                        callFromWB=false  
                        _DeployEnv=params.Enviroment  
                        _ALMS_ID=params.WB_ID  
                        _Domain=params.Application
                        _listapaquetes=params.List_Packages
                        if (_listapaquetes==""){
                            _listapaquetes=params.WB_ID  
                        }
                             
                        echo "lista paquetes ${_listapaquetes}"   
                        replica_datos(_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                    }
                    else{
                        print "Llamada desde WB "
                        callFromWB=true  
                        pckInfo=readJSON(text: "${PackageInfo}")
                        _DeployEnv=pckInfo['EnvironmentName']
                       _Domain=pckInfo['ApplicationName']  
                       _ALMS_ID=pckInfo.Id.toString()
                       
                    }
                  enviroments=readJSON(file: "${envsConfig}")
                  _ruta=enviroments["${_Domain}"]["${_DeployEnv}"]["ruta"][0][0]
                  _prodDeploy=enviroments["${_Domain}"]["${_DeployEnv}"]["prodDeploy"][0][0]
                
                  print "llamo a getInfoPackage"
                  //(_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
                  (_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN,_Parametros,_HayParametros)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
                    //Configuramos el nombre del build y su descripcion

                  if(_HayModulosDatos == 0 && _HayModulosPVCS == 0) {
                    error("No hay modulos de datos ni de pvcs")
                    }
                    
                   //Si el entorno es PROD leo el servidor SPPR  
                   
                   if ("${_DeployEnv}" == "PROD")
                   {
                    _serverPROD=_server
                    //Cambiamos al server de SPPR
                    _server=enviroments["${_Domain}"]["${_DeployEnv}"]["serverSPPR"][0][0]
                   }
                   else
                   {
                       _serverPROD=""
                   }

                  
                   }//script
                 }//step
            }//prepare
            
            stage("BorraDirectorio"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        print "${_server}"
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_server}"
                        }
                        //Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
                        //Borrado del directorio temporal de anexo si existe por haberse promocionado otra vez este dia
                         cleanDirPaqueteWindows "${_ALMS_ID}","${_serverAenviar}","${hoy}"

                    }//scripts
                }//steps
            }//BorraDirectorio

            
            stage("checkoutModulosDatos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        
                        if(_HayModulosDatos!= 0){
                            print "DEBUG: hay modulos de datos ${_HayModulosDatos}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            if ("${env.NODE_NAME}" == "${_server}")
                            {
                                _serverAenviar =""
                                //  borramos el server para no hacer ssh
                            }
                            else{
                                _serverAenviar ="${_server}"
                            }
                            getFromAnexos "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}","${hoy}"
                        }else{
                            print "DEBUG: No hay modulos de datos "
                        }

                    }//scripts
                }
            }//checkoutModulosDatos

             stage("checkoutAnexos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if(_HayAnexos!= 0){
                            print "DEBUG: hay anexos"
                            if ("${env.NODE_NAME}" == "${_server}")
                            {
                                _serverAenviar =""
                                //  borramos el server para no hacer ssh
                            }
                            else{
                                _serverAenviar ="${_server}"
                            }
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            getAnnexes "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}","${hoy}"
                     }else{
                         print "DEBUG: No hay anexos "
                        }

                    }//scripts
                }//steps
            }//checkoutAnexos

            stage("checkoutPVCS"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                            print "${env.NODE_NAME}"
                            
                        }
                        else{
                            _serverAenviar ="${_server}"
                            
                        }
                        if(_HayModulosPVCS!= 0){
                            print "DEBUG: hay modulos de pvcs ${_HayModulosPVCS}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            
                            getFromPVCSWindows "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}"
                        }else{
                            print "DEBUG: No hay modulos de pvcs "
                        }

                    }//scripts
                }//steps
            }//checkoutPVCS
            stage("Ejecutar"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                         if ("${env.NODE_NAME}" == "${_server}")
                            {
                             _serverAenviar =""
                                //  borramos el server para no hacer ssh
                             }
                             else{
                             _serverAenviar ="${_server}"
                             }
                        
                        //Cargamos la info del paquete en almsPackage para las ejecuciones de funciones
                        almsPackage= new VFESALMSDataRetriever( _ALMS_ID, _Domain, _DeployEnv,  _serverAenviar, _HayModulosPVCS, _dataModules, _HayAnexos, callFromWB, _serverSVN, _serverPROD, _ruta, _prodDeploy)
                        //mirar que exista domain_<entorno>
                        //    si existe la funcion es la de domain_entorno
                        // Si no existe domain_<entorno> em quedo con domain
                        
                        _funcionEnt=pipelineConfig["${_Domain}-${_DeployEnv}"]
                        //print "funciones por entorno ${_funcionEnt}"
                        if ("${_funcionEnt}" == "null"){
                            //print "es nulo"
                            _funcion=pipelineConfig["${_Domain}"]
                        }
                        else{
                            //print "NO es nulo"
                            _funcion=_funcionEnt
                        }
                        print "ejecutamos ${_funcion}"
                        for (pos = 0; pos < _funcion.size(); pos++) { 
                             _funcionAejecutar=_funcion[pos]
                            print "funciona a ejecutar ${_funcionAejecutar}"
                            def ejecutar="CDM/Jenkins/WORKBENCH/common/${_funcionAejecutar}"
                            def clase=load "${ejecutar}"
                            clase.execute(almsPackage)
                     }//Fin del for

                    }//scripts
                }//steps
            }//Ejecutar

          stage("Etiquetar"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {//Si hay modulos de pvcs y estamos ejecutando de forma manual etiquetamos y no es PROD
                        if(_HayModulosPVCS != 0 && callFromWB == false ) {
                            print "DEBUG: hay modulos pvcs y es manual "
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            txeker("-t -l",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                            
                        }else{
                            print "DEBUG: No hay modulos de pvcs o lo ha llamado WB"
                        }
                        if (_HayModulosPVCS != 0 && callFromWB == false && _serverSVN != null ){
                            //Si hay máquina de SVN ejecuto el promoSVN 
                                print "DEBUG: hay modulos pvcs y es manual y tiene SVN"
                                cleanDirPaquete "${_ALMS_ID}","${_serverSVN}","${hoy}"
                                getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverSVN}"
                                promoSVN "${_ALMS_ID}","${_DeployEnv}","${_Domain}","${_serverSVN}"
                            }
                            else{
                                print "server SVN ${_serverSVN}"
                            }
                    }//scripts
                }//steps
          }//etiquetar



          }//stages
    
        }//pipeline
    }//map
