def call (String _Nombre,String _lista){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python get_applicationCRQ.py -p ${_lista} -c ${_Nombre}"
        }
    }
}
def call (String _Nombre,String _lista ,String _user, String _pass){
    node ('es1117yw'){
       
      //  ListaFinal='"'+_lista+'"'
     //   print "list inicial ${_lista}"
     //   print "list final ${ListaFinal}"
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
             wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                bat "python get_applicationCRQ.py -u ${_user} -c ${_pass}  -p ${_lista} -f ${_Nombre}"
             }//wrap


        }
    }
}
