import vfes.utils.VFESALMSDeployment

def call(String slackChannel,String message,String result){
	color="#FFFFFF" // blanco
	switch(result) {
		case "OK":
			color="#00FF00" //green
			break
		case "KO":
			color="#FF0000" //red
			break
	}

	slackSend(channel: slackChannel, color: color, message: message)
}


