import java.text.SimpleDateFormat

def call (String _RELEASE){
    echo "getFechaRelease"	
    	//RELEASE="ES1904FD"
	//FD ->MES tiene que venir
	//FR ->SEM
	//DL ->SEM
	def FECHA=""
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	Calendar cal = Calendar.getInstance();
	
	if("${FECHA}" == ""){
		def DEV_TYPE=_RELEASE.substring(6,8)
		//echo "DEV_TYPE=${DEV_TYPE}"
		if("${DEV_TYPE}" == "FD"){
			//echo "Warning Fecha no definida para FD"
			return FECHA
		}
		if("${DEV_TYPE}" == "FR" || "${DEV_TYPE}" == "DL"){
			def SORTYEAR=_RELEASE.substring(2,4)
			def WEEK=_RELEASE.substring(4,6)
			//echo "SORTYEAR=${SORTYEAR}"
			//echo "WEEK=${WEEK}"
			String YEAR="20"+"${SORTYEAR}"
			//echo "YEAR=${YEAR}"
			//echo "set year"  
			cal.set(Calendar.YEAR, YEAR.toInteger());
			//echo "set week"        
			cal.set(Calendar.WEEK_OF_YEAR, WEEK.toInteger());
			//echo "set day"    
			cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
			FECHA=sdf.format(cal.getTime());
			//echo "Fecha para ${_RELEASE}:${FECHA}"
			return FECHA
		}
	}
	return FECHA
} 