import groovy.json.JsonSlurper
import vfes.utils.nexusData

def call(nexusData nexus, String _ARTID, String _GID, String _VERSION){
    echo "getDownloadUrlNexus"
    List urlList=[]
    def SALIDA=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${nexus.nexusCred}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            curl -u ${USERNAME}:${PASSWORD} -k "${nexus.nexusUrl}/service/rest/v1/search?repository=${nexus.nexusRepo}&format=maven2&group=${_GID}&name=${_ARTID}&version=${_VERSION}"
        """
    }
    if (SALIDA != ""){
        def jsonSlurper = new JsonSlurper()
        def jsonnexusquery = jsonSlurper.parseText(SALIDA)
        jsonnexusquery.items.each(){
            it.assets.each{
                def downloadUrl=it.downloadUrl
                echo "downloadUrl:${downloadUrl}"
                urlList.add(downloadUrl)
            }
        }
    }
    //def fichero=url.substring(url.lastIndexOf("/")+1,url.size())
    return urlList
}