def call (String User, String passw, String view , String env , String proyect, String _sistema, String _BBDD){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
             if (_sistema == "N")
            {
                bat 'python create_package.py -s "CRM AMDOCS" '+"-u ${User} -c ${passw} -e ${env} -v ${view} -p ${proyect}"
                
            }
            else
            {
                 bat 'python create_package.py -s "CRM AMDOCS 10.2" '+"-u ${User} -c ${passw} -e ${env} -v ${view} -p ${proyect}"

            }
          print "_BBDD ${_BBDD}"
            if (_BBDD == "Y")
            {
              dir ("New_Scripts/"){ 
              		bat "python add_packages_from_view_to_oow.py -u ${User} -c ${passw} -v ${view} "      
              }
            }
              
        }
    }
}
