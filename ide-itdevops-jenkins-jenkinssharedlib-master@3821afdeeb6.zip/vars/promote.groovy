def call (String _usuario, String _estado, String _paquete){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python promo_paquetes.py -u ${_usuario} -e ${_estado}  ${_paquete} "
        }
    }
}