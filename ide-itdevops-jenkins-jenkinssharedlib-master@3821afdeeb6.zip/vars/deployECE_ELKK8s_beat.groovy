import vfes.git.VFESGitMergeInfo_aaresmi
import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(Map config, VFESALMSDeployment alms,VFESGitMergeInfo_aaresmi mergeInfo)
{
    //echo "=============================================="
    //echo "DISABLED. UNDER CONSTRUCTION"
    //echo "=============================================="
    //sh ("exit 1")
    def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    def _envConfig=myEnvsConfig[alms.deployEnv]
    def envPath=myEnvsConfig[alms.deployEnv]['deploy_beatk8s']['environment_path']

    //////////////////////////////////////////
    /////////CHECK REPOSITORY CHANGES/////////
    //////////////////////////////////////////
    items2DeployBase=mergeInfo.FilesChangedDetailed.findAll{it[1] =~ "base/"}
    items2DeployOverlaysCurrentEnv=mergeInfo.FilesChangedDetailed.findAll{it[1] =~ "overlays/${envPath}/"}
    items2DeployOverlaysOthersEnvs=mergeInfo.FilesChangedDetailed.findAll{!(it[1] =~ "base/") && !(it[1] =~ "overlays/${envPath}/") }

    echo "=============================================="
    echo "CHANGES FOUNDS IN COMMIT"
    echo "=============================================="
    echo "Changes at base directory:                                    ${items2DeployBase.size()}"
    echo "Changes at overlays directories for the current environment:  ${items2DeployOverlaysCurrentEnv.size()}"
    echo "Changes at overlays directories for others environments:      ${items2DeployOverlaysOthersEnvs.size()}"
    echo "=============================================="

    if (items2DeployBase.size() == 0 && items2DeployOverlaysCurrentEnv.size() == 0 && items2DeployOverlaysOthersEnvs.size() == 0)
    {
        echo "ERROR. There are not any change detected!!!!!."
        sh ("exit 1")
    }

    ///////////////////////////////////
    /////////NEW CHECK ACTIONS/////////
    ///////////////////////////////////
    if (config.containsKey("deployActions"))
    {
        deployECE_ELKCheckVariables config,alms
    }
    ///////////////////////////////////
    /////////NEW CHECK ACTIONS/////////
    ///////////////////////////////////

    echo "Deploying beats at k8s ...."
    echo "Environment Data:"
    echo "  environment_path: " + envPath

    def dryrun_exits = [:]

    //ALWAYS DRY RUN FOR ALL ENVS
    echo "=========================================="
    echo "DRY RUN: FOR ALL ENVIRONMENTS"
    echo "=========================================="

    def getEnvs=sh(returnStdout: true, script:'''cd project/overlays; ls -1''').split()
    echo "Environments Founds: ${getEnvs}"

    def dryrun_list = []
    getEnvs.each { it ->
        def dryrun_map = [:]
        echo "==> Executing DRY RUN for ${it}"
        sh (returnStatus: true, script: 'rm dryrun_stdout.log > /dev/null 2>&1')
        sh (returnStatus: true, script: 'rm dryrun_stderr.log > /dev/null 2>&1')
        dryrun_exitcode=sh(returnStatus: true, script:"""kubectl apply --dry-run=client -k project/overlays/${it} 2>dryrun_stderr.log 1>dryrun_stdout.log""")
        dryrun_stdout = readFile('dryrun_stdout.log').trim()
        dryrun_stderr = readFile('dryrun_stderr.log').trim()
        sh (returnStatus: true, script: 'rm dryrun_stdout.log > /dev/null 2>&1')
        sh (returnStatus: true, script: 'rm dryrun_stderr.log > /dev/null 2>&1')

        dryrun_map.environment=it
        dryrun_map.exit_code=dryrun_exitcode
        dryrun_map.stdout=dryrun_stdout
        dryrun_map.stderr=dryrun_stderr

        dryrun_list.add(dryrun_map)
    }
    dryrun_ok=dryrun_list.findResults{it.exit_code == 0 ? it.environment : null}
    dryrun_ko=dryrun_list.findResults{it.exit_code != 0 ? it.environment : null}

    echo "==> DRY RUN environments OK: ${dryrun_ok}"
    echo "==> DRY RUN environments KO: ${dryrun_ko}"

    dryrun_list.each { it ->
        if (it.exit_code != 0)
        {
            echo "==> DRY RUN Error Details for ${it.environment} environment!!!!"
            echo "====> Details: "
            echo "Exit Code: "
            echo "${it.exit_code}"
            echo "stdout: "
            echo "${it.stdout}"
            echo "stderr: "
            echo "${it.stderr}"
        }
    }
    if (dryrun_ko.size() != 0)
    {
        echo "==> DRY RUN Errors Founds. No continue with the deploy!!!!"
        sh ("exit 1")
    }


    //IF THERE IS CHANGES IN THE BASE OR IN THE CURRENT ENVIRONMENT IS NECESSARY DEPLOY
    if (items2DeployBase.size() != 0 || items2DeployOverlaysCurrentEnv.size() != 0)
    {
        echo "Detected changes in the bases or in the overlay current env. Proceed with the deploy:"
        echo "==> Executing RUN for ${envPath}"
        sh (returnStatus: true, script: 'rm run_stdout.log > /dev/null 2>&1')
        sh (returnStatus: true, script: 'rm run_stderr.log > /dev/null 2>&1')
        run_exitcode=sh(returnStatus: true, script:"""kubectl apply -k project/overlays/${envPath} 2>run_stderr.log 1>run_stdout.log""")
        run_stdout = readFile('run_stdout.log').trim()
        run_stderr = readFile('run_stderr.log').trim()
        sh (returnStatus: true, script: 'rm run_stdout.log > /dev/null 2>&1')
        sh (returnStatus: true, script: 'rm run_stderr.log > /dev/null 2>&1')

        //if (run_exitcode != 0)
        //{
            echo "==> RUN Details for ${envPath} environment!!!!"
            echo "====> Details: "
            echo "Exit Code: "
            echo "${run_exitcode}"
            echo "stdout: "
            echo "${run_stdout}"
            echo "stderr: "
            echo "${run_stderr}"
        //}
    }
    else
    {
        echo "There is only changes in other environments overlays:"
        echo "${items2DeployOverlaysOthersEnvs}"
        echo "Not Needed to deploy"
    }
}
