import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo

def deploy_env=""
def commit_id=""
def alms_id=""
def delivery=""
def project_id=""
def squad=""

def almsPackage=null
def gitRepo=null
def gitOtherRepo=null
def pipelineConfig=null
VFESGitMergeInfo mergeInfo=null

def call(Map pipelineParams){	
    pipeline{
        agent none
        parameters { 
            //09-10-20 meguiza2
            //string(name: 'DeployEnv', defaultValue: '', description: 'SIT1CI, SIT2CI, SIT3CI, PPRD1CI, HID, master') 
            choice(name: 'DeployEnv',  choices: pipelineParams.environmentChoices , description: '') 
            //09-10-20 meguiza2
            string(name: 'CommitID', defaultValue: '', description: '') 
            string(name: 'ALMS_ID', defaultValue: '', description: '') 
            string(name: 'Delivery', defaultValue: '', description: '') 
            string(name: 'ProjectId', defaultValue: '', description: '') 
            string(name: 'SQUAD', defaultValue: 'BAU', description: '') 
            string(name: 'PackageInfo', defaultValue: '', description: '') 
        }
        stages{
            
            stage("Prepare"){
                agent {
                    label 'MVOW'
                        }

                steps{
					
                    script {
						env.current_stage=env.STAGE_NAME
                        if (params.PackageInfo==""){
                            // executed manually or from ALMS
                            deploy_env=params.DeployEnv
                            
                            commit_id=params.CommitID
                            
                            alms_id=params.ALMS_ID
                            delivery=params.Delivery
                            project_id=params.ProjectId
                            squad=params.SQUAD
                        }else{
                            echo "PackageInfo: ${params.PackageInfo}"
                            (deploy_env,commit_id,alms_id,delivery,project_id,squad)=parsePckInfo(PackageInfo)
                            //pckinfo=readJSON(text:PackageInfo)
                            //deploy_env=pckinfo.Environment.Name
                            //commit_id=pckinfo.decideCommitId(pckinfo.Commits,deploy_env)
                            //alms_id=pckinfo.Id
                            //delivery=pckinfo.Delivery.Name
                            //project_id=pckinfo.Project.CodProject
                            //squad=pckinfo.EnterpriseName
                        }
                    
                        echo "    DeployEnv: ${deploy_env}"
                        echo "    CommitID:  ${commit_id}"
                        echo "    PackageID: ${alms_id}"
                        echo "    Delivery:  ${delivery}"
                        echo "    Project:   ${project_id}"
                        echo "    Squad:     ${squad}"                        
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        almsPackage= new VFESALMSDeployment(alms_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,squad)
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
                        // TODO : when 
                        gitRepo=new VFESGitRepo("${pipelineConfig.gitRepo}",this)
                        
                    }
                    
                }
            }
            stage('Checkout'){
                agent {
                    
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
						//meguiza2
						echo "pipelineConfig.BranchPolicy: ${pipelineConfig.branchPolicy} almsPackage.deployEnv: ${almsPackage.deployEnv}"
						echo "cual es el entorno: ${almsPackage.deployEnv} :"
                        if (pipelineConfig.branchPolicy=="SIMPLE" && ! (almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/)){
							echo "SIMPLE branch policy and non-prod or develop env ! doing checkoutCommit"
                            gitRepo.checkoutCommit(pipelineConfig.extractFolder,almsPackage.deployEnv,almsPackage.commitID)
                        }else if (pipelineConfig.branchPolicy==~/(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI)/)
                        {
                            gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,"develop")
                        }else{
                        	gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
						}
                        if(pipelineConfig.gitOtherRepo?.trim()){
                            // Hacer el checkout en carpeta extractOtherFolder
                            echo "Do checkout of other folder"
                            gitOtherRepo=new VFESGitRepo("${pipelineConfig.gitOtherRepo}",this)
                            gitOtherRepo.cloneBranchToLocalFolder(pipelineConfig.extractOtherFolder,almsPackage.deployEnv)
                            
                        }
                    }
                }
            }
            stage('merge'){
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    }
                }
				when{
                    expression { return (!(pipelineConfig.branchPolicy ==~ /SIMPLE/) || (pipelineConfig.branchPolicy ==~ /SIMPLE/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/))}
                }

                steps{
                    script{
						env.current_stage=env.STAGE_NAME
						if (pipelineConfig.branchPolicy ==~ /(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(master|masterCI)/){
                            echo "Merging to ${almsPackage.deployEnv} we will check for the corresponding tag for ${almsPackage.commitID} in develop branch..."
                            mergeInfo=gitRepo.mergeCommitFromDevelop(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage,almsPackage.almsID)
                        }else{
                        	mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
						}
                    }
                }
            }
            stage('Compile'){
                agent {
                    docker {
                        // TODO : revisar si usamos "cache" de npm 
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                        reuseNode true
                    }
                }
                steps{
                    // TODO : manejar el caso master/ HID vs resto entornos
                    // TODO : gestionar el empaquetado del resultado 
                    script{
						env.current_stage=env.STAGE_NAME
                    	buildWithScript pipelineConfig
					}
                    
                }            
            }
            /*stage('RunSonar'){
                when{
                    expression { return pipelineConfig.runSonar == true }
                    beforeAgent true
                }
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.sonarImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr --entrypoint=""'                    
                    }
                }
                steps{
                    echo "runSonar: ${pipelineConfig.runSonar}"
                    runSonar pipelineConfig, almsPackage
                }
            }*/

            stage('PushToNexus'){
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
					script 
					{
						env.current_stage=env.STAGE_NAME
                    	pushToNexus pipelineConfig, almsPackage
					}
                }

            }
            stage('CopyToRelease'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                }
                agent{
                    //label "deploy-apache-wcs"
                    label "${pipelineConfig.releaseAgent}"
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        echo "Download artifacts from Nexus ..."
                        downloadArtifactsFromNexus pipelineConfig, almsPackage
                        
                        echo "DeployType: ${pipelineConfig.deployType}"
                        switch(pipelineConfig.deployType) {
                            case ~/^(release|catalogo)$/:
                                echo "Copy code to release folder ..."
                                copyToRelease  pipelineConfig,  almsPackage
                            break
                            case ~/^apache$/:
                                echo "Deploy to apache ..."
                                deployToApacheScript.deploy  pipelineConfig,almsPackage

                            break
							case ~/^apacheFromEnvsFile$/:
                                echo "Deploy to apache from envs file..."
								deployToApacheScript.deployByEnvsFile pipelineConfig,almsPackage
                            break

                        }
                   
                    }

                }
            }

            stage('Deploy'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                }
                agent{
                    label "${pipelineConfig.deployAgent}"
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
                        switch(pipelineConfig.deployType) {
                            case ~/^catalogo$/:
                                echo "running deploy step"
                                deployCatalogo pipelineConfig, almsPackage
                            break
                        }
                    }
                    
                }
            }
            /*stage('RunSelenium'){
                when{
                    expression { return pipelineConfig.runSelenium == true  && deploy_env ==~ /(?i)(sit1|sit2|sit3|pprd|pprd1|sit1ci|sit2ci|sit3ci|pprdci|pprd1ci)/ }
                    beforeAgent true
                }
                agent{
                    label 'es1117yw'
                }
                steps{
                    script{
                        //def ret=bat(returnStdout:true , script:"python CDM/Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${deploy_env} ")
                        //echo "${ret}"
                        try{
                            bat "del *.png"
                            bat "python CDM/Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${deploy_env} ${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}"
                        }catch (e) {
                            echo "error when doing Selenium !!!!"
                        }
                        archiveArtifacts artifacts: '*.png', fingerprint: true
                        def myfiles=findFiles glob:"*.png"
                        myfiles.each{ pngfile -> 
                            echo "Selenium Screenshot: <a href='$BUILD_URL/artifact/${pngfile.name}' target='_blank' >${pngfile.name}</a>"
                        }
                        bat "del *${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}*.png"
                    }
                }
            }*/

            stage('Prepare PAP'){
                agent{
                    //label "deploy-apache-wcs"
                    label "${pipelineConfig.releaseAgent}"
                }
                when{
                    expression { return deploy_env ==~ /(?i)(master|masterCI|hid|hid1|hidci|hid1ci)/ }
                }
                steps{
                    echo "Download artifacts from Nexus ..."
                    downloadArtifactsFromNexus pipelineConfig, almsPackage
                    echo "running Prepare PAP step"
                    prepareForProdDeployment pipelineConfig, almsPackage
                }
            }
            stage('TagAndPush'){
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
						env.current_stage=env.STAGE_NAME
						if (pipelineConfig.branchPolicy=="SIMPLE"){
                            if (almsPackage.deployEnv==~/(?i)(hid1|hid|hidci|hid1ci)/){
                                //caso de Oculto uso rama develop
                                echo "Tag and push to develop branch ..."
                                gitRepo.tagAndPushDevelop pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,"develop",almsPackage.almsID,almsPackage.commitID
                            }else if (almsPackage.deployEnv==~/(?i)(master|masterCI)/){
                                echo "Tag commit and push to git "
                                gitRepo.tagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                            else{
                                echo "Tag and push to git "
                                gitRepo.simpleTagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv,almsPackage.almsID

                            }
                        }else if (pipelineConfig.branchPolicy=="envs_and_develop")
                        {
                            if (almsPackage.deployEnv==~/(?i)(hid1|hid|hidci|hid1ci)/){
                                //caso de Oculto uso rama develop
                                echo "Tag and push to develop branch ..."
                                gitRepo.tagAndPushDevelop pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,"develop",almsPackage.almsID,almsPackage.commitID
                            }else if (almsPackage.deployEnv==~/(?i)(master|masterCI)/){
                                echo "Tag commit and push to git "
                                gitRepo.tagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                            else{
                            echo "Tag commit and push to git "
                            gitRepo.tagAndPush pipelineConfig.extractFolder,
                                almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                        }
                        else
                        {
							echo "Tag commit and push to git "
							gitRepo.tagAndPush pipelineConfig.extractFolder,
								almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
						}
                    }
                }
            }
            stage('PublishChanges'){
                agent {
                    docker {
                        label 'npm-prueba'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    echo "Publish changes to ELK  and GitPublish plugin"
                    publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                    
                }
            }

        }
        post { 
            always { 
                node('master') {
                    catchError(message:"Error when publishing to InfluxDB") {
                        script{
                            echo 'Publishing to Influx for Pipeline KPI!!!'
                            echo "Squad: ${squad}"
                            sendInfluxMetrics "${deploy_env}", squad
                        }
                    }
                }

            }
			//failure{
				//slackNotify pipelineConfig,almsPackage,"ERROR"
			//}
			//success{
				//slackNotify pipelineConfig,almsPackage,"OK"
			//}
			

        }

        
    }
}