import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def deploy(Map config,VFESALMSDeployment alms){
    
    
    
    envsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    
    
    
    
    envConfig=envsConfig[alms.deployEnv]
    
      
    
    for (i =0;i<config.distFile.size();i++){
        
        
	
        echo "Deploying "+config.distFolder[i]+"/"+config.distFile[i]+" at "+config.htdocsPath[i]+"/"+config.htdocsFolder[i]
        deployToApacheScript config.artifactId[i],config.htdocsPath[i],config.extractFolder+"/"+config.distFolder[i],
            config.distFile[i],config.htdocsFolder[i],alms,envConfig,config.releaseDeployTemplate
    }

}

def prepareForProd(_almsDep,_distFile,_artifactId){
	if (_almsDep.deployEnv == 'master' || _almsDep.deployEnv == 'masterCI'){
		sh "ssh -q -o StrictHostKeyChecking=no vodlow01 'mkdir -p /home/plataforma/plausr/data/temporal/${_almsDep.jobDate}/${_almsDep.almsID}/PROD' "
		sh "scp ${_distFile} vodlow01:/home/plataforma/plausr/data/temporal/${_almsDep.jobDate}/${_almsDep.almsID}/PROD 2>/dev/null"
		currentBuild.description=currentBuild.description+"""

		Artifact ${_artifactId} Deploy Scripts:
		"""

    }
}
def deployByEnvsFile(Map config, VFESALMSDeployment almsDep){
    envsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
    
    
    
    for (i =0;i<config.artifactId.size();i++){
		artifactConfig=envsConfig[config.artifactId[i]]
	    
		
		envArtifact=artifactConfig[almsDep.deployEnv]
		
		
		
		dir(config.extractFolder+"/"+config.distFolder[i]) {
		    
		    
			prepareForProd (almsDep,config.distFile[i],config.artifactId[i])
			envArtifact.webservers.each { item ->
				echo "item: ${item}"
				echo "item.htdocspath.size(): ${item.htdocspath.size()}"
				echo "item.htdocsfolder.size(): ${item.htdocsfolder.size()}"
				for (indexHtdocs=0;indexHtdocs<item.htdocspath.size();indexHtdocs++){
					echo "apachepath: ${item.apachepath} htdocspath: ${item.htdocspath[indexHtdocs]} htdocsfolder: ${item.htdocsfolder[indexHtdocs]} distFile: ${config.distFile[i]} artifactId: ${config.artifactId[i]}"
					def strDeployScript=renderTemplateFromEnvs(almsDep,config.releaseDeployTemplate,item.apachepath,item.htdocspath[indexHtdocs],item.htdocsfolder[indexHtdocs],config.distFile[i],config.artifactId[i])
					def scriptName="${item.server}.${almsDep.appName}.${config.artifactId[i]}.${almsDep.almsID}.${almsDep.jobTimeStamp}.sh"
								
								// push template and zip file to server 
								sh """#!/bin/sh
								echo '${strDeployScript}' > ${scriptName}
								chmod 755 ${scriptName}
								"""				
					if (almsDep.deployEnv != 'master' && almsDep.deployEnv != 'masterCI'){
						deployToNonProd(item,almsDep,config.distFile[i],scriptName)
					}else
					{
						deployToPROD(item,almsDep,config.distFile[i],scriptName)
					}
				}
			}
		}
    }
}

def deployToPROD(_item,_almsDep,_distFile,_scriptName){
	echo "Deploying up on  ${_item.apacheusername}@${_item.server} ${_item.apachepath}..."
					sh "scp ${_scriptName} vodlow01:/home/plataforma/plausr/data/temporal/${_almsDep.jobDate}/${_almsDep.almsID}/PROD 2>/dev/null"
					sh """
					ssh -q -o StrictHostKeyChecking=no vodlow01 '
					cd /home/plataforma/plausr/data/temporal/${_almsDep.jobDate}/${_almsDep.almsID}/PROD
					ssh -q -o StrictHostKeyChecking=no  ${_item.apacheusername}@${_item.server} "mkdir -p ${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID}"
					scp ${_distFile} ${_item.apacheusername}@${_item.server}:${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID} 2>/dev/null
					scp ${_scriptName} ${_item.apacheusername}@${_item.server}:${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID} 2>/dev/null
					'
					"""
					currentBuild.description=currentBuild.description+"""
	Deploy ${_item.apacheusername}@${_item.server}:${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID}"""            

}
def deployToNonProd(_item,_almsDep,_distFile,_scriptName){
	sh "ssh -q -o StrictHostKeyChecking=no ${_item.apacheusername}@${_item.server} 'mkdir -p ${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID}'"
	sh "scp ${_distFile} ${_item.apacheusername}@${_item.server}:${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID} 2>/dev/null" 
	sh "scp ${_scriptName} ${_item.apacheusername}@${_item.server}:${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID} 2>/dev/null" 
	echo "Deploying ${_almsDep.appName} ${_almsDep.almsID}: run ${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID}/${_scriptName}"
	sh "ssh -q -o StrictHostKeyChecking=no ${_item.apacheusername}@${_item.server} '${_item.apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID}/${_scriptName}' "
}
def renderTemplate(_template,_variables,_almsDep,_item){
	
	def template = libraryResource("${_template}")
	//render the template  for the item (server etc)
	def strDeployScript=helpers.renderTemplate(template, _variables)
	def scriptName="${_item.server}.${_almsDep.appName}.${_artifactId}.${_almsDep.almsID}.${_almsDep.jobTimeStamp}.sh"
	// push template and zip file to server 
	sh """#!/bin/sh
	echo '${strDeployScript}' > ${scriptName}
	chmod 755 ${scriptName}
	"""
	return ${scriptName}
}

def renderTemplateFromEnvs(_almsDep,_template,_apachepath,_htdocspath,_htdocsfolder,_distFile,_artifactId){
	def variables = [ 'zip2deploy' : "${_distFile}",
	'rootPath' : "${_apachepath}/${_htdocspath}",
	'deployPath' : "${_htdocsfolder}",
	'appName' : "${_almsDep.appName}.${_artifactId}",
	'alms' :  "${_almsDep.almsID}",
	'devopsPath' : "${_apachepath}/devops/${_almsDep.jobDate}/${_almsDep.almsID}"
	]
	def template = libraryResource("${_template}")
	return helpers.renderTemplate(template,variables)
}

def call(String _artifactId,String _htdocsPath,String _distFolder,String _distFile,
String _folderName,VFESALMSDeployment _almsDep,JSONObject _envConfig,String _template)
{

    dir(_distFolder) {
        if (_almsDep.deployEnv == 'master' || _almsDep.deployEnv == 'masterCI'){
            sh "ssh -q -o StrictHostKeyChecking=no vodlow01 'mkdir -p /home/plataforma/plausr/data/temporal/${_almsDep.jobDate}/${_almsDep.almsID}/PROD' "
            sh "scp ${_distFile} vodlow01:/home/plataforma/plausr/data/temporal/${_almsDep.jobDate}/${_almsDep.almsID}/PROD 2>/dev/null"
            currentBuild.description=currentBuild.description+"""

            Artifact ${_artifactId} Deploy Scripts:
            """

        }

        _envConfig.webservers.each { item ->
            // ${zip2deploy}
            // ${rootPath}
            // ${deployPath}
            // ${appName}
            // ${alms}
            def variables = [ 'zip2deploy' : "${_distFile}",
            'rootPath' : "${item.apachepath}/${_htdocsPath}",
            'deployPath' : "${_folderName}",
            'appName' : "${_almsDep.appName}.${_artifactId}",
            'alms' :  "${_almsDep.almsID}"
            ]
            
            def template = libraryResource("${_template}")
            //render the template  for the item (server etc)
            def strDeployScript=helpers.renderTemplate(template, variables)
            def scriptName="${item.server}.${_almsDep.appName}.${_artifactId}.${_almsDep.almsID}.${_almsDep.jobTimeStamp}.sh"
            
            // push template and zip file to server 
            sh """#!/bin/sh
            echo '${strDeployScript}' > ${scriptName}
            chmod 755 ${scriptName}
            """

            if (_almsDep.deployEnv != 'master' && _almsDep.deployEnv != 'masterCI'){
                sh "scp ${_distFile} ${item.apacheusername}@${item.server}:${item.apachepath}/${_htdocsPath} 2>/dev/null" 
                sh "scp ${scriptName} ${item.apacheusername}@${item.server}:${item.apachepath}/${_htdocsPath} 2>/dev/null" 
                echo "Deploying ${_almsDep.appName} ${_almsDep.almsID}"
                sh "ssh -q -o StrictHostKeyChecking=no ${item.apacheusername}@${item.server} '${item.apachepath}/${_htdocsPath}/${scriptName}' "
                // in case of non-prod (other than masterCI) execute the .sh generated from template:)
            }else
            {
                echo "Deploying up on  ${item.apacheusername}@${item.server} ${item.apachepath}..."
                sh "scp ${scriptName} vodlow01:/home/plataforma/plausr/data/temporal/${_almsDep.jobDate}/${_almsDep.almsID}/PROD 2>/dev/null"
                sh """
                ssh -q -o StrictHostKeyChecking=no vodlow01 '
                cd /home/plataforma/plausr/data/temporal/${_almsDep.jobDate}/${_almsDep.almsID}/PROD
                scp ${_distFile} ${item.apacheusername}@${item.server}:${item.apachepath}/${_htdocsPath} 2>/dev/null
                scp ${scriptName} ${item.apacheusername}@${item.server}:${item.apachepath}/${_htdocsPath} 2>/dev/null
                '
                """
                currentBuild.description=currentBuild.description+"""
  Deploy ${item.apacheusername}@${item.server}:${item.apachepath}/${_htdocsPath}/${scriptName}"""            

            }
        }
    }
}
return this