import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo
import vfes.git.VFESGitMergeInfo

def deploy_env=""
def commit_id=""
def alms_id=""
def delivery=""
def project_id=""
def artifact_id=""
def squad=""

def almsPackage=null
def gitRepo=null
def pipelineConfig=null
VFESGitMergeInfo mergeInfo=null
def artifacts=null
def gitRepoURL=""


def LOCALbuildBackMVOWProp(Map config,VFESGitMergeInfo mergeInfo){
    def onlyProperties=false
    dir("${config.extractFolder}"){
        def gitPropertiesChanged=sh(returnStdout: true, script: "git diff --name-only  ${mergeInfo.commitBefore}..${mergeInfo.commitAfter} | sed -n '/^WCS-[a-zA-Z0-9]*\\/properties\\//!p'").toString().trim()
        

        echo "gitPropertiesChanged: ${gitPropertiesChanged}"
        echo "Number of gitFilesChanged: ${mergeInfo.filesChanged.size()}"
        NumeroFichero = mergeInfo.filesChanged.size() //Numero de Fichero del diff, se cambian en este merge
        if (mergeInfo.filesChanged.size()>0){
            // there are changes involved !
            if (gitPropertiesChanged != ""){
                FicheroJava=gitPropertiesChanged.split("\n") //hacesmos un array de los que no son properties
                SizeDicheroJava=FicheroJava.size() //tamano de los no properties
                
                if ( NumeroFichero == SizeDicheroJava )
                { 
                  IsProperties = false
                }
                else
                {
                  IsProperties = true
                }
                  
                
            }else
            {
                IsProperties = true
            }
        }else{
            //in case no changes involved , lets recompile all
            IsProperties = false
        }
    }
    if (IsProperties){
            echo "There are properties to copy!!!"
        }
    
    return IsProperties
}


def detectMavenArtifactsWithProperties(String projectPath){
    def artifacts=[]
    dir("${projectPath}"){
        poms=findFiles glob:"**/pom.xml"
        for (i=0;i<poms.size();i++)
        { 
            def pomfile=poms[i]
            echo "name: ${pomfile.name} path: ${pomfile.path} directory: ${pomfile.directory}"
            def pom = readMavenPom file: pomfile.path
            echo "    packaging:${pom.packaging}"
            if (pom.packaging ==~ /[jwe]ar/){
                echo "    packaging:${pom.packaging}"
                def artifact=[groupId:"${pom.groupId}",artifactId:"${pom.artifactId}",version:"${pom.version}",packaging:"${pom.packaging}",pomfile:"${pomfile.name}"]
                echo "artifact:${artifact}"
                artifacts+=artifact
            }
        }
        
    }
    return artifacts

}

def detectChangedArtifacts(Map config){
    def ret=null
    switch(config.artifactDetection) {
        case 'maven_full_compile':
            echo "Detecting all maven artifacts... "
            ret=detectMavenArtifactsWithProperties(config.extractFolder)
        break
    }
    return ret
}
def call(Map pipelineParams){
    pipeline{
        agent none
        parameters { 
            //09-10-20 meguiza2
            choice(name: 'DeployEnv',  choices: pipelineParams.environmentChoices , description: '') 
            choice(name: 'ArtifactId', choices: pipelineParams.artifactChoices, description: '') 
            //string(name: 'DeployEnv', defaultValue: '', description: 'SIT1CI, SIT2CI, PPRD1CI, HID1CI, masterCI or master(EDC)') 
            //string(name: 'ArtifactId', defaultValue: '', description: '') 
            //09-10-20 meguiza2
            string(name: 'CommitID', defaultValue: '', description: '') 
            string(name: 'ALMS_ID', defaultValue: '', description: '') 
            string(name: 'Delivery', defaultValue: '', description: '') 
            string(name: 'ProjectId', defaultValue: '', description: '') 
            string(name: 'SQUAD', defaultValue: 'BAU', description: '') 
            string(name: 'PackageInfo', defaultValue: '', description: '') 
        }
        stages{
            
            stage("Prepare"){
                agent {
                    label "MVOW"
                }
                steps{
                    script {
                        if (params.PackageInfo==""){
                            // executed manually or from ALMS
                            deploy_env=params.DeployEnv
                            
                            commit_id=params.CommitID
                            
                            alms_id=params.ALMS_ID
                            delivery=params.Delivery
                            project_id=params.ProjectId
                            artifact_id=params.ArtifactId
                            squad=params.SQUAD
                        }else{
                            echo "PackageInfo: ${params.PackageInfo}"

                            (deploy_env,commit_id,alms_id,delivery,project_id,squad,artifact_id)=parsePckInfoWithArtifact(PackageInfo)
                            //pckinfo=readJSON(text:PackageInfo)
                            //deploy_env=pckinfo.Environment.Name
                            //commit_id=pckinfo.decideCommitId(pckinfo.Commits,deploy_env)
                            //alms_id=pckinfo.Id
                            //delivery=pckinfo.Delivery.Name
                            //project_id=pckinfo.Project.CodProject
                            //squad=pckinfo.EnterpriseName
                        }
                        echo "    ArtifactId:  ${artifact_id}"
                        echo "    DeployEnv: ${deploy_env}"
                        echo "    CommitID:  ${commit_id}"
                        echo "    PackageID: ${alms_id}"
                        echo "    Delivery:  ${delivery}"
                        echo "    Project:   ${project_id}"
                        echo "    Squad:     ${squad}"  

                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        almsPackage= new VFESALMSDeployment(alms_id,artifact_id,deploy_env,commit_id,delivery,project_id,squad)
                        currentBuild.displayName = almsPackage.jobDisplayName
                        currentBuild.description = almsPackage.jobDescription
						def addArtifactToExtractFolder=true
						if (pipelineConfig.containsKey("addArtifactToExtractFolder")){
							addArtifactToExtractFolder=pipelineConfig.addArtifactToExtractFolder
						}
						if (addArtifactToExtractFolder){
							echo "Adding the artifact to the extract folder"
                        	pipelineConfig.extractFolder=pipelineConfig.extractFolder+"/"+artifact_id
						}
                        // TODO : when 
                        if (pipelineConfig.gitRepoPath!=""){
                            gitRepoURL=pipelineConfig.gitRepoPath+artifact_id+".git"
                            echo "Git Repo URL: ${gitRepoURL}"
                            gitRepo=new VFESGitRepo("${gitRepoURL}",this)    
                        }else{
                            gitRepo=new VFESGitRepo("${pipelineConfig.gitRepo}",this)
                        }

                    }
                    
                }
            }
            stage('Checkout'){
                agent {
                    
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy=="SIMPLE" && ! (almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/)){
                            gitRepo.checkoutCommit(pipelineConfig.extractFolder,almsPackage.deployEnv,almsPackage.commitID)
                        }else if (pipelineConfig.branchPolicy==~/(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI)/)
                        {
                            gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,"develop")
                        }else{
                            gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
                        }
                    }
                }
            }
            stage('merge'){
                when{
                    expression { return (!(pipelineConfig.branchPolicy ==~ /SIMPLE/) || (pipelineConfig.branchPolicy ==~ /SIMPLE/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/))}
                }
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy ==~ /(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(master|masterCI)/){
                            echo "Merging to ${almsPackage.deployEnv} we will check for the corresponding tag for ${almsPackage.commitID} in develop branch..."
                            mergeInfo=gitRepo.mergeCommitFromDevelop(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage,almsPackage.almsID)
                        }else{
                            mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
                        }
                        
                    }
                }
            }
            stage('detectChangedArtifacts'){
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                    }
                }
                steps{
                    script{
                        artifacts=detectChangedArtifacts(pipelineConfig)
                        echo "Artifacts: ${artifacts}"
                    }
                }
            }
            stage('CopieProperties'){
                  agent{
                   label "eswltahr"
                  }
                        steps{
                   
                         script{
                          HayProperties=LOCALbuildBackMVOWProp(pipelineConfig,mergeInfo)
                          
                          if(HayProperties == true)
                          {  //hay properties las copio a la ruta
                              //checkout del codigo
                              if (pipelineConfig.branchPolicy=="SIMPLE" && ! (almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/)){
                                    gitRepo.checkoutCommit(pipelineConfig.extractFolder,almsPackage.deployEnv,almsPackage.commitID)
                                }else if (pipelineConfig.branchPolicy==~/(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(HID|HID1|HIDCI|HID1CI)/)
                                {
                                    gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,"develop")
                                }else{
                                    gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,almsPackage.deployEnv)
                                }
                                
                                //merge
                                if (pipelineConfig.branchPolicy ==~ /(SIMPLE|envs_and_develop)/ && almsPackage.deployEnv==~ /(?i)(master|masterCI)/){
                                    echo "Merging to ${almsPackage.deployEnv} we will check for the corresponding tag for ${almsPackage.commitID} in develop branch..."
                                    mergeInfo=gitRepo.mergeCommitFromDevelop(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage,almsPackage.almsID)
                                }else{
                                    mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,almsPackage.commitID,almsPackage.mergeMessage)
                                }
                                sh "pwd"
                                sh "scp ID-NETWORK/msisdn/src/main/resources/*.properties.* wlsrad@vodlpa18:/opt/weblogic/wlsrad/RAD/properties/config"
                                sh "scp ID-NETWORK/msisdn/src/main/resources/*.properties.* wlsrad@vodlpa17:/opt/weblogic/wlsrad/RAD/properties/config"
                                sh "scp ID-NETWORK/msisdn/src/main/resources/logback.xml.* wlsrad@vodlpa18:/opt/weblogic/wlsrad/RAD/properties/"
                                sh "scp ID-NETWORK/msisdn/src/main/resources/logback.xml.* wlsrad@vodlpa17:/opt/weblogic/wlsrad/RAD/properties/"
                                //find de los fichero propeties
                                //scp properites a la ruta final
                                //scp properties a la otra maquina ruta final
                                
                          }
                     }//script
                  }//step
               
                      
            }//stage
            
            
            stage('Compile'){
                agent {
                    label 'maven'
                    //docker {

                        // TODO : revisar si usamos "cache" de npm 
                        //label 'maven'
                        //image "${pipelineConfig.dockerImage}"
                        //args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'
                        //reuseNode true
                    //}
                }
                steps{
                    // TODO : manejar el caso master/ HID vs resto entornos
                    // TODO : gestionar el empaquetado del resultado 
                    script{
                        docker.image("${pipelineConfig.dockerImage}").inside('-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr') { c -> 
                            buildWithScript pipelineConfig
                        }   
                    }
                    
                }            
            }
            stage('RunSonar'){
                when{
                    expression { return pipelineConfig.runSonar == true }
                    beforeAgent true
                }
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.sonarImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr --entrypoint=""'                    
                    }
                }
                steps{
                    echo "runSonar: ${pipelineConfig.runSonar}"
                    runSonar pipelineConfig, almsPackage
                }
            }

            stage('CopyToRelease'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/ }
                }
                agent{
                    //label "deploy-apache-wcs"
                    label 'maven'
                }
                steps{
                    script{
                        if (pipelineConfig.artifactDetection!='maven_full_compile'){
                            echo "Download artifacts from Nexus ..."
                            downloadArtifactsFromNexus pipelineConfig, almsPackage
                        }
                        echo "DeployType: ${pipelineConfig.deployType}"
                        switch(pipelineConfig.deployType) {
                            case ~/^(wcs-app)$/:
                                echo "Copy code to release folder ..."
                                copyToRelease  pipelineConfig,  almsPackage
                            break
                            case ~/^(release|catalogo)$/:
                                echo "Copy code to release folder ..."
                                copyToRelease  pipelineConfig,  almsPackage
                            break
                            case ~/^(wl_redeploy)$/: case ~/^(wl_restart)$/:
                                echo "Do wl_redeploy..."
                                copyToReleaseWL pipelineConfig, almsPackage
                            break
                            case ~/^apache$/:
                                echo "Deploy to apache ..."
                                deployToApacheScript.deploy  pipelineConfig,almsPackage

                            break
							case ~/^download_from_nexus$/:
								node("${pipelineConfig.deployToken}-${deploy_env}"){
									echo "Doing checkout of CDM repo"
									checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'CDM']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'vfjenkins-passwd', url: 'http://eswltbhr:8282/vodafone/CDM.git']]]
									echo "Downloading from nexus and copying to release folders"
									getArtifactsFromNexus("https://nexus-apps.es.sedc.internal.vodafone.com/nexus","releases-maven-repository",artifacts)
									ansibleCopyLocalArtifactsToRelease(pipelineConfig,almsPackage,artifacts,)
								}

							break

                        }
                   
                    }

                }
            }

            stage('Deploy'){
                when{
                    expression { return deploy_env ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/ }
                }
                agent{
                    label "${pipelineConfig.deployToken}-${deploy_env}"
                }
                steps{
                    script{
                        switch(pipelineConfig.deployType) {
                            case ~/^catalogo$/:
                                echo "running deploy step"
                                deployCatalogo pipelineConfig, almsPackage
                            break
                            case ~/^wl_redeploy$/:
                                echo "running deploy step"
                                artifacts=[['artifactId':almsPackage.appName]]
                                ansibleRedeployWl artifacts, pipelineConfig, almsPackage
                            break
							case ~/^wl_restart$/:
                                echo "running deploy step, restarting weblogic"
								 ansibleRestartWl  pipelineConfig, almsPackage
                            break
							case ~/^download_from_nexus$/:
                                echo "running deploy step"
                                //artifacts=[['artifactId':almsPackage.appName]]
                                ansibleRedeployWl artifacts, pipelineConfig, almsPackage
                            break								
                        }
                    }
                    
                }
            }
            stage('RunSelenium'){
                when{
                    expression { return pipelineConfig.runSelenium == true  && deploy_env ==~ /(?i)(sit1|sit2|pprd|pprd1|sit1ci|sit2ci|pprdci|pprd1ci)/ }
                    beforeAgent true
                }
                agent{
                    label 'es1117yw'
                }
                steps{
                    script{
                        //def ret=bat(returnStdout:true , script:"python CDM/Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${deploy_env} ")
                        //echo "${ret}"
                        try{
                            bat "del *.png"
                            bat "python CDM/Jenkins/Selenium/MV-OW/logadoDeslogadoWin.py ${deploy_env} ${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}"
                        }catch (e) {
                            echo "error when doing Selenium !!!!"
                        }
                        archiveArtifacts artifacts: '*.png', fingerprint: true
                        def myfiles=findFiles glob:"*.png"
                        myfiles.each{ pngfile -> 
                            echo "Selenium Screenshot: <a href='$BUILD_URL/artifact/${pngfile.name}' target='_blank' >${pngfile.name}</a>"
                        }
                        bat "del *${alms_id}-${deploy_env}-${almsPackage.jobTimeStamp}*.png"
                    }
                }
            }

            stage('Prepare PAP'){
                agent{
                    //label "deploy-apache-wcs"
                    label 'maven'
                }
                when{
                    expression { return deploy_env ==~ /(?i)(master|masterCI|hid|hid1|hidci|hid1ci)/ }
                }
                steps{
                    script{
                        if (pipelineConfig.artifactDetection!='maven_full_compile'){
                            echo "Download artifacts from Nexus ..."
                            downloadArtifactsFromNexus pipelineConfig, almsPackage
                        }else{
                            // create zip file from extractFolder
                            // Modify config distFile , artifactId, distFolder to be arrays with 
                            // 1 element
                            sh "rm -rf zips;mkdir -p zips;zip -r zips/${artifact_id}.zip ${pipelineConfig.extractFolder}"
                            pipelineConfig.distFile=["${artifact_id}.zip"]
                            pipelineConfig.artifactId=["${artifact_id}"]
                            //pipelineConfig.distFolder=["../../../zips"]
                        }
                        echo "running Prepare PAP step"
                        prepareForProdDeployment pipelineConfig, almsPackage
                    }
                }
            }
            stage('TagAndPush'){
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy=="SIMPLE"){
                            if (almsPackage.deployEnv==~/(?i)(hid1|hid|hidci|hid1ci)/){
                                //caso de Oculto uso rama develop
                                echo "Tag and push to develop branch ..."
                                gitRepo.tagAndPushDevelop pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,"develop",almsPackage.almsID,almsPackage.commitID
                            }else if (almsPackage.deployEnv==~/(?i)(master|masterCI)/){
                                echo "Tag commit and push to git "
                                gitRepo.tagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                            else{
                                echo "Tag and push to git "
                                gitRepo.simpleTagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv,almsPackage.almsID

                            }
                        }else if (pipelineConfig.branchPolicy=="envs_and_develop")
                        {
                            if (almsPackage.deployEnv==~/(?i)(hid1|hid|hidci|hid1ci)/){
                                //caso de Oculto uso rama develop
                                echo "Tag and push to develop branch ..."
                                gitRepo.tagAndPushDevelop pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,"develop",almsPackage.almsID,almsPackage.commitID
                            }else if (almsPackage.deployEnv==~/(?i)(master|masterCI)/){
                                echo "Tag commit and push to git "
                                gitRepo.tagAndPush pipelineConfig.extractFolder,
                                    almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                            else{
                            echo "Tag commit and push to git "
                            gitRepo.tagAndPush pipelineConfig.extractFolder,
                                almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                            }
                        }
                        else
                        {
                            echo "Tag commit and push to git "
                            gitRepo.tagAndPush pipelineConfig.extractFolder,
                                almsPackage.gitTagId,almsPackage.gitTagComment,almsPackage.deployEnv
                        }
                    }
                }
            }
            stage('PublishChanges'){
                agent {
                    docker {
                        label 'maven'
                        image "${pipelineConfig.dockerImage}"
                        reuseNode true
                        args '-v /etc/passwd:/etc/passwd:ro -v /etc/group:/etc/group:ro -v /home/plataforma/jenkins/platafor-docker-home:/home/plataforma/plausr'                    
                    }
                }
                steps{
                    script{
                        if (pipelineConfig.branchPolicy!="SIMPLE"){
                            echo "Publish changes to ELK  and GitPublish plugin"
                            publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter
                        }
                    }
                    
                }
            }

        }
        post { 
            always { 
                node('master') {
                    catchError(message:"Error when publishing to InfluxDB") {
                        script{
                            echo 'Publishing to Influx for Pipeline KPI!!!'
                            echo "Squad: ${squad}"
                            sendInfluxMetrics "${deploy_env}", squad
                        }
                    }
                }

            }
			//failure{
				//slackNotify pipelineConfig,almsPackage,"ERROR"
			//}
			//success{
				//slackNotify pipelineConfig,almsPackage,"OK"
			//}

        }

        
    }
}
