def call (String User, String passw, String wbid, String code){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts/"){
            bat "python add_kiuwan_to_package.py -u ${User} -c ${passw} -p ${wbid} -t ${code}"
        }
    }
}