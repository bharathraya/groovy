def call(String _ORIGEN,String _DESTINO){
	echo "checkCommitDiff"
    	def SALIDA=""
    	SALIDA=sh returnStdout: true, script: """
	    	    git log "${_DESTINO}..${_ORIGEN}" --pretty=%h --no-merges
		    """
	return SALIDA
}