import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo_aaresmi
import vfes.git.VFESGitMergeInfo_aaresmi

import java.text.SimpleDateFormat

def deploy_env=""
def commit_id=""
def items2Delete=""
def applicationName=""
def mergeMessage=""
def gitTagComment=""
def gitTagId=""
def gitRepo=null
def gitOtherRepo=null
def pipelineConfig=null
def k8sObjects=null

VFESGitMergeInfo_aaresmi mergeInfo=null

def call(Map pipelineParams){
    pipeline{
        agent none
        parameters {
            choice(name: 'DeployEnv',  choices: pipelineParams.environmentChoices , description: '')
            string(name: 'CommitID', defaultValue: '', description: '', trim: true)
            string(name: 'ITEMS2DELETE', defaultValue: '', description: 'Comma separated items to delete. Must to match with the merge commit deleted items ', trim: true)
        }
        stages{
            stage("Prepare"){
                agent {
                    label "eswltbhr-platafor"
                }
                steps{
                    script {
                        echo "########################################"
                        echo "###########START PREPARE PHASE##########"
                        echo "########################################"
                        echo "Start TimeStamp:  ${new Date()}"
                        def timeFormat = new SimpleDateFormat("yyyyMMddHHmmss")
                        def date = new Date()
                        jobTimeStamp=timeFormat.format(date)
                        env.current_stage=env.STAGE_NAME
                        items2Delete=[]

                        wrap([$class: 'BuildUser']) {
                            jobUserId=env.BUILD_USER_ID
                            jobUserName=env.BUILD_USER
                        }

                        deploy_env=params.DeployEnv
                        commit_id=params.CommitID
                        params.ITEMS2DELETE.split(',').each{ item ->
                            items2Delete.add(item.trim())
                        }

                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        applicationName="${pipelineConfig.applicationName}"

                        echo "    ApplicationName: ${applicationName}"
                        echo "    CommitID:        ${commit_id}"
                        echo "    Environment:     ${deploy_env}"
                        echo "    jobUserId:       ${jobUserId}"
                        echo "    jobUserName:     ${jobUserName}"
                        echo "    items2Delete:     ${items2Delete}"

                        currentBuild.displayName = "Application: ${applicationName} Env:${deploy_env} User: ${jobUserId}"
                        currentBuild.description = "Application: ${applicationName} Env:${deploy_env} User: ${jobUserId} Commit: ${commit_id}"

                        mergeMessage="[${applicationName}][${jobTimeStamp}][${deploy_env}][${jobUserId}]"
                        gitTagComment="${applicationName}:${deploy_env}:${jobTimeStamp}"
                        gitTagId="${applicationName}-${deploy_env}-${jobTimeStamp}"
                        // TODO : when
                        gitRepo=new VFESGitRepo_aaresmi("${pipelineConfig.gitRepo}",this)
                        echo "End TimeStamp:  ${new Date()}"
                        echo "########################################"
                        echo "############END PREPARE PHASE###########"
                        echo "########################################"
                    }
                }
            }

            stage('Checkout'){
                agent {
                    label "${pipelineConfig.deployAgent}"
                }
                steps{
                    script{
                        echo "#########################################"
                        echo "###########START CHECKOUT PHASE##########"
                        echo "#########################################"
                        echo "Start TimeStamp:  ${new Date()}"
                        k8sObjects=[]
                        env.current_stage=env.STAGE_NAME
                        gitRepo.cloneBranchToLocalFolder(pipelineConfig.extractFolder,deploy_env)
                        if(pipelineConfig.gitOtherRepo?.trim()){
                            // Hacer el checkout en carpeta extractOtherFolder
                            echo "Do checkout of other folder"
                            gitOtherRepo=new VFESGitRepo_aaresmi("${pipelineConfig.gitOtherRepo}",this)
                            gitOtherRepo.cloneBranchToLocalFolder(pipelineConfig.extractOtherFolder,deploy_env)
                        }
                        k8sObjects=k8sAdminFunctions.k8sLoadInfoFromFS(pipelineConfig)
                        echo "End TimeStamp:  ${new Date()}"
                        echo "#########################################"
                        echo "############END CHECKOUT PHASE###########"
                        echo "#########################################"
                    }
                }
            }

            stage('merge'){
                agent {
                    label "${pipelineConfig.deployAgent}"
                }
                steps{
                    script{
                        echo "######################################"
                        echo "###########START MERGE PHASE##########"
                        echo "######################################"
                        echo "Start TimeStamp:  ${new Date()}"
                        env.current_stage=env.STAGE_NAME
                        mergeInfo=gitRepo.mergeCommit(pipelineConfig.extractFolder,commit_id,mergeMessage)
                        echo "MergeInfo: ${mergeInfo.filesChanged}"
                        echo "MergeInfo Detailed: ${mergeInfo.FilesChangedDetailed}"
                        echo "End TimeStamp:  ${new Date()}"
                        echo "######################################"
                        echo "############END MERGE PHASE###########"
                        echo "######################################"
                    }
                }
            }

            stage('Deploy'){
                agent{
                    label "${pipelineConfig.deployAgent}"
                }
                steps{
                    script{
                        try {
                            echo "###############################################"
                            echo "###############START DEPLOY PHASE##############"
                            echo "###############################################"
                            echo "Start TimeStamp:  ${new Date()}"
                            env.current_stage=env.STAGE_NAME
                            echo "running deploy step for ${pipelineConfig.deployType} and environmnet ${deploy_env}"
                            switch(pipelineConfig.deployType) {
                                case ~/^k8s-admin-objects$/:
                                    deployK8S_AdminObjects pipelineConfig,deploy_env,mergeInfo,k8sObjects,items2Delete
                                    break
                            }
                            echo "End TimeStamp:  ${new Date()}"
                            echo "###############################################"
                            echo "################END DEPLOY PHASE###############"
                            echo "###############################################"
                        }
                        catch (err){
                            echo "############################################"
                            echo "########ERROR IN DEPLOY VISION PHASE########"
                            echo "########ERROR IN DEPLOY VISION PHASE########"
                            echo "############################################"
                            echo err
                            sh ("exit 1")
                        }
                    }
                }
            }

            stage('TagAndPush'){
                agent {
                    label "${pipelineConfig.deployAgent}"
                }
                steps{
                    script{
                        echo "###################################################"
                        echo "###############START TAG & PUSH PHASE##############"
                        echo "###################################################"
                        echo "Start TimeStamp:  ${new Date()}"
                        env.current_stage=env.STAGE_NAME

                        echo "Tag commit and push to git "
                        gitRepo.tagAndPush pipelineConfig.extractFolder,
                                gitTagId,gitTagComment,deploy_env

                        echo "End TimeStamp:  ${new Date()}"
                        echo "###################################################"
                        echo "################END TAG & PUSH PHASE###############"
                        echo "###################################################"
                    }
                }
            }

            stage('PublishChanges'){
                agent {
                    label "${pipelineConfig.deployAgent}"
                }
                steps{
                    script{
                        echo "########################################################"
                        echo "###############START PUBLISH CHANGES PHASE##############"
                        echo "########################################################"
                        echo "Start TimeStamp:  ${new Date()}"
                        env.current_stage=env.STAGE_NAME

                        echo "Publish changes to ELK and GitPublish plugin"
                        publishGitChanges pipelineConfig.extractFolder,mergeInfo.commitBefore,mergeInfo.commitAfter

                        echo "End TimeStamp:  ${new Date()}"
                        echo "########################################################"
                        echo "################END PUBLISH CHANGES PHASE###############"
                        echo "########################################################"
                    }
                }
            }
        }
    }
}