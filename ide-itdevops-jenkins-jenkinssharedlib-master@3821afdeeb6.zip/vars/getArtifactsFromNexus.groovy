def call(nexusurl,repository,artifacts){

	// for each artifact download from nexus
	// Artifacts: [[groupId:com.vf.idg.rad, artifactId:header-enrichment, version:1.0.0, packaging:war, pomfile:pom.xml]]
	// URL to download https://nexus-apps.es.sedc.internal.vodafone.com/nexus/repository/releases-maven-repository/com/vf/idg/rad/header-enrichment/1.0.0/header-enrichment-1.0.0.war
	for (index=0;index<artifacts.size();index++){
		artifactId=artifacts[index]["artifactId"]
		groupId=artifacts[index]["groupId"]
		version=artifacts[index]["version"]
		packaging=artifacts[index]["packaging"]
		urlgroup=artifacts[index]["groupId"].replace(".","/")
		echo "groupId: ${groupId} urlgroup: ${urlgroup} artifactId: ${artifactId} version: ${version} packaging: ${packaging}"
		
		downloadurl=nexusurl+"/repository/${repository}/${urlgroup}/${artifactId}/${version}/${artifactId}-${version}.${packaging}"
		echo "downloadurl: ${downloadurl}"
		sh "wget -nv -O ${artifactId}-${version}.${packaging} --no-check-certificate ${downloadurl}" 
	}
}