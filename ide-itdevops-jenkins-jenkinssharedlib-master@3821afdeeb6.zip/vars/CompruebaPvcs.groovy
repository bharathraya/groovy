def call(String _ALMS_ID, String _DeployEnv){

hoy=new Date().format( 'yyyyMMdd' )
fichero_e="${_ALMS_ID}.${_DeployEnv}.deploy"  

sh "if [ -d CompruebaPvcs ]; then rm -rf CompruebaPvcs ; fi ; mkdir CompruebaPvcs; cd CompruebaPvcs ; scp platafor@es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_ALMS_ID}/${fichero_e} .  "



}
