def call (String _SERVER,String _CREDENTIALID, String _ARTID,String _VERSION, String _ENTORNO ) {
    echo "TagOCImageVersion"
    def SALIDA=""
    def lowerARTID=_ARTID.toLowerCase()
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${_CREDENTIALID}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
		SALIDA=sh returnStdout: true, script: """
            export PATH=$PATH:/var/lib/jenkins/occli
            export KUBERNETES_NAMESPACE="${_ENTORNO}"
            export KUBECONFIG=${HOME}/.kube/"${KUBECONFIG}"
            #oc login "${_SERVER}" --token="$PASSWORD" --insecure-skip-tls-verify=true
            #oc project "${_ENTORNO}"    	    
            oc --server="${_SERVER}" --token="$PASSWORD" tag "${lowerARTID}:latest" "${lowerARTID}:${_VERSION}" -n="${_ENTORNO}" 
	    """
    }
}
