import java.util.regex.Matcher

def getDiff(masterBranch){
    try{
        sh(script: "git --no-pager diff --name-only origin/${masterBranch} > diff_list.txt")
    } catch(Exception ex){
        echo "No se pudo extraer git diff"
    }
}

def getFormattedDiffList(){
    diffList = readFile("diff_list.txt").readLines()
	def includeKiuwan=""
	if (diffList.size()>0){
		includeKiuwan = diffList.first()
		diffList = diffList.drop(1)
		for (line in diffList){
			includeKiuwan += ",${line.trim()}"
		}
	}
    sh "rm diff_list.txt"
    return includeKiuwan.replace('/','\\/')
}

def geLastCommitter(String text, branch) {
    Matcher matcher =  text =~ /.*<([a-zA-Z0-9._%+-]+)@.*>.*/

    try {
        while (matcher.find()) {
          echo "Get Last Commiter ${matcher.group(1)}"
          return "@${matcher.group(1)}\n"
        }
    } catch(Exception ex) {
        echo "Se produjo un error en el matcher ${ex.getMessage()}"
    }
    return ""
}

def extractCommitter() {
    return sh(script: 'git show --format="%ai %an by <%ae> %ce" | head -n 1', returnStdout: true)
    // return sh(script: 'for branch in `git branch -r | grep -v HEAD`;do echo -e `git show --format="%ai %an by <%ae> %ce " $branch | head -n 1` $branch; done | sort -r',
    //         returnStdout: true)

}

def getLastCommitterToSlack(Map functionParams = [:]) {
    def branch = functionParams.getOrDefault("branch", "master")
    String text = extractCommitter()
    env.SLACK_COMMITTERS = geLastCommitter(text, branch)
  	echo "SLACK_COMMITTERS = ${env.SLACK_COMMITTERS}"
    if(SLACK_COMMITTERS.contains("platafor") || SLACK_COMMITTERS.contains("DL-SP-CM-DEP") )  {
        env.SLACK_COMMITTERS = ""
    }
}


