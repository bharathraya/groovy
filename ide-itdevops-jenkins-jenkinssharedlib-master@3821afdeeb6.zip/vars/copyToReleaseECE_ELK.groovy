import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
//def renderTemplateFromEnvs(_almsDep,_template,_apachepath,_htdocspath,_htdocsfolder,_distFile,_artifactId)
def renderTemplateFromEnvs(_alms,_template,_rootPath,_deployPath,_distFile){
	def variables = [ 'zip2deploy' : "${_distFile}",
	'rootPath' : "${_rootPath}",
	'deployPath' : "${_deployPath}",
	'appName' : "${_alms.appName}",
	'alms' :  "${_alms.almsID}",
	'devopsPath' : "${_rootPath}/staging/${_alms.jobDate}/${_alms.almsID}",
	'timestamp' : "${_alms.jobTimeStamp}"
	]
	def template = libraryResource("${_template}")
	return helpers.renderTemplate(template,variables)
}


def call(Map config,VFESALMSDeployment alms)
{
    for (i=0;i<config.artifactId.size();i++){
        def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
        def _envConfig=myEnvsConfig[alms.deployEnv]
        echo "_envConfig"+_envConfig['copyToRelease']

        dir(config.extractFolder) {
            _envConfig['copyToRelease'].each { item ->
                // ${zip2deploy}
                // ${rootPath}
                // ${deployPath}
                // ${appName}
                // ${alms}

                //render the template  for the item (server etc) into string variable
                //def strDeployScript=helpers.renderTemplate(template, variables)
                def strDeployScript=renderTemplateFromEnvs(alms,config.releaseDeployTemplate,item.application_release_path,config.releaseFolder,config.distFile[i])
                def scriptName="${item.server}.${alms.appName}.${alms.almsID}.${alms.jobTimeStamp}.sh"
                // Create script from string variable ...
                sh """#!/bin/sh
                echo '${strDeployScript}' > ${scriptName}
                chmod 755 ${scriptName}
                """

                sh "ssh -q -o StrictHostKeyChecking=no ${item.user}@${item.server} 'mkdir -p ${item.application_release_path}/staging/${alms.jobDate}/${alms.almsID}'"
	              sh "scp ${config.distFolder[i]}/${config.distFile[i]} ${item.user}@${item.server}:${item.application_release_path}/staging/${alms.jobDate}/${alms.almsID} 2>/dev/null"
	              sh "scp ${scriptName} ${item.user}@${item.server}:${item.application_release_path}/staging/${alms.jobDate}/${alms.almsID} 2>/dev/null"
                echo "Deploying ${alms.appName} ${alms.almsID}: run ${item.application_release_path}/staging/${alms.jobDate}/${alms.almsID}/${scriptName}"
                sh "ssh -q -o StrictHostKeyChecking=no ${item.user}@${item.server} '${item.application_release_path}/staging/${alms.jobDate}/${alms.almsID}/${scriptName}' "
            }
        }
    }
}
