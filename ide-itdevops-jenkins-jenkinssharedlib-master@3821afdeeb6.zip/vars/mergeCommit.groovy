

def call(entregasRepo='entregas', gitProtocol='http',
url='eswltbhr:8282',gitCredentials='vfjenkins-passwd',destFolder='.',mergeMessage,CommitID)
{

    dir("${destFolder}"){
        def gitCommitBefore = sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
        echo "GitCommit Before MERGE: ${gitCommitBefore}"

        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${gitCredentials}",
                usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            sh '''
                git remote add entregas http://${USERNAME}:${PASSWORD}@${url}/${entregasRepo}
            '''
        }  
        // git merge ${CommitID} --no-commit --no-ff
        sh """
            git fetch entregas
        """
        try{
            sh "git merge --no-ff -m'${mergeMessage}' ${CommitID} "
        }
        catch(Exception){
            echo "There are following merge conflicts!"
            sh '''
            set -x
            git diff --name-only --diff-filter=U | while read f
            do
            echo $f
            git log --follow --oneline $f
            echo
            done
            '''
            error('Stopping the job, has merge conflicts!!!')
        }
        gitCommitAfter = sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
        echo "GitCommit AFter MERGE: ${gitCommitAfter}"
        sh "git diff --name-only  ${gitCommitBefore}..${gitCommitAfter}"
    }

}

return this;