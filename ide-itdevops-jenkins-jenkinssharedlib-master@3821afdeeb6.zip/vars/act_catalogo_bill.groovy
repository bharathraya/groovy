def call(String _env,String _package,String _remoteServer){
  
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    act_catalogo_bill.sh -d GENEVA-ONO-BILLING  -e ${_env} -p ${_package}
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
