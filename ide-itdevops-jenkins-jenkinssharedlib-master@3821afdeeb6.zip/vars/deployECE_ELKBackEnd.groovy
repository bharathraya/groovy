import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
def call(Map config,VFESALMSDeployment alms, VFESGitMergeInfo_aaresmi mergeInfo, Boolean NO_RESTART)
{

  def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
  def _envConfig=myEnvsConfig[alms.deployEnv]
  /////////////////////////////
  //////TEST NEW RESTART///////
  /////////////////////////////
  //deployECE_ELKRestart config,alms,NO_RESTART
  //sh("exit 1")
  /////////////////////////////
  //////TEST NEW RESTART///////
  /////////////////////////////

  ///////////////////////////////////
  /////////NEW CHECK ACTIONS/////////
  ///////////////////////////////////
  if (config.containsKey("deployActions"))
  {
    deployECE_ELKCheckVariables config,alms
  }
  else
  {
    echo "===> Legacy"
    echo "Checking Variables ...."
    echo "_envConfig"+_envConfig['check_vars']
    _envConfig['check_vars'].each { item ->
      echo "Server Data:"
      echo "  check_vars_server: " + item.server
      echo "  check_vars_user: " + item.user
      echo "  application_release_path: " + item.application_release_path
      echo "  platafor_release_path: " + item.platafor_release_path
      echo "  repo_vars: " + item.repo_vars

      echo "AT: ${item.user}@${item.server}"
      echo "RUN: ${item.platafor_release_path}/scripts/${config.checkVarScript}"
      echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -b ${item.repo_vars}"
      sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.checkVarScript} -a ${config.applicationName} -r ${item.application_release_path} -b ${item.repo_vars}'"
    }
  }
  ///////////////////////////////////
  /////////NEW CHECK ACTIONS/////////
  ///////////////////////////////////

  echo "Deploying Templates ...."
  echo "_envConfig"+_envConfig['deploy_templates']
  _envConfig['deploy_templates'].each { item ->
    echo "Server Data:"
    echo "  deploy_server: " + item.server
    echo "  deploy_user: " + item.user
    echo "  application_release_path: " + item.application_release_path
    echo "  platafor_release_path: " + item.platafor_release_path + "/scripts"
    echo "  variables repository: " + item.repo_vars
    echo "  deploy Script: " + config.deployScript
    echo "ElasticSearch Data:"
    echo "  elastic_sch: " + item.elastic_sch
    echo "  elastic_host: " + item.elastic_host
    echo "  elastic_port: " + item.elastic_port
    echo "  elastic_credential: " + item.elastic_credential
    echo "  watcher_credential: " + item.watcher_credential
    def _elasticURL=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
      _elasticURL=item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
      echo "  ElasticSearch URL: " + _elasticURL
    }

    def _watcherCre=""
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.watcher_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
      _watcherCre="${USERNAME}" + ":" + "${PASSWORD}"
    }

    templates2Reindex=mergeInfo.FilesChangedDetailed.findAll{it[0] == "M" && it[1] =~ "templates/"}
    items2Deploy=mergeInfo.FilesChangedDetailed.findAll{it[0] == "M" || it[0] == "A"}
    items2DeployPurgados=items2Deploy.findAll{it[1] =~ 'purgado/'}

    templatesWithoutDir = []
    def regex = ~"^templates/"
    templates2Reindex.each { it ->
      trimmed = it[1] - regex
      templatesWithoutDir.add(trimmed)
    }
    templatesWithoutDirString=templatesWithoutDir.join(",")
    echo "Templates to reindex: " + templatesWithoutDirString
    _paramI=""
    if (templatesWithoutDirString != null && templatesWithoutDirString != "")
    {
      _paramI="-i ${templatesWithoutDirString}"
    }

    purgados2Deploy=[]
    items2DeployPurgados.each {it -> purgados2Deploy.add(it[1])}
    purgados2DeployString=purgados2Deploy.join(",")
    _paramPurgados=""
    if (purgados2DeployString != null && purgados2DeployString != "")
    {
      _paramPurgados="-p ${purgados2DeployString}"
    }
    echo "Purgeds to deploy: " + purgados2DeployString

    echo "AT: ${item.user}@${item.server}"
    echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
    echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -w ${_watcherCre} -v ${item.repo_vars} ${_paramI} ${_paramPurgados}"
    sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} -w ${_watcherCre} -v ${item.repo_vars} ${_paramI} ${_paramPurgados}'"
  }

  deployECE_ELKRestart config,alms,NO_RESTART

  /////////////////////////
  //////OLD RESTART///////
  ////////////////////////
  //echo "Restarting Logstash ...."
  //echo "_envConfig"+_envConfig['restart_logstash']
  //_envConfig['restart_logstash'].each { item ->
  //  echo "Server Data:"
  //  echo "  ReStart Server: " + item.server
  //  echo "  ReStart User: " + item.user
  //  echo "  ReStart Scripts path: " + item.scripts_path
  //  echo "  ReStart Script: " + config.restartScript
  //  echo "AT: ${item.user}@${item.server} RUN: ${item.scripts_path}/${config.restartScript}"
  // sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.scripts_path}; ./${config.restartScript}'"
  //}
  /////////////////////////
  //////OLD RESTART///////
  ////////////////////////
}
