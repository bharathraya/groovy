import vfes.git.VFESGitRepo

def call(String _PAQUETE, String _TAG, String _COMMIT ,String _branch, VFESGitRepo _repo, String _VERSION) {
  echo "GitTag4"
    // get old commitid
    final String GITLAB="Gitlab"
    final String BITBUCKET="Bitbucket"
    final String INTEGRATION_BB_PREFIX="vodafone"
    final String RELEASE_BB_PREFIX="release"
    final String FEATURE_BB_PREFIX="feature"
    final String REGEX_RELEASE=  /ES[0-9]*[A-Za-z_]*/
    final String REGEX_RELEASE_TEAM= /[A-Za-z_0-9]*-ES[0-9]*[A-Za-z_]*/
    final String REGEX_MASTER_DEVELOP= /(master|masterCI|develop)/    
    final String REGEX_ENVIRONMENTS= /(SIT1|SIT1CI|PPRD|PPRD1|PPRDCI|PPRD1CI|SIT2|SIT2CI|HID|HID1|HIDCI|HID1CI)/
    def _localBranch=_branch
    def _remoteBranch=_branch
    def _packagePrefix=""


    vfRepoPath=_repo.repoPath
    if (_repo.repoType==GITLAB){
        vfRepoPath=(_repo.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
    }    
    if (_repo.repoType==BITBUCKET  && !(_branch=='master'||_branch=='masterCI' || _branch=='develop')){
        if(_branch =~ REGEX_RELEASE || _branch =~ REGEX_RELEASE_TEAM){
            _remoteBranch=RELEASE_BB_PREFIX+"/"+_branch
        }else{
            _remoteBranch=INTEGRATION_BB_PREFIX+"/"+_branch
            _packagePrefix=_branch+"-"
        }
    }else{
        _packagePrefix=_branch+"-"
    }

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${_repo.pushCred}",
            usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
        sh """
            git remote set-url origin ${_repo.protocol}://${USERNAME}:${PASSWORD}@${_repo.server}/${vfRepoPath}/${_repo.repoName}
            git fetch --tags
        """
    }
    def MENSAJE="{PAQUETE: ${_PAQUETE}, VERSION:${_VERSION}}"
    def _remotetags=sh(returnStdout: true, script: """
            git ls-remote --tags origin |cut -d"/" -f3
        """).split("\n").collect{it}
    echo "REMOTE_TAGS:${_remotetags}"
    
    if ("${_TAG}" != ""){
        
        def existetag=sh returnStdout: true, script: """
            git tag -l ${_TAG}
        """
        // deletes current snapshot tag
        if ("${existetag}" != ""){

            sh ("git tag -d ${_TAG} || true")
        }
        // tags current changeset

        sh ("git tag -f ${_TAG} ${_COMMIT}")
    
        // deletes tag on remote if exist in order not to fail pushing the new one
    
        _remotetags.any{
            if (it == "${_TAG}"){
                sh ("git push --delete origin  ${_TAG}" )
                return true
             }
        }
    }
    if ("${_PAQUETE}" != ""){
        def paqueteTag=_packagePrefix+"PACKAGE-"+_PAQUETE

        def existetag=sh returnStdout: true, script: """
            git tag -l ${paqueteTag}
        """
        // deletes current snapshot tag
        if ("${existetag}" != ""){

            sh ("git tag -d ${paqueteTag} || true")
        }
        // tags current changeset

        sh ("git tag -a ${paqueteTag} -m \"${MENSAJE}\" ")
    
        // deletes tag on remote if exist in order not to fail pushing the new one
    
        _remotetags.any{
            if (it == "${paqueteTag}"){
                sh ("git push --delete origin  ${paqueteTag}" )
                return true
             }
        }
    }
    // tag the artifact version
    if ("${_VERSION}" != ""){    
        def existetagversion=sh returnStdout: true, script: """
            git tag -l ${_VERSION}
        """
        // deletes current version tag
        if ("${existetagversion}" != ""){
    
            sh ("git tag -d ${_VERSION} || true")
        }
    
        sh ("git tag -a ${_VERSION} -m \"${MENSAJE}\"")
        // deletes tag on remote if exist in order not to fail pushing the new one
        _remotetags.any{
            if (it == "${_VERSION}"){
                sh ("git push --delete origin  ${_VERSION}" )
                return true
            }
        }
    }
    // pushes the tags
    sh ("git push --tags origin refs/heads/${_localBranch}:${_remoteBranch}")
}

def call(String _PAQUETE, String _TAG, String _COMMIT ,String _branch, VFESGitRepo _repo, String _VERSION, String _TAG1) {
  echo "GitTag"
    // get old commitid
    final String GITLAB="Gitlab"
    final String BITBUCKET="Bitbucket"
    final String INTEGRATION_BB_PREFIX="vodafone"
    final String RELEASE_BB_PREFIX="release"
    final String FEATURE_BB_PREFIX="feature"
    final String REGEX_RELEASE=  /ES[0-9]*[A-Za-z_]*/
    final String REGEX_RELEASE_TEAM= /[A-Za-z_0-9]*-ES[0-9]*[A-Za-z_]*/
    final String REGEX_MASTER_DEVELOP= /(master|masterCI|develop)/    
    final String REGEX_ENVIRONMENTS= /(SIT1|SIT1CI|PPRD|PPRD1|PPRDCI|PPRD1CI|SIT2|SIT2CI|HID|HID1|HIDCI|HID1CI)/
    def _localBranch=_branch
    def _remoteBranch=_branch
    def _packagePrefix=""


    vfRepoPath=_repo.repoPath
    if (_repo.repoType==GITLAB){
        vfRepoPath=(_repo.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
    }    
    if (_repo.repoType==BITBUCKET  && !(_branch=='master'||_branch=='masterCI' || _branch=='develop')){
        if(_branch =~ REGEX_RELEASE || _branch =~ REGEX_RELEASE_TEAM){
            _remoteBranch=RELEASE_BB_PREFIX+"/"+_branch
        }else{
            _remoteBranch=INTEGRATION_BB_PREFIX+"/"+_branch
            _packagePrefix=_branch+"-"
        }
    }else{
        _packagePrefix=_branch+"-"
    }

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${_repo.pushCred}",
            usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
        sh """
            git remote set-url origin ${_repo.protocol}://${USERNAME}:${PASSWORD}@${_repo.server}/${vfRepoPath}/${_repo.repoName}
            git fetch --tags
        """
    }
    def MENSAJE="{PAQUETE: ${_PAQUETE}, VERSION:${_VERSION}}"
    def _remotetags=sh(returnStdout: true, script: """
            git ls-remote --tags origin |cut -d"/" -f3
        """).split("\n").collect{it}
    echo "REMOTE_TAGS:${_remotetags}"
    
    if ("${_TAG}" != ""){
        
        def existetag=sh returnStdout: true, script: """
            git tag -l ${_TAG}
        """
        // deletes current snapshot tag
        if ("${existetag}" != ""){

            sh ("git tag -d ${_TAG} || true")
        }
        // tags current changeset

        sh ("git tag -f ${_TAG} ${_COMMIT}")
    
        // deletes tag on remote if exist in order not to fail pushing the new one
    
        _remotetags.any{
            if (it == "${_TAG}"){
                sh ("git push --delete origin  ${_TAG}" )
                return true
             }
        }
    }
    if ("${_PAQUETE}" != ""){
        def paqueteTag=_packagePrefix+"PACKAGE-"+_PAQUETE

        def existetag=sh returnStdout: true, script: """
            git tag -l ${paqueteTag}
        """
        // deletes current snapshot tag
        if ("${existetag}" != ""){

            sh ("git tag -d ${paqueteTag} || true")
        }
        // tags current changeset

        sh ("git tag -a ${paqueteTag} -m \"${MENSAJE}\" ")
    
        // deletes tag on remote if exist in order not to fail pushing the new one
    
        _remotetags.any{
            if (it == "${paqueteTag}"){
                sh ("git push --delete origin  ${paqueteTag}" )
                return true
             }
        }
    }
    // tag the artifact version
    if ("${_VERSION}" != ""){    
        def existetagversion=sh returnStdout: true, script: """
            git tag -l ${_VERSION}
        """
        // deletes current version tag
        if ("${existetagversion}" != ""){
    
            sh ("git tag -d ${_VERSION} || true")
        }
    
        sh ("git tag -a ${_VERSION} -m \"${MENSAJE}\"")
        // deletes tag on remote if exist in order not to fail pushing the new one
        _remotetags.any{
            if (it == "${_VERSION}"){
                sh ("git push --delete origin  ${_VERSION}" )
                return true
            }
        }
    }
    // tag the artifact version
    if ("${_TAG1}" != ""){    
        def existetagversion=sh returnStdout: true, script: """
            git tag -l ${_TAG1}
        """
        // deletes current version tag
        if ("${existetagversion}" != ""){
    
            sh ("git tag -d ${_TAG1} || true")
        }
    
        sh ("git tag -a ${_TAG1} -m \"${MENSAJE}\"")
        // deletes tag on remote if exist in order not to fail pushing the new one
        _remotetags.any{
            if (it == "${_TAG1}"){
                sh ("git push --delete origin  ${_TAG1}" )
                return true
            }
        }
    }
    // pushes the tags
    sh ("git push --tags origin refs/heads/${_localBranch}:${_remoteBranch}")
}
