import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo


def call(Map _pipelineConfig,Map _env_config,VFESALMSDeployment _alms_dep,String deployment_type)
{

    for (i =0;i<_pipelineConfig.distFile.size();i++){
        def plataforpath=""
        def zipname=""
        if (_alms_dep.deployEnv == 'HID1CI' || _alms_dep.deployEnv == 'masterCI' ||  _alms_dep.deployEnv == 'master' || _env_config[deployment_type][0].server=='es036tvr')   
        {
            def myenvd=""   
            switch  (_alms_dep.deployEnv){
                case 'HID1CI':
                    myenvd='HID1'
                    break
                case 'masterCI':
                    myenvd='PROD'
                    break
                case 'HID1':
                    myenvd='HID1'
                    break
                case 'master':
                    myenvd='PROD'
                    break

            }
          if (_env_config[deployment_type][0].server=='es1573yr') {
            plataforpath="/opt/SP/deploy/data/temporal/${_alms_dep.jobDate}/anexo/${_alms_dep.almsID}/${myenvd}"
          } else {
            plataforpath="/home/plataforma/plausr/data/temporal/${_alms_dep.jobDate}/anexo/${_alms_dep.almsID}/${myenvd}"
          }
            zipname="${_alms_dep.almsID}-${_alms_dep.appName}.${_pipelineConfig.artifactId[i]}"
        }
        else
        {
            if (_env_config[deployment_type][0].server=='es1573yr') {
            	plataforpath="/opt/SP/deploy/data/temporal/${_alms_dep.jobDate}/anexos/${_alms_dep.almsID}"
            } else {
              plataforpath="/home/plataforma/plausr/data/temporal/${_alms_dep.jobDate}/anexos/${_alms_dep.almsID}"
            }
            zipname="${_alms_dep.almsID}-${_alms_dep.deployEnv}.${_pipelineConfig.artifactId[i]}-${_alms_dep.jobTimeStamp}"
        }

        _env_config[deployment_type].each { item ->
            echo "Preparing for ${item.server} ..."
            echo "create .env file for deployment ..."
            sh "echo export REL_ROOT=${item.path} >> ${zipname}.${item.server}.env"
            sh "echo export USER_REL=${item.username} >> ${zipname}.${item.server}.env"
            echo "create path in remote server"
            sh "ssh platafor@${item.server} 'mkdir -p ${plataforpath}'"
            echo "upload .sh, .zip and .env files"
            sh "scp ${zipname}.${item.server}.env platafor@${item.server}:${plataforpath}/${zipname}.env"
            sh "scp ${WORKSPACE}/${_pipelineConfig.extractFolder}/${_pipelineConfig.distFolder[i]}/${_pipelineConfig.distFile[i]} platafor@${item.server}:${plataforpath}/${zipname}.zip"
            sh "scp ${WORKSPACE}/CDM/CommonTools/scripts/ROLLBACK_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.bak.sh"
            sh "scp ${WORKSPACE}/CDM/CommonTools/scripts/DEPLOY_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.sh"
            sh "ssh platafor@${item.server} 'chmod 777 ${plataforpath}; chmod 755 ${plataforpath}/*.sh'"
        }
        echo ""
        echo ""
        echo "************************************************************************"
        echo "************************************************************************"
        echo "Execute:"
        currentBuild.description = currentBuild.description+"\n\r\n\rExecute:"
        _env_config[deployment_type].each { item ->
            echo "${item.username}@${item.server}:${plataforpath}/${zipname}.sh"
            currentBuild.description = currentBuild.description+"\n\r${item.username}@${item.server}:${plataforpath}/${zipname}.sh"
        }
        echo "************************************************************************"
        echo "************************************************************************"
        echo ""
        echo ""
    }
}
