def call (String _app,String _entorno){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python pre_sonar.py -a ${_app} -e ${_entorno} "
        }
        
    }
}