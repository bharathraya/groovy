import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.json.JsonBuilder

def _DeployEnv=""
def _ALMS_ID=""
def _Domain=""
def _listapaquetes=""
def pipelineConfig=null
def modulesUserName=""
def modulesHostIP=""
def modulesPackageBasePath=""
def uploadPath=""
def LocalPackageBasePath=""
def localAnnexesPath=""
def deployConfig=null
def ModulesJSON=null
def hoy=null
def AR_Elastic=null
def LocalHostname=null
def keyfilePath=null
def keyfileName=null

def extractKeyFile ()
{
  sh (script: "rm -fr ${keyfilePath}", returnStatus: false)
  sh ("mkdir -p ${keyfilePath}")
  withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
    niceKeyFile="${keyfile}"
    sh ("cp ${niceKeyFile} ${keyfilePath}/.")
  }
}

def returnPackageOrderModule (String FileName)
{
    int sepPos1 = FileName.indexOf('_')
    String WithoutOrder=FileName.substring(sepPos1+1).trim()
    int sepPos2 = WithoutOrder.indexOf('_')
    String WithoutPackage=WithoutOrder.substring(sepPos2+1).trim()


    String _Order=FileName.substring(0,sepPos1)
    String _Package=WithoutOrder.substring(0,sepPos2)
    String _Module=WithoutPackage.trim()


    return [_Order,_Package,_Module]
}

def FindAnnexFileForPackage (String Order, String Package)
{
    _AnnexeName=null
    localAnnexesPath=LocalPackageBasePath+'/Annexes'
    commandNum="cd ${localAnnexesPath};ls -1 *_${Package}_* | wc -l"
    _Count=sh(script: "${commandNum}", returnStatus: false, returnStdout: true)
    _Count=_Count.trim()
    echo "_Count=[${_Count}]"
    if ("${_Count}" != "1")
    {
      return _AnnexeName
    }
    commandName="cd ${localAnnexesPath};ls -1 *_${Package}_*"
    _AnnexeName=sh(script: "${commandName}", returnStatus: false, returnStdout: true)
    return _AnnexeName.trim()
}

def returnActionContext (String FileName, String Module)
{
  _Action=null
  _Context=null
  commandNum="cat ${localAnnexesPath}/${FileName} | grep \"${Module}#\" | wc -l"
  _Count=sh(script: "${commandNum}", returnStatus: false, returnStdout: true)
  _Count=_Count.trim()
  if ("${_Count}" != "1")
  {
    return [_Action, _Context]
  }
  commandName="cat ${localAnnexesPath}/${FileName} | grep \"${Module}#\""
  _line=sh(script: "${commandName}", returnStatus: false, returnStdout: true)
  args=_line.split('#')
  _file=args[0].trim()
  _Action=args[1].trim()
  _Context=args[2].trim()

  return [_Action.trim(),_Context.trim()]
}

def call(Map pipelineParams){
        pipeline{
            agent {label "SCHAMAN-Consolas"}
            parameters {
                string(name: 'WB_ID', defaultValue: '', description: 'WB ID or CRQ ID')
                string(name: 'Application', defaultValue: '', description: 'Application to deploy')
                string(name: 'Enviroment', defaultValue: '', description: 'Enviroment to deploy')
                string(name: 'List_Packages', defaultValue: '', description: 'List of package for deploy')
                string(name: 'PackageInfo', defaultValue: '', description: 'WB info')
                string(name: 'UserDB', defaultValue: '', description: 'DB USer')
                string(name: 'PasswordDB', defaultValue: '', description: 'DB Password USer')
            }
            stages{
                stage("Prepare"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            AR_Elastic=[]
                            echo "============================================="
                            echo "============================================="
                            echo "===================PREPARE==================="
                            echo "============================================="
                            echo "============================================="
                            LocalHostname=sh(script:"hostname",returnStdout: true).trim()
                            if (PackageInfo==""){
                               //LLamada manual

                               _DeployEnv=params.Enviroment
                               _ALMS_ID=params.WB_ID
                               _Domain=params.Application
                               _listapaquetes=params.List_Packages

                              if (_listapaquetes==""){
                                  _listapaquetes=params.WB_ID
                              }

                              echo "lista paquetes ${_listapaquetes}"
                              replica_datos(_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                            }else{
                                error(" WorkBench execution is not allowed !!!!")
                            }

                            if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="" ) {
                                error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] are mandatories.")
                            }

                            if(_DeployEnv != "PROD") {
                                error("Only allowed for PROD!!!.")
                            }

                            hoy=new Date().format('yyyyMMdd')
                            pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                            deployConfig=readJSON(file: pipelineConfig.deployConfig)
                            //commit_id=""
                            //workbenchPackage= new VFESALMSDeployment(pck_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,enterprise)
                            //currentBuild.displayName = workbenchPackage.jobDisplayName
                            //currentBuild.description = workbenchPackage.jobDescription
                            // TODO : when

                            currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Domain}"
                            currentBuild.description = "Lista: ${_listapaquetes} Entorno: ${_DeployEnv} Aplicación: ${_Domain}"

                            if (_DeployEnv == 'PPRD')
                            {
                                elasticSearch_server=pipelineConfig.ElasticSearch_PPRD
                            } else if (_DeployEnv == 'PROD') {
                                elasticSearch_server=pipelineConfig.ElasticSearch_PROD
                            } else {
                                echo "ERROR. Environment ${_DeployEnv} is not valid"
                                sh "exit 1"
                            }


                            echo "Deploy Info:"
                            echo "    Package Name:      ${_ALMS_ID}"
                            echo "    Domain:            ${_Domain}"
                            echo "    DeployEnv:         ${_DeployEnv}"
                            echo "    Packages IDs:      ${_listapaquetes}"
                            echo "    ElasticSearch Server:     ${elasticSearch_server}"

                            modulesUserName=pipelineConfig.annexesUser
                            modulesHostIP=pipelineConfig.annexesServer
                            modulesPackageBasePath=pipelineConfig.annexesBasePath + '/' + hoy + '/' + _ALMS_ID +  '/'+ _DeployEnv
                        }
                    }
                }
                stage("Previous Checks"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "===============PREVIOUS CHECKS==============="
                            echo "============================================="
                            echo "============================================="
                            echo "==> Get Modules to local server <=="
                            echo "   ==> Remote Server info:"
                            echo "       Modules User Name:             ${modulesUserName}"
                            echo "       Modules Server:                ${modulesHostIP}"
                            echo "       Modules Package Base Path:     ${modulesPackageBasePath}"

                            LocalHostName="hostname".execute().text
                            LocalUserName="id -u -n".execute().text
                            LocalBasePath=sh(script:"pwd",returnStdout: true).trim()
                            LocalPackageBasePath = LocalBasePath + '/' + hoy + '/' + _ALMS_ID + '/'+ _DeployEnv
                            keyfilePath=LocalBasePath + '/' + hoy + '/' + _ALMS_ID + '/' + ".secretFiles"
                            keyfileName="ssh-key-keyfile"
                            echo "==> Extract keyfile to connection to SCHAMAN servers <=="
                            extractKeyFile()

                            echo "   ==> Local Server info:"
                            echo "       Modules User Name:             ${LocalUserName}"
                            echo "       Modules Server:                ${LocalHostName}"
                            echo "       Modules Package Base Path:     ${LocalPackageBasePath}"
                            echo "   ==> Clean Local Modules Package Base Path"
                            sh(script:"rm -fr ${LocalPackageBasePath};exit 0")
                            sh(script:"mkdir -p ${LocalPackageBasePath}")
                            echo "   ==> Get Modules from Remote Server to the LocalServer"
                            sh("scp -r -o ConnectTimeout=30 ${modulesUserName}@${modulesHostIP}:${modulesPackageBasePath}/* ${LocalPackageBasePath}/.")

                            ModulesJSONFile=LocalPackageBasePath + '/'+ "modules.json"
                            ModulesJSON=readJSON(file: ModulesJSONFile)

                            echo "==> Load In-Memory HashMap List <=="
                            for (ModuleJSON in ModulesJSON['Modules'].findAll{it.IsRollback == 0})
                            {
                                _FileName=ModuleJSON.FileName
                                echo "_FileName=${_FileName}"
                                (_Order,_Package,_Module)=returnPackageOrderModule(_FileName)
                                if (_Order == null || _Package == null || _Module== null)
                                {
                                  echo "ERROR. No _Order, _Package or _Module for _FileName ${_FileName}"
                                  sh("exit 1")
                                }
                                _FileNameAnnex=FindAnnexFileForPackage(_Order,_Package)
                                echo "_FileNameAnnex=${_FileNameAnnex}"
                                if (_FileNameAnnex == null)
                                {
                                  echo "ERROR. No Annex for pacakge ${_Package}"
                                  sh("exit 1")

                                }
                                (_Action,_Context)=returnActionContext(_FileNameAnnex, _Module)
                                echo "_Action=${_Action}"
                                echo "_Context=${_Context}"
                                if (_Action == null || _Context == null)
                                {
                                  echo "ERROR. No Action or Context for pacakge ${_Package}"
                                  sh("exit 1")
                                }
                                _AR_Elastic = [filename: "${_FileName}", action:"${_Action}", context: "${_Context}"]
                                AR_Elastic+=_AR_Elastic
                            }
                            echo "AR_Elastic=${AR_Elastic}"
                        }
                    }
                }
                stage("Upload Modules"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "================UPLOAD MODULES==============="
                            echo "============================================="
                            echo "============================================="

                            uploadPath="${pipelineConfig.temporalPath}/_tmp/${hoy}/${_ALMS_ID}/${_DeployEnv}"

                            def remote = [:]
                            remote.user = pipelineConfig.releaseUser
                            remote.allowAnyHosts = true
                            remote.retryCount = 3
                            remote.retryWaitSec = 2
                            remote.timeoutSec = 5

                            for( proxy in deployConfig[_DeployEnv].ProxyServer)
                            {
                                remote.host = proxy.ServerIP
                                remote.name = proxy.ServerName
                                echo "====> Upload Modules to ${proxy.ServerIP} with ip ${proxy.ServerName}"
                                withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
                                {
                                    remote.identityFile = keyfile
                                    sshCommand remote: remote, command:"rm -fr ${uploadPath}", failOnError:false
                                    sshCommand remote: remote, command:"mkdir -p ${uploadPath}"
                                    echo "    ======> Created tmp path at ${uploadPath}"
                                    sh("scp -r -o ConnectTimeout=30 -i ${keyfile} ${LocalPackageBasePath}/DataModules/* ${pipelineConfig.releaseUser}@${proxy.ServerIP}:${uploadPath}/.")
                                    echo "    ======> Modules uploaded to proxyserver with success!!!"
                                }
                            }
                        }
                    }
                }

                stage("Print Actions"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "================PRINT ACTIONS================"
                            echo "============================================="
                            echo "============================================="
                            schamanElasticSearchCommand="${pipelineConfig.CurlproxyPath}" + "/" + "${pipelineConfig.CurlproxyScript} "
                            echo "==> Actions to execute: "
                            for (ModuleJSON in ModulesJSON['Modules'].findAll{it.IsRollback == 0})
                            {
                              _ModuleAR=AR_Elastic.find{it.filename==ModuleJSON.FileName}
                              DMActionFile="${uploadPath}/${_ModuleAR.filename} "
                              DMAction="${_ModuleAR.action} "
                              DMURL="https://${elasticSearch_server}/${_ModuleAR.context}"
                              for( proxy in deployConfig[_DeployEnv].ProxyServer)
                              {
                                command=schamanElasticSearchCommand + DMActionFile + DMAction + DMURL
                                echo "    FROM:      ${LocalHostname}"
                                echo "    GO :       ssh -i ${keyfilePath}/${keyfileName} ${pipelineConfig.releaseUser}@${proxy.ServerIP} \"${command}\""
                                echo " "
                              }
                            }
                        }
                    }
                }
            }
        }
    }
