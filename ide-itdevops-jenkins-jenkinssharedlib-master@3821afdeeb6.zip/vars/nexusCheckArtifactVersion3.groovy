import groovy.json.JsonSlurper;
/**
* this method need below params:
*    NEXUS_URL
*    REPO
*    GID
*    ARTID
*    EXTENSION
*    COMMIT
*/
def call(String _NEXUS_URL,String _REPO,String _GID,String _ARTID,String _EXTENSION,String _COMMIT, String _credential ) {
    echo "nexusCheckArtifactVersion3"
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${_credential}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
        def SALIDA=sh returnStdout: true, script: """
            curl -u ${USERNAME}:${PASSWORD} -k "${_NEXUS_URL}/service/rest/v1/search?repository=${_REPO}&format=maven2&group=${_GID}&name=${_ARTID}&maven.extension=${_EXTENSION}&version=*${_COMMIT}*"
            """
        def version=""
        def versionaux=""
        def downloadUrl=""
            if (SALIDA != ""){
            def jsonSlurper = new JsonSlurper()
            def jsonnexusquery = jsonSlurper.parseText(SALIDA)
            def downloadUrlaux=""
            jsonnexusquery.items.any{
                echo "encontrada version: ${it.version}"
                versionaux=it.version
                def versiontoken=versionaux.tokenize(".")
                def commit=versiontoken[2]
                //echo "commit:${commit}"
                if( "${commit}" == "${_COMMIT}"){   
                    echo "Ya existe el artefacto en nexus ${_ARTID}:${version}"
                    version=versionaux
                    def base="${_NEXUS_URL}/repository/${_REPO}/${_GID}/${_ARTID}/${version}/"
                    it.assets.any{
                        downloadUrlaux=it.downloadUrl
                        echo "tratando: ${it.downloadUrl}"
                        def artifact="${downloadUrlaux.substring(base.size(),downloadUrlaux.size())}"
                        echo "chequeando: ${artifact} vs ${_ARTID}-${version}.${_EXTENSION}"
                    	if ( "${artifact}" == "${_ARTID}-${version}.${_EXTENSION}"){
                    	    downloadUrl=downloadUrlaux
                    	    return true
                    	}
                    }
                    return true
                }
            }
        }
        return downloadUrl
    }
}
def call(String _NEXUS_URL,String _REPO,String _GID,String _ARTID,String _EXTENSION,String _COMMIT, String _credential,String _DELIVERY ) {
    echo "nexusCheckArtifactVersion3"
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${_credential}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
        def SALIDA=sh returnStdout: true, script: """
            curl -u ${USERNAME}:${PASSWORD} -k "${_NEXUS_URL}/service/rest/v1/search?repository=${_REPO}&format=maven2&group=${_GID}&name=${_ARTID}&maven.extension=${_EXTENSION}&version=*${_COMMIT}*"
            """
        def version=""
        def versionaux=""
        def downloadUrl=""
            if (SALIDA != ""){
            def jsonSlurper = new JsonSlurper()
            def jsonnexusquery = jsonSlurper.parseText(SALIDA)
            def downloadUrlaux=""
            jsonnexusquery.items.any{
                echo "encontrada version: ${it.version}"
                versionaux=it.version
                def versiontoken=versionaux.tokenize(".")
                def commit=versiontoken[2]
                def delivery=versiontoken[0]
                //echo "commit:${commit}"
                if( "${commit}" == "${_COMMIT}" && "${delivery.toLowerCase()}" == "${_DELIVERY.toLowerCase()}"){   
                    echo "Ya existe el artefacto en nexus ${_ARTID}:${version}"
                    version=versionaux
                    def base="${_NEXUS_URL}/repository/${_REPO}/${_GID}/${_ARTID}/${version}/"
                    it.assets.any{
                        downloadUrlaux=it.downloadUrl
                        echo "tratando: ${it.downloadUrl}"
                        def artifact="${downloadUrlaux.substring(base.size(),downloadUrlaux.size())}"
                        echo "chequeando: ${artifact} vs ${_ARTID}-${version}.${_EXTENSION}"
                    	if ( "${artifact}" == "${_ARTID}-${version}.${_EXTENSION}"){
                    	    downloadUrl=downloadUrlaux
                    	    return true
                    	}
                    }
                    return true
                }
            }
        }
        return downloadUrl
    }
}
