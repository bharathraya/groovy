def call (String User, String passw, String ruta , String type, String env , String proyect, String file){
    
    node ('es1117yw'){

        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
            wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: passw ]]]) {
                bat "python create_package_amdocs.py -u ${User} -c ${passw} -e ${env} -p ${proyect} -d ${ruta} -t ${type} -f ${file}"
            }//wrap
        }
    }
}

