def call(String _TipoRege,String RutaPaquete, String _CRQ_ID, String Upgrade){
 def hoy=""
 def TiposApp=""
 def _listadoRege=""
 def _listadoServer=""
 def _listadoClient=""
 def iSmart=0
 def ApplicacionesTratar=""
 def iCont=0
 def App=""

  hoy=new Date().format( 'yyyyMMdd' )

//print "DATOS RECOGIDOS"
print "Chosen deployment type ${_TipoRege}"
print "CRQ ${_CRQ_ID}"
//print "Ruta donde estan los datos  ${RutaPaquete}"

 TiposApp = readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")
if ("${_TipoRege}" != "CRMSmart" && "${_TipoRege}" != "ALL except SVN"  && "${_TipoRege}" != "AMDOCS-VISTAS" && "${_TipoRege}" != "ALL except BBDD")
   { 
       
     //  print "entro 1"
    //Casos AMDOCS-BBDD,AMDOCS-CLIENT,AMDOCS-SERVER, AMDOCS-BPM_APM
      
     if (TiposApp.contains(_TipoRege))
     {
          _listadoRege = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_TipoRege}")
          //Si que hay paquete sobre escribo el fichero
               //  print "Vacio el fichero"
                 sh " > ${RutaPaquete}/${_CRQ_ID}_tipos "
               // print "meto en el fichero la opcion elegida"
                 sh " echo ${_TipoRege} > ${RutaPaquete}/${_CRQ_ID}_tipos "
                 
                 if("${Upgrade}" == "NO")
                 {
                  //  print "Copio el fichero a la opetst75"
                    sh "scp ${RutaPaquete}/${_CRQ_ID}_tipos opetst75:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                 }
                 else
                 {
                    // print "Copio el fichero a la ruta del ${_CRQ_ID}"
                     sh "cp ${RutaPaquete}/${_CRQ_ID}_tipos /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                 }
     }
     else
     {
         error("You have chosen ${_TipoRege} and there are no packages")
     }
   }
   else if ("${_TipoRege}" == "CRMSmart")
   {  
       //print "entro 2"
       _listadoServer=""
       _listadoClient=""
        iSmart = 0
       if (TiposApp.contains("AMDOCS-SERVER"))
       {
            _listadoServer = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-SERVER")
       }
       if (TiposApp.contains("AMDOCS-CLIENT"))
       {
            _listadoClient = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-CLIENT")
       }
                            
        if (_listadoServer == "" && _listadoClient =="")
           { //No hay ni server ni client
                 error("You have chosen ${_TipoRege} and there are no packages")
           }
        else 
           {
               if ( _listadoServer == "" && _listadoClient !="")
                {//Hay client y no sever
                         _TipoRege = "AMDOCS-CLIENT"
                         iSmart = 1 
                }
                if ( _listadoServer != "" && _listadoClient == "")
                {//Hay server y no client
                        _TipoRege = "AMDOCS-SERVER"
                        iSmart = 1 
                }
                if ( _listadoServer != "" && _listadoClient != "")
                {//Hay server y client
                     _TipoRege = "AMDOCS-CLIENT AMDOCS-SERVER"
                     iSmart = 2
                }
               // print "Vacio el fichero"
                sh " > ${RutaPaquete}/${_CRQ_ID}_tipos "
               // print "meto en el fichero la opcion elegida"
                if (iSmart == 1 && _listadoServer != ""  )
                {
                    print "There are only SERVER "
                    sh " echo 'AMDOCS-SERVER' >> ${RutaPaquete}/${_CRQ_ID}_tipos "
                }
                else if ( iSmart == 1 && _listadoClient != ""  )
                {
                    print "There are only CLIENT"
                    sh " echo 'AMDOCS-CLIENT' >> ${RutaPaquete}/${_CRQ_ID}_tipos "
                }
                else
                {
                    print "There are Client and Server"
                    sh " echo 'AMDOCS-CLIENT' >> ${RutaPaquete}/${_CRQ_ID}_tipos "
                    sh " echo 'AMDOCS-SERVER' >> ${RutaPaquete}/${_CRQ_ID}_tipos "
                }
                
                if("${Upgrade}" == "NO")
                 {
                    print "I copy the file to opetst75"
                    sh "scp ${RutaPaquete}/${_CRQ_ID}_tipos opetst75:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                 }
                 else
                 {
                     print "I copy the file to the path of the ${_CRQ_ID}"
                     sh "cp ${RutaPaquete}/${_CRQ_ID}_tipos /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                 }
                                
            }//fin de que si hay Smart
     }
     else if ("${_TipoRege}" == "ALL except SVN")
     {   //print "entro 3"
        print "We have chosen to regenerate everything except SVN"
        //print " Tipo de aplicación ${TiposApp}"
        ApplicacionesTratar=readYaml(file: "CDM/Jenkins/WORKBENCH/ONO/AMDOCS/TiposAmdocsSinSVN.yml")
        Applicaciones=ApplicacionesTratar.split()
        iCont = 0
        sh " cp  ${RutaPaquete}/${_CRQ_ID}_tipos ${RutaPaquete}/${_CRQ_ID}_tipos_inicial"
        for (pos = 0; pos < Applicaciones.size(); pos++) {
            
            App = Applicaciones[pos]
            print "I analyze if there are packages of ....${App}....."
            File fh2 = new File("${RutaPaquete}/${_CRQ_ID}_tipos_inicial")
            def lines = fh2.readLines()
            for (line in lines) {
              if (line.equals(App))
              {   
                  print "There are packages of ${App}"
                _listadoRege = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${App}")
                
                 if (_listadoRege != "" )
                   {
                      iCont=iCont+1
                    //  print "${iCont}"
                      if (iCont == 1)
                      { //Es el primero que si hay 
                            print "I empty the file when it is the first"
                            sh " > ${RutaPaquete}/${_CRQ_ID}_tipos "
                      }
                      sh " echo ${App} >> ${RutaPaquete}/${_CRQ_ID}_tipos "
                   }
              }
            }
        }//for
        if (iCont == 0)
        {
            error ("There are no applications to analyze")
        }
        else
        {
              if("${Upgrade}" == "NO")
                 {
                   // print "Copio el fichero a la opetst75"
                    sh "scp ${RutaPaquete}/${_CRQ_ID}_tipos opetst75:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                 }
                 else
                 {
                     //print "Copio el fichero a la ruta del ${_CRQ_ID}"
                     sh "cp ${RutaPaquete}/${_CRQ_ID}_tipos /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                 }
        }
     }
     else if ("${_TipoRege}" == "ALL except BBDD")
     {
         if (TiposApp.contains("AMDOCS-BBDD"))
         {
               print "Quito AMDOCS-BBDD"
               sh " grep -v 'AMDOCS-BBDD' ${RutaPaquete}/${_CRQ_ID}_tipos > ${RutaPaquete}/${_CRQ_ID}_tipos_SIN "
               //print "Copio el fichero sin BBDD"
               sh " cp ${RutaPaquete}/${_CRQ_ID}_tipos_SIN ${RutaPaquete}/${_CRQ_ID}_tipos  "
                 
                 if("${Upgrade}" == "NO")
                 {
                   // print "Copio el fichero a la opetst75"
                    sh "scp ${RutaPaquete}/${_CRQ_ID}_tipos opetst75:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                 }
                 else
                 {
                     //print "Copio el fichero a la ruta del ${_CRQ_ID}"
                     sh "cp ${RutaPaquete}/${_CRQ_ID}_tipos /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                 }
         }
     }

}
