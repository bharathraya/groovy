

def call(String scmRepo='CDM',String scmBranch='master',String repoFolder='vodafone',
String gitProtocol='http',String gitUrl='eswltbhr:8282',String gitCredentials='vfjenkins-passwd',
String destFolder='.')
{
    echo "scmRepo: ${scmRepo}"
    checkout([$class: 'GitSCM', 
    branches: [[name: "${env.scmBranch}"]], 
    doGenerateSubmoduleConfigurations: false, 
    extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${env.destFolder}"]], 
    submoduleCfg: [], 
    userRemoteConfigs: [[credentialsId: "${env.gitCredentials}", 
                url: "${env.gitProtocol}://${env.gitUrl}/${env.repoFolder}/${env.scmRepo}.git"]]
    ])
}
return this;