def call(String _bitbucket,String delivery, String commit){
	echo "getGitDiffFileListRelease"
    def SALIDA=""
    
    if (delivery=='master'||delivery=='masterCI'||delivery=='develop'){
        SALIDA=sh returnStdout: true, script: """
            #git branch -r
            git diff --name-only ${delivery} ${commit}

        """ 
    }else{
        if (delivery =~/[A-Za-z_0-9]*-ES[0-9]*[A-Za-z_]*/ || delivery =~/ES[0-9]*[A-Za-z_]*/ || delivery =~/ES[0-9]*[A-Za-z_]*-RC/){
            SALIDA=sh returnStdout: true, script: """
                #git branch -r
                if [ "${_bitbucket}" != "bitbucket" ]
                then
                    git diff --name-only vodafone/${delivery} ${commit}
                else
                    git diff --name-only origin/release/${delivery} ${commit}
                fi
            """ 
        }else{
            if (delivery =="SIT1" ||delivery =="SIT2" ||delivery =="PPRD" ){
                SALIDA=sh returnStdout: true, script: """
                    #git branch -r
                    git diff --name-only origin/vodafone/${delivery} ${commit}
        
                """ 
            }else{
                SALIDA=sh returnStdout: true, script: """
                    #git branch -r
                    git diff --name-only ${delivery} ${commit}
        
                """                 
            }
        }
    }
	def lista = SALIDA.split("\n").collect{it.trim()}
	return lista
}

