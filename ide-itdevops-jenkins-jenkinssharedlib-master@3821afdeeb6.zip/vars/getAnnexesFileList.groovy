def call(String _Alms,String _Env,String _remoteServer,String _date){
    def SALIDA=""
    SALIDA=sh returnStdout: true, script: """
        . \$HOME/.profile >/dev/null 2>&1
        ls -1 \$DIR_BASE_TEMPORAL/${_date}/anexo/${_Alms}/${_Env}/Annexes/*
    """
    return SALIDA.split("\n").collect{it}
}