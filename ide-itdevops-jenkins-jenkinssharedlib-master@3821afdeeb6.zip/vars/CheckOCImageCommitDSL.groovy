def call(String clusterName, String _ARTID,String commit, String _ENTORNO, String noproxy ) {
    echo "CheckOCImageCommitDSL"
    def version=""
    def versionaux=""
    def lowerARTID=_ARTID.toLowerCase()
    withEnv(["PATH+OC=${tool 'occli-jenkins'}","KUBECONFIG=$HOME/.kube/config"]) {
        openshift.withCluster(clusterName) {
    	    echo "Using Cluster: ${openshift.cluster()}"
    	    openshift.withProject("${_ENTORNO}") {
    	        //echo "Using project: ${openshift.project()}"
    	        if(openshift.selector('is', "${lowerARTID}").exists()){
        	        def tags = openshift.selector('is', "${lowerARTID}").object().status.tags
                	tags.any{
                	    versionaux=it.tag
                        //echo "Found tag:${versionaux}"
                        def token=versionaux.tokenize(".")
                        if( token[2] == commit){   
                            version=versionaux
                            echo "Ya existe la imagen ${_ARTID}:${version} para el commit ${commit}"
                            return true
                        }
                    }
                	if ( version == "")
                	{
                	    echo "Existe la imagen en el repositorio, pero no el commit ${commit}"
                	}
    	        }else{
    	            echo "No existe la imagen en el repositorio"
    	        }
            }
        }
    }
    return version
}
def call(String clusterName, String _ARTID,String commit, String _ENTORNO, String noproxy,String _Delivery ) {
    echo "CheckOCImageCommitDSL"
    def version=""
    def versionaux=""
    def lowerARTID=_ARTID.toLowerCase()
    withEnv(["PATH+OC=${tool 'occli-jenkins'}","KUBECONFIG=$HOME/.kube/config"]) {
        openshift.withCluster(clusterName) {
    	    //echo "Using Cluster: ${openshift.cluster()}"
    	    openshift.withProject("${_ENTORNO}") {
    	        //echo "Using project: ${openshift.project()}"
    	        if(openshift.selector('is', "${lowerARTID}").exists()){
        	        def tags = openshift.selector('is', "${lowerARTID}").object().status.tags
                	tags.any{
                	    versionaux=it.tag
                        //echo "Found tag:${versionaux}"
                        def token=versionaux.tokenize(".")
                        if( token[2] == commit && token[0].toLowerCase() == _Delivery.toLowerCase()){   
                            version=versionaux
                            echo "Ya existe la imagen ${_ARTID}:${version} para el commit ${commit}"
                            return true
                        }
                    }
                	if ( version == "")
                	{
                	    echo "Existe la imagen en el repositorio, pero no el commit ${commit}"
                	}
    	        }else{
    	            echo "No existe la imagen en el repositorio"
    	        }
            }
        }
    }
    return version
}
