def call (String _pomstring,String _version){
    echo "getLibProjectVerion"
    def project = new XmlSlurper().parseText(_pomstring)
    def _versionvar=""
    def _versionaux=""
    if (_version =~ /^\$\{.*\}/){
        def token=_version.tokenize('{')
        def token1=token[1].tokenize('}')
        _versionvar=token1[0]
        echo "property:${_versionvar}"
        project.properties.children().any(){
            def property=it
            if (property.name() == _versionvar){
                echo "property:${property.name()}:${property}"
                _versionaux=property.toString()
                return true
            }
        }
    }else{
        _versionaux=_version
    }
    return _versionaux
}
