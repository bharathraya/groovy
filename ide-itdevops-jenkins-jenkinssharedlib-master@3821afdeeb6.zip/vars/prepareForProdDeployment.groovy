import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

// prepareForProdDeployment (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in Production environments
// It checks over envs.json the type of deployment and calls the corresponding function 

def call(Map config,VFESALMSDeployment alms)
{
    def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
	if (config.containsKey("deployType")&&config.deployType=="apacheFromEnvsFile"){
		deployToApacheScript.deployByEnvsFile config,alms
	}else{
		def _envConfig=myEnvsConfig[alms.deployEnv]
		_envConfig.keySet().each{ deployConfig->
			echo "Configuracion: ${deployConfig}"
			switch(deployConfig) {
				case 'deploy_servers':
					echo "Upload zip file and scripts to infrastructure server"
					uploadToInfraServer config,_envConfig,alms,"deploy_servers"
				break
				case 'release_servers':
					echo "Upload zip file and scripts to release servers"
					uploadToInfraServer config,_envConfig,alms,"release_servers"
				break
				case 'release':
					echo "Upload zip file and scripts to release servers"
					uploadToInfraServer config,_envConfig,alms,"release"
				break

				case 'wcs-app':
					echo "Upload zip file and scripts to release servers"
					uploadWCSAPPToInfraServer config,_envConfig,alms

				break
				case 'webservers':
					echo "Upload zip file and scripts to apache servers"
					deployToApacheScript.deploy  config,alms
				break
				case ~/^apacheFromEnvsFile$/:
						echo "Deploy to apache ..."
						deployToApacheScript.deployByEnvsFile  config,alms
				break

			}
		}
	}
}