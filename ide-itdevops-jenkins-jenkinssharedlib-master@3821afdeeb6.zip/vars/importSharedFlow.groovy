def call(String sharedFlow, Object env_config){
    echo "importSharedFlow"
    def SALIDA=""
    def maxrev=""
    def pom = readMavenPom file: "./pom.xml"
    version= pom.version
    echo "version: ${pom.version}"    
    echo "Applicacion: ${pom.artifactId}"
    
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
                                credentialsId: "${env_config.credentialid}", 
                                usernameVariable: 'USERNAME', 
                                passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            https_proxy="${env_config.proxyurl}"
            export https_proxy
            no_proxy="${env_config.noproxy}"
            export no_proxy
            curl -k -X POST --silent --write-out "HTTPSTATUS:%{http_code}" -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} -F "file=@./target/${pom.artifactId}-${pom.version}.zip" "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/sharedflows?action=import&name=${sharedFlow}"
        """
    }
	index=SALIDA.indexOf('HTTPSTATUS:')+11
	errorcode=SALIDA.substring(index,index+3)
	echo "POST status:${errorcode}"
	if (errorcode.substring(0,1) !="2"){
	    echo "WARNING:${SALIDA}"
	    error "Al importar: ${sharedFlow}"
	}

}
