def call (String User, String passw, String report){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts/"){
            bat "python get_pulse_cm.py -u ${User} -c ${passw} -t ${report}"
        }
    }
}