def call (List mslistdc, String ENTORNO, String oc_cluster){
    echo "showPodsReadyReplicas"
    withEnv(["PATH+OC=${tool 'occli-jenkins'}","KUBECONFIG=$HOME/.kube/config"]) {
        openshift.withCluster(oc_cluster) {
            echo "Using Cluster: ${openshift.cluster()}"
            echo "Pods info:"
            mslistdc.each(){
                def ms=it
                _App=ms.application
                APLICACION=_App.toLowerCase()
                project_dest="${ms.namespace}-${ENTORNO}"
                openshift.withProject(project_dest) {
                    def rcs=openshift.selector('rc',[ app: "${APLICACION}" ]).objects()
                    //echo "rcs:[${dcs}]"
                    rcs.each(){
                        def rc=it
                        //echo "rc:[${rc}]"
                        //echo "app:${rc.metadata.name}"
                        if(rc.status.replicas>0){
                            echo "Pod ${rc.metadata.name} Replicas: Deseadas=${rc.status.replicas} ready=${rc.status.readyReplicas}"
                        }
                    }
                }
            }
        }
    }
}
def call (List mslistdc, String ENTORNO, String oc_cluster,String namespace){
    echo "showPodsReadyReplicas"
    withEnv(["PATH+OC=${tool 'occli-jenkins'}","KUBECONFIG=$HOME/.kube/config"]) {
        openshift.withCluster(oc_cluster) {
            echo "Using Cluster: ${openshift.cluster()}"
            List dc=mslistdc
            dc.each(){
                def ms=it
                _App=ms.application
                APLICACION=_App.toLowerCase()
                if(namespace!=""){
                    project_dest=namespace
                }else{
                    project_dest="${ms.namespace}-${ENTORNO}"
                }
                openshift.withProject(project_dest) {
                    def rcs=openshift.selector('rc',[ app: "${APLICACION}" ]).objects()
                    //echo "rcs:[${dcs}]"
                    rcs.each(){
                        def rc=it
                        //echo "rc:[${rc}]"
                        //echo "app:${rc.metadata.name}"
                        if(rc.status.replicas>0){
                            echo "Pod ${rc.metadata.name} Replicas: Deseadas=${rc.status.replicas} ready=${rc.status.readyReplicas}"
                        }
                    }
                }
            }
        }
    }
}