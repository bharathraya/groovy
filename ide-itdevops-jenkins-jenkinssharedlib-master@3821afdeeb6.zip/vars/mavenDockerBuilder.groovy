   def call(dockerImage,projectFolder,usesMavenCacheFolder,deployEnv){
        def m2Folder=""
        if (usesMavenCacheFolder) {
            m2Folder="-v /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${deployEnv}/.m2:/home/plataforma/.m2"
            sh "mkdir -p /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${deployEnv}/.m2"
            echo "Copy settings.xml  to .m2 cache folder ... "
            sh "cp ${WORKSPACE}/CDM/Jenkins/${JOB_NAME}/m2/settings.xml /home/plataforma/jenkins/maven_repos/${JOB_NAME}/${deployEnv}/.m2"       
        }
        else{
            echo "CDM Job m2 folder maps to .m2 inside the docker image"
            m2Folder="-v ${WORKSPACE}/CDM/Jenkins/${JOB_NAME}/m2:/home/plataforma/.m2"
        }
        dir(projectFolder){
            echo "We start build as there are code changes involved in current merge..."
            echo "Copy cm_build_script  to project folder ... "
            sh "cp ${WORKSPACE}/CDM/Jenkins/${JOB_NAME}/cm_build_script ${projectFolder}/"
            sh "chmod 755 ${projectFolder}/cm_build_script"

            echo "BUILD ${deployEnv}"
            sh """
            docker run --user=\$(id -u):\$(id -g) --ulimit nofile=98304:98304 \
                -v ${projectFolder}:/home/plataforma/project  ${m2Folder} \
                ${dockerImage} /home/plataforma/project/cm_build_script
            """
            //error('Stopping the job before rest of steps ...')
        }
    }
    return this;