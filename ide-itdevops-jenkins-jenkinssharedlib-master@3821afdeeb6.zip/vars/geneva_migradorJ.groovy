def call(String _env,String _package,String _remoteServer){
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_package}
    geneva_migrador_j.sh -d GENEVA-ONO-JAVA -e ${_env} -p ${_package} 
    
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}