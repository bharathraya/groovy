import vfes.utils.VFESALMSDeployment
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.json.JsonBuilder

def deploy_env=""
def commit_id=""
def pck_id=""
def delivery=""
def project_id=""
def enterprise=""
def pipelineConfig=null
def annexes=""
def annexesCompletePath=""
def annexesAppendPath=""
def annexesUserName=""
def annexesHostIP=""
def contextPathToRestart=""
def serverToBackUp=null
def deployConfig=null
def hoy=null
def AR_annexes=null
def stageError=""
def backupFileWithPath=""
def backupFile=""

def returnSplitName (String full_name){
    def _contex=null
    def _extension=null
    def _server=null
    def _env=null


    int sepPos1 = full_name.indexOf('.')
    if (sepPos1 == -1) {
        return [_contex,_extension,_server,_env]
    }
    _contex=full_name.substring(0,sepPos1).trim()

    int sepPos2 = full_name.indexOf('_',sepPos1+1)
    if (sepPos2 == -1) {
        return [_contex,_extension,_server,_env]
    }
    _extension=full_name.substring(sepPos1+1,sepPos2)

    int sepPos3 = full_name.indexOf('_',sepPos2+1)
    if (sepPos3 == -1) {
        return [_contex,_extension,_server,_env]
    }
    _server=full_name.substring(sepPos2+1,sepPos3)
    _env=full_name.substring(sepPos3+1).trim()

    return [_contex,_extension,_server,_env]
}

def getContextPath(String propName){
    def _context=""
    int sepPos1 = propName.indexOf('.')
    if (sepPos1 == -1) {
        return _context
    }
    _context=propName.substring(0,sepPos1).trim()+"_"
    return _context
}

def getServerName(String propName){
    def _server=""
    int sepPos1 = propName.indexOf('.')
    if (sepPos1 == -1) {
        return _server
    }

    _server = propName =~ /_.*?_/
    if (_server.getCount() == 0) {
        _server=""
        return _server
    }

    _server = _server[0].replace("_", "");

    return _server
}

def findBinaryFromContext(String context, String ip, String name){
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 3
    remote.retryWaitSec = 2
    remote.timeoutSec = 5
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
        connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
        {
            remote.host = ip
            remote.name = name
            remote.identityFile = keyfile
            compose_ret=" --command=\"deployment-info\" | grep \"${context}\" | awk '{print \$1\" \"\$4}'| grep \"true\"| wc -l"
            command=connect + compose_ret
            echo "        =>Command: ${command}"
            ret=sshCommand remote: remote, command:"${command}"
            if (ret != "1")
            {
                return
            }
            compose_bin=" --command=\"deployment-info\" | grep \"${context}\" | awk '{print \$1\" \"\$4}'| grep \"true\" | awk '{print \$1}'"
            command=connect + compose_bin
            bin_name=sshCommand remote: remote, command:"${command}"
            return bin_name
        }
    }

}

def CleanEnvironment(){
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 5
    remote.retryWaitSec = 2
    remote.timeoutSec = 15

    for (server in serverToBackUp)
    {
        remote.host = server
        remote.name = server
            withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
                remote.identityFile = keyfile
                echo "    =======> Cleaning backup directory <======="
                sshCommand remote: remote, command:"cd ${pipelineConfig.backUpPath};ls -t | awk 'NR>5' | xargs rm -f", failOnError:false
            }
    }
}

def ReleaseBackup(){
    backupFile="PROPERTIES_"+"${workbenchPackage.gitTagComment}"+".tar"
    backupFile=backupFile.replaceAll(':','_')
    backupFileWithPath="${pipelineConfig.backUpPath}" + "/" + "${backupFile}"

    _serverToBackUp=[]
    for (annexe in AR_annexes)
    {
        _FileName=annexe.file
        _ContextPath=annexe.context
        _annexeEnv=deployConfig[deploy_env][_ContextPath]
        for (server in _annexeEnv)
        {
            _serverToBackUp+=server.ip
        }
    }
    serverToBackUp=new LinkedHashSet<String>(_serverToBackUp)
    echo "serverToBackUp=${serverToBackUp}"


    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 5
    remote.retryWaitSec = 2
    remote.timeoutSec = 15

    for (server in serverToBackUp)
    {
        remote.host = server
        remote.name = server
            withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
                remote.identityFile = keyfile

                echo "Creating backup tar file ${backupFileWithPath} at server ${server}"
                sshCommand remote: remote, command:"cd ${pipelineConfig.releasePath}/; tar cvf ${backupFileWithPath} ."
            }
    }
}

def ReleaseUpdate(){

    echo "Getting Annexes to Local Path"
    sh(script:"rm -fr ${annexesAppendPath}", returnStatus:false)
    sh(script:"mkdir -p ${annexesAppendPath}")
    sh("scp -o ConnectTimeout=30 ${annexesUserName}@${annexesHostIP}:${annexesCompletePath}* ${annexesAppendPath}.")

    withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
    {
        for (annexe in AR_annexes)
        {
            _file=annexe.file
            _context=annexe.context
            _serverName=annexe.serverName
            _annexeEnv=deployConfig["${deploy_env}"]["${_context}"].find{it.name=="${_serverName}"}
            echo "====> Upload Module ${_file} to ${_serverName} with ip ${_annexeEnv.ip}"
            if (_annexeEnv == null)
            {
                echo "        ERROR. Server ${_server} not found at deploy config file for the env ${deploy_env} and the Context ${_context}"
                sh "exit 1"
            }
            sh("scp -o ConnectTimeout=30 -i ${keyfile} ${annexesAppendPath}${_file} ${pipelineConfig.releaseUser}@${_annexeEnv.ip}:${pipelineConfig.releasePath}/.")
        }
    }
}

def SchamanPathUpdate(){
    withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
    {
        for (annexe in AR_annexes)
        {
            _file=annexe.file
            _context=annexe.context
            _serverName=annexe.serverName
            _annexeEnv=deployConfig["${deploy_env}"]["${_context}"].find{it.name=="${_serverName}"}
            if (_annexeEnv.EndName == null)
            {
                _EndName=annexe.context.substring(0, annexe.context.length() - 1) + "." + annexe.extension
            } else {
                _EndName=_annexeEnv.EndName
            }


            echo "====> Copy Module ${_file} to ${pipelineConfig.schamanPropertiesPath} with name ${_EndName} into ${_serverName} with ip ${_annexeEnv.ip}"
            if (_annexeEnv == null)
            {
                echo "        ERROR. Server ${_server} not found at deploy config file for the env ${deploy_env} and the Context ${_context}"
                sh "exit 1"
            }
            sh("ssh -o ConnectTimeout=30 -i ${keyfile} ${pipelineConfig.releaseUser}@${_annexeEnv.ip} \"sudo cp ${pipelineConfig.releasePath}/${_file} ${pipelineConfig.schamanPropertiesPath}/${_EndName}\"")
        }
    }
}

def rollBackSchamanPathUpdate(){
    echo "!!!!!!!!START ROLLBACK SCHAMAN PATH UPDATE!!!!!!!!"
    withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
    {
        for (annexe in AR_annexes)
        {
            _file=annexe.file
            _context=annexe.context
            _serverName=annexe.serverName
            _annexeEnv=deployConfig["${deploy_env}"]["${_context}"].find{it.name=="${_serverName}"}
            if (_annexeEnv.EndName == null)
            {
                _EndName=annexe.context.substring(0, annexe.context.length() - 1) + "." + annexe.extension
            } else {
                _EndName=_annexeEnv.EndName
            }
            echo "====> Copy Module ${_file} to ${pipelineConfig.schamanPropertiesPath} with name ${_EndName} into ${_serverName} with ip ${_annexeEnv.ip}"
            if (_annexeEnv == null)
            {
                echo "        ERROR. Server ${_server} not found at deploy config file for the env ${deploy_env} and the Context ${_context}"
                sh "exit 1"
            }
            sh("ssh -o ConnectTimeout=30 -i ${keyfile} ${pipelineConfig.releaseUser}@${_annexeEnv.ip} \"sudo cp ${pipelineConfig.releasePath}/${_file} ${pipelineConfig.schamanPropertiesPath}/${_EndName}\"")
        }
    }
    echo "!!!!!!!!END ROLLBACK SCHAMAN PATH UPDATE!!!!!!!!"
}

def RestartMicroServices(){
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 3
    remote.retryWaitSec = 2
    remote.timeoutSec = 5

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
        connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
        activate_command="curl -s --location --request POST "
        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
        {
            remote.identityFile = keyfile
            for (_context in contextPathToRestart)
            {
                _annexe=AR_annexes.find{it.context == _context}
                _binaryName=_annexe.binaryName
                if (_binaryName != null)
                {
                    disable=" --command=\"deployment disable ${_binaryName}\""
                    enable=" --command=\"deployment enable ${_binaryName}\""
                    _annexeEnv=deployConfig[deploy_env][_context]
                    for (server in _annexeEnv)
                    {
                        remote.host = server.ip
                        remote.name = server.name
                        url_curl="\"http://${server.ip}:8080/"
                        echo "====> Disabling MicroService ${_binaryName} into the ${server.name} with ip ${server.ip}"
                        command=connect+disable
                        echo "command: ${command}"
                        sshCommand remote: remote, command:"${command}"
                        //sh(script: "ssh -o ConnectTimeout=30 -i ${keyfile} ${pipelineConfig.releaseUser}@${server.ip} ${command}", returnStatus:false)
                        echo "====> Enabling MicroService ${_binaryName} into the ${server.name} with ip ${server.ip}"
                        command=connect+enable
                        echo "command: ${command}"
                        sshCommand remote: remote, command:"${command}"
                        echo "====> Starting MicroService ${_binaryName} into the ${server.name} with ip ${server.ip}"
                        _context_to_start=_context.substring(0, _context.length() - 1)
                        command=activate_command + url_curl + _context_to_start + "/api-management/start" + "\""
                        echo "command: ${command}"
                        sshCommand remote: remote, command:"${command}", failOnError:false
                        //sh(script: "ssh -o ConnectTimeout=30 -i ${keyfile} ${pipelineConfig.releaseUser}@${_annexeEnv.ip} ${command}")
                    }
                }
                else
                {
                    echo "Context:${_context} found Annexe ${_annexe} without binary. Maybe is a new binary. Nothing to do"
                }
            }
        }
    }
}

def rollBackRestartMicroServices(){
    echo "!!!!!!!!START ROLLBACK RESTART MICROSERVICES!!!!!!!!"
    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 3
    remote.retryWaitSec = 2
    remote.timeoutSec = 5

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli_PPRD}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
        connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
        withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
        {
            remote.identityFile = keyfile
            for (_context in contextPathToRestart)
            {
                _annexe=AR_annexes.find{it.context == _context}
                _binaryName=_annexe.binaryName
                if (_binaryName != null)
                {
                    disable=" --command=\"deployment disable ${_binaryName}\""
                    enable=" --command=\"deployment enable ${_binaryName}\""
                    _annexeEnv=deployConfig[deploy_env][_context]
                    for (server in _annexeEnv)
                    {
                        echo "====> Disabling MicroService ${_binaryName} into the ${server.name} with ip ${server.ip}"
                        command=connect+disable
                        echo "command: ${command}"
                        sshCommand remote: remote, command:"${command}"
                        //sh(script: "ssh -o ConnectTimeout=30 -i ${keyfile} ${pipelineConfig.releaseUser}@${server.ip} ${command}", returnStatus:false)
                        echo "====> Enabling MicroService ${_binaryName} into the ${server.name} with ip ${server.ip}"
                        command=connect+enable
                        echo "command: ${command}"
                        sshCommand remote: remote, command:"${command}"
                        //sh(script: "ssh -o ConnectTimeout=30 -i ${keyfile} ${command}")
                    }
                }
                else
                {
                    echo "Context:${_context} found Annexe ${_annexe} without binary. Maybe is a new binary. Nothing to do"
                }
            }
        }
    }

    echo "!!!!!!!!END ROLLBACK RESTART MICROSERVICES!!!!!!!!"
}

def rollBackReleaseUpdate(){

    echo "!!!!!!!!START ROLLBACK RELEASE CHANGES!!!!!!!!"
    if (backupFileWithPath == "" || backupFile == "")
    {
        echo "        ERROR. backupFileWithPath||backupFile variable not filled. Something went Wrong."
        echo "        ERROR. MANUAL ROLLBACK IS NEEDED!!!!!!!"
        echo "        ERROR. MANUAL ROLLBACK IS NEEDED!!!!!!!"
        echo "        ERROR. MANUAL ROLLBACK IS NEEDED!!!!!!!"
        sh "exit 1"
    }

    def remote = [:]
    remote.user = pipelineConfig.releaseUser
    remote.allowAnyHosts = true
    remote.retryCount = 5
    remote.retryWaitSec = 2
    remote.timeoutSec = 15

    for (server in serverToBackUp)
    {
        remote.host = server
        remote.name = server
            withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')]) {
                remote.identityFile = keyfile
                echo "Doing RollBack at server ${server} with BackUp tar file ${backupFileWithPath}"
                sshCommand remote: remote, command:"cd ${pipelineConfig.releasePath}/; rm -f *;cp ${backupFileWithPath} .;tar xvf ${backupFile}; rm -f ${backupFile}"
            }
    }
    echo "!!!!!!!!END ROLLBACK RELEASE CHANGES!!!!!!!!"
}

def rollBack(err){
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "!!!!!!!!STARTING THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!STARTING THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "Stage error at: ${stageError}"
    echo "Error Details: ${err}"

    switch(stageError) {
        case ["ReleaseBackup","PreviousChecks"]:
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION"
            echo "NOTHING TO ROLLBACK BUT WE CANNOT CONTINUE WITH THE PROMOTION"
            break
        case "ReleaseUpdate":
            rollBackReleaseUpdate()
            CleanEnvironment()
            break
        case "SchamanPathUpdate":
            rollBackReleaseUpdate()
            rollBackSchamanPathUpdate()
            CleanEnvironment()
            break
        case "RestartMicroServices":
            rollBackReleaseUpdate()
            rollBackSchamanPathUpdate()
            rollBackRestartMicroServices()
            CleanEnvironment()
            break
    }

    currentBuild.result = Result.FAILURE
    error('!!!!!!!!AUTOMATED ROLLBACK ENDED SUCCESSFULLY!!!!!!!!')
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "!!!!!!!!END THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!END THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
}



def call(Map pipelineParams){
        pipeline{
            agent {label "SCHAMAN-Consolas"}
            parameters{
                string(name: 'DeployEnv', defaultValue: '', description: '')
                string(name: 'CommitID', defaultValue: '', description: '')
                string(name: 'Package_ID', defaultValue: '', description: '')
                string(name: 'Delivery', defaultValue: '', description: '')
                string(name: 'ProjectId', defaultValue: '', description: '')
                string(name: 'enterprise', defaultValue: 'BAU', description: '')
                string(name: 'PackageInfo', defaultValue: '', description: '')
            }
            stages{
                stage("Prepare"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            AR_annexes=[]
                            echo "============================================="
                            echo "============================================="
                            echo "===================PREPARE==================="
                            echo "============================================="
                            echo "============================================="
                            if (params.PackageInfo=="")
                            {
                                // executed manually or from ALMS
                                echo "    Manual or Jenkins GUI execution!!!"
                                deploy_env=params.DeployEnv
                                pck_id=params.Package_ID
                                delivery=params.Delivery
                                project_id=params.ProjectId
                                enterprise=params.enterprise
                            }else{
                                echo "    Workbench execution!!!"
                                echo "PackageInfo: ${params.PackageInfo}"
                                (deploy_env,pck_id,delivery,project_id,enterprise,annexes,modules)= parsePckInfo_WithAnnexes_WithoutGit(PackageInfo)
                            }
                            hoy=new Date().format('yyyyMMdd')
                            pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                            deployConfig=readJSON(file: pipelineConfig.deployConfig)
                            commit_id=""
                            workbenchPackage= new VFESALMSDeployment(pck_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,enterprise)
                            currentBuild.displayName = workbenchPackage.jobDisplayName
                            currentBuild.description = workbenchPackage.jobDescription


                            // TODO : when

                            echo "Deploy Info:"
                            echo "    DeployEnv:        ${deploy_env}"
                            echo "    PackageID:        ${pck_id}"
                            echo "    Delivery:         ${delivery}"
                            echo "    Project:          ${project_id}"
                            echo "    Enterprise:       ${enterprise}"
                            echo "    Modules:          ${modules}"
                            echo "    Annexes:          ${annexes}"
                        }
                    }
                }
                stage("PreviousChecks"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try{
                                echo "============================================="
                                echo "============================================="
                                echo "================PREVIOUS CHECKS=============="
                                echo "============================================="
                                echo "============================================="
                                echo "====> Check Annexes Info"
                                echo "======> Check Annexes Host Name/IP"
                                annexesHostIP = pipelineConfig.annexesServer
                                if (annexesHostIP == null || annexesHostIP == "")
                                {
                                    echo "        ERROR. Annexes Host IP not configure at ${pipelineParams.pipelineConfigFile} File"
                                    sh "exit 1"
                                }
                                echo "        Annexes Host Name/IP: ${annexesHostIP}"

                                echo "======> Check Annexes User Name"
                                annexesUserName = pipelineConfig.annexesUser
                                if (annexesUserName == null || annexesUserName == "")
                                {
                                    echo "        ERROR. Annexes User Name not configure at ${pipelineParams.pipelineConfigFile} File"
                                    sh "exit 1"
                                }
                                echo "        Annexes UserName: ${annexesUserName}"

                                echo "======> Check Annexes Base Path"
                                annexesBasePath = pipelineConfig.annexesBasePath
                                if (annexesBasePath == null || annexesBasePath == "")
                                {
                                    echo "        ERROR. Annexes Base Path not configure at ${pipelineParams.pipelineConfigFile} File"
                                    sh "exit 1"
                                }
                                annexesAppendPath="${hoy}" + '/' + "${pck_id}" + '/' + "${deploy_env}" + '/' + 'Annexes/'
                                annexesCompletePath="${annexesBasePath}" + '/' + "${annexesAppendPath}"
                                echo "        Annexes Base Path: ${annexesBasePath}"
                                echo "        Annexes Append Path: ${annexesAppendPath}"
                                echo "        Annexes Complete Path: ${annexesCompletePath}"

                                echo "====> Check Annexes Data"
                                echo "======> Check Annexes Number"

                                annexesEnv=annexes.Annexe.findAll{it.FileName.contains("_"+"${deploy_env}")}
                                numAnnexesNoEnv=annexes.Annexe.findAll{!it.FileName.contains("_"+"${deploy_env}")}.size()
                                numAnnexesEnv=annexesEnv.size()

                                if (numAnnexesEnv == 0){
                                    echo "        Num Annexes (env): ${numAnnexesEnv}"
                                    echo "        Num Annexes must to be >= 1"
                                    sh "exit 1"
                                }

                                echo "        Num Annexes (no env): ${numAnnexesNoEnv}"
                                echo "        Num Annexes (env): ${numAnnexesEnv}"

                                echo "======> Check formats and the existence of the same in the deploy file"
                                for (annexe in annexes.Annexe)
                                {

                                    _FileName=annexe.FileName
                                    echo "========> Check Annexes Files Existence for ${_FileName}"
                                    AnnexesNameWithPath="${annexesCompletePath}" + "${_FileName}"

                                    exist = sh(script:"ssh ${annexesUserName}@${annexesHostIP} \"ls -1 ${AnnexesNameWithPath}\"",  returnStatus: true)
                                    if (exist!=0){
                                        echo "        ERROR. ${AnnexesNameWithPath} not found at server " + "${annexesHostIP}"
                                        sh "exit 1"
                                    }
                                    echo "        File ${_FileName} Found: OK!"

                                    echo "========> Check Format for ${_FileName}"
                                    (_context,_extension,_server,_env) = returnSplitName(_FileName)
                                    if (_context == null || _extension == null || _server == null || _env == null )
                                    {
                                        echo "        ERROR.Property File ${_FileName} Malformed"
                                        echo "              Must to be:"
                                        echo '                          {context_path}.extension_{server_name}_{PPRD|PROD}'
                                        sh "exit 1"
                                    }
                                    if ( _context == "" || _extension == "" || _server == "" || _env == "" )
                                    {
                                        echo "        ERROR.Property File ${_FileName} Malformed"
                                        echo "              Must to be:"
                                        echo '                          {context_path}.extension_{server_name}_{PPRD|PROD}'
                                        sh "exit 1"
                                    }

                                    if (_env != "PROD" && _env != "PPRD")
                                    {
                                        echo "        ERROR.Property File ${_FileName} Malformed"
                                        echo "              Must to be:"
                                        echo '                          {context_path}.extension_{server_name}_{PPRD|PROD}'
                                        sh "exit 1"
                                    }

                                    echo "        Format Name: OK!"

                                    echo "========> Check data in the deploy file for ${_FileName}"
                                    envpluscontext=null
                                    envpluscontextandserver=null
                                    envpluscontext=deployConfig["${_env}"]["${_context}"+"_"]
                                    if (envpluscontext == null)
                                    {
                                        echo "        ERROR. Context ${_context} not found at deploy config file for the env ${_env}"
                                        sh "exit 1"
                                    }
                                    envpluscontextandserver=deployConfig["${_env}"]["${_context}"+"_"].find{it.name=="${_server}"}
                                    if (envpluscontextandserver == null)
                                    {
                                        echo "        ERROR. Server ${_server} not found at deploy config file for the env ${_env} and the Context ${_context}"
                                        sh "exit 1"
                                    }
                                    echo "        Deploy Env ${_env}, Context ${_context} and ServerName ${_server} Found at deploy config file: OK!"
                                }

                                echo "======> Load Annexes In-Memory HashMap for the env ${deploy_env} to deploy"
                                _contextPathToRestart=[]
                                for (annexe in annexesEnv)
                                {
                                    _FileName=annexe.FileName
                                    echo "========> Loading file, context, server, extension values for ${_FileName}"
                                    AnnexesNameWithPath="${annexesCompletePath}" + "${_FileName}"
                                    (_context,_extension,_server,_env) = returnSplitName(_FileName)
                                    _context=_context+"_"
                                    _contextPathToRestart+=_context
                                    _AR_annexes = [file: "${_FileName}", context: "${_context}", serverName: "${_server}", extension: "${_extension}", binaryName: ""]
                                    AR_annexes+=_AR_annexes
                                }
                                contextPathToRestart=new LinkedHashSet<String>(_contextPathToRestart)

                                echo "======> Getting binaryName and Loading it to In-Memory HashMap"
                                for (_context in contextPathToRestart)
                                {
                                    _annexeEnv=deployConfig[deploy_env][_context]
                                    echo "_annexeEnv=${_annexeEnv}"
                                    _annexeEnvFirst=deployConfig[deploy_env][_context].first()
                                    BinaryName=findBinaryFromContext(_context,_annexeEnvFirst.ip,_annexeEnvFirst.name)
                                    echo "          Context ${_context} corresponds to the Binary ${BinaryName}"
                                    for (AR_annexe in AR_annexes.findAll{it.context == _context})
                                    {
                                        AR_annexe.binaryName=BinaryName
                                        echo "              Binary ${BinaryName} added to ${AR_annexe.file}"
                                    }
                                }
                                echo "AR_annexes=${AR_annexes}"
                            }
                            catch(err)
                            {
                                stageError="PreviousChecks"
                                rollBack(err)
                            }
                        }
                    }
                }

                stage('ReleaseBackup'){
                    agent{label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try
                            {
                                echo "=========================================="
                                echo "========START RELEASE BACKUP PHASE========"
                                echo "========START RELEASE BACKUP PHASE========"
                                echo "=========================================="
                                ReleaseBackup ()
                                echo "=========================================="
                                echo "=========END RELEASE BACKUP PHASE========="
                                echo "=========END RELEASE BACKUP PHASE========="
                                echo "=========================================="
                            }
                            catch (err)
                            {
                                stageError="ReleaseBackup"
                                rollBack(err)
                            }
                        }
                    }
                }

                stage("ReleaseUpdate"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try
                            {
                                echo "=========================================="
                                echo "========START RELEASE UPDATE PHASE========"
                                echo "========START RELEASE UPDATE PHASE========"
                                echo "=========================================="
                                ReleaseUpdate ()
                                echo "========================================"
                                echo "========END RELEASE UPDATE PHASE========"
                                echo "========END RELEASE UPDATE PHASE========"
                                echo "========================================"
                            }
                            catch (err)
                            {
                                stageError="ReleaseUpdate"
                                rollBack(err)
                            }
                        }
                    }
                }

                stage("SchamanPathUpdate"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try
                            {
                                echo "==============================================="
                                echo "========START SCHAMAN PATH UPDATE PHASE========"
                                echo "========START SCHAMAN PATH UPDATE PHASE========"
                                echo "==============================================="
                                SchamanPathUpdate ()
                                echo "==============================================="
                                echo "=========END SCHAMAN PATH UPDATE PHASE========="
                                echo "=========END SCHAMAN PATH UPDATE PHASE========="
                                echo "==============================================="
                            }
                            catch (err)
                            {
                                stageError="SchamanPathUpdate"
                                rollBack(err)
                            }
                        }
                    }
                }

                stage("RestartMicroServices"){
                    agent { label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try{
                                echo "==========================================="
                                echo "=====START RESTART MICROSERVICES PHASE====="
                                echo "=====START RESTART MICROSERVICES PHASE====="
                                echo "==========================================="
                                RestartMicroServices()
                                echo "==========================================="
                                echo "=====END RESTART MICROSERVICES PHASE======="
                                echo "=====END RESTART MICROSERVICES PHASE======="
                                echo "==========================================="
                            }
                            catch (err)
                            {
                                stageError="RestartMicroServices"
                                rollBack(err)
                            }
                        }
                    }
                }

                stage('CleanEnvironment') {
                    agent {label "SCHAMAN-Consolas"}
                    steps {
                        script{
                            echo "==========================================="
                            echo "=======START CLEAN ENVIRONMENT PHASE======="
                            echo "=======START CLEAN ENVIRONMENT PHASE======="
                            echo "==========================================="
                            CleanEnvironment()
                            echo "========================================="
                            echo "=======END CLEAN ENVIRONMENT PHASE======="
                            echo "=======END CLEAN ENVIRONMENT PHASE======="
                            echo "========================================="
                        }
                    }
                }
            }
        }
    }
