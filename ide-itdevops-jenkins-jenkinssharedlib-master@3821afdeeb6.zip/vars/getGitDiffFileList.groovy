def call(String _bitbucket,String delivery, String commit){
	echo "getGitDiffFileList"
    def SALIDA=""
    if (delivery == "master" || delivery == "develop"){
        SALIDA=sh returnStdout: true, script: """
            #git branch -r
            git diff --name-only ${delivery} ${commit}

        """        
    }else{
        SALIDA=sh returnStdout: true, script: """
            #git branch -r
            if [ "${_bitbucket}" != "bitbucket" ]
            then
                git diff --name-only vodafone/${delivery} ${commit}
            else
                git diff --name-only origin/vodafone/${delivery} ${commit}
            fi
        """
    }
	def lista = SALIDA.split("\n").collect{it}
	return lista
}