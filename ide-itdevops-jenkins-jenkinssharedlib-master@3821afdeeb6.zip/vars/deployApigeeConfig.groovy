def call(List sChangeList, Object env_config , String _Aplicacion, List sReleaseList ){
    echo "deployApigeeConfig:"
    def goal=""
    def config_option=""
    def deploymenttype=""
    def token1=""
    def install_goal=""
    def test_goal=""
    def config_option_compile="validate"
    def rollback=false
    def configchange=false
    def index=""
    def errorcode=""

    //USERNAME="VFGROUPSVC.apixuser2@internal.vodafone.com"
    //PASSWORD=$EDGE_PWD_apixuser2
    withCredentials([usernamePassword(credentialsId: "${env_config.credentialid}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
        sChangeList.unique().each(){
            def change=it
            if (sReleaseList.contains(change)){
                def saltar=false
                token1=it.tokenize("/")
                if (rollback==false){
                    if (token1[0] =='config'){
                        def curlbase=""
                        def curladd=""
                        def name=""
                        def action="UPDATE"
                        echo "token:[${token1[0]}][${token1[1]}] size:${token1.size()}"
                        if ("${token1[1]}" == "${env_config.config_dir}"){
                            echo "tratando:${it}"
                            configchange=true
                            switch(token1[2]){ 
                                case 'api':
                                    if (token1[3] == _Aplicacion){
                                        if (token1.size() != 6){
                                            saltar=true
                                            break
                                        }
                                        def token2=token1[5].tokenize(".")
                                        name=token2[0]
                                        curlbase="https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/apis/${_Aplicacion}"
                                        curladd=token1[4].toLowerCase()
                                        if(token1[4] == 'kvms'){
                                            curladd="keyvaluemaps"
                                            action="RECREATE"
                                        }

                                    }
                                    break
                                case 'org':
                                    if (token1.size() != 5){
                                        saltar=true
                                        break
                                    }  
                                    curlbase="https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}"
                                    def token2=token1[4].tokenize(".")
                                    name=token2[0]
                                    curladd=token1[3].toLowerCase()
                                    if(token1[3] == 'kvms'){
                                        curladd="keyvaluemaps"
                                        action="RECREATE"
                                    }
                                    break
                                case 'env':
                                    if (token1[3] == env_config.env){
                                        if (token1.size() != 6){
                                            saltar=true
                                            break
                                        }
                                        def token2=token1[5].tokenize(".")
                                        name=token2[0]
                                        curlbase="https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/environments/${env_config.env}"
                                        curladd=token1[4].toLowerCase()
                                        if(token1[4] == 'kvms'){
                                            curladd="keyvaluemaps"
                                            action="RECREATE"
                                        }

                                    }
                                    break
                                default:
                                    saltar=true
                                    break
                            }
                            if (curlbase != "" || saltar ==false){
                                SALIDA=sh returnStdout: true, script: """
                                    https_proxy="${env_config.proxyurl}"
                                    export https_proxy
                                    no_proxy="${env_config.noproxy}"
                                    export no_proxy
                                    curl --silent --write-out "HTTPSTATUS:%{http_code}" -X GET -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} --header "Content-Type: application/json ; charset=UTF-8" "${curlbase}/${curladd}/${name}" |tr -d '\n' 
                                """
                                index=SALIDA.indexOf('HTTPSTATUS:')+11
                                errorcode=SALIDA.substring(index,index+3)
                                echo "GET status:${errorcode}"
                                if (errorcode.substring(0,1) !="2"){
                                    echo "WARNING:${SALIDA}"
                                    echo "warning no existe: ${curlbase}/${curladd}/${name} ,lo recreamos"
                                    action ="RECREATE"
                                }
                                if (action =="RECREATE"){
                                    def SALIDAGET=""
                                    def SALIDADEL=""
                                    SALIDA=sh returnStdout: true, script: """
                                        https_proxy="${env_config.proxyurl}"
                                        export https_proxy
                                        no_proxy="${env_config.noproxy}"
                                        export no_proxy
                                        curl --silent --write-out "HTTPSTATUS:%{http_code}" -X DELETE -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} --header "Content-Type: application/json ; charset=UTF-8" "${curlbase}/${curladd}/${name}" |tr -d '\n' 
                                    """
                                    index=SALIDA.indexOf('HTTPSTATUS:')+11
                                    errorcode=SALIDA.substring(index,index+3)
                                    echo "DELETE status:${errorcode}"
                                    if (errorcode !="200" && errorcode !="404"&& errorcode !="204"){
                                        echo "WARNING:${SALIDA}"
                                        echo "warning borrando ${curlbase}/${curladd}/${name}"
                                    }
                                    def postok=false
                                    def contador=3
                                    while(postok==false && contador>0 && rollback==false){
                                        SALIDA=sh returnStdout: true, script: """
                                            https_proxy="${env_config.proxyurl}"
                                            export https_proxy
                                            no_proxy="${env_config.noproxy}"
                                            export no_proxy
                                            curl --silent --write-out "HTTPSTATUS:%{http_code}" -X POST -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure}  --header "Content-Type: application/json ; charset=UTF-8" -d"@${it}" "${curlbase}/${curladd}" |tr -d '\n' 
                                        """
                                        index=SALIDA.indexOf('HTTPSTATUS:')+11
                                        errorcode=SALIDA.substring(index,index+3)
                                        echo "POST status:${errorcode}"
                                        if (errorcode !="201" && errorcode !="200"){
                                            rollback=true
                                            echo "ERROR:${SALIDA}"
                                            echo "rollback por: ${it}"
                                        }else{
                                             SALIDA=sh returnStdout: true, script: """
                                                https_proxy="${env_config.proxyurl}"
                                                export https_proxy
                                                no_proxy="${env_config.noproxy}"
                                                export no_proxy
                                                curl --silent --write-out "HTTPSTATUS:%{http_code}" -X GET -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} --header "Content-Type: application/json ; charset=UTF-8" "${curlbase}/${curladd}/${name}" |tr -d '\n' 
                                            """
                                            index=SALIDA.indexOf('HTTPSTATUS:')+11
                                            errorcode=SALIDA.substring(index,index+3)
                                            echo "GET status:${errorcode}"
                                            if (errorcode.substring(0,1) !="2"){
                                                echo "WARNING:${SALIDA}"
                                            }else{
                                                postok=true
                                                echo "GET:${SALIDA}"
                                            }
                                        }
                                        contador--
                                    }
                                    if(postok==false){
                                        rollback=true
                                    }

                                }
                                if (action =="UPDATE"){
                                    SALIDA=sh returnStdout: true, script: """
                                        https_proxy="${env_config.proxyurl}"
                                        export https_proxy
                                        no_proxy="${env_config.noproxy}"
                                        export no_proxy
                                        curl --silent --write-out "HTTPSTATUS:%{http_code}" -X PUT -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} --header "Content-Type: application/json ; charset=UTF-8" -d"@${it}" "${curlbase}/${curladd}/${name}" |tr -d '\n'                                     """
                                    index=SALIDA.indexOf('HTTPSTATUS:')+11
                                    errorcode=SALIDA.substring(index,index+3)
                                    echo "PUT status:${errorcode}"
                                    if (errorcode !="201" && errorcode !="200"){
                                        rollback=true
                                        echo "ERROR:${SALIDA}"
                                        echo "rollback por: ${it}"
                                    }
                                }


                            }
                        }
                    }
                }
            }
        }
    }
    return rollback
}
