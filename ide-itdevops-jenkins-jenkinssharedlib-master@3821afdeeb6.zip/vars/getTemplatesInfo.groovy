def call(String sTemplate,String ENTORNO, String APLICACION, Object ms){
    echo "getTemplatesInfo"
    def SALIDA=""
    def sTemplateProp=""
    def sTemplatePropGen=""
    def sTemplatePropSpec=""
    def upgrade=ms.upgrade?ms.upgrade:""
    def DC_SUM=""
    SALIDA=sh returnStdout: true, script: """
        if [ -f ${sTemplate}${upgrade} ]
        then
            md5sum ${sTemplate}${upgrade} |cut -d " " -f1
        else
            echo 0
        fi
    """
    DC_SUM=SALIDA.trim()
    if (DC_SUM != "0" ){
        sTemplate="${sTemplate}${upgrade}"
    }else{
        SALIDA=sh returnStdout: true, script: """
            if [ -f ${sTemplate} ]
            then
                md5sum ${sTemplate} |cut -d " " -f1
            else
                echo 0
            fi
        """
    }
    DC_SUM=SALIDA.trim()
    echo "sTemplate:${sTemplate}"
    echo "DC_SUM:${DC_SUM}"
    SALIDA = sh returnStdout: true, script: """
        if [ -f TemplateCD-Parameters/${ENTORNO}/params.cfg ]
        then
                md5sum TemplateCD-Parameters/${ENTORNO}/params.cfg |cut -d " " -f1
        else
            echo 0
        fi
    """
    def DC_PropGen=SALIDA.trim()
    if (DC_PropGen != "0" ){
        sTemplatePropGen="TemplateCD-Parameters/${ENTORNO}/params.cfg"
        echo "sTemplatePropGen:${sTemplatePropGen}"
    }

    SALIDA = sh returnStdout: true, script: """
        if [ -f TemplateCD-Parameters/${ENTORNO}/params_${APLICACION}.cfg ]
        then
            md5sum TemplateCD-Parameters/${ENTORNO}/params_${APLICACION}.cfg |cut -d " " -f1
        else
            echo 0
        fi
    """
    def DC_PropSpec=SALIDA.trim()
    echo "DC_PropSpec=${DC_PropSpec}"
    if (DC_PropSpec != "0"){
        sTemplatePropSpec="TemplateCD-Parameters/${ENTORNO}/params_${APLICACION}.cfg"
        echo "sTemplatePropSpec:${sTemplatePropSpec}"
    }
    def sTemplatenName=ms.template.tokenize(".")[0]
    SALIDA = sh returnStdout: true, script: """
        if [ -f TemplateCD-Parameters/${ENTORNO}/params_${sTemplatenName}.cfg ]
        then
            md5sum TemplateCD-Parameters/${ENTORNO}/params_${sTemplatenName}.cfg |cut -d " " -f1
        else
            echo 0
        fi
    """
    def DC_PropTemp=SALIDA.trim()
    if (DC_PropTemp != "0" ){
        sTemplateProp="TemplateCD-Parameters/${ENTORNO}/params_${sTemplatenName}.cfg"
        echo "sTemplateProp:${sTemplateProp}"
    }
    def paramsstring1=""
    def paramsstring2=""
    def paramsstring3=""
    if ( "${sTemplatePropGen}" != "" ){
            paramsstring3="--param-file=${sTemplatePropGen}"
    }                                            
    if ( "${sTemplateProp}" != "" ){
            paramsstring2="--param-file=${sTemplateProp}"
    }
    if ( "${sTemplatePropSpec}" != "" ){
            paramsstring1="--param-file=${sTemplatePropSpec}"
    }
    return [DC_SUM,DC_PropGen,DC_PropSpec,DC_PropTemp,paramsstring1,paramsstring2,paramsstring3,sTemplate]
}