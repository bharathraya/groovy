// This function parses pckinfo to return params tuple 
def call(String _pckinfo)
{
    def mypckinfo=readJSON(text:_pckinfo)
    def mydeploy_env=""
    def mydomain=""
    def myalms_id=mypckinfo.Id.toString()
    def myserver=""
    def myPvcs=""
    def mydataModules=""
    def mydataAnexos =""
    def myHayDatos=""
    def myHayPVCS=""
    def myHayAnexos=""
    def myappli=""
    def myParams=""
    def myParamsTotal=""
    def myHayParametros=""
    
    
         wbpckinfo=get_workbench_package_info(myalms_id)
      
        myappli=wbpckinfo.Data.Model.Model.Base.Application.Name
    
        mydomain=wbpckinfo.Data.Model.Model.Base.Application.Description
     
        mydeploy_env=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
    
        myserver=wbpckinfo.Data.Model.Model.Base.DeploymentHost.Host.Host
     
        myPvcs=wbpckinfo.Data.Model.Model.Contents.PVCS
    
        mydataModulesMap=wbpckinfo.Data.Model.Model.Modules
        
        myParamsTotal=wbpckinfo.Data.Model.Model.Params
        print " myParamsTotal de datos ${myParamsTotal}"
        
        if(mydataModulesMap == "null" || ! mydataModulesMap){
            mydataModules=""    
        }else{
            mydataModules=wbpckinfo.Data.Model.Model.Modules.Modules    
        }
       
        mydataAnexos=wbpckinfo.Data.Model.Model.Annexes
        
   
        myHayDatos=mydataModules.size()
     
        
        if(myPvcs == "null"  || ! myPvcs ){
         
            myHayPVCS=0
            //print " myHayPVCS de datos ${myHayPVCS}"
        }
        else
        {
          
            myHayPVCS=myPvcs.size()
            //print " myHayPVCS de datos ${myHayPVCS}"
        }
        
        if(myParamsTotal == "null"  || ! myParamsTotal ){
            myHayParametros=0
            print " myHayParametros de datos ${myHayParametros}"
        }
        else
        {
            myHayParametros=myParamsTotal.size()
           // myParams=myParamsTotal[0]
            myParams=myParamsTotal
            print " myHayParametros de datos ${myHayParametros}"
        }
        
        myHayAnexos=mydataAnexos.size()
       
       
    // we return multiple values from this fucntion. later values should be 
    // taken like : (a,b,c,d)=fucntion(param)
    return [mydeploy_env,mydomain,myalms_id,myserver,myHayPVCS,mydataModules,myHayDatos,myHayAnexos,myParams,myHayParametros]
   
}
