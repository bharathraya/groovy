def call(String NombreCarpeta,String _domain){

hoy=new Date().format( 'yyyyMMdd' )
rutapaquete="/home/plataforma/plausr/data/paquetes/${hoy}/${NombreCarpeta}"

    if (_domain == "AMDOCS-CBS || _domain =="AMDOCS-FORM" )
    {
        
        exec="""
        . \$HOME/.profile >/dev/null 2>&1
        export rutapaquete="/home/plataforma/plausr/data/paquetes/${hoy}/${NombreCarpeta}"
    
        . paquete ${NombreCarpeta}
        if [ -d ${rutapaquete}/PROD_o_no ]
        then
            rmdir ${rutapaquete}/PROD_o_no
        fi
        mkdir -p ${rutapaquete}/PROD_o_no
        
        cp -r ${rutapaquete}/PROD/CRM/* ${rutapaquete}/PROD_o_no 2>/dev/null
        
        if [ ${_domain} == "AMDOCS-CBS"] 
        then
            cd ${rutapaquete}/PROD_o_no/CBS_CODE
            mkdir -p FORMS GLOBALS GLOBALS_APPSRV GLOBALS_CLEARSUPPORT
            mv *.cbs FORMS 2>/dev/null
        fi
        
        promoSVN_todo -a -d AMDOCS -e PROD -p ${NombreCarpeta} 2>/dev/null 
    
        """
        
        
    }//CBS o FORM
     if (_domain == "AMDOCS-MAESTRAS")
     {
        exec="""
        . \$HOME/.profile >/dev/null 2>&1
        export rutapaquete="/home/plataforma/plausr/data/paquetes/${hoy}/${NombreCarpeta}"
    
        . paquete ${NombreCarpeta}
        
        if [ -d ${rutapaquete}/PROD_o_no ]
        then
            rmdir ${rutapaquete}/PROD_o_no
        fi
        mkdir -p ${rutapaquete}/PROD_o_no/BBDD/SA
        
        
        cp -r ${rutapaquete}/PROD/CRM/BBDD ${rutapaquete}/PROD_o_no/BBDD/SA 2>/dev/null
        promoSVN_todo -a -d AMDOCS -e PROD -p ${NombreCarpeta} 2>/dev/null 
    
        """
        
     }//BBDD
     if (_domain == "AMDOCS-PROCESOS")
     {
        exec="""
        . \$HOME/.profile >/dev/null 2>&1
        export rutapaquete="/home/plataforma/plausr/data/paquetes/${hoy}/${NombreCarpeta}"
    
        . paquete ${NombreCarpeta}
        
        promoSVN_todo -a -d AMDOCS -e PROD -p ${NombreCarpeta} 2>/dev/null 
    
        """
        
     }//Procesos
     
     sh "ssh -q opetst75 '${exec}'"
}
