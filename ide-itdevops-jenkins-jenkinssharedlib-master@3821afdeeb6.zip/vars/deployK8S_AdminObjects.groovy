import vfes.git.VFESGitMergeInfo_aaresmi
import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import org.apache.commons.io.FilenameUtils

def call(Map config, String deployEnv,VFESGitMergeInfo_aaresmi mergeInfo,ArrayList k8sObjects,ArrayList items2Delete) {
    echo "=============================================="
    echo "UNDER CONSTRUCTION"
    echo "=============================================="

    def myEnvsConfig = readJSON file: "${WORKSPACE}/${config.releaseConfig}"
    def _envConfig = myEnvsConfig[deployEnv]
    def envPath = myEnvsConfig[deployEnv]['k8s_deploy']['environment_path']
    def groups_list=k8sAdminFunctions.getGroupList()

    /////////////REPOSITORY STRUCTURE CHECKS/////////////
    def actions_details=k8sAdminFunctions.checkInitialStructure(groups_list, config)
    def status=k8sAdminFunctions.checkDetails(actions_details, "STRUCTURE CHECKS")
    if (status) {
        echo "==> CHECKS Errors Founds. No continue with the next step!!!!"
        sh("exit 1")
    }

    /////////////LOAD COMMIT INFO/////////////
    k8sAdminFunctions.loadCommitInfo(groups_list, config, mergeInfo, items2Delete)

    //////////DECRYPT REQUIRED FILES//////////
    actions_details=[]
    actions_details=k8sAdminFunctions.decryptFiles(groups_list, config)
    status=k8sAdminFunctions.checkDetails(actions_details, "DECRYPT")
    if (status) {
        echo "==> DECRYPT Errors Founds. No continue with the next step!!!!"
        k8sAdminFunctions.cleanDecryptedFiles(groups_list)
        sh("exit 1")
    }

    ///////////GET K8S OBJECT INFO////////////
    echo ""
    echo "=============================================="
    echo "          CHECK K8S OBJECTS COHERENCE"
    echo "=============================================="
    echo "CHECK NAMING FILE VS CONTENT"
    echo "=============================================="
    k8sAdminFunctions.k8sCheckAndUpdateValidYaml(groups_list)

    ///////CHECK DUPLICATED K8S OBJECTS///////
    echo "=============================================="
    echo "CHECK DUPLICATED K8S OBJECTS"
    echo "=============================================="
    def duplicateK8sObjects = k8sAdminFunctions.k8sCheckDuplicatedObjects(groups_list,k8sObjects)
    echo "=========================================="
    echo "==> Number of duplicated k8s objects: ${duplicateK8sObjects.size}"
    echo "=========================================="
    duplicateK8sObjects.each{dep ->
        echo "File with k8s object duplicated: ${dep.original}"
    }
    if (duplicateK8sObjects.size() != 0) {
        echo "==> Duplicated k8s objects Founds. No continue with the next step!!!!"
        k8sAdminFunctions.cleanDecryptedFiles(groups_list)
        sh("exit 1")
    }

    //////////CHECK COMMIT VALIDITY///////////
    actions_details=[]
    actions_details=k8sAdminFunctions.commitCheckConstraints(groups_list, config)
    status=k8sAdminFunctions.checkDetails(actions_details, "CHECK COMMIT CONSTRAINTS")
    if (status) {
        echo "==> CHECK COMMIT CONSTRAINTS Errors Founds. No continue with the next step!!!!"
        k8sAdminFunctions.cleanDecryptedFiles(groups_list)
        sh("exit 1")
    }

    //////////////////DRY RUN/////////////////
    actions_details=[]
    actions_details=k8sAdminFunctions.k8sDryRun(groups_list)
    status=k8sAdminFunctions.checkDetails(actions_details, "DRY RUN")
    if (status) {
        echo "==> DRY RUN Errors Founds. No continue with the next step!!!!"
        k8sAdminFunctions.cleanDecryptedFiles(groups_list)
        sh("exit 1")
    }

    //////////////////RUN/////////////////
    echo ""
    echo "=========================================="
    echo "              RUN PHASE"
    echo "=========================================="
    groups_delete_actions = groups_list.findAll{ group -> group.commitInfo.findAll{files -> files.isDelete == true  && files.environment == envPath}}
    groups_rename_actions = groups_list.findAll{ group -> group.commitInfo.findAll{files -> files.isRename == true  && files.environment == envPath}}
    groups_modify_actions = groups_list.findAll{ group -> group.commitInfo.findAll{files -> files.isModify == true  && files.environment == envPath}}
    echo "Groups with k8s object(s) to delete:          ${groups_delete_actions.name}"
    echo "Groups with k8s object(s) to rename:          ${groups_rename_actions.name}"
    echo "Groups with k8s object(s) to add or Modify:   ${groups_modify_actions.name}"

    if (groups_delete_actions.size() != 0) {
        actions_details=[]
        actions_details=k8sAdminFunctions.k8sRunDelete(groups_delete_actions, envPath)
        status=k8sAdminFunctions.checkDetails(actions_details, "RUN DELETE")
        if (status) {
            echo "==> RUN DELETE Errors Founds. No continue with the next step!!!!"
            k8sAdminFunctions.cleanDecryptedFiles(groups_list)
            sh("exit 1")
        }
    }

    if (groups_rename_actions.size() != 0) {
        k8sAdminFunctions.k8sRunRename(groups_rename_actions)
    }

    if (groups_modify_actions.size() != 0) {
        actions_details=[]
        actions_details=k8sAdminFunctions.k8sRunApply(groups_modify_actions, envPath)
        status=k8sAdminFunctions.checkDetails(actions_details, "RUN APPLY")
        if (status) {
            echo "==> RUN APPLY Errors Founds. No continue with the next step!!!!"
            k8sAdminFunctions.cleanDecryptedFiles(groups_list)
            sh("exit 1")
        }
    }

    //////////////////RUN/////////////////
    k8sAdminFunctions.cleanDecryptedFiles(groups_list)
}