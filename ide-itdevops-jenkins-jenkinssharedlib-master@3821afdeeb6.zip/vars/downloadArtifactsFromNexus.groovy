import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def call(Map config,VFESALMSDeployment alms){
    for (i=0;i<config.artifactId.size();i++){
        sh """
            mkdir -p ${config.extractFolder}/${config.distFolder[i]}
            grpid=\$( echo ${config.groupId} | sed -e 's/\\./\\//g')
            wget -nv -O ${config.extractFolder}/${config.distFolder[i]}/${config.distFile[i]} \
             http://es004dxr:8080/nexus/repository/${config.nexusRepo}/\${grpid}/${config.artifactId[i]}/SNAPSHOT-${alms.deployEnv}/${config.artifactId[i]}-SNAPSHOT-${alms.deployEnv}.zip"""
    }
}