
def call()
{
    sh "rm -rf CDM project * .g* .b* .e* .m*"
}
return this;