import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def _ALMS_ID=""
def _server=""
def _funcion=""
def _funcionEnt=""
def funcConfig=""
def hoy=""
def _funcionAejecutar=""
def envsConfig
def _listapaquetes=""
def mybuilduser=""
def _TipoRege =""
def iConectividades=0
def iFalloEsquema =0
def _upgrade=""
def EntSimulacro=""

def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'CRQ_ID', defaultValue: '', description: 'CRQ ID') 
            string(name: 'Deliverys', defaultValue: '', description: 'Deliverys to check') 
            string(name: 'List_Packages', defaultValue: '', description: 'Listado de paquetes a tratar')
            string(name: 'Vista', defaultValue: '', description: 'Nombre de la vista de paquetes') 
            string(name: 'Orden', defaultValue: '', description: 'Fichero de Orden para BBDD') 
            choice(name: 'Opcion',  choices: pipelineParams.OptionChoices , description: 'Elige las opciones:1. Testeo 2. Integridad parche BBDD 3. Ejecuciones 4. Versionar') 
            choice(name: 'TypeToReg',  choices: pipelineParams.TypesChoices , description: 'Elige el tipo a regenerar') 
         }
         
         stages{     
         stage("Prepare"){
                agent {
                    label 'AMDOCS'
                        }
                steps{
                script {
                     //Saco el ejecutor
                     wrap([$class: 'BuildUser']) {
                         echo "Exec user: ${env.BUILD_USER_ID}"
                         mybuilduser=env.BUILD_USER_ID
                       }
                        //Contraseña
                         (_pass,mybuilduser)=findpassword(mybuilduser)
                        //Leo los parametros
                        _CRQ_ID=params.CRQ_ID.trim()  
                        _Orden=params.Orden.trim()
                        _listapaquetes=params.List_Packages.trim()
                        _opcion=params.Opcion
                        _NomVista=params.Vista.trim()
                        _TipoRege=params.TypeToReg
                        _delivery=params.Deliverys
                        _Ventana = false
                        _upgrade="N"
                        EntSimulacro="SIT2"
                        hoy=new Date().format( 'yyyyMMdd' )
                        
                        print "La fecha de hoy es ......${hoy}......"
                
                        //leemos el fichero de configuracion
                        pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                        //leemos el fichero de entornos
                        envsConfig=pipelineConfig.envConfig
                        enviroments=readJSON(file: "${envsConfig}")
                      
                       //Miramos si los parametros están bien
                        if (_CRQ_ID == "" && _NomVista == "" ){
                           error("Nombre del CRQ o Nombre de la vista son obligatorios.")
                        }
                        if (_CRQ_ID != "" && _NomVista != "" ){
                          // error("Solo se puede poner el nombre del CRQ ${_CRQ_ID} o de la vista ${_NomVista} .")
                        }
                        if (_opcion == "" || (_opcion != "1" && _opcion != "2" && _opcion != "3" && _opcion != "4" ) ){
                            error("Hay que indicar una opcion entre 1 y 4.")
                        }
                        
                        if(_CRQ_ID != "" && _listapaquetes == "" && _NomVista == "" ) { 
                	        error("Es necesaria una lista de paquetes para este CRQ ${_CRQ_ID}.")
                        }
                        if(_CRQ_ID != "" && (_listapaquetes != "" && _NomVista != "" ) ) { 
                	        error("Los paquetes vienen en la lista o en la vista.")
                        }
                            
                        if( "${_Orden}" == "" && _opcion == "2" && _TipoRege !="AMDOCS-ESQUEMA") { 
                	       error("Es obligatorio el fichero de Orden.")
                        }    
                        
                         //Configuramos el nombre del build y su descripcion
                        if (_CRQ_ID != "")
                        {
                            currentBuild.displayName = "CRQ: ${_CRQ_ID} Dia: ${hoy} Opcion ${_opcion}"
                            if (_listapaquetes != "" && _Orden != "" )
                            {
                                currentBuild.description = "CRQ: ${_CRQ_ID} Lista Paquetes: ${_listapaquetes} Fichero Orden ${_Orden} Regenerar: ${_TipoRege}"
                            }
                            else if (_listapaquetes != "" && _Orden == "" )
                            {
                                currentBuild.description = "CRQ: ${_CRQ_ID} Lista Paquetes: ${_listapaquetes} Regenerar: ${_TipoRege}"
                            }
                            else if (_listapaquetes == "" && _NomVista != "" )
                            {
                                currentBuild.description = "Vista: ${_NomVista} Regenerar: ${_TipoRege}"
                            }
                        }
                        else
                        {
                            currentBuild.displayName = "Vista: ${_NomVista} Dia: ${hoy} Opcion ${_opcion}"
                            if (_Orden == "")
                            {
                                currentBuild.description = "Vista: ${_NomVista} Regenerar: ${_TipoRege}"
                            }
                            else
                            {
                                 currentBuild.description = "Vista: ${_NomVista} Fichero Orden ${_Orden} Regenerar: ${_TipoRege} "
                            }
                        }
                        
                        if (_CRQ_ID == "" &&  _NomVista != "")
                        {  //No hay CRQ
                            _CRQ_ID="${_NomVista}"
                            _View = true
                        }
                        else if (_CRQ_ID != "" &&  _NomVista != "")
                        {  //Hay crq y lista de paquetes en la vista
                            _View = true
                        }
                        else if ( _NomVista == "")
                        {  //NO hay vista
                            _View = false
                        }
                            
                       
                        RutaTemp="/home/plataforma/plausr/tmp"
                        RutaPaquete="${RutaTemp}/${hoy}/${_CRQ_ID}"
                        sh "if [ -d ${RutaPaquete} ] ; then rm -rf ${RutaPaquete} ; fi ; mkdir -p ${RutaPaquete} "
                        if (_View == false)
                        { //No hay vista
                            checkout scm          
                            sh ("touch -f CDM/DOCUMENTATION/${_CRQ_ID}/hayFile.txt")
                            sh ( "if [ -f CDM/DOCUMENTATION/${_CRQ_ID}/${_listapaquetes} ] ; then echo 1 >> CDM/DOCUMENTATION/${_CRQ_ID}/hayFile.txt ; fi ")
                            prueba=readFile(file: "CDM/DOCUMENTATION/${_CRQ_ID}/hayFile.txt")
                            if ( prueba != "")
                            {
                                myfile=readFile(file: "CDM/DOCUMENTATION/${_CRQ_ID}/${_listapaquetes}")
                            }
                            else
                            {
                                 error(" No existe el listado de paquetes ${_listapaquetes} ")
                            }
                            fileInfo=myfile.split()
                            tamano= fileInfo.size()
                            print " HAY  ${tamano} PAQUETES "
                           
                            sh "cp CDM/DOCUMENTATION/${_CRQ_ID}/${_listapaquetes} ${RutaPaquete}"
                            sh "sort -u ${RutaPaquete}/${_listapaquetes} > ${RutaPaquete}/${_listapaquetes}_tmp"
                            sh "mv  ${RutaPaquete}/${_listapaquetes}_tmp  ${RutaPaquete}/${_listapaquetes}"
                            sh "cat ${RutaPaquete}/${_listapaquetes} | tr '\n' ' ' >> ${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt"
                        }
                         //05-10-20
                        //Reviso si los paquetes estan promocionados
                        if (_View == false)
                        {
                            _listapaquetes=readFile(file: "${RutaPaquete}/${_CRQ_ID}_ListaPaquetes.txt")
                        }
                        else
                        {
                            _listapaquetes=""
                        }
                        
                        print "Lanzo funcion de separar"
                        print "Vista ${_View}"
                        SeparaPaquete2 "${_CRQ_ID}" , _View , _Ventana, "${_NomVista}" , mybuilduser , _pass ,  "${_upgrade}"
                       
                       //Copio los fichero a opetst75
                        exec="""
                            . \$HOME/.profile >/dev/null 2>&1
                            . paquete  ${_CRQ_ID}
                        """
                        sh "ssh -q opetst75 '${exec}'"
                        sh "scp ${RutaPaquete}/* opetst75:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ_ID}"  
                       
                        //Reviso los que no estan promoted en entornos no productivos
                       //05/11/2020 meguiza2 muevo la funcion y solo q lance script
                        EditPackage(_CRQ_ID)
                        PaquetesSinPromote=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/PaquetesSin.txt")
                        //05-10-20
                        //28-01-21
                        print "Tipo elegido ${_TipoRege}"

                        if ("${_TipoRege}" != "ALL" && "${_TipoRege}" != "ALL except Bitbucket")
                        {   
                            print "Entro por aqui porque no es ALL" 
                            RevisarTipos (_TipoRege, RutaPaquete , _CRQ_ID, "NO")
                        }
                        //25-03-21
                        if (_delivery !="")
                        {
                            print "Deliverys a revisar ${_delivery}" 
                            RevisarDelivery (_delivery,_CRQ_ID)
                            DeliveryMal=readFile(file: "/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/Deliverys.txt") 
                        }
                        else
                        {
                            DeliveryMal=""
                        }
                        //25-03-21
                   }//script
                 }//step
            }//prepare
            
            stage("Opciones"){ //Testeo los paquetes
                agent {
                    node("AMDOCS")
                        }
                steps{
                    script {//Elige las opciones:1. Testeo 2. Integridad parche BBDD 3. Commit de los parches en SVN 4. Ejecuciones
                        //Si solo se elige opcion 1 solo testear
                        //Si se elige opcion 2 testear y extraer solo BBDD
                        //Si se elige opcion 3 testear y extraer
                        //Si se elige opcion 4 se testea y versiona-> Opcion de poner paquetes en estado correcto???
                         if ( _opcion == "1" ||  _opcion == "3"  ||  _opcion == "4" )
                         {
                            print "Testeamos los paquetes"
                            MODSIT2=0
                            iFalloEsquema=0
                            Tipos=readFile(file: "${RutaPaquete}/${_CRQ_ID}_tipos")
                            //print " fichero ${Tipos} "
                            TipoDespliegues=Tipos.split()
                            print " Aplicaciones a tratar ${TipoDespliegues}"
                            tamanoDesp= TipoDespliegues.size()
                            //print " Tamaño ${tamanoDesp}"
                            sh "touch -f ${RutaPaquete}/AplicacionesFalloTesteoPROD.txt"
                            sh "touch -f ${RutaPaquete}/AplicacionesFalloTesteoSIT2.txt"
                            sh "touch -f ${RutaPaquete}/Instrucciones.txt"
                            
                            for (pos = 0; pos < TipoDespliegues.size(); pos++) {
                                
                               _domain = TipoDespliegues[pos]
                               _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
                               //print "listado ${_listado}"

                                if (_domain != "APM")
                                {
                                    _Tipo=(_domain.split("-")[-1]) 
                                   // print "Tipo!! ${_Tipo}"
                                }
                                else
                                {
                                    _Tipo="APM"
                                }
                                 
                                _nombreCarpeta="${_CRQ_ID}_${_Tipo}"
                               //print "_nombreCarpeta ${_nombreCarpeta}"
                                 
                                 //Solo testeamos
                                 if ( _opcion == "1")
                                 {
                                    print "****************************************"
                                    print "TESTEANDO CONTRA PROD APLICACION: ${_domain} "
                                    print "****************************************"
                                    
                                    try{
                                            if (_TipoRege != "AMDOCS-ESQUEMA")
                                            {
                                                 txeker("-t",_domain,"PROD",_nombreCarpeta,_listado)
                                            }
                                            else
                                            {  //Si es de amdocs
                                                 sh "touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD"
                                                 _listadoBBDD = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD")
                                                 if (_listadoBBDD != "") 
                                                    {
                                                        print "Hay paquetes de BBDD"
                                                        _listado= "${_listadoBBDD} ${_listado}"
                                                        print "Listado actual: ${_listado}"
                                                    }
                                                //Extraemos el codigo para tener el e
                                                 txeker("","AMDOCS","PROD",_nombreCarpeta,_listado)
                                            }
                                        } catch(Exception e){
                                            if (_TipoRege == "AMDOCS-ESQUEMA")
                                            {
                                                iFalloEsquema=1
                                            }
                                            
                                        echo "Fallo Testeo contra PROD en ${_domain} error: ${e}" 
                                        sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteoPROD.txt  "
                                        //07-10-20 meguiza2
                                        //getInfoErrores  "${_nombreCarpeta}" , "PROD"
                                        //Lanzo el script para sacar los proveedores que tienen errores
                                        fichero_errores="${_nombreCarpeta}.PROD.errores_testeo"
                                        exec="""
                                        . \$HOME/.profile 
                                        if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
                                        then
                                             mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
                                        fi 

                                        echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
                                        echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
                                        echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
                                        getInfoErrores -p  ${_nombreCarpeta} -f ${fichero_errores} >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
                                        echo " "**************************************************************" >> /" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt
                                        """
    
                                        sh "ssh -q es036tvr '${exec}'"
                                        //07-10-20 meguiza2
                                        }
                                    
                                    print "****************************************"
                                    print "TESTEANDO CONTRA SIT2 APLICACION: ${_domain} "
                                    print "****************************************"
                                    
                                    try{
                                        if (_TipoRege == "AMDOCS-ESQUEMA")
                                            { //Hago con dominio AMDOCS por si hay de bbdd
                                                txeker("-t","AMDOCS","SIT2",_nombreCarpeta,_listado)
                                            }
                                            else
                                            {
                                                txeker("-t",_domain,"SIT2",_nombreCarpeta,_listado)
                                            }
                                        } catch(Exception e){
                                            
                                        echo "Fallo Testeo contra SIT2 en ${_domain} error: ${e}" 
                                        sh " echo ${_domain} >> ${RutaPaquete}/AplicacionesFalloTesteoSIT2.txt  "
                                        //07-10-20 meguiza2
                                        //getInfoErrores  "${_nombreCarpeta}" , "SIT2"
                                         //Lanzo el script para sacar los proveedores que tienen errores
                                        fichero_errores="${_nombreCarpeta}.SIT2.errores_testeo"
                                        exec="""
                                        . \$HOME/.profile 
                                        if [ ! -d /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} ] ; 
                                        then
                                             mkdir -p /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID} 
                                        fi 
                                        echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_SIT2.txt
                                        echo "***********************${_domain}******************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_SIT2.txt
                                        echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_SIT2.txt
                                        getInfoErrores -p  ${_nombreCarpeta} -f ${fichero_errores} >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_SIT2.txt
                                        echo "***************************************************************" >> /home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_SIT2.txt
                                        """
    
                                        sh "ssh -q es036tvr '${exec}'"
                                        //07-10-20 meguiza2
                                        }  
                                     if (_TipoRege =="AMDOCS-ESQUEMA" && iFalloEsquema ==0)    
                                     {
                                         //Lazamos la revisión de vistas
                                         check_vistas "${_nombreCarpeta}" , "NO"
                                         sh "touch -f ${RutaPaquete}/check_vistas.PROD.${_nombreCarpeta}.txt"
                                         _ListadoVistas = readFile(file: "${RutaPaquete}/check_vistas.PROD.${_nombreCarpeta}.txt")
                                         if (_ListadoVistas!="")
                                         {
                                             print "Resumen de vistas revisadas para generar orden_pre y orden_post"
                                             print "${_ListadoVistas}"
                                         }
                                     }
                                 }
                                 //Testeamos y extraemos el codigo ¿Poner opcion par hacerlo solo para TGA3 y para PROD?
                                 if ( _opcion == "3")
                                 {    
                                     //Maquina a replicar
                                      _serverSPPPR=enviroments["${_domain}"]["PROD"]["serverSPPR"][0][0]
                                      _serverSIT2=enviroments["${_domain}"]["SIT2"]["server"][0][0]

                                        print "****************************************"
                                        print "TRATANDO APLICACION: ${_domain}"
                                        print "****************************************"
                                    if (_domain =="AMDOCS-BBDD" )
                                    {  //REvisamos si hay vistas
                                         // 05-11-20 meguiza2
                                        sh ("touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-ESQUEMA")
                                        _listadoEsquema = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-ESQUEMA")
                                      
                                        if (_listadoEsquema != "") 
                                        {
                                         print "Hay paquetes de ESQUEMA"
                                        // print "paquetes esquema ${_listadoEsquema}"
                                         _listadoBBDD = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
                                         _listado= "${_listadoEsquema} ${_listadoBBDD}"
                                        }
                                        else
                                        {
                                            _listado = readFile(file: "${RutaPaquete}/${_CRQ_ID}_${_domain}")
                                        }
                                         txeker("","AMDOCS","PROD",_nombreCarpeta,_listado)
                                    }
                                    else if (_TipoRege == "AMDOCS-ESQUEMA")
                                    {
                                        sh "touch -f ${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD"
                                         _listadoBBDD = readFile(file: "${RutaPaquete}/${_CRQ_ID}_AMDOCS-BBDD")
                                         if (_listadoBBDD != "") 
                                           {
                                                 print "Hay paquetes de BBDD"
                                                 _listado= "${_listadoBBDD} ${_listado}"
                                                // print "Listado actual: ${_listado}"
                                           }
                                           txeker("","AMDOCS","PROD",_nombreCarpeta,_listado)
                                    }
                                    else 
                                    {
                                        txeker("",_domain,"PROD",_nombreCarpeta,_listado)
                                    }   
                                        if (_domain == "AMDOCS-UPSD" || _domain == "AMDOCS-CLARIFY")
                                        {
                                            replica_datos("",_domain,"PROD",_nombreCarpeta,_listado)
                                        }
                                        //Funcion a ejecutar
                                        _funcionEnt=pipelineConfig["${_domain}-PROD"]
                                        _funcionAejecutar=_funcionEnt[0]
                                        
                                        if (_domain != "AMDOCS-UPSD" && _domain != "AMDOCS-CLARIFY")
                                        { //NO HAY CONECTIVIDAD, hacer salto
                                            //Borramos el .paquete
                                            CleanPaquete "${_nombreCarpeta}","${_serverSPPPR}", "PROD"
                                             //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                                        //06-10-20 meguiza2
                                            CopiaFicheros "${_nombreCarpeta}","PROD","${_serverSPPPR}"
                                            GenerarWBFile "${_nombreCarpeta}","${_nombreCarpeta}","PROD","${_domain}" , false ,"${_upgrade}"
                                        //06-10-20 meguiza2
                                        }
                                        else
                                        { //Para estas maquinas hay que hacer salto
                                            //Primero nos movemos a opetst75
                                            CleanPaquete "${_nombreCarpeta}","opetst75", "PROD"
                                            //movemos el e y e_backout y el extras.txt
                                            MovePVCS "${_nombreCarpeta}","PROD","appcrm","opetst75"
                                        //06-10-20 meguiza2
                                            GenerarWBFile "${_nombreCarpeta}","${_nombreCarpeta}","PROD","${_domain}" , false, "${_upgrade}"
                                        //06-10-20 meguiza2
                                        }
                                        
                                        //Si NO son las de Subir a SVN sacamos tambien el codigon en SIT2
                                        if (_funcionAejecutar != "SubirSVN.groovy" && _domain != "AMDOCS-BBDD" && _domain != "AMDOCS-ESQUEMA")
                                        {
                                            txeker("",_domain,"SIT2",_nombreCarpeta,_listado)
                                            if (_domain == "AMDOCS-UPSD" || _domain == "AMDOCS-CLARIFY")
                                            {
                                                replica_datos("",_domain,"SIT2",_nombreCarpeta,_listado)
                                                MovePVCS "${_nombreCarpeta}","SIT2","appcrm","${_serverSIT2}"
                                            }
                                            
                                            //Borramos el .paquete
                                            CleanPaquete "${_nombreCarpeta}","${_serverSIT2}","SIT2"
                                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                                            //07-10-20 meguiza2
                                            //getFromPVCS "${_nombreCarpeta}","SIT2","${_serverSIT2}"
                                            CopiaFicheros "${_nombreCarpeta}","SIT2","${_serverSIT2}"
                                            //07-10-20 meguiza2
                                        }
                                        else
                                        {   //Hay que subir a SVN
                                            if (_domain == "AMDOCS-BBDD" || _TipoRege == "AMDOCS-VISTAS" )
                                            { //Lanzamos la funcion de Integridad
                                                  if (_Orden == "")
                                                    {
                                                        error ("No hay fichero de orden para la parte de BBDD")
                                                    }
                                                    else{
                                                       // print "Entro por aqui"
                                                       MODSIT2=IntegridadBBDD2( "${_nombreCarpeta}","${_Orden}","${_CRQ_ID}" , "S","${_upgrade}","${EntSimulacro}")
                                                      // print "........He devuelto ${MODSIT2} .............."
                                                    } //Integridad sube  a SVN
                                            }
                                            else if (_domain == "AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                            {
                                                //Copiamo a es036tvr orden_pre y orden_post y lanazmaos install
                                                print "Preparamos los ficheros para el install_schema"
                                                InstallschemaCreaParche "${_nombreCarpeta}","${_CRQ_ID}"
                                            }
                                            else if (_domain != "AMDOCS-ESQUEMA" &&  _domain != "AMDOCS-BBDD")
                                            {
                                                //Hay que subir a SVN ya tenemos el codigo en opetst75
                                                 //Cargamos la info del paquete en almsPackage para las ejecuciones de funciones
                                                almsPackage= new VFESALMSDataRetriever( _nombreCarpeta, _domain, "PROD", _serverSPPPR, "1", 0, 0, false, _serverSPPPR, _serverSPPPR, _listado )
                     
                                                //print "funciona a ejecutar ${_funcionAejecutar}"
                                                def ejecutar="CDM/Jenkins/WORKBENCH/common/${_funcionAejecutar}"
                                                def clase=load "${ejecutar}"
                                                clase.execute(almsPackage)
                                            }
                                        }//Funciones de SVN
                                        
                                        sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
                                        sh "echo '***************************************************************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                        sh "echo '***************************************************************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                        sh "echo '                                                               ' >>  ${RutaPaquete}/Instrucciones.txt"
                                        if (_domain == "AMDOCS-ESQUEMA" || _domain == "AMDOCS-PM" || _funcionAejecutar == "SubirSVN.groovy" || _domain == "AMDOCS-BBDD" )
                                        { 
                                            if (_domain =="AMDOCS-ESQUEMA" &&  _TipoRege == "AMDOCS-ESQUEMA")
                                            {
                                                sh "echo 'Para lanzar AMDOCS-PREVIEW en SIT2 hay que ejecutar desde opetst75:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '       install_schema_WB_simulacro -d AMDOCS-PREVIEW -e SIT2 -p ${_nombreCarpeta}' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'Para lanzar ${_domain} en SIT2 hay que ejecutar desde opetst75:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '       install_schema_WB_simulacro -d AMDOCS-ESQUEMA -e SIT2 -p ${_nombreCarpeta}' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'Para lanzar AMDOCS-PREVIEW en PROD hay que ejecutar desde crmsmart01:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '       install_schema_WB_prod -d AMDOCS-PREVIEW -e PROD -p ${_nombreCarpeta}' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'Para lanzar ${_domain} en PROD hay que ejecutar el parche de SVN mediante HUDSON:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'El parche se llama ${_nombreCarpeta}' >>  ${RutaPaquete}/Instrucciones.txt"
                                            }
                                            if (_domain == "AMDOCS-PM")
                                            {
                                                sh "echo 'Paquetes AMDOCS-PM: Estos paquetes se hacen de forma manual en PROD.' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'Revisar si viene custCrmConfig.conf, se hace de esta forma en PROD:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '       ssh weblogic@appcrm (PROD)' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '       cd /home/weblogic/AmdocsCRM7.5/ProcessManager/bin/ASC_conf_datadictionaryfrec' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '       cp custCrmConfig.conf custCrmConfig.conf_YYYYMMDD_CRQ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'Copiar el custCrmConfig.conf SIN tokens, que este en el ${_nombreCarpeta} en la maquina opetst75 en la ruta  de entorno.' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'SIT2 ejecutar:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '      ssh ${_serverSIT2} (SIT2) ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '      . paquete ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '      mig2 -D -d ${_domain} -e SIT2  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            }
                                            if (_funcionAejecutar == "SubirSVN.groovy" && _domain !="AMDOCS-MAESTRAS" )
                                            {
                                                sh "echo 'Para lanzar ${_domain} hay que ejecutar el parche de SVN mediante HUDSON:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'El parche se llama ${_nombreCarpeta}' >>  ${RutaPaquete}/Instrucciones.txt"
                                            }
                                            //05-11-20 meguiza2
                                            if (_domain == "AMDOCS-BBDD" || _domain =="AMDOCS-MAESTRAS" || _TipoRege == "AMDOCS-VISTAS")
                                            {
                                                sh "echo 'El parche ${_nombreCarpeta} estan en SVN pero se ejecutara desde unix' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo '      ssh appcrm01 (SIT2) (PROD)' >>  ${RutaPaquete}/Instrucciones.txt"
                                                sh "echo 'EJECUTAR en SIT2: ' >>  ${RutaPaquete}/Instrucciones.txt" 
                                                if (_domain == "AMDOCS-BBDD")
                                                {
                                                 sh "echo '      nohup carga_bbdd_PROD.sh -p ${_nombreCarpeta} -P<DDBB password> -S  &' >>  ${RutaPaquete}/Instrucciones.txt"  
                                                }
                                                else
                                                {
                                                    sh "echo '      nohup carga_bbdd_PROD.sh -p ${_nombreCarpeta} -P<DDBB password> -CS &' >>  ${RutaPaquete}/Instrucciones.txt"  
                                                }
                                                sh "echo 'EJECUTAR en PROD: ' >>  ${RutaPaquete}/Instrucciones.txt" 
                                                if (_domain == "AMDOCS-BBDD")
                                                {
                                                    sh "echo '      nohup carga_bbdd_PROD.sh -p ${_nombreCarpeta} -P<DDBB password>  &' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                                else
                                                {
                                                    sh "echo '      nohup carga_bbdd_PROD.sh -p ${_nombreCarpeta} -P<DDBB password> -C  &' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                            
                                                 if ("${MODSIT2}" == "1" )
                                                { 
                                                    sh "echo 'HAY MODULOS CON TOKEN SIT2 QUE HABRIA QUE LANZAR TRAS EL SIMULACRO' >>  ${RutaPaquete}/Instrucciones.txt"
                                                    sh "echo 'REVISADLO!!!' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                             } //BBDD y maestras
                                            //05-11-20 meguiza2
                                        }
                                        else
                                        {
                                            if (_domain == "APM")
                                            {
                                                sh "echo 'Para lanzar ImpresionContratos tienes que hacer lo siguiente:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            }else{
                                                 sh "echo 'Para lanzar ${_domain} tienes que hacer lo siguiente:' >>  ${RutaPaquete}/Instrucciones.txt"
                                            }
                                             
                                            if (_domain == "AMDOCS-AIF" || _domain == "AMDOCS-AIF_APM")
                                            {
                                                sh "echo '      ssh ${_serverSIT2} (SIT2) (PROD)' >>  ${RutaPaquete}/Instrucciones.txt"
                                            }else
                                            {
                                                if (_domain == "AMDOCS-UPSD" || _domain == "AMDOCS-CLARIFY")
                                                {
                                                    sh "echo '      ssh ${_serverSIT2} (SIT2) | ssh  appcrm (PROD)' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                                else{
                                                
                                                   sh "echo '      ssh ${_serverSIT2} (SIT2) | ssh  ${_serverSPPPR} (PROD)' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                            }  
                                            sh "echo '      . paquete ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                            if (_funcionAejecutar == "mig.groovy"  )
                                               {
                                                   if (_domain == "AMDOCS-CLIENT" || _domain == "AMDOCS-SERVER")
                                                   {
                                                       sh "echo '      migWB -cW -d CRMSmart -e SIT2|PROD -i ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                   }
                                                   else
                                                   {
                                                         sh "echo '      migWB -cW -d ${_domain} -e SIT2|PROD -i ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                   } 
                                                if (_domain == "AMDOCS-CLIENT")
                                                  {
                                                     sh "echo '*********************EN EL PASO A PROD LANZAR!!!********************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                     sh "echo '      copia_client_prod -d CRMSmart -e PROD -p ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                  }
                                                if(_domain == "AMDOCS-AIF" || _domain == "AMDOCS-AIF_APM")
                                                    {
                                                      sh "echo '**********EN EL PASO A PROD NOS PEDIRA LA PASS DE PPP!!!********************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                    }
                                                if(_domain == "AMDOCS-SPM")
                                                    {
                                                      sh "echo '**********************PARA PROD LANZAR en opetst75!!!******************:' >>  ${RutaPaquete}/Instrucciones.txt"
                                                      sh "echo '      cambia_zip -d ${_domain} -e PROD -p ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                    }                                                    
                                                 }
                                                 
                                                if (_funcionAejecutar == "compile_CBA.groovy")
                                                {
                                                    sh "echo '      compile_CBA -c -d ${_domain} -e SIT2|PROD -p ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                                if (_funcionAejecutar == "compile_Process.groovy")
                                                {
                                                     sh "echo '      compile_Process -c -d ${_domain} -e SIT2|PROD -p ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                                 //05-11-20 meguiza2
                                                 if (_funcionAejecutar == "j3nk1ns_crm.groovy")
                                                {
                                                     sh "echo '      j3nk1ns_crm -d ${_domain} -e SIT2|PROD -p ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                                  //05-11-20 meguiza2
                                                if (_funcionAejecutar == "mig_NoCompila.groovy" || _funcionAejecutar == "MoveToAppcrm.groovy" )
                                                {
                                                    if (_domain == "AMDOCS-UPSD")
                                                    {
                                                        sh "echo '      En el ENTORNO de SIT2  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                        sh "echo '      mig2 -c -D -d ${_domain} -e SIT2 -i ${_nombreCarpeta}  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                        sh "echo '      En el ENTORNO de PROD  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                        sh "echo '      mig2 -D -d ${_domain} -e PROD  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                    }
                                                    else{
                                                        sh "echo '      mig2 -D -d ${_domain} -e SIT2|PROD  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                    }
                                                }
                                                if (_funcionAejecutar == "bpm_launcher.groovy")
                                                {
                                                     sh "echo '      bpm_launcher -d ${_domain} -e SIT2|PROD  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                                 if (_funcionAejecutar == "mq_migrador.groovy")
                                                {
                                                     sh "echo ' En el entorno SIT2  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                     sh "echo '      mq_migrador.sh -d ${_domain} -e SIT2 -p ${_nombreCarpeta}  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                     sh "echo ' En el entorno PROD  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                     sh "echo '      mq_migrador.sh -d ${_domain} -e PROD -p ${_nombreCarpeta} -t SIT2  ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                       
                                                }
                                                 if (_funcionAejecutar == "IntegracionTOA.groovy")
                                                {
                                                     sh "echo '      IntegracionTOA.sh -e SIT2|PROD -p ${_nombreCarpeta} ' >>  ${RutaPaquete}/Instrucciones.txt"
                                                }
                                      }//No esquema
                                     
                                 }//OPCION 3
                                 
                                 //Testeamos de nuevo y versionamos en PROD
                                  if ( _opcion == "4")
                                   {
                                        CreaParcheOption4 "${_domain}","${_nombreCarpeta}","${_listado}","${_TipoRege}"
                                   }//OPCION 4
                                 
                            }//for
                            
                             if ( _opcion == "1")
                              { //Revisar si han fallado
                                  AplicacionesFalloTesteoPROD= readFile(file: "${RutaPaquete}/AplicacionesFalloTesteoPROD.txt")
                                  AplicacionesFalloTesteoSIT2= readFile(file: "${RutaPaquete}/AplicacionesFalloTesteoSIT2.txt")
                                 //07-10-20 meguiza2
                                  if (AplicacionesFalloTesteoSIT2 != "")
                                  {
                                      sh "scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_SIT2.txt  ${RutaPaquete}/InfoErroresTesteo_SIT2.txt"
                                      InfoErroresTesteoSIT2= readFile(file: "${RutaPaquete}/InfoErroresTesteo_SIT2.txt")
                                  }
                                  if (AplicacionesFalloTesteoPROD != "")
                                  {
                                      sh "scp es036tvr:/home/plataforma/plausr/tmp/${hoy}/${_CRQ_ID}/InfoErroresTesteo_PROD.txt  ${RutaPaquete}/InfoErroresTesteo_PROD.txt"
                                      InfoErroresTesteoPROD= readFile(file: "${RutaPaquete}/InfoErroresTesteo_PROD.txt")
                                  }
                                  //07-10-20 meguiza2
                                  if (AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 != "")
                                  {
                                    print "****************************************"
                                    print "         TESTEO INCORRECTO"
                                    print "****************************************"
                                    print "Se han analizado estas aplicaciones:"
                                    print "${Tipos}"
                                    print "Fallan en PROD estas aplicaciones:"
                                    print "${AplicacionesFalloTesteoPROD}"
                                    //07-10-20 meguiza2
                                    print "INFO de PROVEEDORES con ERRORES de TESTEO en PROD"
                                    print "${InfoErroresTesteoPROD}"
                                    //07-10-20 meguiza2
                                    print "Fallan en SIT2 estas aplicaciones:"
                                    print "${AplicacionesFalloTesteoSIT2}"
                                    //07-10-20 meguiza2
                                    print "INFO de PROVEEDORES con ERRORES de TESTEO en SIT2"
                                    print "${InfoErroresTesteoSIT2}"
                                    //07-10-20 meguiza2
                                    //error ("Fallos de testeo en PROD y SIT2")
                                  }
                                  if (AplicacionesFalloTesteoSIT2 != "" && AplicacionesFalloTesteoPROD == "")
                                  {
                                    print "****************************************"
                                    print "TESTEO INCORRECTO SIT2 pero correcto en PROD"
                                    print "****************************************"
                                    
                                    print "Se han analizado estas aplicaciones:"
                                    print "${Tipos}"
                                    print "Fallan en SIT2 estas aplicaciones:"
                                    print "${AplicacionesFalloTesteoSIT2}"
                                    //07-10-20 meguiza2
                                    print "INFO de PROVEEDORES con ERRORES de TESTEO en SIT2"
                                    print "${InfoErroresTesteoSIT2}"
                                    //07-10-20 meguiza2
                                    //error ("Fallos de testeo en SIT2")
                                   }
                                   if (AplicacionesFalloTesteoPROD != "" && AplicacionesFalloTesteoSIT2 == "")
                                  {
                                    print "********************************************"
                                    print "TESTEO INCORRECTO PROD pero correcto en SIT2"
                                    print "*********************************************"
                                    
                                    print "Se han analizado estas aplicaciones:"
                                    print "${Tipos}"
                                    print "Fallan en PROD estas aplicaciones:"
                                    print "${AplicacionesFalloTesteoPROD}"
                                    //07-10-20 meguiza2
                                    print "INFO de PROVEEDORES con ERRORES de TESTEO en PROD"
                                    print "${InfoErroresTesteoPROD}"
                                    //07-10-20 meguiza2
                                    //error ("Fallos de testeo en PROD")
                                   }
                                   if  (AplicacionesFalloTesteoPROD == "" && AplicacionesFalloTesteoSIT2 == "")
                                   {
                                    print "********************************************"
                                    print "         TESTEO CORRECTO"
                                    print "Se han analizado estas aplicaciones:"
                                    print "${Tipos}"
                                    print "********************************************"
                                   }
                                   //05-10-20
                                   if (PaquetesSinPromote != "" )
                                    {
                                     print "****************************************************************"
                                     print "Estos paquetes no están promocionados en el entorno preproductivo"
                                     print "${PaquetesSinPromote}"
                                     print "****************************************************************"
                                    // error ("Paquetes en estados incorrectos")
                                    }//05-10-20
                                    //25-03-21 meguiza2
                                    
                                    if (DeliveryMal != "")
                                    {   print "****************************************************************"
                                        print "Estos paquetes no son de las deliverys correctas"
                                        print "${DeliveryMal}"
                                        print "****************************************************************"
                                    }
                                   // print "la gestion de errores"
                                    GestionErroresCreaParche (_opcion, PaquetesSinPromote,  AplicacionesFalloTesteoPROD, AplicacionesFalloTesteoSIT2,  DeliveryMal, 0, _delivery)
                                    //25-03-21 meguiza2
                              }
                              if ( _opcion == "3")
                              {
                                  print "***************************************************************"
                                  print "Estas son las instrucciones"
                                  print "${RutaPaquete}/Instrucciones.txt"
                                  sh "cat ${RutaPaquete}/Instrucciones.txt"
                                  print "***************************************************************"
                                  
                                   //05-10-20
                                   if (PaquetesSinPromote != "" )
                                    {
                                     print "****************************************************************"
                                     print "Estos paquetes no están promocionados en el entorno preproductivo"
                                     print "${PaquetesSinPromote}"
                                     print "****************************************************************"
                                    }//05-10-20
                                
                                 iConectividades=ChequeoConectividades (RutaPaquete , _CRQ_ID, _upgrade)
                                // print "resultado conectividaddes ${iConectividades}"
                                //25-03-21 meguiza2
                                   if (DeliveryMal != "")
                                    {   print "****************************************************************"
                                        print "Estos paquetes no son de las deliverys correctas"
                                        print "${DeliveryMal}"
                                        print "****************************************************************"
                                    }
                                      // print "la gestion de errores"
                                       GestionErroresCreaParche (_opcion, PaquetesSinPromote,  "", "",  DeliveryMal, iConectividades, _delivery)
                                        //25-03-21 meguiza2
                              }
                         }//of de opciones 1, 3 o 4 
                         
                         if ( _opcion == "2") //Integridad de BBDD
                         {
                                 //Lllamamos a la funcion que revisa la integridad
                                 MODSIT2=CreaParcheOption2( "${RutaPaquete}","${_CRQ_ID}","${_TipoRege}", "${_Orden}", "${_upgrade}", "${EntSimulacro}")
                                //05-10-20
                                 if (PaquetesSinPromote != "" )
                                 {
                                    print "****************************************************************"
                                    print "Estos paquetes no están promocionados en el entorno preproductivo"
                                    print "${PaquetesSinPromote}"
                                    print "****************************************************************"
                                  }//05-10-20
                                  
                                  //25-03-21 meguiza2
                                   if (DeliveryMal != "")
                                    {   print "****************************************************************"
                                        print "Estos paquetes no son de las deliverys correctas"
                                        print "${DeliveryMal}"
                                        print "****************************************************************"
                                    }
                                    //  print "la gestion de errores"
                                    GestionErroresCreaParche (_opcion, PaquetesSinPromote,  "", "",  DeliveryMal, 0, _delivery)
                                    //25-03-21 meguiza2
                             
                         }//Integridad
                         
                         
                        if ( _opcion=="2" ) 
                        {
                            print "******************************"
                            print "Elegida opcion 2 de INTEGRIDAD"
                            print "Nombre del parche ${_CRQ_ID} "
                            print "******************************"
                        }  
                         if ( _opcion=="1" ) 
                        {
                            print "******************************"
                            print "Elegida opcion 1 de TESTEO"
                            print "Nombre del parche ${_CRQ_ID} "
                            print "******************************"
                        }  
                        if ( _opcion=="3" ) 
                        {
                            print "******************************"
                            print "Elegida opcion 3 de CREACION DE PARCHES"
                            print "Nombre del parche ${_CRQ_ID} "
                            print "******************************"
                        } 
                    }//scripts
                }//steps
            }//Testeo
            stage("EditPackage"){
                agent {
                    node("AMDOCS")
                        }
                steps{
                    script {//Si hay modulos de pvcs y estamos ejecutando de forma manual etiquetamos y no es PROD
                        
                        if(_opcion=="4"  ) {
                            EditPackageAmdocs(_CRQ_ID, mybuilduser, _View,_NomVista, _pass) 
                             
                        }//SI es opcion 4
                    }//scripts
                }//steps
          }//etiquetar
         }//stages
        }//pipeline
    }//map