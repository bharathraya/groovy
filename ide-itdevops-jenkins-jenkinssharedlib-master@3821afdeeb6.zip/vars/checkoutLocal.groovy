import vfes.git.VFESGitRepo
def call(VFESGitRepo repo, String remoteBranch, 
   String localBranch,String localPath,Boolean changeLog)
{
    // descargamos la parte de CDM donde tenemos los ficheros de configuracion (settings.xml, script build etc)
    checkout changelog: changeLog, poll: false, 
        scm: [$class: 'GitSCM', branches: [[name: "${remoteBranch}"]], 
        doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CheckoutOption'], 
        [$class: 'RelativeTargetDirectory', relativeTargetDir: "${localPath}"],
        [$class: 'LocalBranch', localBranch: "${localBranch}"], ], 
        submoduleCfg: [], 
        userRemoteConfigs: [[credentialsId: "${repo.checkoutCred}", 
        url: "${repo.protocol}${repo.server}/${repo.repoPath}/${repo.repoName}.git"]]]
}
return this;