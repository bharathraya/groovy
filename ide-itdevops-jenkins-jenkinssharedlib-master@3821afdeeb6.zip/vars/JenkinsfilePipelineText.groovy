#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def almsPackage=null
def callFromWB=true
def _DeployEnv=""
def _ALMS_ID=""
def _server=""
def _serverSVN=""
def _dataModules=null
def _HayModulosPVCS=""
def _HayModulosDatos=""
def _HayAnexos=""
def _Pvcs=""
def _Anexos=""
def _funcion=""
def _funcionEnt=""
def funcConfig=""
def hoy=""
def pckInfo=null
def _funcionAejecutar=""
def _serverAenviar=""
def _WB_ID=""
def envsConfig
def databaseConfig
def _listapaquetes=""
def _serverPROD=""


def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'WB_ID', defaultValue: '', description: 'WB ID or CRQ ID') 
            string(name: 'Application', defaultValue: '', description: 'Application to deploy') 
            string(name: 'Enviroment', defaultValue: '', description: 'Enviroment to deploy') 
            string(name: 'List_Packages', defaultValue: '', description: 'List of package for deploy') 
            string(name: 'PackageInfo', defaultValue: '', description: 'WB info') 
            string(name: 'Fichero', defaultValue: '', description: 'Fichero Texto') 
         }
         
         stages{     
         stage("Prepare"){
                agent {
                    label 'MEDIACION'
                        }
                steps{
                script {
               // funcConfig=readJSON(file: CDM/Jenkins/WORKBENCH/ORACLE/MEDIACION/funciones.json)
                hoy=new Date().format( 'yyyyMMdd' )
                print "La fecha de hoy es ......${hoy}......"
                
                //leemos el fichero de configuracion
                pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                //print "pipelineConfig ${pipelineConfig}"
                //leemos el fichero de entornos
                envsConfig=pipelineConfig.envConfig
                //print "envsConfig ${envsConfig}"
                //leemos el fichero de BBDD
                databaseConfig=pipelineConfig.databaseConfig
                     
                if (PackageInfo==""){
                    //LLamada manual
                        print "Llamada manual"
                        callFromWB=false  
                        _DeployEnv=params.Enviroment  
                        _ALMS_ID=params.WB_ID  
                        _Domain=params.Application
                        _listapaquetes=params.List_Packages
                        _Fichero = FileParameterValue('Fichero')
                       // build job: 'otherproject', parameters: [new FileParameterValue('file_param_name', param_file, 'original_file_name')], wait: false
                        if (_listapaquetes==""){
                            _listapaquetes=params.WB_ID  
                        }
                             
                        echo "lista paquetes ${_listapaquetes}"   
                        replica_datos("",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                        txeker("",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                        
                    }
                    else{
                        print "Llamada desde WB "
                        callFromWB=true  
                        pckInfo=readJSON(text: "${PackageInfo}")
                        _DeployEnv=pckInfo['EnvironmentName']
                        _Domain=pckInfo['ApplicationName']
                        _ALMS_ID=pckInfo.Id.toString()
                        _listapaquetes=_ALMS_ID  

                    }

                if(_Domain=="" || _DeployEnv=="" || _ALMS_ID=="") { 
        	        error("DomainNane [${_Domain}] DeployEnv [${_DeployEnv}] ALMS_ID [${_ALMS_ID}] son obligatorio.")
                    }
                
                
                //Configuramos el nombre del build y su descripcion
                currentBuild.displayName = "WB: ${_ALMS_ID} Env: ${_DeployEnv} Apli: ${_Domain}"
                currentBuild.description = "Lista: ${_listapaquetes} Entorno: ${_DeployEnv} Aplicación: ${_Domain}"
                
                //Actualizo info del paquete                       
                  print "llamo a getInfoPackage"
                  //(_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
                  (_ALMS_ID,_DeployEnv,_Domain,_server,_dataModules,_HayModulosDatos,_HayModulosPVCS,_HayAnexos,_serverSVN,_Parametros,_HayParametros)=getInfoPackage("${_ALMS_ID}","${_DeployEnv}","${_Domain}", "${PackageInfo}", "${envsConfig}")
                    
                  if(_HayModulosDatos == 0 && _HayModulosPVCS == 0 && _HayAnexos == 0) {
                    createReject (_ALMS_ID , "No hay modulos de datos ni de pvcs ni anexos en el paquete","5")
                    error("No hay modulos de datos ni de pvcs ni anexos añadidos al paquee")
                    }
                    
                   //Si el entorno es PROD leo el servidor SPPR  
                   enviroments=readJSON(file: "${envsConfig}")
                   
                   if ("${_DeployEnv}" == "PROD")
                   {
                    _serverPROD=_server
                    //Cambiamos al server de SPPR
                    _server=enviroments["${_Domain}"]["${_DeployEnv}"]["serverSPPR"][0][0]
                   }
                   else
                   {
                       _serverPROD=""
                   }

                  
                   }//script
                 }//step
            }//prepare
            
            stage("BorraDirectorio"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_server}"
                        }
                        //Borrado del directorio del alms si existe por haberse promocionado otra vez el mismo dia
                        //Borrado del directorio temporal de anexo si existe por haberse promocionado otra vez este dia
                         cleanDirPaquete "${_ALMS_ID}","${_serverAenviar}","${hoy}","${_DeployEnv}","${_Domain}"

                    }//scripts
                }//steps
            }//BorraDirectorio

            
            stage("checkoutModulosDatos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        
                        if(_HayModulosDatos!= 0){
                            print "DEBUG: hay modulos de datos ${_HayModulosDatos}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            if ("${env.NODE_NAME}" == "${_server}")
                            {
                                _serverAenviar =""
                                //  borramos el server para no hacer ssh
                            }
                            else{
                                _serverAenviar ="${_server}"
                            }
                            getFromModules "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}","${hoy}","${_Domain}"
                        }else{
                            print "DEBUG: No hay modulos de datos "
                        }

                    }//scripts
                }
            }//checkoutModulosDatos

             stage("checkoutAnexos"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if(_HayAnexos!= 0){
                            print "DEBUG: hay anexos"
                            if ("${env.NODE_NAME}" == "${_server}")
                            {
                                _serverAenviar =""
                                //  borramos el server para no hacer ssh
                            }
                            else{
                                _serverAenviar ="${_server}"
                            }
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            getAnnexes "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}","${hoy}"
                     }else{
                         print "DEBUG: No hay anexos "
                        }

                    }//scripts
                }//steps
            }//checkoutAnexos

            stage("checkoutPVCS"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                        if ("${env.NODE_NAME}" == "${_server}")
                        {
                            _serverAenviar =""
                            //  borramos el server para no hacer ssh
                        }
                        else{
                            _serverAenviar ="${_server}"
                        }
                        if(_HayModulosPVCS!= 0){
                            print "DEBUG: hay modulos de pvcs ${_HayModulosPVCS}"
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverAenviar}"
                        }else{
                            print "DEBUG: No hay modulos de pvcs "
                        }

                    }//scripts
                }//steps
            }//checkoutPVCS

            stage("Ejecutar"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {
                         if ("${env.NODE_NAME}" == "${_server}")
                            {
                             _serverAenviar =""
                                //  borramos el server para no hacer ssh
                             }
                             else{
                             _serverAenviar ="${_server}"
                             }
                        
                        //Cargamos la info del paquete en almsPackage para las ejecuciones de funciones
                        almsPackage= new VFESALMSDataRetriever( _ALMS_ID, _Domain, _DeployEnv,  _serverAenviar, _HayModulosPVCS, _dataModules, _HayAnexos, callFromWB, _serverSVN, _serverPROD , _listapaquetes,_Parametros,_HayParametros )
                        //mirar que exista domain_<entorno>
                        //    si existe la funcion es la de domain_entorno
                        // Si no existe domain_<entorno> em quedo con domain
                        
                        _funcionEnt=pipelineConfig["${_Domain}-${_DeployEnv}"]
                        //print "funciones por entorno ${_funcionEnt}"
                        if ("${_funcionEnt}" == "null"){
                            //print "es nulo"
                            _funcion=pipelineConfig["${_Domain}"]
                        }
                        else{
                            //print "NO es nulo"
                            _funcion=_funcionEnt
                        }
                        print "ejecutamos ${_funcion}"
                        for (pos = 0; pos < _funcion.size(); pos++) { 
                             _funcionAejecutar=_funcion[pos]
                            print "funciona a ejecutar ${_funcionAejecutar}"
                            def ejecutar="CDM/Jenkins/WORKBENCH/common/${_funcionAejecutar}"
                            def clase=load "${ejecutar}"
                            clase.execute(almsPackage)
                     }//Fin del for

                    }//scripts
                }//steps
            }//Ejecutar

        
          
          stage("Etiquetar"){
                agent {
                    node("${_Domain}-${_DeployEnv}")
                        }

                steps{
                    script {//Si hay modulos de pvcs y estamos ejecutando de forma manual etiquetamos y no es PROD
                        if(_HayModulosPVCS != 0 && callFromWB == false ) {
                            print "DEBUG: hay modulos pvcs y es manual "
                            //Descargar el codigo extraido por WB en es036tvr para el alms y entorno
                            txeker("-t -l",_Domain,_DeployEnv,_ALMS_ID,_listapaquetes)
                            
                        }else{
                            print "DEBUG: No hay modulos de pvcs o lo ha llamado WB"
                        }
                        if (_HayModulosPVCS != 0 && callFromWB == false && _serverSVN != null ){
                            //Si hay máquina de SVN ejecuto el promoSVN 
                                print "DEBUG: hay modulos pvcs y es manual y tiene SVN"
                                cleanDirPaquete "${_ALMS_ID}","${_serverSVN}","${hoy}","${_DeployEnv}","${_Domain}"
                                getFromPVCS "${_ALMS_ID}","${_DeployEnv}","${_serverSVN}"
                                promoSVN "${_ALMS_ID}","${_DeployEnv}","${_Domain}","${_serverSVN}"
                            }
                            else{
                                print "server SVN ${_serverSVN}"
                            }
                    }//scripts
                }//steps
          }//etiquetar
          
         }//stages
        }//pipeline
    }//map

