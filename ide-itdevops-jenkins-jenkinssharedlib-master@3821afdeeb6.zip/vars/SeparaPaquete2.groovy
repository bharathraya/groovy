def call(String _NombreCRQ, Boolean _View , Boolean _Ventana, String _NombreView, String mybuilduser, String _pass, String _upgrade){

def hoy=""
def RutaTemp=""
def RutaPaquete=""
def _listapaquetes=""
def exec=""
def _remoteServer=""


//print "Nombre del parche ${_NombreCRQ}"
//print "Nombre de la Vista ${_NombreView}"
//print "Valores booleanos : ${_View} : ${_Ventana}"
//print "Nombre del parche${_NombreCRQ}"

//print "Es upgrade : ${_upgrade}"

   hoy=new Date().format( 'yyyyMMdd' )
  if (_upgrade == "S")
  {
       _remoteServer="devopststtools01"   
  }
  else
  {
        _remoteServer="opetst75"
  }
  
  RutaTemp="/home/plataforma/plausr/tmp"
  RutaPaquete="${RutaTemp}/${hoy}/${_NombreCRQ}"
   
   if (_View == false)
   {
    _listapaquetes=readFile(file: "${RutaPaquete}/${_NombreCRQ}_ListaPaquetes.txt")
    if (_listapaquetes=="")
    {
        error ("There are no packages to process.")
     }
    //lanzo funcion para sacar los tipos de paquetes

    get_applicationCRQ(_NombreCRQ,'"' + _listapaquetes + '"',mybuilduser,_pass)
   }
   else
   {
       get_packagesbyview(_NombreView,mybuilduser,_pass)
       if ( _Ventana == true ) //Lo ha llamado el ventana_ono
       { //tengo que sacar el listado de paquetes
       
       
        
       // sh "ssh -q opetst75 '${exec}'"
       if (_remoteServer != "devopststtools01")
        {
            //Copio los fichero a opetst75
            exec="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete  ${_NombreCRQ} >/dev/null 2>&1
                scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_NombreView}/ListaPaquetes.txt .
                cut -d: -f3 ListaPaquetes.txt > ListaPaquetes.txt_tmp
                scp ListaPaquetes.txt_tmp 195.233.178.75:/home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ}/
                
            """
            sh "ssh -q ${_remoteServer} '${exec}'"
        }
        else
        {
            exec="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete  ${_NombreCRQ} >/dev/null 2>&1
                scp es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_NombreView}/ListaPaquetes.txt .
                cut -d: -f3 ListaPaquetes.txt > ListaPaquetes.txt_tmp
                cp ListaPaquetes.txt_tmp /home/plataforma/plausr/tmp/${hoy}/${_NombreCRQ}/
                
            """
            sh "${exec}"
        }
        
        sh "cat ${RutaPaquete}/ListaPaquetes.txt_tmp | tr '\n' ' ' >> ${RutaPaquete}/${_NombreCRQ}_ListaPaquetes.txt"

        _listapaquetes=readFile(file: "${RutaPaquete}/${_NombreCRQ}_ListaPaquetes.txt")       
           if (_listapaquetes=="")
           {
               error ("No hay paquetes a procesar.")
           }
       }
       else
       {  //No es de la ventana, copio el fichero al directorio del CRQ
           if ( "${_NombreCRQ}" != "${_NombreView}" )
           {
               exec="""
                . \$HOME/.profile >/dev/null 2>&1
                . paquete  ${_NombreCRQ} >/dev/null 2>&1
                cp  /home/plataforma/plausr/data/paquetes/${hoy}/${_NombreView}/ListaPaquetes.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_NombreCRQ}
                """
                sh "ssh -q es036tvr '${exec}'"
           }
       }
   }
  
   if (_Ventana == true )
   {
    print "Checking the dependencies"
    //Info de la dependencias
    applicationDependencyCRQ(_NombreCRQ,'"' + _listapaquetes + '"')
    //Una vez listado de dependencias las reviso
    check_dependencies_WB(_NombreCRQ, _listapaquetes , "es036tvr")
   }
   
   //Lanzo la funcion que separa por tipos
   exec="""
    . \$HOME/.profile >/dev/null 2>&1
    SeparaPaquetes.sh -p  ${_NombreCRQ} -W
    """

    if (_remoteServer != "devopststtools01")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }


}
