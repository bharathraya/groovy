import groovy.json.JsonSlurper 
/*@return
true -> If the unit test stage has to be exect
false -> If the unit test stage hasn,t to be exect
*/
def call(def bb_url, def bb_projectKey, def bb_repoSlug) {

  def url = "$bb_url/1.0/projects/$bb_projectKey/repos/$bb_repoSlug"
  Boolean result = true

  withCredentials([usernamePassword(credentialsId: 'syncReposBitBucket', passwordVariable: 'PASSWORD', usernameVariable: 'USERNAME')]) {
      def response = sh(returnStdout: true, script: "curl -k -u ${USERNAME}:${PASSWORD} -X GET ${url}")
      echo "$response"
      def description = new JsonSlurper().parseText(response).description

      result = !description?.contains("#DISABLETU")
  }

  if(result == true){
    echo "[INFO] Unit test enabled."
    return "true"
  }else{
    echo "[INFO] Unit test disabled by hashtag #DISABLEUT in repository description."
    return "false"
  }
  
}
