def call(String _Alms,String _Env,String _remoteServer){
    hoy=new Date().format( 'yyyyMMdd' )
 	node('es036tvr'){
 	    dir("/home/plataforma/plausr/data/paquetes/${hoy}/${_Alms}/${_Env}"){
 	        stash name: 'sources', includes: '**/*'
	   	}
	}
    node("${_remoteServer}"){
    	dir("c:\\home\\plataforma\\plausr\\data\\paquetes\\${hoy}\\${_Alms}\\${_Env}"){
    	    unstash name: 'sources'
    	}
  	}
 
}
