def call(String _domain,String _application,String _env,String _package,String _remoteServer,String _configOptions){
    opt_application=""
    if (_application!=""){
        opt_application="-a ${_application}"
    }

    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_package}
    mig -c  -d ${_domain} ${opt_application} -e ${_env} ${_package}
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
