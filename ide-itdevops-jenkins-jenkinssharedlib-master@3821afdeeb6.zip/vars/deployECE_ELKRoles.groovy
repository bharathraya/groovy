package vars

import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject
import vfes.git.VFESGitMergeInfo_aaresmi

// copyToRelease (Map config, VFESALMSDeployment alms)
// This method is only used to deploy in non-production environments
// it creates a .sh file for each server/release combination and
// executes it
// The .sh file is created through a template that is taken from config.releaseDeployTemplate
def call(Map config,VFESALMSDeployment alms, VFESGitMergeInfo_aaresmi mergeInfo)
{

  def myEnvsConfig=readJSON file:"${WORKSPACE}/${config.releaseConfig}"
  def _envConfig=myEnvsConfig[alms.deployEnv]

  echo "Deploying Roles ...."
  echo "_envConfig"+_envConfig['deploy_roles']
  _envConfig['deploy_roles'].each { item ->
    echo "Server Data:"
    echo "  deploy_server: " + item.server
    echo "  deploy_user: " + item.user
    echo "  application_release_path: " + item.application_release_path
    echo "  platafor_release_path: " + item.platafor_release_path + "/scripts"
    //echo "  variables repository: " + item.repo_vars
    echo "  deploy Script: " + config.deployScript
    echo "ElasticSearch Data:"
    echo "  elastic_sch: " + item.elastic_sch
    echo "  elastic_host: " + item.elastic_host
    echo "  elastic_port: " + item.elastic_port
    echo "  elastic_credential: " + item.elastic_credential
    //echo "  watcher_credential: " + item.watcher_credential
    def _elasticURL=""
    //withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    //{
    //  _elasticURL=item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
    //  echo "  ElasticSearch URL: " + _elasticURL
    //}

    //def _watcherCre=""
    //withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.watcher_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    //{
    //  _watcherCre="${USERNAME}" + ":" + "${PASSWORD}"
    //}

    items2Deploy=mergeInfo.FilesChangedDetailed.findAll{it[0] == "M" || it[0] == "A"}
    items2DeployRoles=items2Deploy.findAll{it[1] =~ 'Roles/'}

    roles2Deploy=[]
    items2DeployRoles.each { it -> roles2Deploy.add(it[1])}


    roles2DeployString=roles2Deploy.join(",")
    _paramRoles=""
    if (roles2DeployString != null && roles2DeployString != "")
    {
      _paramRoles="-R ${roles2DeployString}"
    }

    echo "AT: ${item.user}@${item.server}"
    echo "RUN: ${item.platafor_release_path}/scripts/${config.deployScript}"
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${item.elastic_credential}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
      _elasticURL=item.elastic_sch + "://" + "${USERNAME}" + ":" + "${PASSWORD}" + "@" + item.elastic_host + ":" + item.elastic_port
      echo "PARAMETERS: -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL}"
      sh "ssh -o StrictHostKeyChecking=no ${item.user}@${item.server} 'cd ${item.platafor_release_path}/scripts; ./${config.deployScript} -a ${config.applicationName} -r ${item.application_release_path} -e ${_elasticURL} ${_paramRoles}'"
    }
  }
}
