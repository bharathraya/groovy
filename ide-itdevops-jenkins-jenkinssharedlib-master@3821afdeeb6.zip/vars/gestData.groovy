def call(String _Alms,_dataModules,String _remoteServer,String _date,String _env){

    def data_module_name=""
    def es_tipo_bbdd=""
    def es_rollback=""
    def pos=0
    def ruta_temp=""
    def DDBBServerHost=""
    def DDBBName=""
    def DDBBServerName=""
    def DDBBUser=""
    def DDBBPassword=""
    
    //ruta_temp="/home/plataforma/plausr/data/temporal/${_date}/anexo/${_Alms}/${_env}" //Ruta donde estan los ficheros a ejecutar
    DDBBServerHost= _dataModules[0].HostDns //Servidor donde hay que ejecutar el gestdata_2.sh
    
    //print "DEBUG Servidor Unix ${DDBBServerHost} "
    //print "DEBUG ruta temporal ${ruta_temp} "
    
    if ( "${DDBBServerHost}" != "${_remoteServer}" ) //Si es diferente el servidor de BBDD que el de la aplicación
        {
             if ("${env.NODE_NAME}" == "${DDBBServerHost}") //Si el nodo es igual q el servidor de BBDD no hay que hacer ssh
             {
                DDBBServerHost =""
             //print "DEBUG server [${DDBBServerHost}] "
             }
             getFromAnexos "${_Alms}","${_env}","${DDBBServerHost}","${_date}" //Si el servidor es diferente el de bbdd q el de aplicacion
        }
    if ("${env.NODE_NAME}" == "${DDBBServerHost}") //El nodo es igual q el servidor de BBDD
         {
            DDBBServerHost =""
            //print "DEBUG server [${DDBBServerHost}] "
        }

    
    for (pos = 0; pos < _dataModules.size(); pos++) {
        data_module_name = _dataModules[pos].FileName; //Nombre del sql a ejecutar
        es_tipo_bbdd = _dataModules[pos].IsDataBase; //es BBDD
        es_rollback = _dataModules[pos].IsRollback; //es rollback
        DDBBName = _dataModules[pos].DdBbName; // NomberBBDD
        DDBBServerName = _dataModules[pos].ManagerName; //Nombre Servidor BBDD
        DDBBUser = _dataModules[pos].DdBbUser; //Usuario de ejecución
        DDBBPassword = _dataModules[pos].DdBbPassword; //Password del usuario
        
    
    //Ejecutar gestdata_2.sh
    //gestdata.sh [-h] <Fich.Data> <Gestor> <BBDD> <Usuario> [<Password>]
         
        if (es_tipo_bbdd == true){
            if (es_rollback == false){
                exec="""
                . \$HOME/.profile >/dev/null 2>&1
                export ruta_temp=\$DIR_BASE_TEMPORAL/${_date}/anexo/${_Alms}/${_env}/DataModules
                cd \${ruta_temp}
                gestdata_2.sh "${data_module_name}" "${DDBBServerName}" "${DDBBName}" "${DDBBUser}" "${DDBBPassword}" 2>/dev/null
                """
                if (DDBBServerHost!="")
                 {
                    sh "ssh -qn  ${DDBBServerHost} '${exec}'"
                 }
                 else
                {
                    sh "${exec}"
                }
            }
            else{
                print "Module [${data_module_name}] is rollback, omited"
            }
        }
        else{
            print "Module [${data_module_name}] is NOT type BBDD, omited"
        }
    }

}
