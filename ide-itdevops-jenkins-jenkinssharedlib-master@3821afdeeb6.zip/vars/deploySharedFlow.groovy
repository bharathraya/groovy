def call(String sharedFlow, Object env_config, String REVISION){
    echo "deploySharedFlow"
    def SALIDA=""
    
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
                                credentialsId: "${env_config.credentialid}", 
                                usernameVariable: 'USERNAME', 
                                passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            https_proxy="${env_config.proxyurl}"
            export https_proxy
            no_proxy="${env_config.noproxy}"
            export no_proxy
            curl -k -X POST --silent --write-out "HTTPSTATUS:%{http_code}" -u ${USERNAME}:${PASSWORD} ${env_config.apigee_secure} "https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/environments/${env_config.env}/sharedflows/${sharedFlow}/revisions/${REVISION}/deployments" 
        """
    }
	index=SALIDA.indexOf('HTTPSTATUS:')+11
	errorcode=SALIDA.substring(index,index+3)
	echo "POST status:${errorcode}"
	if (errorcode.substring(0,1) !="2"){
	    echo "WARNING:${SALIDA}"
	    error "Al desplegar: ${sharedFlow}"
	}
}