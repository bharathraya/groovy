import vfes.utils.VFESALMSDeployment
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.json.JsonBuilder

class DataModule implements Comparable<DataModule> {
    public String Order, ModuleFileName, RollBackModuleFileName, Action, Context, StatusGO, StatusRollBack;
    public DataModule(String Order, String ModuleFileName, String Action, String Context, String StatusGO, String StatusRollBack) {
        this.Order = Order;
        this.ModuleFileName = ModuleFileName;
        this.Action = Action;
        this.Context = Context;
        this.StatusGO = StatusGO;
        this.StatusRollBack = StatusRollBack;
    }
    public String toString() {
        return ("(" + Order + ", " + ModuleFileName + ", " + Action + ", " + Context + ", " + StatusGO + ", " + StatusRollBack + ")");
    }
    @Override
    public int compareTo(DataModule o) {
        // usually toString should not be used,
        // instead one of the attributes or more in a comparator chain
        return toString().compareTo(o.toString());
    }
}

class SortbyOrder implements Comparator<DataModule>
{
    // Used for sorting in ascending order of
    // roll number
    @NonCPS
    public int compare(DataModule o1, DataModule o2)
    {
         return o1.Order.compareTo(o2.Order);
    }
}


def deploy_env=""
def commit_id=""
def pck_id=""
def delivery=""
def project_id=""
def enterprise=""
def pipelineConfig=null
def annexes=""
def modules=""
def modulesHostIP=""
def modulesUserName=""
def modulesCompletePath=""
def uploadPath=""
def deployConfig=null
def dataModuleActionStatus=null
def hoy=null
def Order=""
def Module=""
def persistence_status_filename=""
def AR_annexes=null
def elasticSearch_server=""


def printDataModules(ArrayList<DataModule> DataModules){
    for( b in DataModules )
    {
        echo "Order: ${b.Order}, ModuleFileName: ${b.ModuleFileName}, Action: ${b.Action}, Context: ${b.Context}, StatusGO: ${b.StatusGO}, StatusRollBack: ${b.StatusRollBack}"
    }
}

def WriteDataModulesToFile(ArrayList<DataModule> DataModules, String File){
    String Line = ""
    for( b in DataModules )
    {
        Line = Line + "Order: ${b.Order}, ModuleFileName: ${b.ModuleFileName}, Action: ${b.Action}, Context: ${b.Context}, StatusGO: ${b.StatusGO}, StatusRollBack: ${b.StatusRollBack}" + "\r\n"
    }
    writeFile([file: File, text: Line])
}

def call(Map pipelineParams){
        pipeline{
            agent {label "SCHAMAN-Consolas"}
            parameters{
                string(name: 'DeployEnv', defaultValue: '', description: '')
                string(name: 'CommitID', defaultValue: '', description: '')
                string(name: 'Package_ID', defaultValue: '', description: '')
                string(name: 'Delivery', defaultValue: '', description: '')
                string(name: 'ProjectId', defaultValue: '', description: '')
                string(name: 'enterprise', defaultValue: 'BAU', description: '')
                string(name: 'PackageInfo', defaultValue: '', description: '')
            }
            stages{
                stage("Prepare"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            AR_annexes=[]
                            echo "============================================="
                            echo "============================================="
                            echo "===================PREPARE==================="
                            echo "============================================="
                            echo "============================================="
                            dataModuleActionStatus = new ArrayList<DataModule>();
                            if (params.PackageInfo=="")
                            {
                                // executed manually or from ALMS
                                echo "    Manual or Jenkins GUI execution!!!"
                                deploy_env=params.DeployEnv
                                pck_id=params.Package_ID
                                delivery=params.Delivery
                                project_id=params.ProjectId
                                enterprise=params.enterprise
                            }else{
                                echo "    Workbench execution!!!"
                                echo "PackageInfo: ${params.PackageInfo}"
                                (deploy_env,pck_id,delivery,project_id,enterprise,annexes,modules)= parsePckInfo_WithAnnexes_WithoutGit(PackageInfo)
                            }
                            hoy=new Date().format('yyyyMMdd')
                            pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)
                            deployConfig=readJSON(file: pipelineConfig.deployConfig)
                            commit_id=""
                            workbenchPackage= new VFESALMSDeployment(pck_id,pipelineConfig.applicationName,deploy_env,commit_id,delivery,project_id,enterprise)
                            currentBuild.displayName = workbenchPackage.jobDisplayName
                            currentBuild.description = workbenchPackage.jobDescription
                            if (deploy_env == 'PPRD')
                            {
                                elasticSearch_server=pipelineConfig.ElasticSearch_PPRD
                            } else if (deploy_env == 'PROD') {
                                elasticSearch_server=pipelineConfig.ElasticSearch_PROD
                            } else {
                                echo "ERROR. Environment ${deploy_env} is not valid"
                                sh "exit 1"
                            }


                            // TODO : when

                            echo "Deploy Info:"
                            echo "    DeployEnv:                ${deploy_env}"
                            echo "    PackageID:                ${pck_id}"
                            echo "    Delivery:                 ${delivery}"
                            echo "    Project:                  ${project_id}"
                            echo "    Enterprise:               ${enterprise}"
                            echo "    Modules:                  ${modules}"
                            echo "    Annexes:                  ${annexes}"
                            echo "    ElasticSearch Server:     ${elasticSearch_server}"

                        }
                    }
                }
                stage("Previous Checks"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "================PREVIOUS CHECKS=============="
                            echo "============================================="
                            echo "============================================="

                            echo "====> Check Annexes Info"
                            echo "======> Check Annexes Host Name/IP"
                            annexesHostIP = pipelineConfig.annexesServer
                            if (annexesHostIP == null || annexesHostIP == "")
                            {
                                echo "        ERROR. Annexes Host IP not configure at ${pipelineParams.pipelineConfigFile} File"
                                sh "exit 1"
                            }
                            echo "        Annexes Host Name/IP: ${annexesHostIP}"

                            echo "======> Check Annexes User Name"
                            annexesUserName = pipelineConfig.annexesUser
                            if (annexesUserName == null || annexesUserName == "")
                            {
                                echo "        ERROR. Annexes User Name not configure at ${pipelineParams.pipelineConfigFile} File"
                                sh "exit 1"
                            }
                            echo "        Annexes UserName: ${annexesUserName}"

                            echo "======> Check Annexes Base Path"
                            annexesBasePath = pipelineConfig.annexesBasePath
                            if (annexesBasePath == null || annexesBasePath == "")
                            {
                                echo "        ERROR. Annexes Base Path not configure at ${pipelineParams.pipelineConfigFile} File"
                                sh "exit 1"
                            }

                            annexesCompletePath="${annexesBasePath}" + '/' + "${hoy}" + '/' + "${pck_id}" + '/' + "${deploy_env}" + '/' + 'Annexes/'
                            echo "        Annexes Base Path: ${annexesBasePath}"
                            echo "        Annexes Complete Path: ${annexesCompletePath}"

                            echo "====> Check Annexes Data"
                            echo "======> Check Annexes Number"
                            numAnnexes=annexes.size()
                            if (numAnnexes != 1){
                                echo "        Num Annexes: ${numAnnexes}"
                                echo "        Num Annexes must to be = 1"
                                sh "exit 1"
                            }
                            echo "        Num Annexes: ${numAnnexes}"

                            echo "======> Check Annexes Files Existence"
                            AnnexesNameWithPath="${annexesCompletePath}" + "${annexes.Annexe.FileName}"
                            AnnexesNameWithPath = AnnexesNameWithPath.replace('[','').replace(']','')
                            exist = sh(script:"ssh ${annexesUserName}@${annexesHostIP} \"ls -1 ${AnnexesNameWithPath}\"",  returnStatus: true)
                            if (exist!=0){
                                echo "        ERROR. ${AnnexesNameWithPath} not found at server " + "${annexesHostIP}"
                                sh "exit 1"
                            }
                            echo "        ${AnnexesNameWithPath}: OK!"

                            echo "====> Check format of the file"
                            action_cfg = sh(script:"ssh ${annexesUserName}@${annexesHostIP} \"cat ${AnnexesNameWithPath}\"",  returnStatus: false, returnStdout: true)
                            action_cfg = action_cfg.trim()
                            for (line in action_cfg.split(System.getProperty("line.separator"))){

                                args=line.split('#')

                                if (args.size() != 3 )
                                {
                                    echo "        ERROR. It's needed 3 parameter. Line ${line} incorrect"
                                    sh "exit 1"
                                }
                                if (args[0].trim() == "" || args[1].trim() == "" || args[2].trim() == "")
                                {
                                    echo "        ERROR. It's needed 3 parameter. Line ${line} incorrect"
                                    sh "exit 1"
                                }
                            }
                            echo "        Format check: OK!"

                            echo "======> Find duplicate files inside of the Annexes Action Files"
                            duplicates = sh(script:"ssh ${annexesUserName}@${annexesHostIP} \"cat ${AnnexesNameWithPath} | cut -d '#' -f 1 | sort | uniq -d\"",  returnStatus: false, returnStdout: true)
                            if (duplicates.length()!=0){
                                echo "        ERROR. There are Duplicates files in the action file ${AnnexesNameWithPath}:"
                                echo "        ${duplicates}"
                                sh "exit 1"
                            }
                            echo "        Duplicates check: OK!"


                            echo "====> Load Annexes In-Memory HashMap List"
                            action_cfg = sh(script:"ssh ${annexesUserName}@${annexesHostIP} \"cat ${AnnexesNameWithPath}\"",  returnStatus: false, returnStdout: true)
                            action_cfg = action_cfg.trim()
                            for (line in action_cfg.split(System.getProperty("line.separator"))){

                                args=line.split('#')

                                file=args[0].trim()
                                action=args[1].trim()
                                context_path=args[2].trim()

                                _AR_annexes = [file: "${file}", action: "${action}", context: "${context_path}"]
                                AR_annexes+=_AR_annexes
                            }
                            echo "${AR_annexes}"

                            echo "====> Check Modules Host Info"
                            echo "======> Check Modules Host IP"
                            modulesHostIP = modules.HostDestiny.Host.IP
                            if (modulesHostIP == null || modulesHostIP == "")
                            {
                                echo "        ERROR. Modules Host IP cannot be null or \"\""
                                sh "exit 1"
                            }
                            echo "        Modules Host IP: ${modulesHostIP}"
                            echo "======> Check Modules Configured Path"
                            modulesConfiguredPath = modules.HostDestiny.ConfiguredPath
                            if (modulesConfiguredPath == null || modulesConfiguredPath == "")
                            {
                                echo "        ERROR. Modules Host Configure Path cannot be null or \"\""
                                sh "exit 1"
                            }
                            echo "        Modules Host Configure Path: ${modulesConfiguredPath}"
                            echo "======> Check Modules User Name"
                            modulesUserName = modules.HostDestiny.Host.UserName
                            if (modulesUserName == null || modulesUserName == "")
                            {
                                echo "        ERROR. Modules Host UserName cannot be null or \"\""
                                sh "exit 1"
                            }
                            echo "        Modules Host UserName: ${modulesUserName}"
                            modulesCompletePath="${modulesConfiguredPath}" + '/' + "${hoy}" + '/' + "${pck_id}" + '/' + "${deploy_env}" + '/' + 'DataModules/'
                            echo "        Modules Complete Path: ${modulesCompletePath}"

                            echo "====> Check Data Modules Data"
                            echo "======> Check Modules Number"
                            if (modules.Modules.size() <= 0){
                                echo "        Num modules: ${modules.Modules.size()}"
                                echo "        Num modules must to be > 0"
                                sh "exit 1"
                            }
                            echo "        Num modules: ${modules.Modules.size()}"
                            echo "          Num GO modules: ${modules.Modules.findAll{it.IsRollback == 0}.size()}"

                            echo "======> Check Modules Files Existence"
                            for( module in modules.Modules ){
                                ModuleNameWithPath="${modulesCompletePath}" + "${module.FileName}"
                                exist = sh(script:"ssh ${modulesUserName}@${modulesHostIP} \"ls -1 ${ModuleNameWithPath}\"",  returnStatus: true)
                                if (exist!=0){
                                    echo "        ERROR. ${ModuleNameWithPath} not found at server " + "${modulesHostIP}"
                                    sh "exit 1"
                                }
                                echo "        ${ModuleNameWithPath}: OK!"
                            }

                            echo "====> Check Module File Name in the Actions File"
                            if (modules.Modules.findAll{it.IsRollback == 0}.size() != 0)
                            {
                                goModules=modules.Modules.findAll{it.IsRollback == 0}
                                for( goModule in goModules )
                                {
                                    goModuleName = goModule.FileName
                                    echo "${goModuleName}"
                                    index=AR_annexes.findIndexOf{it.file == goModuleName }
                                    if (index != -1) {
                                        echo "        ${goModuleName}: OK!"
                                    } else {
                                        echo "        ERROR. File ${goModuleName} not found at file " + "${AnnexesNameWithPath}"
                                        sh "exit 1"
                                    }
                                }
                            }

                            echo "==> Load In-Memory HashMap List for status control <=="
                            //Load First the Go Modules
                            echo "====> Loading the GO modules and action and context information"
                            if (modules.Modules.findAll{it.IsRollback == 0}.size() != 0)
                            {
                                goModules=modules.Modules.findAll{it.IsRollback == 0}
                                for( goModule in goModules )
                                {
                                    goModuleName = goModule.FileName

                                    index=AR_annexes.findIndexOf{it.file == goModuleName }
                                    _dataModuleActionStatus = new DataModule("${goModule.Order}", "${goModule.FileName}", "${AR_annexes[index].action}", "${AR_annexes[index].context}", "", "")
                                    dataModuleActionStatus.add(_dataModuleActionStatus)
                                }
                            }

                            echo "====> Sorting modules for Order field"
                            Collections.sort(dataModuleActionStatus, new SortbyOrder())
                            echo "    In-Memory Hash Map List Sorted by Order Field: "
                            printDataModules(dataModuleActionStatus)

                        }
                    }
                }

                stage("Retrieve&Upload Modules"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "=======RETRIEVE&UPLOAD MODULES==============="
                            echo "============================================="
                            echo "============================================="

                            uploadPath="${pipelineConfig.temporalPath}/_tmp/${hoy}/${pck_id}/${deploy_env}"

                            def remote = [:]
                            remote.user = pipelineConfig.releaseUser
                            remote.allowAnyHosts = true
                            remote.retryCount = 3
                            remote.retryWaitSec = 2
                            remote.timeoutSec = 5

                            for( proxy in deployConfig[deploy_env].ProxyServer)
                            {
                                remote.host = proxy.ServerIP
                                remote.name = proxy.ServerName
                                echo "====> Upload Modules to ${proxy.ServerIP} with ip ${proxy.ServerName}"
                                withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
                                {
                                    remote.identityFile = keyfile
                                    sshCommand remote: remote, command:"rm -fr ${uploadPath}", failOnError:false
                                    sshCommand remote: remote, command:"mkdir -p ${uploadPath}"
                                    echo "    ======> Created tmp path at ${uploadPath}"

                                    sh("pwd")
                                    sh(script:"rm -fr .ElasticSearch", returnStatus:false)
                                    sh(script:"mkdir .ElasticSearch")
                                    echo "    ======> Created tmp path .ElasticSearch in the localserver to retrive the Data Modules"
                                    sh("scp -o ConnectTimeout=30 ${modulesUserName}@${modulesHostIP}:${modulesCompletePath}* .ElasticSearch/.")
                                    echo "    ======> Modules retrieved to localserver with success!!!"
                                    sh("scp -o ConnectTimeout=30 -i ${keyfile} .ElasticSearch/* ${pipelineConfig.releaseUser}@${proxy.ServerIP}:${uploadPath}/.")
                                    echo "    ======> Modules uploaded to proxyserver with success!!!"
                                }
                            }
                        }
                    }
                }

            stage("Deploy"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try{
                                echo "============================================="
                                echo "============================================="
                                echo "================DEPLOY MODULES==============="
                                echo "============================================="
                                echo "============================================="

                                def remote = [:]
                                remote.user = pipelineConfig.releaseUser
                                remote.allowAnyHosts = true
                                remote.retryCount = 3
                                remote.retryWaitSec = 2
                                remote.timeoutSec = 5

                                for( proxy in deployConfig[deploy_env].ProxyServer)
                                {
                                    remote.host = proxy.ServerIP
                                    remote.name = proxy.ServerName
                                    persistence_status_filename="persistence_status_" + "${proxy.ServerName}" + ".info"
                                    _path = sh(script:"pwd")
                                    echo "Writing Actions Persistence File at: ${_path}/${persistence_status_filename}"
                                    withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
                                    {
                                        remote.identityFile = keyfile

                                        for( DM in dataModuleActionStatus)
                                        {

                                            schamanElasticSearchCommand="${pipelineConfig.CurlproxyPath}" + "/" + "${pipelineConfig.CurlproxyScript} "
                                            DMActionFile="${uploadPath}/${DM.ModuleFileName} "
                                            DMAction="${DM.Action} "
                                            DMURL="https://${elasticSearch_server}/${DM.Context}"

                                            Command=schamanElasticSearchCommand + DMActionFile + DMAction + DMURL
                                            echo "====>      Data Module to execute:        ${DM.ModuleFileName}"
                                            echo "======>    Command to execute:            ${Command}"
                                            echo "======>    Executing ......."

                                            DM.StatusGO="KO"
                                            WriteDataModulesToFile(dataModuleActionStatus, persistence_status_filename)
                                            Order=DM.Order
                                            Module=DM.ModuleFileName
                                            //sshCommand remote: remote, command:"${Command}"
                                            sh(script:"ssh -i ${keyfile} ${pipelineConfig.releaseUser}@${proxy.ServerIP} ${Command}")
                                            DM.StatusGO="OK"
                                            WriteDataModulesToFile(dataModuleActionStatus, persistence_status_filename)
                                        }
                                    }
                                }
                            }
                            catch(err){
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
                                echo "!!!!!!!!ERROR IN THE DEPLOY PHASE!!!!!!!!"
                                echo "!!!!!!!!ERROR IN THE DEPLOY PHASE!!!!!!!!"
                                echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

                                echo "!!!!!!!!CAUTION. THERE IS NO AUTOMATED ROLLBACK FOR THIS KIND OF DEPLOY TYPE!!!!!!!!"
                                echo "!!!!!!!!CAUTION. IT IS NECESSARY TO NOTIFY TO THE DEVELOPMENT TEAM AND PROVIDE THEM THE FOLLOWING INFORMATION:!!!!!!!!"
                                echo "Error executing module: ${Module}"
                                echo "Error Details: ${err}"

                                echo "Status Actions After the Fail."
                                printDataModules(dataModuleActionStatus)

                                currentBuild.result = Result.FAILURE
                                error('!!!!!!!!AUTOMATED ROLLBACK ENDED SUCCESSFULLY!!!!!!!!')
                            }
                        }
                    }
                }


                stage('Clean Environment') {
                    agent {label "SCHAMAN-Consolas"}
                    steps {
                        script{
                            echo "============================================="
                            echo "============================================="
                            echo "==============CLEAN ENVIRONMENT=============="
                            echo "============================================="
                            echo "============================================="
                            def remote = [:]
                            remote.user = pipelineConfig.releaseUser
                            remote.allowAnyHosts = true
                            remote.retryCount = 3
                            remote.retryWaitSec = 2
                            remote.timeoutSec = 5

                            for( proxy in deployConfig[deploy_env].ProxyServer)
                            {
                                remote.host = proxy.ServerIP
                                remote.name = proxy.ServerName
                                echo "====> Cleaning Environment into ${proxy.ServerIP} with ip ${proxy.ServerName}"
                                withCredentials([sshUserPrivateKey(credentialsId: "${pipelineConfig.sshCredential}", keyFileVariable: 'keyfile')])
                                {
                                    remote.identityFile = keyfile
                                    sshCommand remote: remote, command:"rm -fr ${uploadPath}", failOnError:false
                                    echo "    ======> Removed tmp path at ${uploadPath}"
                                }
                            }

                        }
                    }
                }
            }
        }
    }
