import vfes.utils.nexusData

def call(nexusData nexus, String downloadUrl, String ENTORNO){
    echo "uploadNexusfile"
    def fichero=downloadUrl.substring(downloadUrl.lastIndexOf("/")+1,downloadUrl.size())
    def base=downloadUrl.substring(0,downloadUrl.lastIndexOf("/"))
    def _VERSION=base.substring(base.lastIndexOf("/")+1,base.size())
    def base1=base.substring(0,base.lastIndexOf("/"))
    def _ARTID=base1.substring(base1.lastIndexOf("/")+1,base1.size())
    def urlrepo="${nexus.nexusUrl}/repository/${nexus.nexusRepo}"
    def _GIDAUX=base1.substring(urlrepo.size()+1,base1.lastIndexOf("/"))
    def _GID=_GIDAUX.replaceAll("/",".")
    def _EXTENSION=fichero.substring(fichero.lastIndexOf(".")+1,fichero.size())
    if (ENTORNO=="prod"){
        ficherodest=fichero.substring(0,_ARTID.size()+1+_VERSION.size())+"-RELEASE"+fichero.substring(_ARTID.size()+1+_VERSION.size(),fichero.size())
        echo "ficherodest:${ficherodest}"
    }
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${nexus.nexusCredProd}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){
        def SALIDA=sh returnStdout: true, script: """
            curl --request DELETE --silent  --write-out "HTTPSTATUS:%{http_code}" -u ${USERNAME}:${PASSWORD} "${nexus.nexusUrl}/content/repositories/${nexus.nexusRepoProd}/${_GIDAUX}/${_ARTID}/${_VERSION}/${ficherodest}" 
            """
        def index=SALIDA.indexOf('HTTPSTATUS:')+11
        def errorcode=SALIDA.substring(index,index+3)
        echo "POST status:${errorcode}"
        if (errorcode.substring(0,1) !="2"){
            echo "WARNING:${SALIDA}"
        }
    }
}