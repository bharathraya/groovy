def call (String _Year,String _Week,String _Num){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python create_deliverys.py -s ${_Week} -m ${_Num} -y ${_Year}"
        }
    }
}

def call (String _Year,String _Week,String _Num, String User , String _pass ){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/New_Scripts"){
             wrap([$class: 'MaskPasswordsBuildWrapper', varPasswordPairs: [[var: 'PASSWORD_VAR', password: _pass ]]]) {
                 bat "python create_deliverys.py -u ${User} -c ${_pass} -s ${_Week} -m ${_Num} -y ${_Year}"
             }//wrap
        }
    }
}
