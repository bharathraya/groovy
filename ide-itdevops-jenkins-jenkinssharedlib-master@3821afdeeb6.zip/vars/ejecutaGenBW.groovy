import groovy.time.TimeCategory
 
def call(String _CRQ, String _domain, String _server , Boolean _Job){
    _env ="prd"
   hoy=new Date().format( 'yyyyMMdd' )
   tomorrow =  new Date().plus(1).format( 'yyyyMMdd' )
   print "tomorrow ${tomorrow}"
   print "el valor de _Job es ${_Job}"
   if (_domain != "BW_AMX")
   {
       if (_Job == true)
       { //No lo llama el job de jenkins si no el GenTibcoPipeline
        sh "if [ -d /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ} ] ; then rm -Rf  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ} ; fi ; mkdir -p /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ} "
        sh "scp ${_server}:/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/ListaEjecucion.txt /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}"
       }
   }
   else
   {
       _server="" //Vaciamos para que no haga ssh con BW_AMX
   }
   
   
    sh "touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
    sh "touch -f /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/PENTI.txt"
       
    Ejecucion=readFile(file: "/home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/ListaEjecucion.txt")
   
      sh "echo '****************************************************************************************** ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/PENTI.txt"
      sh "echo '*********BACKUPS TO EXECUTE*************************************************************** ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/PENTI.txt"        
      sh "echo '****************************************************************************************** ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/PENTI.txt"        
      sh "echo '****************************************************************************************** ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/PENTI.txt"        

   
    print "Agrupacion inicial ${Ejecucion} "
    EjecucionLineas = Ejecucion.split("\n")
    print "Ejecución lineas ${EjecucionLineas} "
    tam=EjecucionLineas.size()
    print "Tamaño ${tam}"
    
    for (pos = 0; pos < EjecucionLineas.size(); pos++) {
        Linea = EjecucionLineas[pos]
        LineSpli=Linea.split(":")
        print "LineSpli: ${LineSpli}"
        _PaqueteVir=LineSpli[0]
        print "Paquete Virtual  ${_PaqueteVir} "
        _lista=LineSpli[1] 
        print "Lista ${_lista} "
        
        print "lanzamos el txeker"
        txeker("",_domain,"prd",_PaqueteVir,_lista)
       
        print "Borramos el directorio ${_PaqueteVir}/${_env} "
        CleanPaquete "${_PaqueteVir}","${_server}", "${_env}"
        print "Copiamos el directorio ${_PaqueteVir}/${_env} "
        CopiaFicheros "${_PaqueteVir}","${_env}","${_server}"
        gen=0
        nivela=0
        copia=0
        
         sh "echo 'EXECUTE /home/tibprd/entorno/PENTIAdministrator/PENTIADMIN.sh -i ${_PaqueteVir} -e ${_env} -v -B ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/PENTI.txt"        
        
        
         sh "echo '****************************************************************************************** ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
         sh "echo '*********VIRTUAL PACKAGE:**${_PaqueteVir}************************************************** ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"        
         sh "echo '****************************************************************************************** ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"        
         
         try{
                if (_domain == "BW_AMX")
                {
                     sh ". \$HOME/.profile >/dev/null 2>&1 ; . paquete ${_PaqueteVir} ; gen_bw_release_linux_WB -NxB -d ${_domain}  -e ${_env} -p ${_PaqueteVir} ${_lista} "
                }
                else
                {
                        execGen="""
                        . \$HOME/.profile >/dev/null 2>&1
                        . paquete ${_PaqueteVir}
                        gen_bw_release_WB -NxB -d ${_domain}  -e ${_env} -p ${_PaqueteVir} ${_lista}
                        """
                      sh "ssh -q ${_server} '${execGen}'"
                }
                
         } catch(Exception e){
            gen=1
            if (_domain == "BW_AMX")
            {
                sh "echo '**** FAILED ->  gen_bw_release_linux_WB -NxB -d ${_domain}  -e ${_env} -p ${_PaqueteVir} ${_lista} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                sh "echo '**** IT IS NECESARY TO EXECUTE MANUALLY ->  gen_bw_release_linux_WB -NxB -d ${_domain}  -e ${_env} -p ${_PaqueteVir} ${_lista} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"                                              
            }
            else{
                sh "echo '**** FAILED ->  gen_bw_release_WB -NxB -d ${_domain}  -e ${_env} -p ${_PaqueteVir} ${_lista} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                sh "echo '**** IT IS NECESARY TO EXECUTE MANUALLY ->  gen_bw_release_WB -NxB -d ${_domain}  -e ${_env} -p ${_PaqueteVir} ${_lista} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"                                              
            }
            if (_domain == "BW_AMX")
            { //Si es AMX hay que ejcutar el nivela
                sh "echo '**** IT IS NECESARY TO EXECUTE MANUALLY ->  nivela_deploy.sh -d ${_domain}  -e ${_env} ${_PaqueteVir} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
            }
            sh "echo '**** IT IS NECESARY TO EXECUTE MANUALLY ->  copia_paquete_fecha -f ${tomorrow} -F ${hoy}   ${_PaqueteVir}  ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
         }
         
         if (gen==0 )
         {//No ha fallado el gen
            if (_domain == "BW_AMX")
            {
                sh "echo '**** EXECUTED ->  gen_bw_release_linux_WB -NxB -d ${_domain}  -e ${_env} -p ${_PaqueteVir} ${_lista} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
            }
            else
            {
                sh "echo '**** EXECUTED ->  gen_bw_release_WB -NxB -d ${_domain}  -e ${_env} -p ${_PaqueteVir} ${_lista} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
            }
             
             if (_domain == "BW_AMX")
             {
                 try{
                      sh ". \$HOME/.profile >/dev/null 2>&1 ; . paquete ${_PaqueteVir}  ; nivela_deploy.sh -d ${_domain}  -e ${_env} ${_PaqueteVir}  "
                 } catch(Exception e){
                     nivela = 1
                     sh "echo '**** FAILED ->  nivela_deploy.sh -d ${_domain}  -e ${_env} ${_PaqueteVir} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                     sh "echo '**** IT IS NECESARY TO EXECUTE MANUALLY ->  nivela_deploy.sh -d ${_domain}  -e ${_env} ${_PaqueteVir} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                     sh "echo '**** IT IS NECESARY TO EXECUTE MANUALLY ->  copia_paquete_fecha -f ${tomorrow} -F ${hoy}   ${_PaqueteVir}  ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                }        
            } //Si es AMX lanzo el nivela_deploy
          
            if (nivela==0)
            {//No ha fallado el nivela
                  if (_domain == "BW_AMX")
                    { //Solo se ha ejecutado si es AMX
                        sh "echo '**** EXECUTED ->  nivela_deploy.sh -d ${_domain}  -e ${_env} ${_PaqueteVir} ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                    }
                
                 try{
                        if (_domain == "BW_AMX")
                        {
                             sh ". \$HOME/.profile >/dev/null 2>&1 ; copia_paquete_fecha -f ${tomorrow} -F ${hoy}   ${_PaqueteVir}"
                        }
                        else
                        {
                               execCop="""
                               . \$HOME/.profile >/dev/null 2>&1
                               copia_paquete_fecha -f ${tomorrow} -F ${hoy}   ${_PaqueteVir}
                                """
                                sh "ssh -q ${_server} '${execCop}'"
                        }
                        
                 } catch(Exception e){
                     copia=1
                     sh "echo '**** FAILED ->  copia_paquete_fecha -f ${tomorrow} -F ${hoy}   ${_PaqueteVir}  ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                     sh "echo '**** IT IS NECESARY TO EXECUTE MANUALLY ->  copia_paquete_fecha -f ${tomorrow} -F ${hoy}   ${_PaqueteVir}  ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                 }
                if (copia==0)
                {
                     sh "echo '**** EXECUTED ->  copia_paquete_fecha -f ${tomorrow} -F ${hoy}   ${_PaqueteVir}  ' >>  /home/plataforma/plausr/data/paquetes/${hoy}/${_CRQ}/Instrucciones.txt"
                }
            }//No ha fallado el nivela o no se ha ejecutado por ser BW
            
            
         }//No ha fallado el gen
         
    }//for
}
