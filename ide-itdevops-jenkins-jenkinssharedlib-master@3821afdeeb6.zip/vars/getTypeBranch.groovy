def call(def branch) {
   return checkValidateBranch(branch)
}

def getNameBranch(def branch) {
   echo "Resolve branch ${branch}"
   return branch.substring(0, (branch.indexOf('/') > 0) ? branch.indexOf('/') : branch.length() )
}

def checkValidateBranch(def branch){
   MASTER = "master"
   FEATURE = "feature"
   DEVELOP = "develop"
   RELEASE = "release"
   VODAFONE = "vodafone"
   branch = getNameBranch(branch)
   if(branch) {
     if(branch == MASTER || branch == FEATURE || branch == DEVELOP || branch == RELEASE  || branch == VODAFONE){
      	return branch
     }
   } else {
      echo "Sorry, nogitflow..."
      printError("[ERROR]: The branch name don not exist")
   }
}

