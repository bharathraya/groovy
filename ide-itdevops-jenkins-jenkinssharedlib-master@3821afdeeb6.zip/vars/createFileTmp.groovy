def call(String _Alms,String _Env,String _remoteServer,String _date){

    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    touch /home/plataforma/tmp/${_Alms}
    export ruta_temp=\$DIR_BASE_PAQUETE/${_date}/${_Alms}/${_Env}/BBDD
    find \${ruta_temp} -type f | while read linea
    do
    echo \$linea >> /home/plataforma/tmp/${_Alms}
    done
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
