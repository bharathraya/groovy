def call(String _Alms,String _remoteServer,String _Today){
  
    exec="""
    . \$HOME/.profile_WB >/dev/null 2>&1
    . paquete >/dev/null 2>&1
    if [ -d ${_Alms} ]
    then
        echo 'Existe el directorio ${_Alms} lo borramos.'
        rm -Rf ${_Alms} 
    fi
    export ruta_temp=\$DIR_BASE_TEMPORAL/${_Today}/anexo/
    if [ -d \${ruta_temp}/${_Alms} ]
    then
        echo 'Existe el temporal ${_Alms} lo borramos.'
        cd \${ruta_temp}
        rm -Rf ${_Alms} 
    fi
    if [ -f /home/plataforma/tmp/${_Alms} ]
    then
        echo 'Existe el fichero temporal /home/plataforma/tmp/${_Alms} lo borramos.'
        rm -f /home/plataforma/tmp/${_Alms}
    fi
    if [ -f /home/plataforma/plausr/logs/modulos_datos_${_Alms}.txt ]
    then
        echo 'Existe el fichero temporal /home/plataforma/plausr/logs/modulos_datos_${_Alms}.txt lo borramos.'
        rm -f /home/plataforma/plausr/logs/modulos_datos_${_Alms}.txt
    fi
    
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}