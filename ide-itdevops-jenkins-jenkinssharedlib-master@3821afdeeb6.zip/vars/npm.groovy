def Dependencies(Map functionParams = [:]) {
    echo "Into Dependencies script"

    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return

    echo "Config github/bitbucket token for CSEOF ws2-reboot"
    withCredentials([string(credentialsId: 'github-token', variable: 'GITHUB_TOKEN')]) {
        sh "git config --global url.\"https://${GITHUB_TOKEN}:x-oauth-basic@github.com\".insteadOf \"https://github.com\""
    }
    withCredentials([string(credentialsId: 'bitbucket-read-token', variable: 'BITBUCKET_TOKEN')]) {
        sh "git config --global url.\"https://administrator:${BITBUCKET_TOKEN}@webpre-adm.es.sedc.internal.vodafone.com\".insteadOf \"https://webpre-adm.es.sedc.internal.vodafone.com\""
    }

    echo "Config logs directory: "
    sh "npm config get cache"

    sh """
        rm -fr node_modules dist/*
        ls -la
        node -v
        npm -v
        pwd    
        sed -i '/\"registry\"/d' package.json
        sed -i '/\"private\"/d' package.json
    """

    // PUESTO SIN CONSENSUAR
    // def branch = functionParams.getOrDefault("branch", "")
    // echo "Estamos en la rama ${branch}"
    // if (!(branch ==~ /master|release.*|develop-temp/)) {
    //     jsonfile = readJSON file: 'package.json'
    //     def newName = "${jsonfile.name}-${branch}".replaceAll(/feature\/|[0-9]{0,6}/, "").toLowerCase().replace("--", "-")
    //     echo "Nuevo nombre $newName"
    //     jsonfile['name'] = newName.toString()
    //     writeJSON file: 'package.json', json: jsonfile, pretty: 4
    // }
	cleanNpmrc()
    
    
    sh "cat package.json"
    sh "npm config set registry https://webpre-adm.es.sedc.internal.vodafone.com:44100/nexus/repository/group-npm-repository"
    if ( env.NPM_PREREQUISITES && env.NPM_PREREQUISITES != "null") {
        echo "Installing prerequisites"
        sh "npm --prefer-offline install -g ${env.NPM_PREREQUISITES}"
    }
        
    if (env?.BUILD_TOOL == 'lerna') {
        commitLernaChanges()

        def status = sh(returnStatus: true, script: "npm i lerna")
        archiveLogsNpm(status)

    } else {
        if (functionParams.buildfile == "true")
            sh "./build.sh"
        else {
            def status = sh(returnStatus: true, script: 'npm install')
            archiveLogsNpm(status)
        }
    }


}

def DependenciesDXL(Map functionParams = [:]) {
    echo "Into Dependencies script"

    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return
  
    if ( env.NPM_PREREQUISITES && env.NPM_PREREQUISITES != "null") {
        echo "Installing prerequisites"
        sh "npm --prefer-offline install -g ${env.NPM_PREREQUISITES}"
    }else{
        echo "No hay prerequisites"
		sh "npm --prefer-offline install"
    }


}


def commitLernaChanges() {
    sh '''
        git config --global user.email "groupDevOps@example.com"
        git config --global user.name "GrupoDevOps"
        git commit -am "borrado .npmrc"
    '''


}


def BuildDXL(Map functionParams = [:]) {
    echo "Into Build script"

    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return
    sh "ls -la"
    if (env?.ARGS_CMD_BUILD_NPM != "") {
      builsArgs=ARGS_CMD_BUILD_NPM
    }
    proxy=""
  	noproxy=""
  	if (env?.ARGS_CMD_BUILD_NOPROXY != "") {
      noproxy=ARGS_CMD_BUILD_NOPROXY
    }  
    def status = sh(returnStatus: true, script: """
          	export https_proxy
          	no_proxy=${noproxy}
            npm --prefer-offline install
          	ng build ${builsArgs}
            chown -R 1000:1000 dist
        """)
    archiveLogsNpm(status)

  	sh "pwd; ls -la package.json; ls -la dist"

    if (!fileExists('dist/package.json')) {
        jsonfile = readJSON file: 'package.json'
      
      	echo "readJSON"
        jsonfile.remove("scripts")
        jsonfile.remove("devDependencies")
        writeJSON file: 'dist/package.json', json: jsonfile, pretty: 4
      	echo "writeJSON"
    }

}


def BuildWebPortal(Map env_config,Map functionParams = [:] ) {
    echo "Into Build script"

    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return
    sh "ls -la"
    if (env?.ARGS_CMD_BUILD_NPM != "") {
      builsArgs=ARGS_CMD_BUILD_NPM
    }
    proxy=""
  	noproxy=""
  	if (env?.ARGS_CMD_BUILD_NOPROXY != "") {
      noproxy=ARGS_CMD_BUILD_NOPROXY
    }
	withCredentials([string(credentialsId: 'token-npm-github', variable: 'TOKEN')]) {
      def status = sh(returnStatus: true, script: """
              no_proxy=${noproxy}
              export https_proxy
              #yarn config set http-proxy http://10.13.51.133:8080
              #yarn config set https-proxy http://10.13.51.133:8080
              #yarn config set //npm.pkg.github.com/:_authToken ${TOKEN}
              #yarn config set @vodafone-es:registry https://npm.pkg.github.com/
              #yarn config set registry http://registry.npmjs.org

			  npm config set http-proxy http://10.13.51.133:8080
              npm config set https-proxy http://10.13.51.133:8080
              #npm config set //npm.pkg.github.com/:_authToken ${TOKEN}
              #npm config set @vodafone-es:registry https://npm.pkg.github.com/
              #npm config set registry http://registry.npmjs.org
              #echo "master"
              npm uninstall --save-dev webpack 
              
              rm -f package-lock.json
              rm -Rf node_modules
              #yarn install
              #yarn remove --save-dev webpack 
              
              npm --prefer-offline install


              #yarn remove @types/lodash
              npm uninstall @types/lodash 

              sed -i -e "s/function syntaxErrorToDiagnostics(error) {/function syntaxErrorToDiagnostics(error) { console.log(error)/g" ./node_modules/@angular/compiler-cli/src/transformers/program.js

              node --max_old_space_size=20048 ./node_modules/@angular/cli/bin/ng build --configuration=${env_config.entorno}

          """)

    	archiveLogsNpm(status)
	}
  	sh """
    	pwd;
        chown -R 1000:1000 dist
        ls -la package.json; 
        ls -la dist
    """

    if (!fileExists('dist/package.json')) {
        jsonfile = readJSON file: 'package.json'
      
      	echo "readJSON"
        jsonfile.remove("scripts")
        jsonfile.remove("devDependencies")
        writeJSON file: 'dist/package.json', json: jsonfile, pretty: 4
      	echo "writeJSON"
    }

}

def BuildWebPortalYarn(Map env_config,Map functionParams = [:] ) {
    echo "Into Build script"

    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return
    sh "ls -la"
    if (env?.ARGS_CMD_BUILD_NPM != "") {
      builsArgs=ARGS_CMD_BUILD_NPM
    }
    proxy=""
  	noproxy=""
  	if (env?.ARGS_CMD_BUILD_NOPROXY != "") {
      noproxy=ARGS_CMD_BUILD_NOPROXY
    }
	withCredentials([string(credentialsId: 'token-npm-github', variable: 'TOKEN')]) {
      def status = sh(returnStatus: true, script: """
              no_proxy=${noproxy}
              export https_proxy
              yarn config set http-proxy http://10.13.51.133:8080
              yarn config set https-proxy http://10.13.51.133:8080
              yarn config set //npm.pkg.github.com/:_authToken ${TOKEN}
              yarn config set @vodafone-es:registry https://npm.pkg.github.com/
              yarn config set registry http://registry.npmjs.org

              echo "master"
              rm -f package-lock.json
              rm -Rf node_modules
              yarn install
              
              yarn remove --save-dev webpack 
              
              rm -f package-lock.json
              rm -Rf node_modules
              #yarn install
              

              yarn remove @types/lodash

              sed -i -e "s/function syntaxErrorToDiagnostics(error) {/function syntaxErrorToDiagnostics(error) { console.log(error)/g" ./node_modules/@angular/compiler-cli/src/transformers/program.js

              node --max_old_space_size=20048 ./node_modules/@angular/cli/bin/ng build --configuration=${env_config.entorno}

          """)

    	archiveLogsNpm(status)
	}
  	sh """
    	pwd;
        chown -R 1000:1000 dist
        ls -la package.json; 
        ls -la dist
    """

    if (!fileExists('dist/package.json')) {
        jsonfile = readJSON file: 'package.json'
      
      	echo "readJSON"
        jsonfile.remove("scripts")
        jsonfile.remove("devDependencies")
        writeJSON file: 'dist/package.json', json: jsonfile, pretty: 4
      	echo "writeJSON"
    }

}

def BuildWebPortalPnpm(Map env_config,Map functionParams = [:] ) {
    echo "Into Build script"

    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return
    sh "ls -la"
    if (env?.ARGS_CMD_BUILD_NPM != "") {
      builsArgs=ARGS_CMD_BUILD_NPM
    }
    proxy=""
  	noproxy=""
  	if (env?.ARGS_CMD_BUILD_NOPROXY != "") {
      noproxy=ARGS_CMD_BUILD_NOPROXY
    }
	withCredentials([string(credentialsId: 'token-npm-github', variable: 'TOKEN')]) {
      def status = sh(returnStatus: true, script: """
              no_proxy=${noproxy}
              export https_proxy

			  pnpm config set http-proxy http://10.13.51.133:8080
              pnpm config set https-proxy http://10.13.51.133:8080
              pnpm config set //npm.pkg.github.com/:_authToken ${TOKEN}
              pnpm config set @vodafone-es:registry https://npm.pkg.github.com/
              npm config set registry http://registry.npmjs.org
              echo "master"
              pnpm --prefer-offline install
              
              pnpm uninstall --save-dev webpack ||true
              
              rm -f package-lock.json
              rm -Rf node_modules
              
              pnpm --prefer-offline install

              pnpm uninstall @types/lodash ||true

              sed -i -e "s/function syntaxErrorToDiagnostics(error) {/function syntaxErrorToDiagnostics(error) { console.log(error)/g" ./node_modules/@angular/compiler-cli/src/transformers/program.js

              node --max_old_space_size=20048 ./node_modules/@angular/cli/bin/ng build --configuration=${env_config.entorno}

          """)

    	archiveLogsNpm(status)
	}
  	sh """
    	pwd;
        chown -R 1000:1000 dist
        ls -la package.json; 
        ls -la dist
    """

    if (!fileExists('dist/package.json')) {
        jsonfile = readJSON file: 'package.json'
      
      	echo "readJSON"
        jsonfile.remove("scripts")
        jsonfile.remove("devDependencies")
        writeJSON file: 'dist/package.json', json: jsonfile, pretty: 4
      	echo "writeJSON"
    }

}

def Build(Map functionParams = [:]) {
    echo "Into Build script"

    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return
    if (env.JOB_NAME.contains("IDG-MVOW-ANGULAR-Voldemort")){
        voldemort.build()
        return
    }

    sh "ls -la"

    if (env?.BUILD_TOOL == 'lerna') { 
        def status = sh(returnStatus: true, script: """
            NODE_ENV=production npm run init -- --hoist
            npm run build:angular
        """)
        archiveLogsNpm(status)
    } else {
        def status = sh(returnStatus: true, script: 'npm run build')
        archiveLogsNpm(status)
    }

    if (!fileExists('dist/package.json')) {
        jsonfile = readJSON file: 'package.json'
        jsonfile.remove("scripts")
        jsonfile.remove("devDependencies")
        writeJSON file: 'dist/package.json', json: jsonfile, pretty: 4
    }

}

def Test() {
  	if (fileExists('jest.config.js')) { 
        sh 'npm run test'
        publishCoverageReports(GIT_COMMIT[0..10])
    } else {
        error("No hay tests de jest disponibles")
    }
}

def getCoverageResult(){
    COVERAGE_RESULT = sh(script: """
                            ./node_modules/.bin/jest --testFailureExitCode 0 --coverage --coverageReporters text 2>/dev/null \
                            | grep "All files" \
                            | awk -F '|' '{ gsub (" ", "", \$0); print \$5 }' \
                                """,
                    returnStdout: true).trim()
  	env.PCT_COVERAGE = "$COVERAGE_RESULT" ?: '0'
  	echo "Cobertura: $COVERAGE_RESULT %"
}

def publishCoverageReports (def commit_id) {
  // this method need params from environment vars
  PATH_COVERAGE_REPORTS   = "$WORKSPACE/coverage"
  TITLE_PROYECT_REPORT    = "Coverage report"
  TITLE_BUILD_REPORT      = "Coverage report"

  def coverage_artf_name = "coverage-${commit_id}.zip"
  sh encoding: 'UTF-8', label: 'Compress ./coverage folder', returnStdout: true, script: "zip -r $coverage_artf_name coverage"
  if(fileExists(coverage_artf_name)){
    archiveArtifacts "$coverage_artf_name"
    echo "Archive $coverage_artf_name"
  }
  //publish report in build level
  publishHTML([allowMissing: false, alwaysLinkToLastBuild: true, includes: '**/*', keepAll: true, reportDir: PATH_COVERAGE_REPORTS, reportFiles: 'app.component.html.html', reportName: TITLE_BUILD_REPORT, reportTitles: ''])
  //publish report in project level
  //publishHTML([allowMissing: false, alwaysLinkToLastBuild: false, includes: '**/*', keepAll: false, reportDir: PATH_COVERAGE_REPORTS, reportFiles: 'index.html', reportName: TITLE_PROYECT_REPORT, reportTitles: ''])
}

def Publish() {
    echo "Into Publish script"
    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return ''

    def repositories = [master : ['releases-npm-repository', 'releases-libs-npm-repository'],
                        develop: ['snapshots-npm-repository', 'snapshots-libs-npm-repository']]
    sh "npm config set globalconfig /home/node/npmrc"

    def repositoryList = repositories[env.branch] ?: repositories['develop']
    def repository = (env?.IS_LIBRARY && env.IS_LIBRARY.toLowerCase() == 'true' ? repositoryList[1] : repositoryList[0])

    repository = "https://webpre-adm.es.sedc.internal.vodafone.com:44100/nexus/repository/${repository}/"
    sh "npm config set registry ${repository}"

    // TODO Sacar las credenciales de aqui
    if (env?.BUILD_TOOL == 'lerna') {
        commitLernaChanges()

        def status = sh(returnStatus: true, script: "npm run lerna:publish -- --registry ${repository} --legacy-auth YWRtaW46NVQ0clc0UiU= --yes")
        archiveLogsNpm(status)

    } else {
        def response = sh(returnStdout: true, script: 'npm publish dist/ --timing')
        return slackUtils.resolveNpmUrlArtifact(response, repository)
    }
    return ''


}

def publishZip(Map functionParams = [:]) {
    echo "Into PublishZip script"
    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return

    sh "cd ${functionParams.distFolder}/${env.PACKAGE_GROUP} && zip -r ../../app.zip ./*"
    sh "ls -l"

    withCredentials([[$class          : 'UsernamePasswordMultiBinding',
                      credentialsId   : 'es004dxr-nexus-wcsdev',
                      usernameVariable: 'USERNAME',
                      passwordVariable: 'PASSWORD']]) {
        sh """ 
                unset http_proxy && unset https_proxy 
        	    curl -v -u ${USERNAME}:${PASSWORD} \
            --upload-file app.zip \
            http://31.4.249.63:8080/nexus/repository/${functionParams.destination}-raw-repository/${this.env.PACKAGE_URL}/${this.env.PACKAGE_VERSION}/${this.env.PACKAGE_NAME}-${this.env.PACKAGE_VERSION}.zip
            """
    }
}


def uploadNexusfile(String nexusUrl, String nexusRepo, String nexusCred, String _GID, String _ARTID,String _VERSION, String _EXTENSION, String filename){
  	echo "uploadNexusfile (..,${nexusRepo},..,${_GID},${_ARTID},${_VERSION}, ${filename})"
  	def _GIDAUX=_GID.replaceAll('\\.','/');
  def ficherodest="${_ARTID}-${_VERSION}.${_EXTENSION}"
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${nexusCred}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){
        def SALIDA=sh returnStdout: true, script: """
            curl --silent --write-out "HTTPSTATUS:%{http_code}" -u ${USERNAME}:${PASSWORD} --upload-file ${filename} "${nexusUrl}/content/repositories/${nexusRepo}/${_GIDAUX}/${_ARTID}/${_VERSION}/${ficherodest}" 
            """
        def index=SALIDA.indexOf('HTTPSTATUS:')+11
        def errorcode=SALIDA.substring(index,index+3)
        echo "POST status:${errorcode}"
        if (errorcode.substring(0,1) !="2"){
            error "${SALIDA}"
        }
    }
}



def loadConfigYaml(){
    if (fileExists('./configCI.yaml'))
        return readYaml (file: './configCI.yaml')
    else 
        return new LinkedHashMap(['NODE_VERSION': env.NODE_VERSION ?: '12.16.1'])
}

def resolveNodeVariables() {
    echo "Into resolveNodeVariables script"
    if (kiuwan.chekOnlyKiuwanAnalysis(env)) return

    configYaml = loadConfigYaml()
    env.NODE_VERSION = configYaml.NODE_VERSION

    packageJson = readJSON file: "./package.json"
    env.PACKAGE_VERSION = packageJson.version
    env.PACKAGE_URL = packageJson.name.replace("@", "")
    env.PACKAGE_NAME = env.PACKAGE_URL.split("/").last()
    env.PACKAGE_GROUP = env.PACKAGE_URL.split("/").first()

    //sh "env | sort"
}

def cleanNpmrc() {
   if(fileExists('.npmrc')){
    echo ("Clean .npmr file...")
    sh("rm -rf /.nprmc && ls")
  }
}

def cleanPackagelock() {
   if(fileExists('package-lock.json')){
    echo ("Clean package-lock.json file...")
    sh("rm -rf package-lock.json && ls")
  }
}

def archiveLogsNpm(status) {
    if (status != 0) {
        echo "Archiving log file..."
        sh "cat /home/jenkins/.npm/_logs/**.log > ./npm.log"
        sh "ls ./npm.log"
        archiveArtifacts artifacts: "npm.log"
        error("CHECK PREVIOUS STEPS AND LOGS IN ARTIFACTS TAB")
    }
}

return this
