def call(String _Application, String CRQ_ID, String _Server, String _listado){
 
 // print " Parametros ${_Application} ${CRQ_ID}  ${_Server} ${_listado} "
 if ( _Application == "TIBCOES" || _Application == "TIBCOIT")
 {
 //Lanzo el script para sacar los paquetes a notificar y promocionar
       exec="""
        . \$HOME/.profile >/dev/null 2>&1
        gen_tibco_release_WB -d ${_Application}  -e prd -p  ${CRQ_ID} ${_listado}
        """
        
        sh "ssh -q ${_Server} '${exec}'"
 }
 
 
 
}

