def call(Map salidaCfg, String k8s_cluster, List projectlist, List msListDeployment, String ENTORNO, String BASEDIR, Integer configTimeout, List jsonDeployment, String project, String storecredentialid ){
    echo "deployCfg_K8s"
    def rollback=false
	def rollback1=false
    openshift.withCluster(k8s_cluster) {
        echo "Using Cluster: ${openshift.cluster()}"
        //openshift.verbose()
        //openshift.logLevel(3)

        def APP=""
        def status=""
        def listresources=getResouceFileList("microservice web",ENTORNO)
        echo "resources [${listresources}]"
        projectlist.unique().each(){
            echo "rollback1: ${rollback1}"
            if (rollback1==false){
                project_dest=it
                openshift.withProject(project_dest) {
                    echo "Using project: ${openshift.project()}"
                    //crear recursos
                    def resourcefilelist=[]
                    def resourcenameant=""
                    def resourcetypeant=""
                    def resourcetoken=""
                    def resourcetype=""
                    def resourcename=""
                    def resourceenv=""
                    def resourcefileant=""
                    try{
                        listresources.each(){
                            echo "Procesando ${it}"
                            resourcetoken=it.tokenize("/")
                            resourcetype=resourcetoken[1]
                            if (resourcetype == 'configmap'){
                                resourcename=resourcetoken[2]
                                resourceenv=resourcetoken[3]
                            }
                            if (resourcetype == 'secretTemplates' || resourcetype == 'secret' || resourcetype == 'trustore'){
                                if (resourcetoken[2] != ENTORNO){
                                    resourcename=resourcetoken[2]
                                }else{
                                    resourcename=resourcetoken[3]
                                    resourceenv=resourcetoken[2]
                                }
                            }
                            if (resourcenameant == ""){
                                resourcenameant = resourcename
                                resourcetypeant = resourcetype
                            }
                            if (resourcenameant == resourcename){
                                resourcefilelist.add(it)
                            }
                            echo "resourcenameant: ${resourcenameant}"
                            echo "resourcetypeant: ${resourcetypeant}"
                            if (resourcenameant != resourcename){
                                echo "Procesar ${resourcenameant}"
                                //procesar
                                if (resourcetypeant=="configmap"){
                                    //si existe
                                    if (openshift.selector('configmap', "${resourcenameant}").exists()){
                                        def cmap=openshift.selector('configmap', "${resourcenameant}").objects()
                                        echo "Existe ${resourcenameant}"
                                        //si ha sido modificado
                                        cmap.each(){
                                            salidaCfg.listconfigmap.add(it)
                                            echo "guardado cmap:${it.metadata.name}"
                                        }
                                        openshift.selector('configmap', "${resourcenameant}").delete()
                                        def fromfilestring=""
                                        resourcefilelist.each(){
                                            fromfilestring+="--from-file=${it} "
                                        }
                                        echo "oc create configmap ${resourcenameant} ${fromfilestring}"
                                        openshift.logLevel(3)
                                        openshift.create('configmap', "${resourcenameant}","${fromfilestring}")
                                        openshift.logLevel(0)
                                    }else{
                                        Map resource=[ "name":"${resourcename}",
                                            "type":"${resourcetype}",
                                            "namespace":"${project_dest}"]
                                        def fromfilestring=""
                                        resourcefilelist.each(){
                                            fromfilestring+="--from-file=${it} "
                                        }
                                        echo "oc create configmap ${resourcenameant} ${fromfilestring}"
                                        openshift.create('configmap', "${resourcenameant}","${fromfilestring}")
                                        salidaCfg.listresourcedel.add(resource)
                                    }
                                }
                                resourcefilelist=[]
                                resourcefilelist.add(it)
                            }
                            if(resourcetype=="secretTemplates"){
                                def sSecretTemplate=""
                                
                                def secretparam="${BASEDIR}/CDM/Jenkins/DXL/secrets/${ENTORNO}/parametros.cfg"
                                sSecretTemplate=it
                                //openshift.withCluster(oc_cluster) {
                                //    secretprocesed=openshift.process("-f", "${sSecretTemplate}",
                                //        "-p","NAMESPACE=${project_dest}","--param-file","${secretparam}","--ignore-unknown-parameters")
                                //}    
                                sh"""
                                    cp -p $secretparam secret_params.cfg
                                    sed -i "s/: /=/g" secret_params.cfg
                                """
                                sh"""
                                    cp -p $sSecretTemplate Template
                                    awk -f ${BASEDIR}/templates/scripts/params_from_temp.awk Template
                                    cp -p template_params.cfg params_template.cfg
                                """  
                                sh"""    
                                    echo "NAMESPACE=${project_dest}">params.cfg
                                """
                                sh"""    
                                    awk -f ${BASEDIR}/templates/scripts/override_file_params.awk params_template.cfg secret_params.cfg
                                    awk -f ${BASEDIR}/templates/scripts/override_file_params.awk params_template.cfg params.cfg
                                    awk -f ${BASEDIR}/templates/scripts/set_params.awk params_template.cfg
                                    awk -f ${BASEDIR}/templates/scripts/template_process.awk  Template
                                """
                                objects=readYaml (file: "Template.process")
                                List secretprocesed=[]
                                SALIDA= sh returnStdout: true, script: "grep kind: Template.process |wc -l "
                                if(SALIDA.trim()=="1"){
                                    secretprocesed.add(objects)
                                }else{
                                    secretprocesed=objects
                                }
                                echo "${secretprocesed}"                                
                                secretprocesed.each(){
                                    def restype=it.kind
                                    def resname=it.metadata.name
                                    def resnamespace=it.metadata.namespace
                                    echo "Procesando: ${restype}[${resname}] en ${resnamespace} "
                                    if (restype !="Secret" || resnamespace!=project_dest){
                                        error "En la plantilla solo puede haber secrets"
                                    }
                                    else{
                                        if (openshift.selector("${restype}", "${resname}").exists()){
                                            //echo "Existe secret ${resname}"
                                            def secret=openshift.selector("${restype}", "${resname}").objects()
                                            //si ha sido modificado
                                            secret.each(){
                                                salidaCfg.listsecrets.add(it)
                                                echo "guardado secrettemplate:${it.metadata.name}"
                                            }
                                            echo "Tratando recurso:${restype} ${resname} "
                                            if (openshift.selector("${restype}", "${resname}").exists()){
                                                //echo "Borrando recurso:${restype} ${resname} "
                                                openshift.selector("${restype}", "${resname}").delete()
                                                //echo "Creando recurso:${restype} ${resname} "
                                                openshift.create(it)
                                            }                                                                    
                                        }else{
                                            Map resource=[ "name":"${resname}",
                                                "type":"${restype}",
                                                "namespace":"${project_dest}"]
                                            openshift.create(it)
                                            salidaCfg.listresourcedel.add(resource)
                                        }
                                    }
                                }
                            }
                            if(resourcetype=="secret"){
                                def params=""
                                def fileList = readFile(it)
                                List files=fileList.split("\n").collect{it.trim()}
                                for (i=1;i<files.size();i++){
                                    if (files[i] !=""){
                                        params+=files[i]+" "
                                    }
                                }
                                echo "Procesando: ${resourcetype}[${resourcename}] en ${project_dest} "

                                if (openshift.selector("${resourcetype}", "${resourcename}").exists()){
                                    //echo "Existe secret ${resourcename}"
                                    def secret=openshift.selector("${resourcetype}", "${resourcename}").objects()
                                    //si ha sido modificado
                                    secret.each(){
                                        salidaCfg.listsecrets.add(it)
                                        echo "guardado secret:${it.metadata.name}"
                                    }
                                    echo "Tratando recurso:${resourcetype} ${resourcename} "
                                    if (openshift.selector("${resourcetype}", "${resourcename}").exists()){
                                        //echo "Borrando recurso:${restype} ${resname} "
                                        openshift.selector("${resourcetype}", "${resourcename}").delete()
                                        //echo "Creando recurso:${restype} ${resname} "
                                        dir("${BASEDIR}/CDM/Jenkins/DXL/secrets/${ENTORNO}"){
                                            openshift.create( "secret" , "${files[0]}","${resourcename}", "${params}")
                                        }
                                    }                                                                    
                                }else{
                                    Map resource=[ "name":"${resourcename}",
                                        "type":"${resourcetype}",
                                        "namespace":"${project_dest}"]
                                    dir("${BASEDIR}/CDM/Jenkins/DXL/secrets/${ENTORNO}"){
                                        openshift.create( "secret" , "${files[0]}", "${resourcename}", "${params}")
                                    }
                                    salidaCfg.listresourcedel.add(resource)
                                }
                            }
                            if(resourcetype=="trustore"){
                                def params=""
                                def fileList = readFile(it)
                                List files=fileList.split("\n").collect{it.trim()}
                                withCredentials([usernamePassword(credentialsId: "${storecredentialid}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
                                    dir("${BASEDIR}/CDM/Jenkins/DXL/secrets/${ENTORNO}"){
                                        try {
                                            def trustore=readFile(resourcename)
                                        }
                                        catch(e){
                                            for (i=0;i<files.size();i++){
                                                sh returnStdout: false, script: """
                                                    if [ -f ~/.profile ]; then
                                                            . ~/.profile
                                                    fi
                                                    if [ -f ~/.bash_profile ]; then
                                                            . ~/.bash_profile
                                                    fi
                                                    keytool -importcert ${files[i]} -storepass ${PASSWORD} -trustcacerts -keystore ${resourcename} -noprompt
                                                """
                                            }
                                        }
                                    }
                                }
                            }
                            resourcenameant=resourcename
                            resourcetypeant=resourcetype
                        }
                        //procesar el ultimo configmap si solo hay configmaps
                        if (resourcetype=="configmap"){
                            //si existe
                            echo "procesando configmap ${resourcename}"
                            openshift.logLevel(3)
                            if (openshift.selector('configmap', "${resourcename}").exists()){
                                def cmap=openshift.selector('configmap', "${resourcename}").objects()
                                echo "Existe ${resourcename}"
                                //si ha sido modificado
                                 cmap.each(){
                                    salidaCfg.listconfigmap.add(it)
                                    echo "guardado cmap:${it.metadata.name}"
                                }
                                openshift.selector('configmap', "${resourcename}").delete()
                                def fromfilestring=""
                                resourcefilelist.each(){
                                    fromfilestring+="--from-file=${it} "
                                }
                                echo "oc create configmap ${resourcename} ${fromfilestring}"
                                openshift.create('configmap', "${resourcename}","${fromfilestring}")

                            }else{
                                Map resource=[ "name":"${resourcename}",
                                    "type":"${resourcetype}",
                                    "namespace":"${project_dest}"]
                                def fromfilestring=""
                                resourcefilelist.each(){
                                    fromfilestring+="--from-file=${it} "
                                }
                                echo "oc create configmap ${resourcename} ${fromfilestring}"
                                openshift.create('configmap', "${resourcename}","${fromfilestring}")
                                salidaCfg.listresourcedel.add(resource)
                            }
                            openshift.logLevel(0)
                        }
                    }
                    catch(e){
                        echo "Error al crear recursos"
                        echo "${e.getMessage()}"
                        rollback1=true
                        rollback=true
                    }
                    echo "recursos a borrar en caso de rollback:[${salidaCfg.listresourcedel}]"
                    //redeploy ms
                    def cmapsize=salidaCfg.listconfigmap.size()
                    def secretssize=salidaCfg.listsecrets.size()
                    echo "cmaps[${cmapsize}] sectes[${secretssize}}"
                    if (cmapsize>0 || secretssize >0){
                        salidaCfg.listrollbackprojects.add(project_dest)
                        msListDeployment.each(){
                            if (rollback1==false){
                                def ms=it
                                _App=ms.application
                                APLICACION=_App.toLowerCase()
                                app_project_dest="${ms.namespace}-${project}"
                                if (app_project_dest == project_dest){
                                    echo "Desplegando ${APLICACION} en: ${openshift.project()}"
                                    def listDeployment=getListJsonDC(jsonDeployment,APLICACION)
                                    listDeployment.each(){
                                        def prevDeployment="${it.name}"
                                        if (it.version != "latest"){
                                            def token1=it.version.tokenize(".")
                                            def LOWERVERSION="${token1[0].toLowerCase()}.${token1[1]}.${token1[2]}"
                                            prevDeployment="${prevDeployment}-${LOWERVERSION}"
                                        }
                                        //openshift.selector("deployment", "${prevDeployment}").rollout().latest()
                                        openshift.selector("deployment", "${prevDeployment}").related("pods").delete()
                                        def latestDeploymentVersion = openshift.selector("deployment", "${prevDeployment}").object().status.latestVersion
                                        def replicasetToCheck = openshift.selector('replicaset', "${prevDeployment}-${latestDeploymentVersion}")
                                        echo "replicasetToCheck:[${replicasetToCheck}]"
                                        try{
                                            timeout(configTimeout){
                                                replicasetToCheck.untilEach(1){
                                                    def replicasetMap1 = it.object()
                                                    replicas=replicasetMap1.status.replicas.equals(replicasetMap1.status.readyReplicas)
                                                    return (replicas)
                                                }
                                            }
                                        }
                                        catch(all){
                                            echo "error al desplegar"
                                            rollback=true
                                            rollback1=true
                                        }
                                        salidaCfg.listrollbackdc.add(ms)
                                    }
                                }
                            }
                        }
                    }
                    else{
                        echo "no hay cambios ni en config, ni en secrets, no se redespliega"
                    }
                }
            }
        }
    }
    return rollback
}

def call(Map salidaCfg, String k8s_cluster, List projectlist, List msListDeployment, String ENTORNO, String BASEDIR, Integer configTimeout, List jsonDeployment, String project, String storecredentialid, String upgrade ){
    echo "deployCfg"
    def rollback=false
	def rollback1=false
    openshift.withCluster(k8s_cluster) {
        echo "Using Cluster: ${openshift.cluster()}"
        //openshift.verbose()
        //openshift.logLevel(3)

        def APP=""
        def status=""
        def listresources=getResouceFileList("microservice web",ENTORNO)
        echo "resources [${listresources}]"
        projectlist.unique().each(){
            echo "rollback1: ${rollback1}"
            if (rollback1==false){
                project_dest=it
                openshift.withProject(project_dest) {
                    echo "Using project: ${openshift.project()}"
                    //crear recursos
                    def resourcefilelist=[]
                    def resourcenameant=""
                    def resourcetypeant=""
                    def resourcetoken=""
                    def resourcetype=""
                    def resourcename=""
                    def resourceenv=""
                    def resourcefileant=""
                    try{
                        listresources.each(){
                            echo "Procesando ${it}"
                            resourcetoken=it.tokenize("/")
                            resourcetype=resourcetoken[1]
                            if (resourcetype == 'configmap'){
                                resourcename=resourcetoken[2]
                                resourceenv=resourcetoken[3]
                            }
                            if (resourcetype == 'secretTemplates' || resourcetype == 'secret' || resourcetype == 'trustore'){
                                if (resourcetoken[2] != ENTORNO){
                                    resourcename=resourcetoken[2]
                                }else{
                                    resourcename=resourcetoken[3]
                                    resourceenv=resourcetoken[2]
                                }
                            }
                            if (resourcenameant == ""){
                                resourcenameant = resourcename
                                resourcetypeant = resourcetype
                            }
                            if (resourcenameant == resourcename){
                                resourcefilelist.add(it)
                            }
                            echo "resourcenameant: ${resourcenameant}"
                            echo "resourcetypeant: ${resourcetypeant}"
                            if (resourcenameant != resourcename){
                                echo "Procesar ${resourcenameant}"
                                //procesar
                                if (resourcetypeant=="configmap"){
                                    //si existe
                                    if (openshift.selector('configmap', "${resourcenameant}").exists()){
                                        def cmap=openshift.selector('configmap', "${resourcenameant}").objects()
                                        echo "Existe ${resourcenameant}"
                                        //si ha sido modificado
                                        cmap.each(){
                                            salidaCfg.listconfigmap.add(it)
                                            echo "guardado cmap:${it.metadata.name}"
                                        }
                                        openshift.selector('configmap', "${resourcenameant}").delete()
                                        def fromfilestring=""
                                        resourcefilelist.each(){
                                            fromfilestring+="--from-file=${it} "
                                        }
                                        echo "oc create configmap ${resourcenameant} ${fromfilestring}"
                                        openshift.logLevel(3)
                                        openshift.create('configmap', "${resourcenameant}","${fromfilestring}")
                                        openshift.logLevel(0)
                                    }else{
                                        Map resource=[ "name":"${resourcename}",
                                            "type":"${resourcetype}",
                                            "namespace":"${project_dest}"]
                                        def fromfilestring=""
                                        resourcefilelist.each(){
                                            fromfilestring+="--from-file=${it} "
                                        }
                                        echo "oc create configmap ${resourcenameant} ${fromfilestring}"
                                        openshift.create('configmap', "${resourcenameant}","${fromfilestring}")
                                        salidaCfg.listresourcedel.add(resource)
                                    }
                                }
                                resourcefilelist=[]
                                resourcefilelist.add(it)
                            }
                            if(resourcetype=="secretTemplates"){
                                def sSecretTemplate=""
                                
                                def secretparam="${BASEDIR}/CDM/Jenkins/DXL/secrets${upgrade}/${ENTORNO}/parametros.cfg"
                                sSecretTemplate=it
                                
                                //openshift.withCluster(oc_cluster) {
                                //    secretprocesed=openshift.process("-f", "${sSecretTemplate}",
                                //        "-p","NAMESPACE=${project_dest}","--param-file","${secretparam}","--ignore-unknown-parameters")
                                //}

                                sh"""
                                    cp -p $secretparam secret_params.cfg
                                    sed -i "s/: /=/g" secret_params.cfg
                                """
                                sh"""
                                    cp -p $sSecretTemplate Template
                                    awk -f ${BASEDIR}/templates/scripts/params_from_temp.awk Template
                                    cp -p template_params.cfg params_template.cfg
                                """  
                                sh"""    
                                    echo "NAMESPACE=${project_dest}">params.cfg
                                """
                                sh"""    
                                    awk -f ${BASEDIR}/templates/scripts/override_file_params.awk params_template.cfg secret_params.cfg
                                    awk -f ${BASEDIR}/templates/scripts/override_file_params.awk params_template.cfg params.cfg
                                    awk -f ${BASEDIR}/templates/scripts/set_params.awk params_template.cfg
                                    awk -f ${BASEDIR}/templates/scripts/template_process.awk  Template
                                """

                                objects=readYaml (file: "Template.process")
                                List secretprocesed=[]
                                SALIDA= sh returnStdout: true, script: "grep kind: Template.process |wc -l "
                                if(SALIDA.trim()=="1"){
                                    secretprocesed.add(objects)
                                }else{
                                    secretprocesed=objects
                                }
                                echo "${secretprocesed}"
                                secretprocesed.each(){
                                    def restype=it.kind
                                    def resname=it.metadata.name
                                    def resnamespace=it.metadata.namespace
                                    echo "Procesando: ${restype}[${resname}] en ${resnamespace} "
                                    if (restype !="Secret" || resnamespace!=project_dest){
                                        error "En la plantilla solo puede haber secrets"
                                    }
                                    else{
                                        if (openshift.selector("${restype}", "${resname}").exists()){
                                            //echo "Existe secret ${resname}"
                                            def secret=openshift.selector("${restype}", "${resname}").objects()
                                            //si ha sido modificado
                                            secret.each(){
                                                salidaCfg.listsecrets.add(it)
                                                echo "guardado secrettemplate:${it.metadata.name}"
                                            }
                                            echo "Tratando recurso:${restype} ${resname} "
                                            if (openshift.selector("${restype}", "${resname}").exists()){
                                                //echo "Borrando recurso:${restype} ${resname} "
                                                openshift.selector("${restype}", "${resname}").delete()
                                                //echo "Creando recurso:${restype} ${resname} "
                                                openshift.create(it)
                                            }                                                                    
                                        }else{
                                            Map resource=[ "name":"${resname}",
                                                "type":"${restype}",
                                                "namespace":"${project_dest}"]
                                            openshift.create(it)
                                            salidaCfg.listresourcedel.add(resource)
                                        }
                                    }
                                }
                            }
                            if(resourcetype=="secret"){
                                def params=""
                                def fileList = readFile(it)
                                List files=fileList.split("\n").collect{it.trim()}
                                for (i=1;i<files.size();i++){
                                    if (files[i] !=""){
                                        params+=files[i]+" "
                                    }
                                }
                                echo "Procesando: ${resourcetype}[${resourcename}] en ${project_dest} "

                                if (openshift.selector("${resourcetype}", "${resourcename}").exists()){
                                    //echo "Existe secret ${resourcename}"
                                    def secret=openshift.selector("${resourcetype}", "${resourcename}").objects()
                                    //si ha sido modificado
                                    secret.each(){
                                        salidaCfg.listsecrets.add(it)
                                        echo "guardado secret:${it.metadata.name}"
                                    }
                                    echo "Tratando recurso:${resourcetype} ${resourcename} "
                                    if (openshift.selector("${resourcetype}", "${resourcename}").exists()){
                                        //echo "Borrando recurso:${restype} ${resname} "
                                        openshift.selector("${resourcetype}", "${resourcename}").delete()
                                        //echo "Creando recurso:${restype} ${resname} "
                                        dir("${BASEDIR}/CDM/Jenkins/DXL/secrets${upgrade}/${ENTORNO}"){
                                            openshift.create( "secret" , "${files[0]}","${resourcename}", "${params}")
                                        }
                                    }                                                                    
                                }else{
                                        Map resource=[ "name":"${resourcename}",
                                            "type":"${resourcetype}",
                                            "namespace":"${project_dest}"]
                                    dir("${BASEDIR}/CDM/Jenkins/DXL/secrets${upgrade}/${ENTORNO}"){
                                        openshift.create( "secret" , "${files[0]}", "${resourcename}", "${params}")
                                    }
                                    salidaCfg.listresourcedel.add(resource)
                                }
                            }
                            if(resourcetype=="trustore"){
                                def params=""
                                def fileList = readFile(it)
                                List files=fileList.split("\n").collect{it.trim()}
                                withCredentials([usernamePassword(credentialsId: "${storecredentialid}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
                                    dir("${BASEDIR}/CDM/Jenkins/DXL/secrets${upgrade}/${ENTORNO}"){
                                        try {
                                            def trustore=readFile(resourcename)
                                        }
                                        catch(e){
                                            for (i=0;i<files.size();i++){
                                                sh returnStdout: true, script: """
                                                    if [ -f ~/.profile ]; then
                                                            . ~/.profile
                                                    fi
                                                    if [ -f ~/.bash_profile ]; then
                                                            . ~/.bash_profile
                                                    fi
                                                    keytool -importcert ${files[i]} -storepass ${PASSWORD} -trustcacerts -keystore ${resourcename} -noprompt
                                                """
                                            }
                                        }
                                    }
                                }
                            }
                            resourcenameant=resourcename
                            resourcetypeant=resourcetype
                        }
                        //procesar el ultimo configmap si solo hay configmaps
                        if (resourcetype=="configmap"){
                            //si existe
                            echo "procesando configmap ${resourcename}"
                            openshift.logLevel(3)
                            if (openshift.selector('configmap', "${resourcename}").exists()){
                                def cmap=openshift.selector('configmap', "${resourcename}").objects()
                                echo "Existe ${resourcename}"
                                //si ha sido modificado
                                 cmap.each(){
                                    salidaCfg.listconfigmap.add(it)
                                    echo "guardado cmap:${it.metadata.name}"
                                }
                                openshift.selector('configmap', "${resourcename}").delete()
                                def fromfilestring=""
                                resourcefilelist.each(){
                                    fromfilestring+="--from-file=${it} "
                                }
                                echo "oc create configmap ${resourcename} ${fromfilestring}"
                                openshift.create('configmap', "${resourcename}","${fromfilestring}")

                            }else{
                                    Map resource=[ "name":"${resourcename}",
                                        "type":"${resourcetype}",
                                        "namespace":"${project_dest}"]
                                def fromfilestring=""
                                resourcefilelist.each(){
                                    fromfilestring+="--from-file=${it} "
                                }
                                echo "oc create configmap ${resourcename} ${fromfilestring}"
                                openshift.create('configmap', "${resourcename}","${fromfilestring}")
                                salidaCfg.listresourcedel.add(resource)
                            }
                            openshift.logLevel(0)
                        }
                    }
                    catch(e){
                        echo "Error al crear recursos"
                        echo "${e.getMessage()}"
                        rollback1=true
                        rollback=true
                    }
                    echo "recursos a borrar en caso de rollback:[${salidaCfg.listresourcedel}]"
                    //redeploy ms
                    def cmapsize=salidaCfg.listconfigmap.size()
                    def secretssize=salidaCfg.listsecrets.size()
                    echo "cmaps[${cmapsize}] sectes[${secretssize}}"
                    if (cmapsize>0 || secretssize >0){
                        salidaCfg.listrollbackprojects.add(project_dest)
                        msListDeployment.each(){
                            if (rollback1==false){
                                def ms=it
                                _App=ms.application
                                APLICACION=_App.toLowerCase()
                                app_project_dest="${ms.namespace}-${project}"
                                if (app_project_dest == project_dest){
                                    echo "Desplegando ${APLICACION} en: ${openshift.project()}"
                                    def listDeployment=getListJsonDC(jsonDeployment,APLICACION)
                                    listDeployment.each(){
                                        def prevDeployment="${it.name}"
                                        if (it.version != "latest"){
                                            def token1=it.version.tokenize(".")
                                            def LOWERVERSION="${token1[0].toLowerCase()}.${token1[1]}.${token1[2]}"
                                            prevDeployment="${prevDeployment}-${LOWERVERSION}"
                                        }
                                        //openshift.selector("deployment", "${prevDeployment}").rollout().latest()
                                        openshift.selector("deployment", "${prevDeployment}").related("pods").delete()
                                        def latestDeploymentVersion = openshift.selector("deployment", "${prevDeployment}").object().status.latestVersion
                                        def replicasetToCheck = openshift.selector('replicaset', "${prevDeployment}-${latestDeploymentVersion}")
                                        echo "replicasetToCheck:[${replicasetToCheck}]"
                                        try{
                                            timeout(configTimeout){
                                                replicasetToCheck.untilEach(1){
                                                    def replicasetMap1 = it.object()
                                                    replicas=replicasetMap1.status.replicas.equals(replicasetMap1.status.readyReplicas)
                                                    return (replicas)
                                                }
                                            }
                                        }
                                        catch(all){
                                            echo "error al desplegar"
                                            rollback=true
                                            rollback1=true
                                        }
                                        salidaCfg.listrollbackdc.add(ms)
                                    }
                                }
                            }
                        }
                    }
                    else{
                        echo "no hay cambios ni en config, ni en secrets, no se redespliega"
                    }
                }
            }
        }
    }
    return rollback
}
