import vfes.utils.VFESALMSDeployment
import net.sf.json.JSONObject

def runScript(Map config,String script ){
	// changes for settings.xml if needed 
    if (config.mvnSettingsXml?.trim()){
        echo "Copiando  CDM/${config.mvnSettingsXml}  a  ${config.extractFolder}"
        sh """
           cp CDM/${config.mvnSettingsXml} ${config.extractFolder}

        """
    }
    
    if (config.scriptOwner=="CDM"){
        def fname=new File(script).name
        //def fname=pipelineConfig.buildScript.replaceFirst(~/\.[^\.]+$/, '')
        echo "Script Name: ${fname}"
        sh """
            cp CDM/${script} ${config.extractFolder}
            chmod 755 ${config.extractFolder}/${fname}
            cd ${config.extractFolder}
            ./${fname} ${WORKSPACE}/${config.extractFolder} 
        """

    }else{
        sh """
            chmod 755 ${config.extractFolder}/${script}
            cd ${config.extractFolder}
            ./${script}
        """
    }
}
def call(Map config)
{

    // changes for settings.xml if needed 
    if (config.mvnSettingsXml?.trim()){
        echo "Copiando  CDM/${config.mvnSettingsXml}  a  ${config.extractFolder}"
        sh """
           cp CDM/${config.mvnSettingsXml} ${config.extractFolder}

        """
    }
    
    if (config.scriptOwner=="CDM"){
        def fname=new File(config.buildScript).name
        //def fname=pipelineConfig.buildScript.replaceFirst(~/\.[^\.]+$/, '')
        echo "Script Name: ${fname}"
        sh """
            cp CDM/${config.buildScript} ${config.extractFolder}
            chmod 755 ${config.extractFolder}/${fname}
            cd ${config.extractFolder}
            ./${fname} ${WORKSPACE}/${config.extractFolder} 
        """

    }else{
        sh """
            chmod 755 ${config.extractFolder}/${config.buildScript}
            cd ${config.extractFolder}
            ./${config.buildScript}
        """
    }
}