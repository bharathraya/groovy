import vfes.utils.VFESALMSDeployment
def call(Map config,VFESALMSDeployment alms,artifacts){
	def ansibleInstall='ansibleusrbin'
	if (config.containsKey('ansibleInstall')){
		ansibleInstall=config.ansibleInstall
	}
	for (index=0;index<artifacts.size();index++){
		
		artifactId=artifacts[index]["artifactId"]
		version=artifacts[index]["version"]
		packaging=artifacts[index]["packaging"]

		sh "mv ${artifactId}-${version}.${packaging} CDM/Ansible"

		
		ansiblePlaybook(
		playbook: 'CDM/Ansible/copy_artifact_to_release.yml',
		inventory : "CDM/Ansible/inventories/${alms.deployEnv}/hosts",
		installation: ansibleInstall,
		extras: "-e 'artifact_file=${artifactId}-${version}.${packaging} deployment_env=${alms.deployEnv} deployment_artifact=${config.artifactPath}/${artifactId}'")
	}
}