import vfes.utils.VFESALMSDeployment
import vfes.git.VFESGitRepo


def call(String _gitFolder,String _localBranch,String _remoteBranch,VFESGitRepo _repo,VFESALMSDeployment _almsDep)
{
    def NO_PROXY='eswltbhr,eswltbhr.es.sedc.internal.vodafone.com,195.233.178.75'
    dir (_gitFolder){
        sh "git tag -a ${_almsDep.gitTagId} -m '${_almsDep.gitTagComment}'"
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${_repo.pushCred}",
                usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            sh "git remote set-url origin ${_repo.protocol}${USERNAME}:${PASSWORD}@${_repo.server}/${_repo.repoPath}/${_repo.repoName}.git"
        }
        sh "echo '#!/bin/bash' > cm_push_bitbucket"
        sh "echo 'cd /home/platafor/project' >> cm_push_bitbucket"
        sh "echo 'export no_proxy=${NO_PROXY}' >> cm_push_bitbucket"
        sh "echo 'export NO_PROXY=${NO_PROXY}' >> cm_push_bitbucket"
        sh "echo 'git push --tags origin ${_localBranch}:${_remoteBranch}' >> cm_push_bitbucket"
        sh "chmod 750 cm_push_bitbucket"
        sh "docker run -v \$(pwd):/home/platafor/project vfes_cdm_centos7_base /home/platafor/project/cm_push_bitbucket "   
    }
}
return this;