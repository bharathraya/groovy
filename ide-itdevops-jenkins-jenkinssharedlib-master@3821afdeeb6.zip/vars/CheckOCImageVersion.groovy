import groovy.json.JsonSlurper

def call(String _SERVER,String _CREDENTIALID, String _ARTID,String _VERSION, String _ENTORNO ) {
    echo "CheckOCImageVersion"
    def version=""
    def SALIDA=""
    def lowerARTID=_ARTID.toLowerCase()
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
    credentialsId: "${_CREDENTIALID}", 
    usernameVariable: 'USERNAME', 
    passwordVariable: 'PASSWORD']]){ 
        try {
    		SALIDA=sh returnStdout: true, script: """
                export PATH=$PATH:/var/lib/jenkins/occli
                export KUBERNETES_NAMESPACE="${_ENTORNO}"
                export KUBECONFIG=${HOME}/.kube/"${KUBECONFIG}"
                #oc login "${_SERVER}" --token="$PASSWORD" --insecure-skip-tls-verify=true >/dev/null 2>&1
	    	    #oc project "${_ENTORNO}" >/dev/null 2>&1
                oc --server="${_SERVER}" --token="$PASSWORD" get imagestream "${lowerARTID}" -n="${_ENTORNO}" --output='json'
		    """
	    }catch (Exception e) {
    	    echo "No existe la imagen en el repositorio"
    	    SALIDA=""
        }
    }
    if (SALIDA != "")
    {
        echo SALIDA
        def jsonSlurper = new JsonSlurper()
        def jsonnexusquery = jsonSlurper.parseText(SALIDA)
        jsonnexusquery.status.tags.any{ 
            echo "Found tag:${it.tag}"
            if( "${it.tag}" == "${_VERSION}"){   
                version=it.tag
                echo "Ya existe la imagen ${_ARTID}:${version}"
                return true
            }
        }
        if ( version == "")
        {
            echo "Existe la imagen en el repositorio, pero no la version ${_VERSION}"
        }
    }
    return version
}