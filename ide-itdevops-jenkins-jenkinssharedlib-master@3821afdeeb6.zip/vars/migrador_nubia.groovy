def call(String _Aplicacion, String _env, String _package,String _remoteServer){
  
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    migrador_nubia.sh -d ${_Aplicacion} -e ${_env} -p ${_package} -W
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}

