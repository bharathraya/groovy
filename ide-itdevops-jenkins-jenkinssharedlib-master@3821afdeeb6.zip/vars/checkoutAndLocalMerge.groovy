

def call(repo,deployEnv,commitId,entregas='entregas',vodafone='vodafone',
gitProtocol='http',url='eswltbhr:8282',gitCredentials='vfjenkins-passwd',destFolder='.')
{

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: gitCredentials,
                        usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                echo "${deployEnv} ${entregas} ${gitProtocol}://${USERNAME}:${PASSWORD}@${env.url}/${vodafone}/${repo} ${destFolder}"
                sh """
                    git clone -b${deployEnv} ${gitProtocol}://${USERNAME}:${PASSWORD}@${url}/${vodafone}/${repo}.git ${destFolder}
                    git remote add ${entregas} ${gitProtocol}://${USERNAME}:${PASSWORD}@${url}/${entregas}/${repo}.git ${destFolder}
                """
                }    
    sh "git fetch ${entregas}"
    sh "git merge ${commitId}"

}
return this;