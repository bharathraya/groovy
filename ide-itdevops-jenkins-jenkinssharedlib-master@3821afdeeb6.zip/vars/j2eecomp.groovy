def call(String _domain,String _env,String _package,String _remoteServer){
   

    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_package}
    j2eecomp.sh -d ${_domain} -e ${_env} -p ${_package}
    """
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
