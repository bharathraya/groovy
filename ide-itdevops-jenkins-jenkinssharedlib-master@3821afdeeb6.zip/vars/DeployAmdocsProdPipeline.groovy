import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario

def _App=""
def _CRQ_ID=""
def _Date=""
def _delivery=""
def _env=""
def Execution=""
def exec=""
def iCopia=0
def hoy=""
def mybuilduser=""
def NodoAgent=""
def Parameter=""
def _password=""
def pipelineConfig
def pos=0
def _Scripts=""


def call(Map pipelineParams){
    pipeline{
         agent none
        
         parameters { 
            string(name: 'WB_ID', defaultValue: '', description: 'Name of package') 
            choice(name: 'Application',  choices: pipelineParams.TypesChoices , description: 'Application to deploy') 
            string(name: 'Delivery', defaultValue: '', description: 'Delivery to find dependencies') 
            string(name: 'Date', defaultValue: '', description: 'Date when package was generated YYYYMMDD') 
            string(name: 'Password',  defaultValue: '', description: 'Password for user PPP') 
            
         }

stages{     
       stage("Parameters"){
            agent {
                label 'AMDOCS-DEPLOY'
                    }
             steps{
               script {

                //Leo los parametros
                _CRQ_ID=params.WB_ID.trim()  
                _Date=params.Date.trim()
                _password=params.Password.trim()
                _App=params.Application
                _delivery=params.Delivery
                _env="PROD"
                    
                currentBuild.displayName = "PARCHE: ${_CRQ_ID} App: ${_App}"
                currentBuild.description = "PARCHE: ${_CRQ_ID} App: ${_App}"
                }//Script
             }//step
            }//prepare
      
        stage("Preparation"){ //Testeo los paquetes
                agent { 
                        label 'AMDOCS-DEPLOY'
                     }
                steps{
                  script {

                    //Saco el ejecutor
                     wrap([$class: 'BuildUser']) {
                             echo "Exec user: ${env.BUILD_USER_ID}"
                             mybuilduser=env.BUILD_USER_ID
                        }//WARP
                                
                        hoy=new Date().format( 'yyyyMMdd' )
                        print "**********Hoy es : ${hoy}  ******"
                        print "**********Parametros**********"
                        print "Nombre del parche: ${_CRQ_ID}"
                        print "Fecha del parche: ${_Date}"
                        print "Aplicacion del despliegue: ${_App}"
                        print "Contraseña para BBDD: ${_password}"
                        print "Delivery para el Esquema: ${_delivery}"
                        
                        if (_CRQ_ID == "")
                        {
                            error ("Es necesario el nombre del parche")
                        }
                        if ((_App =="AMDOCS-BBDD" || _App =="AMDOCS-BusinessRules" || _App =="AMDOCS-ESQUEMA" || _App =="AMDOCS-PREVIEW") && _password =="")
                        {
                            error ("Es necesario la contraseña para el carga_amdocs")
                        }
                        if ((_App =="AMDOCS-ESQUEMA" || _App =="AMDOCS-PREVIEW") && _delivery =="")
                        {
                            error ("Es necesario la delivery para el esquema")
                        }
                        if (_Date == "" )
                        {
                            print "Usaremos como fecha la de hoy: ${hoy}"
                            _Date=hoy
                        }
                        pipelineConfig=readYaml(file: pipelineParams.pipelineDeployConfigFile)
                       
                        print "Cual es la app y el enviroment ->  ${_App}-${_env}"
                        _Scripts=pipelineConfig["${_App}-${_env}"]
                        
                        if ("${_Scripts}" == "null")
                        { //No hay script especifico
                            exec="""
                             . \$HOME/.profile >/dev/null 2>&1
                                deploy_prod -d ${_App} -p ${_CRQ_ID} -f ${_Date}
                            """
                        }
                        else    
                        {
                           //Saco lo que hay que ejecutar
                            print "Hemos leido ${_Scripts}"
                            Execution=""
                            for (pos = 0; pos < _Scripts.size(); pos++) { 
                                Parameter = _Scripts[pos]
                               // print "Para ${pos} es el parametro ${Parameter}"
                                if (Parameter =="Parche")
                                {
                                    Execution="${Execution}"+' ' +"${_CRQ_ID}" 
                                }
                                else if (Parameter =="Entorno")
                                {
                                    Execution="${Execution}"+' ' +"${_env}"    
                                }
                                else if (Parameter =="Domain")
                                {
                                    Execution="${Execution}"+' ' +"${_App}"    
                                }
                                 else if (Parameter =="Delivery")
                                {
                                    Execution="${Execution}"+' ' +"${_delivery}"    
                                }
                                else if (Parameter =="Password")
                                {
                                    Execution="${Execution}"+' ' +"${_password}"    
                                }
                                else if (Parameter =="Fecha")
                                {
                                    Execution="${Execution}"+' ' +"${_Date}"    
                                }
                                 else 
                                {
                                    Execution="${Execution}"+' ' +"${Parameter}"    
                                }
                             //   print "Componiendo ${Execution}"
                            }//for

                            //print "Execution es ->>>   ${Execution}"
                                exec="""
                                    . \$HOME/.profile >/dev/null 2>&1
                                    . paquete  ${_CRQ_ID}
                                    ${Execution}
                                """
                        }//Fin si hay script diferente
         }// scripts
        }//steps
  }//Stage execution
   
   stage("Execution"){ //Testeo los paquetes
                agent { 
                       //node("${MachineMaster}")
                       node("AMDOCS-DEPLOY")
                     }
                steps{
                  script {
                      
                       //sh "${exec}"
                       print "Se ejecuta en devopsprdtools01 esto:: "
                       print "************************************"
                       print "${exec}"
                       print "************************************"
                   
                  }// scripts
                  }//steps
  }//Stage execution
}//stages

}//pipeline
}//map


