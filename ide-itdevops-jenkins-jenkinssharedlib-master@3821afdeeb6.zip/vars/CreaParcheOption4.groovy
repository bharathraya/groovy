def call(String _domain, String _nombreCarpeta, String _listado, String _TipoRege){


hoy=new Date().format( 'yyyyMMdd' )
print "Parametros:"
print "Domain: ${_domain}"
print "NombreCarpeta: ${_nombreCarpeta}"
print "Listado Paquetes: ${_listado}"
print "Tipo a Regenerar: ${_TipoRege}"

//Testeamos de nuevo y versionamos en PROD
                                 
print "****************************************"
print "TESTEANDO CONTRA PROD APLICACION: ${_domain} "
print "****************************************"
txeker("",_domain,"PROD",_nombreCarpeta,_listado)
//Subimo a SVN si es necesario                                    
if (_domain == "AMDOCS-CLIENT" ||  _domain == "AMDOCS-SERVER" || _domain == "AMDOCS-BPM_APM" || _domain == "AMDOCS-IntegracionTOA" )
{
    //Si hay máquina de SVN ejecuto el promoSVN 
    print "Hay que subir ${_domain} a SVN"
    cleanDirPaquete "${_nombreCarpeta}","opetst75","${hoy}","PROD","${_domain}"
    getFromPVCS "${_nombreCarpeta}","PROD","opetst75"
    promoSVN "${_nombreCarpeta}","PROD","${_domain}","opetst75"
}
//Subimos a git
if ("${_TipoRege}" != "ALL except Bitbucket")
{
    if (_domain != "MQ_NEPTUNO")
    {
        print "Hay que subir ${_domain} a Bitbucket"
        cleanDirPaquete "${_nombreCarpeta}","eswliahr","${hoy}","PROD","${_domain}"
       // getFromPVCS "${_nombreCarpeta}","PROD","eswliahr"
        CopiaFicheros "${_nombreCarpeta}","PROD","eswliahr"
        //promoGIT (String _TipoObsoletos, String _GenerarFichCambios, String _domain, String _Env, String _Alms, String _remoteServer)
        promoGIT "NO","SI","${_domain}","PROD","${_nombreCarpeta}","eswliahr"
    }
    else
    {
        print "${_domain} is not updated in Bitbucket" 
    }//Es mq-amdocs
}// no hemos elegido no subir a git
else
{
    print "${_domain} is not updated in Bitbucket"
}

print "****************************************"
print "ETIQUETANDO CONTRA PROD APLICACION: ${_domain} "
print "****************************************"
txeker("-l",_domain,"PROD",_nombreCarpeta,_listado)


}
                                