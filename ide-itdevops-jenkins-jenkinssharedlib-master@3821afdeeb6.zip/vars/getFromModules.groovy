def call(String _Alms,String _Env,String _remoteServer,String _date,String _domain){
    
   
   if (_domain != "SAP")
   {
        //Hacemos el dos2unix en todos los casos en es036tvr
        
        execdos="""
            . \$HOME/.profile >/dev/null 2>&1
            ssh es036tvr " . \$HOME/.profile >/dev/null 2>&1; cd /home/plataforma/plausr/data/temporal/${_date}/${_Alms}/${_Env}/DataModules ; dos2unix *"
            
        """
       
        try{     
            if (_remoteServer!="")
                {
                    sh "ssh -q ${_remoteServer} '${execdos}'"
                }
            else
                {
                    sh "${execdos}"
                }
        } catch(Exception e){
                createReject (_Alms , "Para este tipo de paquetes no se tratan los modulos de datos/For this kind of packages data modules are not treated.","5")
            
        }
   }  
   
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    export ruta_temp=\$DIR_BASE_TEMPORAL/${_date}/anexo/${_Alms}/${_Env}
    
    if [ ! -d \${ruta_temp} ]
    then
        mkdir -p \${ruta_temp}
    fi
    
    cd \${ruta_temp}

    scp -qr es036tvr:/home/plataforma/plausr/data/temporal/${_date}/${_Alms}/${_Env}/DataModules .
    
    """
    
    if (_remoteServer!="")
    {
        sh "ssh -q ${_remoteServer} '${exec}'"
    }
    else
    {
        sh "${exec}"
    }
}
