#!groovy
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import vfes.utils.VFESALMSDataRetriever

// Parametros necesario
def _packageName=""
def _Domain=""
def _Env=""
def _SVNfolder=""
def _listapaquetes=""
def hoy=""

def call(Map pipelineParams){
	pipeline{
		agent none
		
		parameters { 
			string(name: 'WB_ID', defaultValue: '', description: 'WB ID or CRQ ID') 
			choice(name: 'Application', choices: pipelineParams.applicationChoices, description: 'Application to deploy') 
			choice(name: 'Enviroment',  choices: pipelineParams.environmentChoices , description: 'Enviroment to deploy') 
			string(name: 'SVN_folder', defaultValue: '', description: 'Folder name, inside the path: .../svn/CRM/branches/DOCUMENTACION/CM') 
			choice(name: 'Action', choices: ['ADD','DEL','MOD'], description: 'Actions to do with List_Packages: add, delete or modify')
			string(name: 'List_Packages', defaultValue: '', description: 'List of packages for deploy')
			choice(name: 'Modificar_parche', choices: ['NO','YES'], description: 'Update patch in path: .../svn/CRM/trunk_Read_only/INSTALACIONES?')
			string(name: 'Nombre_parche', defaultValue: '', description: 'Patch name')
		}
		
		
		stages{     
			stage("Prepare"){
				agent{
						label 'AMDOCS'
					}
				steps{
					script{
						def mybuilduser=""
						wrap([$class: 'BuildUser']) {
							echo "Exec user: ${env.BUILD_USER_ID}"
							mybuilduser=env.BUILD_USER_ID
						}
						
						echo "Exec user: ${mybuilduser}"
						
						hoy=new Date().format( 'yyyyMMdd' )
						print "La fecha de hoy es ......${hoy}......"
						
						_packageName=params.WB_ID.trim()
						_Domain=params.Application
						_Env=params.Enviroment					
						_SVNfolder=params.SVN_folder.trim()
						_Action=params.Action
						_listapaquetes=params.List_Packages
						_ModificarParche=params.Modificar_parche
						_NombreParche=params.Nombre_parche
						
						if(_Domain=="" || _Env=="" || _packageName=="" || _SVNfolder=="" || _Action=="" || _listapaquetes=="") { 
							error("Los parametros --> Application [${_Domain}] Enviroment [${_Env}] WB_ID [${_packageName}] Action [${_Action}] List_Packages [${_listapaquetes}] son obligatorios.")
						}
						
						if(_ModificarParche=="YES" && _NombreParche==""){
						    error("Los parametros --> Modificar_parche [${_ModificarParche}] Nombre_parche [${_NombreParche}] falta introducir el nombre del Parche dentro de INSTALACIONES.")
						}
						
						print "Package name: ${_packageName}"
						print "Aplicacion: ${_Domain}"
						print "Entorno: ${_Env}"
						print "Carpeta SVN: ${_SVNfolder}"
						print "Accion a realizar: ${_Action}"
						print "Lista de paquetes: ${_listapaquetes}"
						print "Modificar el parche?: ${_ModificarParche}"
						print "Nombre del parche: ${_NombreParche}"
						
						
						//Configuramos el nombre del build y su descripcion
						if(_SVNfolder==""){
							currentBuild.displayName = "WB_ID: ${_packageName} Aplicacion: ${_Domain} Entorno: ${_Env}"
						}
						else{
							currentBuild.displayName = "WB_ID: ${_packageName} Carpeta SVN: ${_SVNfolder} Aplicacion: ${_Domain} Entorno: ${_Env}"
						}
						currentBuild.description = "Accion: ${_Action} Lista Paquetes: ${_listapaquetes} "
					}//Scripts		
				}//Steps			
			}//Prepare
			stage("Testeo"){
				agent{
						label 'AMDOCS'
					}
				steps{
					script{
						//Solo testeamos y extraemos para obtener el e
						print "****************************************"
						print "Extraemos fichero e con los modulos PVCS de los paquetes: ${_listapaquetes} "
						print "****************************************"
						
						try{
							txeker("",_Domain,_Env,_packageName,_listapaquetes)
						} 
						catch(Exception e){
							error("Fallo Testeo contra ${_Env} en ${_Domain} error: ${e}")
						}
						
						fichero_e="${_packageName}.${_Env}.deploy"
						fichero_por="${_packageName}.${_Env}.por_paquete"
						
						exec="""
							. \$HOME/.profile >/dev/null 2>&1
							. paquete ${_packageName} ${_Env}
							//scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_packageName}/${fichero_e} e
							//scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_packageName}/${fichero_por} ../e_por_paquete
							scp -qr es036tvr:/home/plataforma/plausr/data/paquetes/${hoy}/${_packageName}/${fichero_por} e_${_Action}
							"""
						
						sh "ssh -q opetst75 '${exec}'"
					}//Scripts
				}//Steps
			}//Testeo
			stage("Actualizar"){
				agent{
						label 'AMDOCS'
					}
				steps{
					script{
						print "****************************************"
						print "Extraemos fichero e con los modulos PVCS de los paquetes: ${_listapaquetes} "
						print "****************************************"
						
						try{
							actualiza_paquetes "NO", "${_Domain}", "${_Env}", "${_SVNfolder}", "${_Action}", "${_packageName}", "${_listapaquetes}", "opetst75"
						} 
						catch(Exception e){
							error("Fallo en la actualizacion de paquetes. error: ${e}")
						}
					}//Scripts
				}//Steps
			}//Actualizar
			stage("ModificarParche"){
				agent{
						label 'AMDOCS'
					}
				steps{
					script{
					    if(_ModificarParche=="YES"){
					        if(_NombreParche!=""){
        						print "****************************************"
        						print "Modificamos el parche: ${_NombreParche} en INSTALACIONES con el WB_BBDD.txt y el fichero de orden"
        						print "****************************************"
        						
        						try{
        							//descargarse el orden de la ruta de GIT al . paquete
									if (_Domain == "AMDOCS-BBDD" )
									{ 
										//Lanzamos la funcion de Integridad
										MODSIT2=IntegridadBBDD2( "${_packageName}","orden.txt","${_NombreParche}" , "N")
										print "........IntegridadBBDD2 ha devuelto: ${MODSIT2} .............."
									}
        							///quitar substring AMDOCS-
        							//wb2svn "/home/plataforma/../${_packageName}/WB_BBDD.txt" "WB_${_Domain}" "/home/plataforma/../${_packageName}/orden.txt"
        						} 
        						catch(Exception e){
        							error("Fallo en la actualizacion de paquetes. error: ${e}")
        						}
					        }
        					else{
        					    print "No se ha introducido el nombre del parche, por lo que no se ha actualizado en INSTALACIONES"
        					}	
					    }
					}//Scripts
				}//Steps
			}//ModificarParche
		}//stages
	}//pipeline
}//map