def call(String _Alms,String _Env,String _domain, String _remoteServer){

_date=new Date().format( 'yyyyMMdd' )
print "el dominio es ${_domain}"
    
//AMDOCS
if(_domain == "AMDOCS-SERVER" || _domain == "AMDOCS-CLIENT" || _domain == "AMDOCS-BPM_APM" || _domain == "AMDOCS-IntegracionTOA")
{
    _domain = "AMDOCS"
}

//BIZTALK
if(_domain == "BIZTALK-BBDD" || _domain == "BIZTALK-IIS" || _domain == "BIZTALK-SQLSERVER" || _domain == "BIZTALK-TEST" || _domain == "BIZTALK-BINDINGS" || _domain == "BIZTALK-CONFIG" )
{
    _domain = "BIZ2016"
   // MaquinaRemota="fwapptst01"
}

//BIZTALK2020
if(_domain == "BIZTALK2020-BBDD" || _domain == "BIZTALK2020-IIS" || _domain == "BIZTALK2020-SQLSERVER" || _domain == "BIZTALK2020-TEST" || _domain == "BIZTALK2020-BINDINGS" || _domain == "BIZTALK2020-CONFIG" )
{
    _domain = "BIZ2020"
   // MaquinaRemota="fwapptst01"
}

//MOBILITY
if(_domain == "JAVA-JSP" || _domain == "JAVA-J2EE"  )
{
    _domain = "MOBILITY"
   // MaquinaRemota="scfrontst01"
}

//IPORTA
if(_domain == "IPORTA" || _domain == "IPORTA-BBDD" )
{
    _domain = "IPORTA"
   // MaquinaRemota="iportaapptst02"
}

//SGP
if(_domain == "SGP" || _domain == "SGP-BBDD" || _domain =="WEB-SGP" )
{
    _domain = "SGP"
   // MaquinaRemota="sgpapptst04"
}
//SGPMC 
if(_domain == "SGPMC" || _domain == "SGPMC-BBDD" || _domain =="SGPMC-UNIX" )
{
    _domain = "SGPMC"
 //   MaquinaRemota="sgpmctst08"
}

if (_domain == "DOTNET" )
{
     MaquinaRemota="scfrontst01"
      _domain = "MOBILITY"
     
      exec="""
        . \$HOME/.profile >/dev/null 2>&1
        . paquete ${_Alms}
        promoSVN_dotnet -d ${_domain} -e ${_Env} -p ${_Alms}
        """
}
else
{
    exec="""
    . \$HOME/.profile >/dev/null 2>&1
    . paquete ${_Alms}
    promoSVN -d ${_domain} -e ${_Env} -p ${_Alms}
    """
}
    if (_remoteServer!="")
    {
        if (_domain!="SGP")
        {
            sh "ssh -q ${_remoteServer} '${exec}'"
        }
    }
    else
    {
        sh "${exec}"
    }
}
