def call(){
    pipeline{
        agent{
            label 'eswltahr-platafor'
        }
        stages{
            stage('prueba'){
                steps{
                    script{
                                        
                        def prueba="CDM/Jenkins/WORKBENCH/_pruebas/prueba.groovy"
                        def clase=load "${prueba}"
                        clase.prueba("hola caracola")
                    }
                }
            }
        }
    }
}