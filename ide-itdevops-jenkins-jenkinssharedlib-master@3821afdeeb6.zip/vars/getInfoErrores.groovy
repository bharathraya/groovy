def call(String _CRQ,String _env){
  hoy=new Date().format( 'yyyyMMdd' )
  fichero_errores="${_CRQ}.${_env}.errores_testeo"
  _remoteServer="es036tvr"

 //Lanzo el script para sacar los proveedores que tienen errores
       exec="""
        . \$HOME/.profile 
        getInfoErrores -p  ${_CRQ} -f ${fichero_errores}
    """
    
       sh "ssh -q es036tvr '${exec}'"
    
}