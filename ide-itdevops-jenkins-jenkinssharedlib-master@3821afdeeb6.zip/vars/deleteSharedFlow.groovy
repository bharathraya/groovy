call(String sharedFlow, Object env_config{
    echo "deleteSharedFlow"
    def SALIDA=""
    
    withCredentials([[$class: 'UsernamePasswordMultiBinding', 
                                credentialsId: "${env_config.credentialid}", 
                                usernameVariable: 'USERNAME', 
                                passwordVariable: 'PASSWORD']]){ 
        SALIDA=sh returnStdout: true, script: """
            https_proxy="${env_config.proxyurl}"
            export https_proxy
            no_proxy="${env_config.noproxy}"
            export no_proxy
            curl -k -X DELETE --silent --write-out "HTTPSTATUS:%{http_code}" -u $user:$password https://${env_config.hosturl}/${env_config.apiversion}/organizations/${env_config.org}/sharedflows/${sharedFlow} 
        """
	index=SALIDA.indexOf('HTTPSTATUS:')+11
	errorcode=SALIDA.substring(index,index+3)
	echo "POST status:${errorcode}"
	if (errorcode.substring(0,1) !="2"){
	    echo "WARNING:${SALIDA}"
	    echo "WARNING: Al Borrar: ${sharedFlow}"
	}
    }
}