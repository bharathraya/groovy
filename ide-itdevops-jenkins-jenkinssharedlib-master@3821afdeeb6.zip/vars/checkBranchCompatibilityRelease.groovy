def call ( String RELEASEORDERFILE, String bitbucket, String _Delivery, String ENTORNO, String _SortCommit ){
    echo "checkBranchCompatibilityRelease"
    echo "releasejson:${RELEASEORDERFILE}"
    def cadenajson = readFile("${RELEASEORDERFILE}")
	list BranchList=getBranchList("${bitbucket}")
	echo "Branches:" + BranchList.join(",")
    cadenajson=addMissingBrachesInfo(cadenajson, BranchList)
	list ListPrevRelease=getListPrevRelease(cadenajson, _Delivery, ENTORNO)
	def COMMITDIFF=""
    ListPrevRelease.each{
        def release=it
		COMMITDIFF=checkCommitDiffRelease(bitbucket,release,_SortCommit)
        COMMITDIFF.any(){
            echo "COMMITDIFF: [${it}]"
            if (it !=""){
                echo "INFO: La entrega ${_SortCommit} no contiene el commit [${it}] de la releases previa ${release}"
                return true
            }
        }
	}
}

