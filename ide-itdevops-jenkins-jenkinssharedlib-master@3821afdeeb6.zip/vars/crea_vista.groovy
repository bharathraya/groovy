def call (String _dateSanity, String _view, String _env ){
    node ('es1117yw'){
        checkout scm
        dir ("CDM/CommonTools/WorkBenchClient/"){
            bat "python crea_vista.py -d ${_dateSanity} -v ${_view} -e ${_env} "
        }
    }
}
