def call (String _params,String _dominio,String _entorno,String _package,String _wbID){
    node ('es243ahr'){
        dir ("/home/plataforma/PRUEBAS/py"){
            bat "python txeker.py ${_params} -d ${_dominio} -e ${_entorno} -p ${_package} ${_wbID}"
        }
    }
}