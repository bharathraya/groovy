def call(def branch) {
   return checkValidateBranch(branch)
}

def getNameBranch(def branch) {
   echo "Resolve Name branch ${branch}"
   return branch.substring(0, (branch.indexOf('/') > 0) ? branch.indexOf('/') : branch.length() )
}

def checkValidateBranch(def branch){
   FEATURE = "feature"
   RELEASE = "release"
   DEVELOP = "develop"
   MASTER = "master"
   PR = "event"
   VODAFONE = "vodafone"
   branchName = getNameBranch(branch)
  
   echo "Branch: ${branchName}"
   if((branchName == FEATURE || branchName == RELEASE ||branchName == VODAFONE) && branch.contains("/")) {
     return branch.split("/")[1]
   } else if (branchName == DEVELOP || branchName == MASTER){
     return null
   } else if (branchName == PR){
     echo "[PR]: Pull Request received"
   }else {
      echo "Sorry, nogitflow... [ERROR]: The branch name don not exist"

   }
}

