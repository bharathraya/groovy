import groovy.json.JsonSlurper
import groovy.json.JsonOutput

class DataModule implements Comparable<DataModule> {
    public String Order, Package, ModuleFileName, RollBackModuleFileName, StatusGO, StatusRollBack;
    public DataModule(String Order, String Package, String ModuleFileName, String RollBackModuleFileName, String StatusGO, String StatusRollBack) {
        this.Order = Order;
        this.Package = Package;
        this.ModuleFileName = ModuleFileName;
        this.RollBackModuleFileName = RollBackModuleFileName;
        this.StatusGO = StatusGO;
        this.StatusRollBack = StatusRollBack;
    }
    public String toString() {
        return ("(" + Order + ", " + Package + ", " + ModuleFileName + ", " + RollBackModuleFileName + ", " + StatusGO + ", " + StatusRollBack + ")");
    }
    @Override
    public int compareTo(DataModule o) {
        // usually toString should not be used,
        // instead one of the attributes or more in a comparator chain
        return toString().compareTo(o.toString());
    }
}

class SortbyOrder implements Comparator<DataModule>
{
    // Used for sorting in ascending order of
    // roll number
    @NonCPS
    public int compare(DataModule o1, DataModule o2)
    {
         return o1.Order.compareTo(o2.Order);
    }
}

def deploy_env=""
def pckWildfly=""
def pckProperties=""
def pckDatabase=""
def crq_id=""

def pipelineConfig=null
def envConfig=null
def deployConfig=null
def hoy=null
def date4File=null
def annexes=""
def modules=""
def localPrePath=""

def isThereDBActions=false
def isThereWildFlyActions=false
def isTherePropertyActions=false

def isThereBackupProperties=false


def varMain=null
def varDataBase=null
def varProperties=null
def varWildFly=null

def binaryActionStatus=null
def propertyActionStatus=null
def dataModuleActionStatus=null

def Order=""
def Module=""

def stageError=""



/**********************************************************************
FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS
FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS
FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS FUNCTIONS
**********************************************************************/

def CheckpipelineConfig (){
  iRet=0
  if (!pipelineConfig.containsKey("applicationName"))
  {
    echo "Missed key applicationName"
    iRet=1
  }
  if (!pipelineConfig.containsKey("extractFolder"))
  {
    echo "Missed key extractFolder"
    iRet=1
  }
  if (!pipelineConfig.containsKey("envConfig"))
  {
    echo "Missed key envConfig"
    iRet=1
  }
  if (!pipelineConfig.containsKey("nexusRepo"))
  {
    echo "Missed key nexusRepo"
    iRet=1
  }
  if (!pipelineConfig.containsKey("deployConfig"))
  {
    echo "Missed key deployConfig"
    iRet=1
  }
  if (!pipelineConfig.containsKey("releasePath"))
  {
    echo "Missed key releasePath"
    iRet=1
  }
  if (!pipelineConfig.containsKey("stagingPath"))
  {
    echo "Missed key stagingPath"
    iRet=1
  }
  if (!pipelineConfig.containsKey("backupPath"))
  {
    echo "Missed key backupPath"
    iRet=1
  }

  if (!pipelineConfig.containsKey("typeWildFly"))
  {
    echo "Missed key typeWildFly"
    iRet=1
  }
  if (!pipelineConfig.containsKey("typeProperties"))
  {
    echo "Missed key typeProperties"
    iRet=1
  }
  if (!pipelineConfig.containsKey("typeDataBase"))
  {
    echo "Missed key typeDataBase"
    iRet=1
  }

  if (!pipelineConfig.containsKey("schamanDBproxyPath"))
  {
    echo "Missed key schamanDBproxyPath"
    iRet=1
  }
  if (!pipelineConfig.containsKey("schamanDBproxyJar"))
  {
    echo "Missed key schamanDBproxyJar"
    iRet=1
  }
  if (!pipelineConfig.containsKey("releaseUser"))
  {
    echo "Missed key releaseUser"
    iRet=1
  }
  if (!pipelineConfig.containsKey("annexesUser"))
  {
    echo "Missed key annexesUser"
    iRet=1
  }
  if (!pipelineConfig.containsKey("annexesBasePath"))
  {
    echo "Missed key annexesBasePath"
    iRet=1
  }
  if (!pipelineConfig.containsKey("annexesServer"))
  {
    echo "Missed key annexesServer"
    iRet=1
  }
  if (!pipelineConfig.containsKey("sshCredential"))
  {
    echo "Missed key sshCredential"
    iRet=1
  }
  if (!pipelineConfig.containsKey("jbossCliPath"))
  {
    echo "Missed key jbossCliPath"
    iRet=1
  }
  if (!pipelineConfig.containsKey("jbossCliName"))
  {
    echo "Missed key jbossCliName"
    iRet=1
  }
  if (!pipelineConfig.containsKey("credentialJBCli"))
  {
    echo "Missed key credentialJBCli"
    iRet=1
  }
  if (!pipelineConfig.containsKey("contextMicroServiceStart"))
  {
    echo "Missed key contextMicroServiceStart"
    iRet=1
  }
  if (!pipelineConfig.containsKey("microServicePort"))
  {
    echo "Missed key microServicePort"
    iRet=1
  }
  if (!pipelineConfig.containsKey("needStartMicro"))
  {
    echo "Missed key needStartMicro"
    iRet=1
  }
  if (!pipelineConfig.containsKey("maxBackupNumProperties"))
  {
    echo "Missed key maxBackupNumProperties"
    iRet=1
  }
  if (!pipelineConfig.containsKey("maxBackupNumWildFly"))
  {
    echo "Missed key maxBackupNumWildFly"
    iRet=1
  }

  if (iRet == 1)
  {
    return false
  }

  return true
}

def ExistFile(String ffff)
{
  ret=sh(script:"test -f ${ffff}",returnStatus:true)
  if(ret == 0)
  {
    return true
  }
  return false
}

def ReturnSplitNameProperties (String full_name){
    def _contex=null
    def _extension=null
    def _server=null
    def _env=null


    int sepPos1 = full_name.indexOf('.')
    if (sepPos1 == -1) {
        return [_contex,_extension,_server,_env]
    }
    _contex=full_name.substring(0,sepPos1).trim()

    int sepPos2 = full_name.indexOf('_',sepPos1+1)
    if (sepPos2 == -1) {
        return [_contex,_extension,_server,_env]
    }
    _extension=full_name.substring(sepPos1+1,sepPos2)

    int sepPos3 = full_name.indexOf('_',sepPos2+1)
    if (sepPos3 == -1) {
        return [_contex,_extension,_server,_env]
    }
    _server=full_name.substring(sepPos2+1,sepPos3)
    _env=full_name.substring(sepPos3+1).trim()

    return [_contex,_extension,_server,_env]
}

def ReturnSplitNameProperties_ReplicaDatos (String full_name){
    def _order=null
    def _package=null
    def _contex=null
    def _extension=null
    def _server=null
    def _env=null

    int sepPos1 = full_name.indexOf('_')
    if (sepPos1 == -1) {
        return [_order,_package,_contex,_extension,_server,_env]
    }
    _order=full_name.substring(0,sepPos1).trim()

    int sepPos2 = full_name.indexOf('_',sepPos1+1)
    if (sepPos2 == -1) {
        return [_order,_package,_contex,_extension,_server,_env]
    }
    _package=full_name.substring(sepPos1+1,sepPos2).trim()

    int sepPos3 = full_name.indexOf('.',sepPos2+1)
    if (sepPos3 == -1) {
        return [_order,_package,_contex,_extension,_server,_env]
    }
    _contex=full_name.substring(sepPos2+1,sepPos3).trim()

    int sepPos4 = full_name.indexOf('_',sepPos3+1)
    if (sepPos4 == -1) {
        return [_order,_package,_contex,_extension,_server,_env]
    }
    _extension=full_name.substring(sepPos3+1,sepPos4)

    int sepPos5 = full_name.indexOf('_',sepPos4+1)
    if (sepPos5 == -1) {
        return [_order,_package,_contex,_extension,_server,_env]
    }
    _server=full_name.substring(sepPos4+1,sepPos5)
    _env=full_name.substring(sepPos5+1).trim()

    return [_order,_package,_contex,_extension,_server,_env]
}

def ReturnSplitNameBinaries (String full_name)
{
    def _name=null
    def _version=null
    def _freeText=null
    def _extension=null

    int sepPos1 = full_name.indexOf('_')
    if (sepPos1 == -1) {
        return [_name,_version,_freeText,_extension]
    }
    _name=full_name.substring(0,sepPos1).trim()

    int sepPos2 = full_name.indexOf('_',sepPos1+1)
    if (sepPos2 == -1) {
        int sepPos3 = full_name.lastIndexOf('.')
        if (sepPos3 == -1) {
            return [_name,_version,_freeText,_extension]
        }
        _version=full_name.substring(sepPos1+1,sepPos3)
        _extension=full_name.substring(sepPos3+1).trim()
        return [_name,_version,_freeText,_extension]
    }
    _version=full_name.substring(sepPos1+1,sepPos2)

    int sepPos3 = full_name.lastIndexOf('.')
    _extension=full_name.substring(sepPos3+1).trim()

    _freeText=full_name.substring(sepPos2+1,sepPos3)
    return [_name,_version,_freeText,_extension]
}

def ReturnSplitNameDataBase (String full_name){
    def _context=null
    def _free=null
    def _extension=null

    int sepPos1 = full_name.indexOf('_')
    if (sepPos1 == -1) {
        return [_context,_free,_extension]
    }
    _context=full_name.substring(0,sepPos1).trim()

    int sepPos2 = full_name.lastIndexOf('.')
    if (sepPos2 == -1) {
        return [_context,_free,_extension]
    }
    _free=full_name.substring(sepPos1+1,sepPos2).trim()
    _extension=full_name.substring(sepPos2+1).trim()

    return [_context,_free,_extension]
}

def ReturnSplitNameDataBase_ReplicaDatos (String full_name){
  def _order=null
  def _package=null
  def _context=null
  def _free=null
  def _extension=null

  int sepPos1 = full_name.indexOf('_')
  if (sepPos1 == -1) {
      return [_order,_package,_context,_free,_extension]
  }
  _order=full_name.substring(0,sepPos1).trim()


  int sepPos2 = full_name.indexOf('_',sepPos1+1)
  if (sepPos2 == -1) {
      return [_order,_package,_context,_free,_extension]
  }
  _package=full_name.substring(sepPos1+1,sepPos2).trim()


  int sepPos3 = full_name.indexOf('_',sepPos2+1)
  if (sepPos3 == -1) {
      return [_order,_package,_context,_free,_extension]
  }
  _context=full_name.substring(sepPos2+1,sepPos3).trim()


  int sepPos4 = full_name.lastIndexOf('.')
  if (sepPos4 == -1) {
      return [_order,_package,_context,_free,_extension]
  }
  _free=full_name.substring(sepPos3+1,sepPos4).trim()
  _extension=full_name.substring(sepPos4+1).trim()


  return [_order,_package,_context,_free,_extension]
}

def GetFirstKeyPairEnvConfigJSON(){
  for (key in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
  {
    value=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${key}"]
    return[key,value]
  }
}

def ExecuteRemote (String user, String server, String credential, String action, String mode)
{
  def ret
  echo "Executing (${mode}):"
  withCredentials([sshUserPrivateKey(credentialsId: credential, keyFileVariable: 'keyfile')]) {
    def command="ssh -i ${keyfile} ${user}@${server} "
    if ("${mode}" == "STDOUT")
    {
      echo command + action
      result=sh(script:command + action,  returnStatus: false, returnStdout: true)
      ret=result.trim()
    }
    if ("${mode}" == "STATUS")
    {
      echo command + action
      result=sh(script:command + action,  returnStatus: true, returnStdout: false)
      ret=result
    }
  }
  return ret
}

def ExecuteRemote (String user, String server, String credential, String action, String mode, boolean dryrun)
{
  def ret
  if (!dryrun)
  {
      echo "Executing (${mode}):"
  } else {
    echo "Executing (${mode}) (DRYRUN):"
  }
  withCredentials([sshUserPrivateKey(credentialsId: credential, keyFileVariable: 'keyfile')]) {
    def command="ssh -i ${keyfile} ${user}@${server} "
    if ("${mode}" == "STDOUT")
    {
      echo command + action
      if (!dryrun){
        result=sh(script:command + action,  returnStatus: false, returnStdout: true)
        ret=result.trim()
      }
      else
      {
        ret=0
      }
    }
    if ("${mode}" == "STATUS")
    {
      echo command + action
      if (!dryrun){
        result=sh(script:command + action,  returnStatus: true, returnStdout: false)
        ret=result
      }
      else {
        ret=0
      }
    }
  }
  return ret
}

def CopyRemote (String user, String server, String credential, String src_path, String dst_path, String mode)
{
  echo "Executing (${mode}): ${user}@${server}"
  def ret
  if ("${mode}" == "FROM_REMOTE")
  {
    withCredentials([sshUserPrivateKey(credentialsId: credential, keyFileVariable: 'keyfile')]) {

      result=sh(script:"scp -i ${keyfile} ${user}@${server}:${src_path} ${dst_path}",  returnStatus: false, returnStdout: true)
      ret=result.trim()
    }
  }
  if ("${mode}" == "FROM_LOCAL")
  {
    withCredentials([sshUserPrivateKey(credentialsId: credential, keyFileVariable: 'keyfile')]) {
      result=sh(script:"scp -i ${keyfile} ${src_path} ${user}@${server}:${dst_path}",  returnStatus: true)
      ret=result
    }
  }
  return ret
}

def FindFileRemote(String ip, String pathToSearch, String binarytoSearch)
{

      action="cd ${pathToSearch}; test -f ${binarytoSearch} " + '&& ' + "ls ${binarytoSearch} " + '|| ' + "echo \"null\""
      String filetoReturn=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","\'${action}\'","STDOUT")
      return filetoReturn
}

def PrintDataModules(ArrayList<DataModule> DataModules){
    for( b in DataModules )
    {
        echo "Order: ${b.Order}, Package: ${b.Package}, ModuleFileName: ${b.ModuleFileName}, RollBackModuleFileName: ${b.RollBackModuleFileName}, StatusGO: ${b.StatusGO}, StatusRollBack: ${b.StatusRollBack}"
    }
}

def DefineGlobalVariables (String app){
  switch(app) {
    case "Main":
      varMain.localPrePath="${localPrePath}"
      varMain.appendPath="${hoy}" + '/' + "${crq_id}" + '/' + "${deploy_env}"
      varMain.packageBasePath="${varMain.localPrePath}" + '/' + "${pipelineConfig.extractFolder}" + '/' + "${varMain.appendPath}"
      varMain.annexesRemoteAbsolutePath="${pipelineConfig.annexesBasePath}" + '/' + "${varMain.appendPath}" + '/' + 'Annexes'
      varMain.modulesRemoteAbsolutePath="${pipelineConfig.annexesBasePath}" + '/' + "${varMain.appendPath}" + '/' + 'DataModules'
      varMain.annexesLocalRelativePath="${pipelineConfig.extractFolder}" + '/' + "${varMain.appendPath}" + '/' + 'Annexes'
      varMain.modulesLocalRelativePath="${pipelineConfig.extractFolder}" + '/' + "${varMain.appendPath}" + '/' + 'DataModules'
      varMain.wildFlyLocalRelativePath="${pipelineConfig.extractFolder}" + '/' + "${varMain.appendPath}" + '/' + 'WildFly'
      varMain.numModulesPackage=""
      varMain.numAnnexesPackage=""
      varMain.binaryDeployedEnv=""
      varMain.binaryPackage=""
      break
    case "${pipelineConfig.typeDataBase}":
      //STAGE ZONE
      varDataBase.stagePathPackage="${pipelineConfig.stagingPath}" + "/${varMain.appendPath}" + "/${pipelineConfig.typeDataBase}"
      break
    case "${pipelineConfig.typeProperties}":
      //RELEASE ZONE
      varProperties.releasePath="${pipelineConfig.releasePath}" + "/${pipelineConfig.typeProperties}"
      //STAGE ZONE
      varProperties.stagePathPackage="${pipelineConfig.stagingPath}" + "/${varMain.appendPath}" + "/${pipelineConfig.typeProperties}"
      //BACKUP ZONE
      varProperties.backupPathRoot="${pipelineConfig.backupPath}" + "/${pipelineConfig.typeProperties}"
      varProperties.backupFileName="PROPERTIES_" + "${deploy_env}_" + "${crq_id}_" + "${date4File}.tar"
      break
    case "${pipelineConfig.typeWildFly}":
      //RELEASE ZONE
      varWildFly.releasePath="${pipelineConfig.releasePath}" + "/${pipelineConfig.typeWildFly}"
      //STAGE ZONE
      varWildFly.stagePathPackage="${pipelineConfig.stagingPath}" + "/${varMain.appendPath}" + "/${pipelineConfig.typeWildFly}"
      //BACKUP ZONE
      varWildFly.backupPathRoot="${pipelineConfig.backupPath}" + "/${pipelineConfig.typeWildFly}"
      varWildFly.backupFileName="WILDFLY_" + "${deploy_env}_" + "${crq_id}_" + "${date4File}.tar"
      break
  }
}

def CheckActions(){
  //DB MODULES
  echo "====> CHECK ACTIONS <===="
  echo "======> MODULES"

  if (modules == "null")
  {
      varMain.numModulesPackage=0
  } else {
      varMain.numModulesPackage=modules.Modules.size()
      if (varMain.numModulesPackage != 0){
        echo "        FOUND DB ACTIONS!!!!!"
        isThereDBActions=true
      }
  }
  //WILDFLY AND PROPERTIES
  echo "======> ANNEXES"
  echo "========> Check Annexes Number"
  varMain.numAnnexesPackage=annexes.size()
  numAnnexesRemotePath=sh(script:"ssh ${pipelineConfig.annexesUser}@${pipelineConfig.annexesServer} ls -1 ${varMain.annexesRemoteAbsolutePath}|wc -l", returnStatus:false, returnStdout: true)
  if (varMain.numAnnexesPackage != 0){
    echo "          Num Annexes in the package:     ${varMain.numAnnexesPackage}"
    echo "          Num Annexes in the Remote Path: ${numAnnexesRemotePath}"
    if (varMain.numAnnexesPackage != numAnnexesRemotePath.toInteger())
    {
      echo "Number of Annexes in The package != Number of Annexes in the remote Path. Maybe you need to Test the package first.EXIT WITH ERROR"
      sh ("exit 1")
    }
    echo "          Annexes Number OK!!!"
    echo "========> Download Annexes to Local Path ${varMain.annexesLocalRelativePath}"
    sh(script:"rm -fr ${varMain.annexesLocalRelativePath}", returnStatus:false)
    sh(script:"mkdir -p ${varMain.annexesLocalRelativePath}")
    sh("scp -o ConnectTimeout=30 ${pipelineConfig.annexesUser}@${pipelineConfig.annexesServer}:${varMain.annexesRemoteAbsolutePath}/* ${varMain.annexesLocalRelativePath}/.")
    echo "          Annexes Download OK!!!"
    echo "========> Find ${pipelineConfig.deployConfig} File"
    if (!ExistFile("${varMain.localPrePath}/${varMain.annexesLocalRelativePath}/${pipelineConfig.deployConfig}"))
    {
      echo "      ERROR.  There is annexes but ${pipelineConfig.deployConfig} File not found. Exit with error"
      sh ("exit 1")
    }
    echo "          ${pipelineConfig.deployConfig} File Found OK!!!"
    sh(script:"mv ${varMain.localPrePath}/${varMain.annexesLocalRelativePath}/${pipelineConfig.deployConfig} ${varMain.packageBasePath}/.")
    echo "========> Load ${pipelineConfig.deployConfig}"
    deployConfig=readYaml(file: "${varMain.packageBasePath}/${pipelineConfig.deployConfig}")
    echo "        ${pipelineConfig.deployConfig} File Loaded OK!!!"
    echo "========> Check actions to do in ${pipelineConfig.deployConfig} File"
    if (deployConfig.containsKey("property"))
    {
      isTherePropertyActions=true
      echo "        FOUND PROPERTY ACTIONS!!!!!"
    }

    if (deployConfig.containsKey("binary"))
    {
      isThereWildFlyActions=true
      echo "        FOUND WILDFLY ACTIONS!!!!!"
    }
  }
}

def IntegrityChecks (String app) {
  switch(app) {
    case "${pipelineConfig.typeDataBase}":
      echo "====> INTEGRITY CHECK DATABASE <===="
      echo "======> Check: Must to be DataBase info in the ${pipelineConfig.envConfig}"
      for (entorno in envConfig["Entornos"].keySet())
      {
        if (envConfig["Entornos"]["${entorno}"]["DataBases"]["Proxy_Server"] == null){
          echo "               Failed!!!!.  Proxy_Server key for ${entorno} environment must to be defined in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
        if (envConfig["Entornos"]["${entorno}"]["DataBases"]["Proxy_Server"]["ServerName"] == null || envConfig["Entornos"]["${entorno}"]["DataBases"]["Proxy_Server"]["ServerName"] == ""){
          echo "               Failed!!!!.  Proxy_Server.ServerName key for ${entorno} environment must to be defined in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
        if (envConfig["Entornos"]["${entorno}"]["DataBases"]["Proxy_Server"]["ServerIP"] == null || envConfig["Entornos"]["${entorno}"]["DataBases"]["Proxy_Server"]["ServerIP"] == ""){
          echo "               Failed!!!!.  Proxy_Server.ServerIP key for ${entorno} environment must to be defined in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
        if (envConfig["Entornos"]["${entorno}"]["DataBases"]["databaseServer"] == null || envConfig["Entornos"]["${entorno}"]["DataBases"]["databaseServer"] == ""){
          echo "               Failed!!!!.  databaseServer key for ${entorno} environment must to be defined in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
        if (envConfig["Entornos"]["${entorno}"]["DataBases"]["database"] == null || envConfig["Entornos"]["${entorno}"]["DataBases"]["database"] == ""){
          echo "               Failed!!!!.  database key for ${entorno} environment must to be defined in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
        if (envConfig["Entornos"]["${entorno}"]["DataBases"]["Port"] == null || envConfig["Entornos"]["${entorno}"]["DataBases"]["Port"] == ""){
          echo "               Failed!!!!.  Port key for ${entorno} environment must to be defined in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
        if (envConfig["Entornos"]["${entorno}"]["DataBases"]["Parameters"] == null || envConfig["Entornos"]["${entorno}"]["DataBases"]["Parameters"] == ""){
          echo "               Failed!!!!.  Parameters key for ${entorno} environment must to be defined in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
        if (envConfig["Entornos"]["${entorno}"]["DataBases"]["Password_File"] == null || envConfig["Entornos"]["${entorno}"]["DataBases"]["Password_File"] == ""){
          echo "               Failed!!!!.  Password_File key for ${entorno} environment must to be defined in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
      }
      echo  "              Passed OK!!!"

      echo "======> Check: Modules number ${varMain.numModulesPackage} in the package must to be the same as in the remote Path"
      numModulesLocalRelativePath=sh(script:"ls -1 ${varMain.modulesLocalRelativePath}|wc -l", returnStatus:false, returnStdout: true)
      if (varMain.numModulesPackage != numModulesLocalRelativePath.toInteger())
      {
        echo "               Failed!!!!. Number of Modules in The package (${varMain.numModulesPackage})!= Number of Modules in the remote Path (${numModulesLocalRelativePath}). Maybe you need to Test the package first."
        sh ("exit 1")
      }
      echo  "              Passed OK!!!"
      echo "======> Check: Num Modules of Go must to be equal to num Modules RollBack"
      _numModulesGo=modules.Modules.findAll{it.IsRollback == 0}.size()
      _numModulesRollBack=modules.Modules.findAll{it.IsRollback == 1}.size()
      if (_numModulesGo != _numModulesRollBack)
      {
        echo "               Failed!!!!. Number of Modules Go ${_numModulesGo} != Number of Modules RollBack ${_numModulesRollBack}."
        sh ("exit 1")
      }
      echo  "              Passed OK!!!"
      goModules=modules.Modules.findAll{it.IsRollback == 0}
      for( goModule in goModules )
      {
          goModuleName = goModule.FileName
          echo "======> Check: Naming Format for ${goModuleName}"
          (_order,_package,_context,_free,_extension)=ReturnSplitNameDataBase_ReplicaDatos(goModuleName)

          if (_order == null || _package == null || _extension == null || _context == null || _free == null)
          {
            echo "               Failed!!!!. Module File ${goModuleName} Naming Malformed"
            echo "                  Must to be:"
            echo '                     {order}_{package}_{contextPath}_{FreeText}.sql'
            sh "exit 1"
          }

          if (_order == "" || _package == "" || _extension == "" || _context == "" || _free == "")
          {
            echo "               Failed!!!!. Module File ${goModuleName} Naming Malformed"
            echo "                  Must to be:"
            echo '                     {order}_{package}_{contextPath}_{FreeText}.sql'
            sh "exit 1"
          }

          if (_extension != "sql")
          {
            echo "               Failed!!!!. Module File ${goModuleName} Naming Malformed"
            echo "                  Must to be:"
            echo '                     {contextPath}_{FreeText}.sql'
            sh "exit 1"
          }
          echo  "              Passed OK!!!"
          echo "======> Check: Context ${_context} for ${goModuleName} must to be the same to ${pipelineConfig.applicationName}"
          if ( _context != "${pipelineConfig.applicationName}" )
          {
            echo "               Failed!!!!. Context !=  ${pipelineConfig.applicationName} "
            sh("exit 1")
          }
          echo  "               Passed OK!!!"


        }
      break
    case "${pipelineConfig.typeProperties}":
      echo "====> INTEGRITY CHECK PROPERTIES <===="
      ar_property=deployConfig.property.split(',')
      echo "======> Check: Package must to include the properties for all environments in ${pipelineConfig.deployConfig} File"
      for (entorno in envConfig["Entornos"].keySet())
      {

        for (servidor in envConfig["Entornos"]["${entorno}"]["Servers"].keySet())
        {
          pattern="._${servidor}_${entorno}"
          if (!ar_property.any{it =~ /${pattern}/}){
            echo "               Failed!!!!.  File for the environment ${entorno} and server ${servidor} is missed at ${pipelineConfig.deployConfig}!!!!. Exit with error"
            sh("exit 1")
          }
        }
      }
      echo  "               Passed OK!!!"
      echo "======> Check: Package must to include the properties for all environments in annexes path"
      for (entorno in envConfig["Entornos"].keySet())
      {
        for (servidor in envConfig["Entornos"]["${entorno}"]["Servers"].keySet())
        {
          if (!ExistFile("${varMain.localPrePath}/${varMain.annexesLocalRelativePath}/*_${servidor}_${entorno}"))
          {
            echo "               Failed!!!!.  File for the environment ${entorno} and server ${servidor} is missed in the ${varMain.localPrePath}/${varMain.annexesLocalRelativePath}!!!!. Exit with error"
            sh("exit 1")
          }
        }
      }
      echo  "               Passed OK!!!"
      for (propertytoDeploy in ar_property)
      {
        echo "======> Check: File ${propertytoDeploy} at ${pipelineConfig.deployConfig} must to be exists in the annexes path:"
        if (!ExistFile("${varMain.localPrePath}/${varMain.annexesLocalRelativePath}/${propertytoDeploy}"))
        {
          echo "               Failed!!!!. Property key found in the file ${pipelineConfig.deployConfig} but in the package not found file ${propertytoDeploy}. Exit with error"
          sh("exit 1")
        }
        echo  "               Passed OK!!!"
        echo "======> Check: Naming Format for ${propertytoDeploy}"
        (_context,_extension,_server,_env) = ReturnSplitNameProperties(propertytoDeploy)
        if (_context == null || _extension == null || _server == null || _env == null )
        {
          echo "               Failed!!!!. Property File ${propertytoDeploy} Naming Malformed"
          echo "                   Must to be:"
          echo '                          {context_path}.extension_{server_name}_{PPRD|PROD}'
          sh("exit 1")
        }
        if ( _context == "" || _extension == "" || _server == "" || _env == "" )
        {
          echo "               Failed!!!!. Property File ${propertytoDeploy} Naming Malformed"
          echo "                   Must to be:"
          echo '                          {context_path}.extension_{server_name}_{PPRD|PROD}'
          sh("exit 1")
        }
        echo  "               Passed OK!!!"
        echo "======> Check: Context ${_context} for ${propertytoDeploy} must to be the same to ${pipelineConfig.applicationName}"
        if ( _context != "${pipelineConfig.applicationName}" )
        {
          echo "               Failed!!!!. Context !=  ${pipelineConfig.applicationName} "
          sh("exit 1")
        }
        echo  "               Passed OK!!!"

        echo "======> Check: Environment ${_env} for ${propertytoDeploy} must to be defined in the ${pipelineConfig.envConfig} File"
        if (!envConfig["Entornos"].containsKey(_env))
        {
          echo "               Failed!!!!. The Environment ${_env} not found in the ${pipelineConfig.envConfig} File"
          sh("exit 1")
        }
        echo  "               Passed OK!!!"

        echo "======> Check: Server ${_server} for ${propertytoDeploy} must to be defined in the ${pipelineConfig.envConfig} File"
        if (!envConfig["Entornos"]["${_env}"]["Servers"].containsKey(_server))
        {
          echo "               Failed!!!!. Server ${_server} not found in the ${pipelineConfig.envConfig} File for the env ${_env}"
          sh("exit 1")
        }
        echo  "               Passed OK!!!"
      }
      break
    case "${pipelineConfig.typeWildFly}":
      echo "====> INTEGRITY CHECK WILDFLY <===="
      varMain.binaryPackage="${deployConfig.binary}"

      echo "======> Check: Naming Format for ${varMain.binaryPackage}"
      (AppName_toDeploy,Version_toDeploy,FreeText_toDeploy,Extension_toDeploy) = ReturnSplitNameBinaries(varMain.binaryPackage)
      if (AppName_toDeploy == null || Version_toDeploy == null || Extension_toDeploy == null)
      {
        echo "               Failed!!!!. Binary File ${varMain.binaryPackage} Naming Malformed"
        echo "                  Must to be:"
        echo '                     {context_path}_{version}[_modificadores-libres (cliente, funcionalidad, fecha, hash...)].{extension}'
        sh("exit 1")
      }
      echo  "               Passed OK!!!"
      echo "======> Check: Context ${AppName_toDeploy} for ${varMain.binaryPackage} must to be the same to ${pipelineConfig.applicationName}"
      if (AppName_toDeploy != "${pipelineConfig.applicationName}")
      {
        echo "               Failed!!!!. Context !=  ${pipelineConfig.applicationName} "
        sh("exit 1")
      }
      echo  "               Passed OK!!!"

      echo "======> Download ${varMain.binaryPackage} from Nexus"
      compose="${pipelineConfig.nexusRepo}" + "/" + "${varMain.binaryPackage}"
      sh "mkdir -p ${varMain.packageBasePath}/WildFly"
      sh "cd ${varMain.packageBasePath}/WildFly; wget -nv --progress=dot --no-check-certificate ${compose}"
      echo  "               Download OK!!!"
      break
  }
}

def CheckBinaryintoWildfly(String binaryPattern){
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
  {
    (name,ip)=GetFirstKeyPairEnvConfigJSON()
    connect="${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD "
    deploymentCount="--command=\"deployment-info\" | grep \"${binaryPattern}\" | wc -l"
    deployment="--command=\"deployment-info\" | grep \"${binaryPattern}\" | "
    parse_output='awk \'{print \$1}\''
    resultCount=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}",connect+deploymentCount,"STDOUT")
    if (resultCount.toInteger() > 1)
    {
      echo "ERROR. There is something wrong in the WildFly. Found more than one binary with the pattern ${binaryPattern} deployed"
      sh "exit 1"
    } else if ( resultCount.toInteger() == 0)
      return null
    else {
      resultBinaryName=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}",connect+deployment+parse_output,"STDOUT")
      return resultBinaryName.trim()
    }
  }
}

def GettingBinaryForEnableDisableActions (){
  echo "====> CHECK BINARY FOR ENABLE/DISABLE ACTIONS <===="
  wildFlyReleasePath="${pipelineConfig.releasePath}" + "/${pipelineConfig.typeWildFly}"
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
  {
    (name,ip)=GetFirstKeyPairEnvConfigJSON()
    commandCheckReleasePath="[ -d \"${wildFlyReleasePath}\" ] &&  echo \"true\" || echo \"false\""
    result=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}",commandCheckReleasePath,"STDOUT")
    result=result.trim()
    if (result == "false")
    {
      echo "======> WildFly Release Path ${wildFlyReleasePath} doesn't exists. Maybe it's a new application. Checking WildFly ....."
      binaryName=CheckBinaryintoWildfly("${pipelineConfig.applicationName}_")
      if (binaryName == null)
      {
        echo "========> Nothing found in the WildFly. it's a new application."
        echo "          Release Path:           ${wildFlyReleasePath}"
        echo "          Binary at release Path: null"
        echo "          Binary at Wildfly:      ${binaryName}"
      } else {
        echo "========> ERROR: Binary Found at WildFly ${binaryName}. The release path and the Wildfly are misaligned!!!!!"
        echo "          Release Path:           ${wildFlyReleasePath}"
        echo "          Binary at release Path: null"
        echo "          Binary at Wildfly:      ${binaryName}"
        sh "exit 1"
      }

    } else {
      echo "======> WildFly Release Path ${wildFlyReleasePath} found. Checking Binary in this release path...."
      commandBinaryCount="\"cd ${wildFlyReleasePath}; find . -type f -name \\\"${pipelineConfig.applicationName}_*\\\" | wc -l\""
      resultBinaryCount=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}",commandBinaryCount,"STDOUT")
      if (resultBinaryCount.toInteger() > 1)
      {
        echo "========> ERROR. There is something wrong in the release. Found more than one binary with the pattern ${pipelineConfig.applicationName}_*"
        sh "exit 1"
      } else if (resultBinaryCount.toInteger() == 0) {
        echo "========> There is not the binary in the release path with pattern ${pipelineConfig.applicationName}_*. Maybe it's a new application. Checking WildFly"
        binaryName=CheckBinaryintoWildfly("${pipelineConfig.applicationName}_")
        if (binaryName == null)
        {
          echo "========> Nothing found in the WildFly. it's a new application."
          echo "          Release Path:           ${wildFlyReleasePath}"
          echo "          Binary at release Path: null"
          echo "          Binary at Wildfly:      ${binaryName}"
        } else {
          echo "========> ERROR: Binary Found at WildFly ${binaryName}. The release path and the Wildfly are misaligned!!!!!"
          echo "          Release Path:           ${wildFlyReleasePath}"
          echo "          Binary at release Path: null"
          echo "          Binary at Wildfly:      ${binaryName}"
          sh "exit 1"
        }
      } else {
        commandBinary="\"cd ${wildFlyReleasePath}; find . -type f -name \\\"${pipelineConfig.applicationName}_*\\\" -exec basename {} \\;\""
        resultBinary=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}",commandBinary,"STDOUT")
        echo "========> Binary ${resultBinary.trim()} found in the release!!! Checking it in the Wildfly"
        binaryName=CheckBinaryintoWildfly(resultBinary.trim())
        if (binaryName == null)
        {
          echo "========> ERROR. Nothing found in the WildFly. The release path and the Wildfly are misaligned!!!!!"
          echo "          Release Path:           ${wildFlyReleasePath}"
          echo "          Binary at release Path: ${resultBinary.trim()}"
          echo "          Binary at Wildfly:      ${binaryName}"
          sh "exit 1"
        } else {
          echo "========> Binary Found at WildFly ${binaryName}."
          echo "          Release Path:           ${wildFlyReleasePath}"
          echo "          Binary at release Path: ${resultBinary.trim()}"
          echo "          Binary at Wildfly:      ${binaryName}"
          varMain.binaryDeployedEnv=binaryName.trim()
        }
      }
    }
  }
}

def CreatingPathsForNewMicro(){
  echo "INFO. Detected New MicroService. Creating Paths ...."
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
  {
    wildFlyReleasePath="${pipelineConfig.releasePath}" + "/${pipelineConfig.typeWildFly}"
    propertiesReleasePath="${pipelineConfig.releasePath}" + "/${pipelineConfig.typeProperties}"
    wildFlyBackupPath="${pipelineConfig.backupPath}" + "/${pipelineConfig.typeWildFly}"
    propertiesBackupPath="${pipelineConfig.backupPath}" + "/${pipelineConfig.typeProperties}"
    stagingPath="${pipelineConfig.stagingPath}"

    //WILDFLY AND PROPERTIES
    for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
    {
      serverIP=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
      echo "======> Creating Release Paths for ${servidor} (${serverIP})"
      command="mkdir -p ${wildFlyReleasePath}"
      echo "========> Creating WildFly Release Paths"
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Created OK!!!"
      command="mkdir -p ${propertiesReleasePath}"
      echo "========> Creating Properties Release Paths"
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Created OK!!!"

      echo "======> Creating Backups Paths for ${servidor} (${serverIP})"
      command="mkdir -p ${wildFlyBackupPath}"
      echo "========> Creating WildFly Backups Paths"
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Created OK!!!"
      command="mkdir -p ${propertiesBackupPath}"
      echo "========> Creating Properties Backups Paths"
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Created OK!!!"

      echo "======> Creating Staging Paths for ${servidor} (${serverIP})"
      command="mkdir -p ${stagingPath}"
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Created OK!!!"
    }

    //BD
    servidor=envConfig["Entornos"]["${deploy_env}"]["DataBases"].Proxy_Server
    echo "======> Creating Staging Database Path for ${servidor.ServerName} (${servidor.ServerIP})"
        command="mkdir -p ${stagingPath}"
    commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",servidor.ServerIP,"${pipelineConfig.sshCredential}",command,"STATUS", false)
    echo  "       Created OK!!!"

  }
}

def GettingEnableDisableInfo(){
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
  {
    (name,ip)=GetFirstKeyPairEnvConfigJSON()
    connect="${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD "
    deployment="--command=\"deployment-info\" | grep \"${pipelineConfig.applicationName}_\" | "
    parse_output='awk \'{print \$1\" \"\$4}\'| grep \"true\" | awk \'{print \$1}\''
    result=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}",connect+deployment+parse_output,"STDOUT")
    varMain.binaryDeployedEnv=result.trim()
  }
}

def LoadInMemoryHashMap(String app){
  switch(app) {
    case "${pipelineConfig.typeDataBase}":
      echo "====> LOAD IN MEMORY HASH MAP DATABASE <===="
      echo "======> Loading Go Modules"
      goModules=modules.Modules.findAll{it.IsRollback == 0}
      //echo "${goModules}"
      for( goModule in goModules )
      {
        goModuleName = goModule.FileName
        (_order,_package,_context,_free,_extension)=ReturnSplitNameDataBase_ReplicaDatos(goModuleName)
        _dataModuleActionStatus = new DataModule("${_order}", "${_package}","${goModule.FileName}", "", "", "")
        dataModuleActionStatus.add(_dataModuleActionStatus)
      }
      echo "        Loaded OK!!!"
      echo "======> Loading RollBack Modules"
      rollBackModules=modules.Modules.findAll{it.IsRollback == 1}
      //echo "${rollBackModules}"
      for( rollBackModule in rollBackModules )
      {
          rollBackModuleDependence=rollBackModule.ModuleDependenceWorkBenchId
          index=modules.Modules.findIndexOf{it.WorkBenchId == rollBackModule.ModuleDependenceWorkBenchId}
          if (index != -1)
          {
              goModuleName = modules.Modules[index].FileName
              index2=dataModuleActionStatus.findIndexOf{it.ModuleFileName == goModuleName}
              if (index2 != -1)
              {
                  dataModuleActionStatus[index2].RollBackModuleFileName = "${rollBackModule.FileName}"
              } else {
                  echo "        ERROR. Parent Module not found in In-Memory Hash Map List for ${rollBackModule.FileName}"
                  sh "exit 1"
              }
          } else {
              echo "        ERROR. ${rollBackModule.FileName} without parent"
              sh "exit 1"
          }
      }
      echo "        Loaded OK!!!"
      break
    case "${pipelineConfig.typeProperties}":
      echo "====> LOAD IN MEMORY HASH MAP PROPERTIES <===="
      ar_property=deployConfig.property.split(',')
      for (propertytoDeploy in ar_property)
      {
        (_context,_extension,_server,_env) = ReturnSplitNameProperties(propertytoDeploy)
        ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${_server}"]
        if ("${deploy_env}" == "${_env}"){
          _propertyActionStatus = [propertyName: "${propertytoDeploy}", context: "${_context}", env: "${_env}", extension: "${_extension}", serverName: "${_server}", serverIP: "${ip}", status: ""]
          propertyActionStatus+=_propertyActionStatus
        }
      }
      echo  "      Loaded OK!!!"
      break
    case "${pipelineConfig.typeWildFly}":
      echo "====> LOAD IN MEMORY HASH MAP WILDFLY <===="
      (AppName_toDeploy,Version_toDeploy,FreeText_toDeploy,Extension_toDeploy) = ReturnSplitNameBinaries(varMain.binaryPackage)
      for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
      {
        ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
        //_binaryActionStatus = [binaryPackage: "${varMain.binaryPackage}", binaryEnvironment: "${varMain.binaryDeployedEnv}", serverName:"${servidor}", serverIP: "${ip}", statusEnvironment:"Enabled", statusPackage:"Undeployed"]
        if (varMain.binaryDeployedEnv!="")
        {
          _binaryActionStatus = [binaryPackage: "${varMain.binaryPackage}", binaryEnvironment: "${varMain.binaryDeployedEnv}", serverName:"${servidor}", serverIP: "${ip}", statusEnvironment:"Enabled", statusPackage:"Undeployed"]
        } else {
          _binaryActionStatus = [binaryPackage: "${varMain.binaryPackage}", binaryEnvironment: "${varMain.binaryDeployedEnv}", serverName:"${servidor}", serverIP: "${ip}", statusEnvironment:"", statusPackage:"Undeployed"]
        }
        binaryActionStatus+=_binaryActionStatus
      }
      echo  "      Loaded OK!!!"
      break
  }

}

def CleanAndUploadtoStage (String app) {
  switch(app) {
    case "${pipelineConfig.typeDataBase}":
      echo "====> CLEAN AND UPLOAD TO STAGE ZONE DATABASE <===="
      servidor=envConfig["Entornos"]["${deploy_env}"]["DataBases"].Proxy_Server
      echo "======> Cleaning at ${servidor.ServerName} (${servidor.ServerIP})"
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",servidor.ServerIP,"${pipelineConfig.sshCredential}","rm -fr ${varDataBase.stagePathPackage}","STATUS")
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",servidor.ServerIP,"${pipelineConfig.sshCredential}","mkdir -p ${varDataBase.stagePathPackage}","STATUS")
      echo  "       Cleaned OK!!!"
      echo "======> Uploading to ${servidor.ServerName} (${servidor.ServerIP}) at stage zone ${varDataBase.stagePathPackage}"
      commandStatus=CopyRemote("${pipelineConfig.releaseUser}",servidor.ServerIP,"${pipelineConfig.sshCredential}","${varMain.modulesLocalRelativePath}/*","${varDataBase.stagePathPackage}/.","FROM_LOCAL")
      echo  "       Uploaded OK!!!"
      break
      case "${pipelineConfig.typeProperties}":
        echo "====> CLEAN AND UPLOAD TO STAGE ZONE PROPERTIES <===="
        for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
        {
          ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
          echo "======> Cleaning stage zone ${varProperties.stagePathPackage} at ${servidor} (${ip})"
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","rm -fr ${varProperties.stagePathPackage}","STATUS")
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","mkdir -p ${varProperties.stagePathPackage}","STATUS")
          echo  "       Cleaned OK!!!"
          echo "======> Uploading to ${servidor} (${ip}) at stage zone ${varProperties.stagePathPackage}"
          commandStatus=CopyRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","${varMain.annexesLocalRelativePath}/*","${varProperties.stagePathPackage}/.","FROM_LOCAL")
          echo  "       Uploaded OK!!!"
        }
        break

      case "${pipelineConfig.typeWildFly}":
        echo "====> CLEAN AND UPLOAD TO STAGE ZONE WILDFLY <===="
        for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
        {
          ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
          echo "======> Cleaning stage zone ${varWildFly.stagePathPackage} at ${servidor} (${ip})"
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","rm -fr ${varWildFly.stagePathPackage}","STATUS")
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","mkdir -p ${varWildFly.stagePathPackage}","STATUS")
          echo  "       Cleaned OK!!!"
          echo "======> Uploading to ${servidor} (${ip}) at stage zone ${varWildFly.stagePathPackage}"
          commandStatus=CopyRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","${varMain.wildFlyLocalRelativePath}/*","${varWildFly.stagePathPackage}/.","FROM_LOCAL")
          echo  "       Uploaded OK!!!"
        }
        break
  }
}

def Backups (String app) {
  switch(app) {
      case "${pipelineConfig.typeProperties}":
        echo "====> BACKUPS PROPERTIES <===="
        for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
        {
          ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
          echo "======> Cleaning Backup tmp path ${varProperties.backupPathRoot}/tmp at ${servidor} (${ip})"
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","rm -fr ${varProperties.backupPathRoot}/tmp","STATUS")
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","mkdir -p ${varProperties.backupPathRoot}/tmp","STATUS")
          if (commandStatus != 0)
          {
            echo  "       ERROR. Cannot be created the tmp path ${varProperties.backupPathRoot}/tmp !!!"
            sh "exit 1"
          }
          echo  "       Cleaned OK!!!"
        }
        for (property in propertyActionStatus.findAll{it.env == "${deploy_env}"})
        {
          remoteServerIP="${property.serverIP}"
          pathToSearch="${pipelineConfig.releasePath}/${pipelineConfig.typeProperties}"
          fileToSearch="${property.propertyName}"
          file=FindFileRemote(remoteServerIP, pathToSearch, fileToSearch)
          if ("${file}" == "${fileToSearch}"){
            echo "======> Coping File ${fileToSearch} to Backup to the tmp path ${varProperties.backupPathRoot}/tmp"
            commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",remoteServerIP,"${pipelineConfig.sshCredential}","cp ${pathToSearch}/${fileToSearch} ${varProperties.backupPathRoot}/tmp","STATUS")
            if (commandStatus != 0)
            {
              echo  "       ERROR. File ${fileToSearch} cannot be copied to ${varProperties.backupPathRoot}/tmp !!!"
              sh "exit 1"
            }
            isThereBackupProperties=true
            echo  "       Copied OK!!!"
          }
        }
        for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
        {
          ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
          if (isThereBackupProperties)
          {
          echo "======> Creating tar Backup file ${varProperties.backupFileName} in the tmp path ${varProperties.backupPathRoot}/tmp at ${servidor} (${ip})"
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","\'cd ${varProperties.backupPathRoot}/tmp;tar cvf ${varProperties.backupPathRoot}/${varProperties.backupFileName} .\'","STATUS")
          if (commandStatus != 0)
          {
            echo  "       ERROR. Cannot be created the ${varProperties.backupPathRoot}/${varProperties.backupFileName} !!!"
            sh "exit 1"
          }
          echo  "       Created OK!!!"
          }
          else {
            echo "======> Is no needed to create tar file because there is not nothing to backup in the tmp path ${varProperties.backupPathRoot}/tmp at ${servidor} (${ip})"
          }
          echo "======> Cleaning Backup tmp path ${varProperties.backupPathRoot}/tmp at ${servidor} (${ip})"
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","rm -fr ${varProperties.backupPathRoot}/tmp","STATUS")
          echo  "       Cleaned OK!!!"
        }
        break
      case "${pipelineConfig.typeWildFly}":
      echo "====> BACKUPS WILDFLY <===="
      if (varMain.binaryDeployedEnv != "")
      {
        for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
        {
          ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
          echo "======> Cleaning Backup tmp path ${varWildFly.backupPathRoot}/tmp at ${servidor} (${ip})"
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","rm -fr ${varWildFly.backupPathRoot}/tmp","STATUS")
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","mkdir -p ${varWildFly.backupPathRoot}/tmp","STATUS")
          echo  "       Cleaned OK!!!"
        }
        for (binary in binaryActionStatus)
        {
          remoteServerIP="${binary.serverIP}"
          pathToSearch="${pipelineConfig.releasePath}/${pipelineConfig.typeWildFly}"
          fileToSearch="${binary.binaryEnvironment}"
          echo "======> File to Backup ${fileToSearch}"
          file=FindFileRemote(remoteServerIP, pathToSearch, fileToSearch)
          if ("${file}" == "${fileToSearch}"){
            echo "======> Coping File ${fileToSearch} to Backup to the tmp path ${varWildFly.backupPathRoot}/tmp"
            commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",remoteServerIP,"${pipelineConfig.sshCredential}","cp ${pathToSearch}/${fileToSearch} ${varWildFly.backupPathRoot}/tmp","STATUS")
            if (commandStatus != 0)
            {
              echo  "       ERROR. File ${fileToSearch} cannot be copied to ${varProperties.backupPathRoot}/tmp !!!"
              sh "exit 1"
            }
            echo  "       Copied OK!!!"
          }
        }
        for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
        {
          ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
          echo "======> Creating tar Backup file ${varWildFly.backupFileName} in the tmp path ${varWildFly.backupPathRoot}/tmp at ${servidor} (${ip})"
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","\'cd ${varWildFly.backupPathRoot}/tmp;tar cvf ${varWildFly.backupPathRoot}/${varWildFly.backupFileName} .\'","STATUS")
          if (commandStatus != 0)
          {
            echo  "       ERROR. Cannot be created the ${varWildFly.backupPathRoot}/${varWildFly.backupFileName} !!!"
            sh "exit 1"
          }
          echo  "       Created OK!!!"
          echo "======> Cleaning Backup tmp path ${varWildFly.backupPathRoot}/tmp at ${servidor} (${ip})"
          commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}","rm -fr ${varWildFly.backupPathRoot}/tmp","STATUS")
          echo  "       Cleaned OK!!!"
        }
      } else {
        echo "======> Nothing to Backup. binary.binaryEnvironment == \"\" "
      }
      break
  }
}

def UpdateWildFlyAction (String ip, String micro, String location, String status)
{
  switch(location) {
      case "Environment":
        for (binary in binaryActionStatus.findAll{it.serverIP == ip && it.binaryEnvironment == micro})
        {
          binary.statusEnvironment=status
        }
        break
      case "Package":
        for (binary in binaryActionStatus.findAll{it.serverIP == ip && it.binaryPackage == micro})
        {
          binary.statusPackage=status
        }
        break
    }
}

def EnableDisableMicro (String action, String micro, String location)
{
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
  {
    if (micro != "") {
      connect="${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD "
      switch(action) {
          case "DISABLE":
            disable="--command=\\\"deployment disable ${micro}\\\""
            command=connect + disable
            _action="Disabling"
            status="Disabled"
            break
          case "ENABLE":
            curl_command="curl -s --location --request POST "
            enable="--command=\\\"deployment enable ${micro}\\\""
            command=connect + enable
            _action="Enabling"
            status="Enabled"
            break
        }
        for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
        {
          ip=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
          echo "======> ${_action} ${micro} at ${servidor} (${ip})"
          result=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}",command,"STATUS")
          if ("${result}" != "0")
          {
            echo "======> ERROR ${_action} for microService ${micro} at ${servidor} (${ip})"
            sh ("exit 1")
          }
          if (isThereWildFlyActions)
          {
            UpdateWildFlyAction(ip,micro,location,status)
          }
          if ("${action}" == "ENABLE" && "${pipelineConfig.needStartMicro}" == "Y")
          {
            urlStart="\"http://${ip}:${pipelineConfig.microServicePort}/${pipelineConfig.applicationName}${pipelineConfig.contextMicroServiceStart}\""
            echo "========> Starting ${micro} at ${servidor} (${ip})"
            result=ExecuteRemote("${pipelineConfig.releaseUser}",ip,"${pipelineConfig.sshCredential}",curl_command + urlStart,"STDOUT")
          }
        }
      } else {
        echo "THERE IS NOT ANY MICRO TO ENABLE/DISABLE."
      }
    }
}

/**********************************************************************
DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY
DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY
DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY DEPLOY
**********************************************************************/
def DeployDataBase () {
    echo "====> DEPLOY DATABASE <===="
    for( DM in dataModuleActionStatus)
    {
      _DBInfo=envConfig["Entornos"][deploy_env]["DataBases"]
      withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${_DBInfo.Password_File}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
      {
        schamanDBproxyCommand="java -jar ${pipelineConfig.schamanDBproxyPath}/${pipelineConfig.schamanDBproxyJar} -u ${USERNAME} -p ${PASSWORD}"
        serverIP = _DBInfo.Proxy_Server.ServerIP
        serverName = _DBInfo.Proxy_Server.ServerName
        DBproxyServer=" -S ${_DBInfo.databaseServer}"
        DBproxyPort=" -P ${_DBInfo.Port}"
        DBproxyDBName= " -D ${_DBInfo.database}"
        DBproxyConnParam= " -C \"${_DBInfo.Parameters}\""
        DBproxyFile=" -f ${varDataBase.stagePathPackage}/${DM.ModuleFileName}"
        command=schamanDBproxyCommand + DBproxyServer + DBproxyPort + DBproxyDBName + DBproxyConnParam + DBproxyFile
        echo "====>      Data Module to execute:          ${DM.ModuleFileName}"
        echo "======>    (If ERROR) RollBack Module:          ${DM.RollBackModuleFileName}"
        echo "======>    Command to execute: ${command}"
        echo "======>    Executing ......."
        Order=DM.Order
        Module=DM.ModuleFileName
        result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
        if (result != 0)
        {
          DM.StatusGO="KO"
          sh "exit 1"
        }
        DM.StatusGO="OK"
        PrintDataModules(dataModuleActionStatus)
    }
  }
}

def DeployProperties () {
  echo "====> DEPLOY PROPERTIES <===="
  for( property in propertyActionStatus)
  {
    command="mv ${varProperties.stagePathPackage}/${property.propertyName} ${varProperties.releasePath}/."
    serverIP=property.serverIP
    result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
    if (result != 0)
    {
      property.status="Error"
      echo "${propertyActionStatus}"
      sh "exit 1"
    } else {
        property.status="Deployed"
    }
  }
  echo "${propertyActionStatus}"
}

def DeployWildFly () {
  echo "====> DEPLOY WILDFLY <===="
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
  {
    connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
    for( binary in binaryActionStatus)
    {
      binPackage = "${binary.binaryPackage}"
      binEnvironment = "${binary.binaryEnvironment}"
      serverName = "${binary.serverName}"
      serverIP = "${binary.serverIP}"
      install=" --command=\\\"deployment deploy-file ${varWildFly.stagePathPackage}/${binPackage} --disabled"
      replace = ""
      if (binary.binaryPackage==binary.binaryEnvironment) {
          replace = " --replace"
      }
      // Code for test
      //if (serverIP == "10.167.74.166"){
        //echo "ERROR FORZADO MAQUINA 10.167.74.166"
        //echo "${binaryActionStatus}"
        //sh "exit 1"
      //}
      echo "    =======> Deploying binaries (Disabled Status) at ${serverName} (${serverIP})<======="
      command=connect + install + replace + "\\\""
      result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      if (result != 0)
      {
        echo "${binaryActionStatus}"
        sh "exit 1"
      } else {
        binary.statusPackage="Disabled"
        if (binary.binaryPackage==binary.binaryEnvironment) {
            binary.statusEnvironment="Undeployed"
        }
        echo "        =>${binPackage}     - Status: ${binary.statusPackage}"
        echo "        =>${binEnvironment} - Status: ${binary.statusEnvironment}"
        echo "${binaryActionStatus}"
      }
    }
  }
}

def UndeployMicro(String micro)
{
  echo "====> UNDEPLOY MICRO <===="
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
  {
    if (micro != "")
    {
      connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"
      for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
      {
        serverIP=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
        echo "======> Undeploying ${micro} at ${servidor} (${serverIP})"
        undeploy=" --command=\\\"deployment undeploy ${micro}\\\""
        command=connect + undeploy
        result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
        if (result != 0)
        {
          echo "        ERROR. Undeploy of the old binaries cannot be done.!!!"
          sh "exit 1"
        } else {
          echo "        Undeployed OK!!!"
        }
        if (isThereWildFlyActions)
        {
          UpdateWildFlyAction(serverIP,micro,"Environment","Undeployed")
          echo "binaryActionStatus: "
          echo "${binaryActionStatus}"
        }
      }
    }
    else
    {
      echo "======> Nothing to Undeploy, there isn't a previous version installed in the environment"
    }
  }
}

def UpdateRelease()
{
  echo "====> UPDATE RELEASE <===="

  for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
  {
    serverIP=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
    echo "======> Updating release for ${servidor} (${serverIP})"

    if (varMain.binaryDeployedEnv != "")
    {
      echo "========> Deleting old binary ${varMain.binaryDeployedEnv}"
      command="rm -f ${varWildFly.releasePath}/${varMain.binaryDeployedEnv}"
      result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      if (result != 0)
      {
        echo "        ERROR. Deleting old binary ${varMain.binaryDeployedEnv} from release path ${varWildFly.releasePath}!!!"
        sh "exit 1"
      }
    } else {
      echo "========> There isn't old binary to delete"
    }
    echo "========> Adding new binary ${varMain.binaryPackage}"
    command="cp -rp ${varWildFly.stagePathPackage}/${varMain.binaryPackage} ${varWildFly.releasePath}/."
    result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
    if (result != 0)
    {
      echo "        ERROR. Adding new binary ${varMain.binaryPackage} to the release path ${varWildFly.releasePath}!!!"
      sh "exit 1"
    }
  }
}

def CleanEnvironment(){
  echo "====> CLEAN ENVIRONMENT <===="
  for (servidor in envConfig["Entornos"]["${deploy_env}"]["Servers"].keySet())
  {
    serverIP=envConfig["Entornos"]["${deploy_env}"]["Servers"]["${servidor}"]
    echo "======> Cleaning Remote for ${servidor} (${serverIP})"
    if (isTherePropertyActions){
      echo "========> Cleaning stage zone ${varProperties.stagePathPackage} for Properties"
      command="rm -fr ${varProperties.stagePathPackage}"
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Cleaned OK!!!"
      echo "========> Cleaning Backup zone ${varProperties.backupPathRoot} for Properties"
      command="\"cd ${varProperties.backupPathRoot};ls -t | awk \'NR>${pipelineConfig.maxBackupNumProperties}\' | xargs rm -f\""
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Cleaned OK!!!"
    }
    if (isThereWildFlyActions){
      echo "========> Cleaning stage zone ${varWildFly.stagePathPackage} for WildFly"
      command="rm -fr ${varWildFly.stagePathPackage}"
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Cleaned OK!!!"
      echo "========> Cleaning Backup zone ${varWildFly.backupPathRoot} for WildFly"
      command="\"cd ${varWildFly.backupPathRoot};ls -t | awk \'NR>${pipelineConfig.maxBackupNumWildFly}\' | xargs rm -f\""
      commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      echo  "         Cleaned OK!!!"
    }
  }
  if (isThereDBActions){
    servidor=envConfig["Entornos"]["${deploy_env}"]["DataBases"].Proxy_Server
    echo "======> Cleaning at ${servidor.ServerName} (${servidor.ServerIP})"
    echo "========> Cleaning stage zone ${varDataBase.stagePathPackage} for DataBase"
    commandStatus=ExecuteRemote("${pipelineConfig.releaseUser}",servidor.ServerIP,"${pipelineConfig.sshCredential}","rm -fr ${varDataBase.stagePathPackage}","STATUS", false)
    echo  "         Cleaned OK!!!"
  }
  echo "======> Cleaning Local at ${"hostname".execute().text}"
  echo "======> Cleaning extract Folder ${varMain.localPrePath}/${pipelineConfig.extractFolder}"
  sh (script:"rm -fr ${pipelineConfig.extractFolder}", returnStatus:false)
  echo  "         Cleaned OK!!!"
}

/**********************************************************************
ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK
ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK
ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK ROLLBACK
**********************************************************************/

def RollBackDataBase (){
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "!!!!!!!!STARTING ROLLBACK DATABASE!!!!!!!!"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "Start TimeStamp:  ${new Date()}"
  echo "Status Actions Before the RollBack:"
  PrintDataModules(dataModuleActionStatus)
  index=dataModuleActionStatus.findIndexOf{it.ModuleFileName == Module && it.Order == Order}
  for( int i = index; i>= 0; i--)
  {
    _DBInfo=envConfig["Entornos"][deploy_env]["DataBases"]
    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${_DBInfo.Password_File}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
    {
      schamanDBproxyCommand="java -jar ${pipelineConfig.schamanDBproxyPath}/${pipelineConfig.schamanDBproxyJar} -u ${USERNAME} -p ${PASSWORD}"
      serverIP = _DBInfo.Proxy_Server.ServerIP
      serverName = _DBInfo.Proxy_Server.ServerName
      DBproxyServer=" -S ${_DBInfo.databaseServer}"
      DBproxyPort=" -P ${_DBInfo.Port}"
      DBproxyDBName= " -D ${_DBInfo.database}"
      DBproxyConnParam= " -C \"${_DBInfo.Parameters}\""
      DBproxyFile=" -f ${varDataBase.stagePathPackage}/${dataModuleActionStatus[i].RollBackModuleFileName}"

      command=schamanDBproxyCommand + DBproxyServer + DBproxyPort + DBproxyDBName + DBproxyConnParam + DBproxyFile
      echo "====>      RollBack Module to execute:           ${dataModuleActionStatus[i].RollBackModuleFileName}"
      echo "======>    Command to execute: ${command}"
      echo "======>    Executing ......."
      result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      if (result != 0)
      {
        dataModuleActionStatus[i].StatusRollBack="KO"
        sh "exit 1"
      }
      dataModuleActionStatus[i].StatusRollBack="OK"
    }
  }
  PrintDataModules(dataModuleActionStatus)
  echo "End TimeStamp:  ${new Date()}"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "!!!!!!!!END ROLLBACK DATABASE!!!!!!!!"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
}

def RollBackProperties () {
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "!!!!!!!!STARTING ROLLBACK PROPERTIES!!!!!!!!"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "Start TimeStamp:  ${new Date()}"
  echo "propertyActionStatus: "
  echo "${propertyActionStatus}"
  for( property in propertyActionStatus)
  {
    serverIP=property.serverIP
    if (property.status == "Deployed")
    {
      result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}","\'rm -f ${varProperties.releasePath}/${property.propertyName} \'","STATUS",false)
      if (result != 0)
      {
        property.status="RollBack Error"
        echo "${propertyActionStatus}"
        sh "exit 1"
      }
    }
    property.status="Deleted file in the release path"
    echo "${propertyActionStatus}"
    if (isThereBackupProperties)
    {
      result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}","\'cd ${varProperties.releasePath}/.;cp ${varProperties.backupPathRoot}/${varProperties.backupFileName} .;tar xvf ${varProperties.backupFileName};rm -f ${varProperties.backupFileName}\'","STATUS",false)
      if (result != 0)
      {
        property.status="RollBack Error"
        echo "${propertyActionStatus}"
        sh "exit 1"
      } else {
          property.status="RollBacked"
      }
    }
    else{
      echo "Nothing to restore"
      property.status="RollBacked"
    }
  }
  echo "propertyActionStatus: "
  echo "${propertyActionStatus}"
  echo "End TimeStamp:  ${new Date()}"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "!!!!!!!!END ROLLBACK PROPERTIES!!!!!!!!"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
}

def RollBackWildFly () {
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "!!!!!!!!STARTING ROLLBACK WILDFLY!!!!!!!!"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "Start TimeStamp:  ${new Date()}"
  echo "binaryActionStatus: "
  echo "${binaryActionStatus}"
  withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"${pipelineConfig.credentialJBCli}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']])
  {
    connect = "${pipelineConfig.jbossCliPath}/${pipelineConfig.jbossCliName} --connect -u=$USERNAME -p=$PASSWORD"

    //DISABLE PACKAGE BINARY
    for( binary in binaryActionStatus.findAll{it.statusPackage == "Enabled"})
    {
      binPackage = "${binary.binaryPackage}"
      binEnvironment = "${binary.binaryEnvironment}"
      serverName = "${binary.serverName}"
      serverIP = "${binary.serverIP}"
      disable=" --command=\\\"deployment disable ${binary.binaryPackage}\\\""
      echo "    =======> Disabling binary ${binary.binaryPackage} at ${serverName} (${serverIP})<======="
      command=connect + disable
      result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      if (result != 0)
      {
        echo "${binaryActionStatus}"
        sh "exit 1"
      } else {
        binary.statusPackage="Disabled"
        echo "        =>${binPackage}       - Status: ${binary.statusPackage}"
        echo "        =>${binEnvironment}   - Status: ${binary.statusEnvironment}"
        echo "${binaryActionStatus}"
      }
    }

    //UNDEPLOY PACKAGE BINARY
    for( binary in binaryActionStatus.findAll{it.statusPackage == "Disabled"})
    {
      binPackage = "${binary.binaryPackage}"
      binEnvironment = "${binary.binaryEnvironment}"
      serverName = "${binary.serverName}"
      serverIP = "${binary.serverIP}"
      undeploy=" --command=\\\"deployment undeploy ${binary.binaryPackage}\\\""
      echo "    =======> Undeploying binary ${binary.binaryPackage} at ${serverName} (${serverIP})<======="
      command=connect + undeploy
      result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      if (result != 0)
      {
        echo "${binaryActionStatus}"
        sh "exit 1"
      } else {
        binary.statusPackage="Undeployed"
        echo "        =>${binPackage}     - Status: ${binary.statusPackage}"
        echo "        =>${binEnvironment} - Status: ${binary.statusEnvironment}"
        echo "${binaryActionStatus}"
      }
    }

    //DEPLOY ENVIRONMENT BINARY IF NEEED
    for( binary in binaryActionStatus.findAll{it.statusEnvironment == "Undeployed"})
    {
      binPackage = "${binary.binaryPackage}"
      binEnvironment = "${binary.binaryEnvironment}"
      serverName = "${binary.serverName}"
      serverIP = "${binary.serverIP}"
      install=" --command=\\\"deployment deploy-file ${varWildFly.backupPathRoot}/tmp/${binEnvironment} --disabled\\\""
      echo "    =======> Recovering from backup binary ${binary.binaryEnvironment} at ${serverName} (${serverIP})<======="
      ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}","\'mkdir ${varWildFly.backupPathRoot}/tmp;cp ${varWildFly.backupPathRoot}/${varWildFly.backupFileName} ${varWildFly.backupPathRoot}/tmp/.;cd ${varWildFly.backupPathRoot}/tmp; tar xvf ${varWildFly.backupFileName}\'","STATUS",false)
      echo "    =======> Deploy binary ${binary.binaryEnvironment} at ${serverName} (${serverIP})<======="
      command=connect + install
      result=ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}",command,"STATUS",false)
      if (result != 0)
      {
        echo "${binaryActionStatus}"
        sh "exit 1"
      } else {
        binary.statusEnvironment="Disabled"
        echo "        =>${binPackage}     - Status: ${binary.statusPackage}"
        echo "        =>${binEnvironment} - Status: ${binary.statusEnvironment}"
        echo "${binaryActionStatus}"
      }
      echo "    =======> Delete tmp path from backup directory at ${serverName} (${serverIP})<======="
      ExecuteRemote("${pipelineConfig.releaseUser}",serverIP,"${pipelineConfig.sshCredential}","\'rm -fr ${varWildFly.backupPathRoot}/tmp\'","STATUS",false)
    }
  }
  echo "binaryActionStatus: "
  echo "${binaryActionStatus}"
  echo "End TimeStamp:  ${new Date()}"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "!!!!!!!!END ROLLBACK WILDFLY!!!!!!!!"
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
}

def RollBack(err){
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "!!!!!!!!STARTING THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!STARTING THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "Start TimeStamp:  ${new Date()}"
    echo "Stage error at: ${stageError}"
    echo "Error Details: ${err}"

    switch(stageError) {
        case ["Prepare","CleanAndUploadtoStage","Backups"]:
            echo "NOTHING TO ROLLBACK. WE CANNOT CONTINUE WITH THE PROMOTION. THIS MUST NOT OCCUR"
            echo "NOTHING TO ROLLBACK. WE CANNOT CONTINUE WITH THE PROMOTION. THIS MUST NOT OCCUR"
            echo "NOTHING TO ROLLBACK. WE CANNOT CONTINUE WITH THE PROMOTION. THIS MUST NOT OCCUR"
            break
        case "DisableMicro":
                echo "WAS UNABLE TO STOP DISABLE THE MICRO. PLEASE IS NEEDED TO REVIEW THE ENVIRONMET IN ORDER TO CHECK IF ALL IS UP AND LET KNOW THE ISSUE TO ENVIRONMENT TEAM. THIS MUST NOT OCCUR"
                echo "WAS UNABLE TO STOP DISABLE THE MICRO. PLEASE IS NEEDED TO REVIEW THE ENVIRONMET IN ORDER TO CHECK IF ALL IS UP AND LET KNOW THE ISSUE TO ENVIRONMENT TEAM. THIS MUST NOT OCCUR"
                echo "WAS UNABLE TO STOP DISABLE THE MICRO. PLEASE IS NEEDED TO REVIEW THE ENVIRONMET IN ORDER TO CHECK IF ALL IS UP AND LET KNOW THE ISSUE TO ENVIRONMENT TEAM. THIS MUST NOT OCCUR"
                CleanEnvironment()
                break
        case "DeployDataBase":
            RollBackDataBase()
            EnableDisableMicro("ENABLE", varMain.binaryDeployedEnv,"Environment")
            CleanEnvironment()
            break
        case "DeployProperties":
            if (isThereDBActions){
              RollBackDataBase()
            }
            RollBackProperties()
            EnableDisableMicro("ENABLE", varMain.binaryDeployedEnv,"Environment")
            CleanEnvironment()
            break
        case ["DeployWildFly","EnableMicro"]:
            if (isThereDBActions){
              RollBackDataBase()
            }
            if (isTherePropertyActions){
              RollBackProperties()
            }
            RollBackWildFly()
            EnableDisableMicro("ENABLE", varMain.binaryDeployedEnv,"Environment")
            CleanEnvironment()
            break
        case ["UpdateWildFly","UpdateRelease", "CleanEnvironment"]:
            echo "THE PROMOTION ENDS OK BUT WE CANNOT UPDATE THE WILDFLY, THE RELEASE OR CLEAN THE ENVIRONMENT. MANUAL UPDATE IS NEEDED. THIS MUST NOT OCCUR."
            echo "THE PROMOTION ENDS OK BUT WE CANNOT UPDATE THE WILDFLY, THE RELEASE OR CLEAN THE ENVIRONMENT. MANUAL UPDATE IS NEEDED. THIS MUST NOT OCCUR."
            echo "THE PROMOTION ENDS OK BUT WE CANNOT UPDATE THE WILDFLY, THE RELEASE OR CLEAN THE ENVIRONMENT. MANUAL UPDATE IS NEEDED. THIS MUST NOT OCCUR."
            break
    }

    currentBuild.result = Result.FAILURE
    echo "End TimeStamp:  ${new Date()}"
    error('!!!!!!!!AUTOMATED ROLLBACK ENDED SUCCESSFULLY!!!!!!!!')
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "!!!!!!!!END THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!END THE ROLLBACK!!!!!!!!"
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
}

def GetAnnexesAndModulesToLocal()
{
  if (isThereDBActions)
  {
      echo "========> Download Modules to Remote Server ${pipelineConfig.annexesServer}"
      replica_datos(pipelineConfig.applicationName,deploy_env,crq_id,pckDatabase)
      echo "========> Download Modules to Local Path ${varMain.modulesLocalRelativePath}"
      sh(script:"rm -fr ${varMain.modulesLocalRelativePath}", returnStatus:false)
      sh(script:"mkdir -p ${varMain.modulesLocalRelativePath}")
      sh("scp -o ConnectTimeout=30 ${pipelineConfig.annexesUser}@${pipelineConfig.annexesServer}:${varMain.modulesRemoteAbsolutePath}/* ${varMain.modulesLocalRelativePath}/.")
      for (pck in pckDatabase.split(' '))
      {
          count=sh(script:"ls -1 ${varMain.modulesLocalRelativePath}/*_${pck}_*| wc -l", returnStdout:true)
          if (count.toInteger() == 0)
          {
            echo "          ERROR. There is no DataModules in the package ${pck}"
            sh("exit 1")
          }
      }

      echo "          Modules Downloaded OK!!!"
      echo "========> Download modules.json to Local Path ${varMain.packageBasePath}"
      sh("scp -o ConnectTimeout=30 ${pipelineConfig.annexesUser}@${pipelineConfig.annexesServer}:${varMain.modulesRemoteAbsolutePath}/../modules.json ${varMain.packageBasePath}/.")
      echo "          modules.json Downloaded OK!!!"
  }

  if (isTherePropertyActions)
  {
    echo "========> Download Modules to Remote Server ${pipelineConfig.annexesServer}"
    replica_datos(pipelineConfig.applicationName,deploy_env,crq_id,pckProperties)
    echo "========> Download Properties to Local Path ${varMain.annexesLocalRelativePath}"
    sh(script:"rm -fr ${varMain.annexesLocalRelativePath}", returnStatus:false)
    sh(script:"mkdir -p ${varMain.annexesLocalRelativePath}")
    count=sh(script:"ssh -o ConnectTimeout=30 ${pipelineConfig.annexesUser}@${pipelineConfig.annexesServer} \"ls -1 ${varMain.annexesRemoteAbsolutePath}/*_${pckProperties}_* | wc -l\"", returnStdout:true)
    if (count.toInteger() == 0)
    {
      echo "          ERROR. There is no annexes in the package ${pckProperties}"
      sh("exit 1")
    }
    sh("scp -o ConnectTimeout=30 ${pipelineConfig.annexesUser}@${pipelineConfig.annexesServer}:${varMain.annexesRemoteAbsolutePath}/*_${pckProperties}_* ${varMain.annexesLocalRelativePath}/.")
    echo "          Properties Downloaded OK!!!"
    echo "========> Find *_${pckProperties}_${pipelineConfig.deployConfig} File"
    if (!ExistFile("${varMain.localPrePath}/${varMain.annexesLocalRelativePath}/*_${pckProperties}_${pipelineConfig.deployConfig}"))
    {
      echo "      ERROR.  There is annexes but *_${pckProperties}_${pipelineConfig.deployConfig} File not found. Exit with error"
      sh ("exit 1")
    }
    echo "          *_${pckProperties}_${pipelineConfig.deployConfig} File Found OK!!!"
    count=sh(script:"grep \"property:\" ${varMain.annexesLocalRelativePath}/*_${pckProperties}_${pipelineConfig.deployConfig} | wc -l", returnStdout:true)
    if (count.toInteger() == 0)
    {
      echo "          ERROR. There is no Property key in the *_${pckProperties}_${pipelineConfig.deployConfig} file"
      sh("exit 1")
    }
    echo "          Key binary Found at file *_${pckProperties}_${pipelineConfig.deployConfig}!!!"
    echo "========> Creating the new ${pipelineConfig.deployConfig} File"
    sh(script:"cat ${varMain.localPrePath}/${varMain.annexesLocalRelativePath}/*_${pckProperties}_${pipelineConfig.deployConfig} | grep \"property:\" >> ${varMain.packageBasePath}/${pipelineConfig.deployConfig}")
    echo "========> Deleting the old *_${pckProperties}_${pipelineConfig.deployConfig} File"
    sh(script:"rm -f ${varMain.localPrePath}/${varMain.annexesLocalRelativePath}/*_${pckProperties}_${pipelineConfig.deployConfig}")
  }

  if (isThereWildFlyActions)
  {
    echo "========> Download Modules to Remote Server ${pipelineConfig.annexesServer}"
    replica_datos(pipelineConfig.applicationName,deploy_env,crq_id,pckWildfly)
    echo "========> Download deployConfig file for Wildfly to Local Path ${varMain.wildFlyLocalRelativePath}"
    sh(script:"rm -fr ${varMain.wildFlyLocalRelativePath}", returnStatus:false)
    sh(script:"mkdir -p ${varMain.wildFlyLocalRelativePath}")
    count=sh(script:"ssh -o ConnectTimeout=30 ${pipelineConfig.annexesUser}@${pipelineConfig.annexesServer} \"ls -1 ${varMain.annexesRemoteAbsolutePath}/*_${pckWildfly}_* | wc -l\"", returnStdout:true)
    if (count.toInteger() == 0)
    {
      echo "          ERROR. There is no annexes in the package ${pckWildfly}"
      sh("exit 1")
    }
    status=sh(script:"scp -o ConnectTimeout=30 ${pipelineConfig.annexesUser}@${pipelineConfig.annexesServer}:${varMain.annexesRemoteAbsolutePath}/*_${pckWildfly}_${pipelineConfig.deployConfig} ${varMain.wildFlyLocalRelativePath}/.", returnStatus:true)
    if (status != 0)
    {
      echo "      ERROR.  There is annexes but *_${pckWildfly}_${pipelineConfig.deployConfig} File not found on remote server. Exit with error"
      sh ("exit 1")
    }
    if (!ExistFile("${varMain.localPrePath}/${varMain.wildFlyLocalRelativePath}/*_${pckWildfly}_${pipelineConfig.deployConfig}"))
    {
      echo "      ERROR.  There is annexes but *_${pckWildfly}_${pipelineConfig.deployConfig} File not found on local server. Exit with error"
      sh ("exit 1")
    }
    echo "          *_${pckWildfly}_${pipelineConfig.deployConfig} File Found OK!!!"
    count=sh(script:"grep \"binary:\" ${varMain.wildFlyLocalRelativePath}/*_${pckWildfly}_${pipelineConfig.deployConfig} | wc -l", returnStdout:true)
    if (count.toInteger() == 0)
    {
      echo "          ERROR. There is no binary key in the *_${pckWildfly}_${pipelineConfig.deployConfig} file"
      sh("exit 1")
    }
    echo "          Key binary Found at file *_${pckWildfly}_${pipelineConfig.deployConfig}!!!"
    echo "========> Creating the new ${pipelineConfig.deployConfig} File"
    sh(script:"cat ${varMain.localPrePath}/${varMain.wildFlyLocalRelativePath}/*_${pckWildfly}_${pipelineConfig.deployConfig} | grep \"binary:\" >> ${varMain.packageBasePath}/${pipelineConfig.deployConfig}")
    echo "========> Deleting the old *_${pckWildfly}_${pipelineConfig.deployConfig} File"
    sh(script:"rm -f ${varMain.localPrePath}/${varMain.wildFlyLocalRelativePath}/*_${pckWildfly}_${pipelineConfig.deployConfig}")
  }
}

def RenameProperties(){
  properties=sh(script:"ls -1 ${varMain.annexesLocalRelativePath}", returnStatus:false, returnStdout:true).trim()
  ar_properties=properties.split("\\r?\\n")
  echo "====> Renaming Properties names change by ReplicaDatos"
  for (property in ar_properties)
  {
    echo "      Property Name (ReplicaDatos): ${property}"
    (_order,_package,_context,_extension,_server,_env)=ReturnSplitNameProperties_ReplicaDatos(property)
    if (_order == null || _package == null || _context == null || _extension == null || _server == null || _env == null )
    {
      echo "               Failed!!!!. Property File ${propertytoDeploy} Naming Malformed"
      echo "                   Must to be:"
      echo '                          {order}_{package}_{context_path}.extension_{server_name}_{PPRD|PROD}'
      sh("exit 1")
    }
    echo "      Property Name (Real): ${_context}.${_extension}_${_server}_${_env}"
    sh(script:"mv ${varMain.annexesLocalRelativePath}/${property} ${varMain.annexesLocalRelativePath}/${_context}.${_extension}_${_server}_${_env}", returnStatus:true)
    echo "      Renaming OK!!!"
  }
}

def call(Map pipelineParams){
        pipeline{
            agent {label "SCHAMAN-Consolas"}
            parameters{
                string(name: 'CRQ_ID', defaultValue: '', description: 'CRQ_ID or Package Name')
                string(name: 'PCK_IDS_DATABASE', defaultValue: '', description: 'Package IDs (in Order) to deploy at Database. Allowed values WorkBench Package IDs. Multiple IDs blank space separated')
                string(name: 'PCK_ID_PROPERTIES', defaultValue: '', description: 'Package where is the Propertie(s) file version to deploy. Allowed value WorkBench Package ID (only one package).')
                string(name: 'PCK_ID_WYLDFLY', defaultValue: '', description: 'Package where is the WildFly binary version to deploy. Allowed values WorkBench Package ID (only one package).')
                string(name: 'ENVIRONMENT', defaultValue: 'PROD', description: 'Target Enviroment to deploy. Only Allowed PROD')
                string(name: 'PackageInfo', defaultValue: '', description: '')
            }
            stages{
                stage("Prepare"){
                    agent {label "SCHAMAN-Consolas"}
                    steps{
                        script{
                          try {
                            isThereBackupProperties=false

                            hoy=new Date().format('yyyyMMdd')
                            date4File=new Date().format('yyyyMMdd_HHmmss')

                            echo "########################################"
                            echo "###########START PREPARE PHASE##########"
                            echo "########################################"
                            echo "Start TimeStamp:  ${new Date()}"
                            stageError="Prepare"

                            binaryActionStatus=[]
                            propertyActionStatus=[]
                            dataModuleActionStatus = new ArrayList<DataModule>();
                            varMain=[:]
                            varDataBase=[:]
                            varProperties=[:]
                            varWildFly=[:]


                            localPrePath=sh(script:"pwd",  returnStatus: false, returnStdout: true)
                            localPrePath=localPrePath.trim()

                            if (params.PackageInfo=="")
                            {
                                // executed manually
                                echo "    Manual or Jenkins GUI execution!!!"
                                crq_id=params.CRQ_ID.trim()
                                pckDatabase=params.PCK_IDS_DATABASE.trim()
                                pckProperties=params.PCK_ID_PROPERTIES.trim()
                                pckWildfly=params.PCK_ID_WYLDFLY.trim()
                                deploy_env=params.ENVIRONMENT.trim()
                            }else{
                                error(" WorkBench execution is not allowed !!!!")
                            }


                            echo "Reading pipelineConfig File: ${pipelineParams.pipelineConfigFile}"
                            pipelineConfig=readYaml(file: pipelineParams.pipelineConfigFile)

                            if (!CheckpipelineConfig())
                            {
                              echo "ERROR. Some keys at ${pipelineParams.pipelineConfigFile} File missed!!!!!. Cannot Continue!!!!"
                              sh "exit 1"
                            }

                            if(deploy_env=="" || crq_id == "") {
                                error("deploy_env [${deploy_env}] listapaquetes [${listapaquetes}] and crq_id [${crq_id}] are mandatories.")
                            }

                            if(deploy_env != "PROD") {
                                error("Only allowed for PROD!!!.")
                            }

                            echo "Reading EnvConfig File: ${pipelineConfig.envConfig}"
                            envConfig=readJSON(file: pipelineConfig.envConfig)

                            jobDisplayName = "CRQ_ID: ${crq_id} Artifact: ${pipelineConfig.applicationName} Environment: ${deploy_env}"
                            jobDescription = "CRQ_ID: ${crq_id} Artifact: ${pipelineConfig.applicationName} Environment: ${deploy_env}"
                            currentBuild.displayName = jobDisplayName
                            currentBuild.description = jobDescription

                            DefineGlobalVariables("Main")
                            echo "Main Variables :"
                            varMain.each{entry -> echo "     $entry.key: $entry.value"}

                            echo "====> Clean Environment"
                            //sh (script:"rm -fr ${pipelineConfig.extractFolder}", returnStatus:false)
                            sh (script:"mkdir ${pipelineConfig.extractFolder}", returnStatus:false)
                            sh (script:"rm -fr ${varMain.annexesLocalRelativePath}", returnStatus:false)
                            sh (script:"mkdir -p ${varMain.annexesLocalRelativePath}")
                            sh (script:"rm -fr ${varMain.modulesLocalRelativePath}", returnStatus:false)
                            sh (script:"mkdir -p ${varMain.modulesLocalRelativePath}")

                            isThereDBActions=false
                            isThereWildFlyActions=false
                            isTherePropertyActions=false

                            if (pckDatabase != "")
                            {
                              isThereDBActions=true
                            }
                            if (pckProperties != "")
                            {
                              pckPro=pckProperties.split(' ')
                              if (pckPro.size() > 1)
                              {
                                echo "ERROR. Only admited one package for Properties type!!!"
                                sh("exit 1")
                              }
                              isTherePropertyActions=true
                            }
                            if (pckWildfly != "")
                            {
                              pckWild=pckWildfly.split(' ')
                              if (pckWild.size() > 1)
                              {
                                echo "ERROR. Only admited one package for WildFly type!!!"
                                sh("exit 1")
                              }
                              isThereWildFlyActions=true
                            }
                            if (!isThereDBActions && !isThereWildFlyActions && !isTherePropertyActions)
                            {
                              echo "ERROR. Not Actions found. Maybe the package is void?!!!"
                              sh "exit 1"
                            }

                            GetAnnexesAndModulesToLocal()

                            if (isThereDBActions)
                            {
                              echo "========> Load modules.json"
                              modules=readJSON(file: "${varMain.packageBasePath}/modules.json")
                              varMain.numModulesPackage=modules.Modules.size()
                              echo "        ${varMain.packageBasePath}/modules.json File Loaded OK!!!"
                            }

                            if (isThereWildFlyActions || isTherePropertyActions)
                            {
                              echo "========> Load ${pipelineConfig.deployConfig}"
                              deployConfig=readYaml(file: "${varMain.packageBasePath}/${pipelineConfig.deployConfig}")
                              echo "        ${varMain.packageBasePath}/${pipelineConfig.deployConfig} File Loaded OK!!!"
                            }

                            //CheckActions()

                            GettingBinaryForEnableDisableActions()
                            if (varMain.binaryDeployedEnv == "")
                            {
                              CreatingPathsForNewMicro()
                            }

                            //GettingEnableDisableInfo()


                            if (isThereWildFlyActions)
                            {
                              DefineGlobalVariables("${pipelineConfig.typeWildFly}")
                              echo "Variables for WildFly:"
                              varWildFly.each{entry -> echo "     $entry.key: $entry.value"}
                              IntegrityChecks("${pipelineConfig.typeWildFly}")
                              LoadInMemoryHashMap("${pipelineConfig.typeWildFly}")
                            }

                            if (isTherePropertyActions)
                            {
                              DefineGlobalVariables("${pipelineConfig.typeProperties}")
                              echo "Variables for Properties:"
                              varProperties.each{entry -> echo "     $entry.key: $entry.value"}
                              echo "${varProperties}"
                              RenameProperties()
                              IntegrityChecks("${pipelineConfig.typeProperties}")
                              LoadInMemoryHashMap("${pipelineConfig.typeProperties}")
                            }

                            if (isThereDBActions)
                            {
                              DefineGlobalVariables("${pipelineConfig.typeDataBase}")
                              echo "Variables for DataBase:"
                              varDataBase.each{entry -> echo "     $entry.key: $entry.value"}
                              IntegrityChecks("${pipelineConfig.typeDataBase}")
                              LoadInMemoryHashMap("${pipelineConfig.typeDataBase}")
                            }


                            // TODO : when
                            echo "Deploy Main Info:"
                            echo "    DeployEnv:                      ${deploy_env}"
                            echo "    CRQ ID:                         ${crq_id}"
                            echo "    Package DataBase:               ${pckDatabase}"
                            echo "    Package Properties:             ${pckProperties}"
                            echo "    Package WildFly:                ${pckWildfly}"

                            if (isThereDBActions){
                              echo "    DataBase: ......................"
                              PrintDataModules(dataModuleActionStatus)
                            }
                            if (isTherePropertyActions){
                              echo "    Properties: ...................."
                              echo "${propertyActionStatus}"
                            }
                            if (isThereWildFlyActions){
                              echo "    WildFly: ......................."
                              echo "${binaryActionStatus}"
                            }

                            echo "End TimeStamp:  ${new Date()}"
                            echo "########################################"
                            echo "############END PREPARE PHASE###########"
                            echo "########################################"
                          }
                          catch (err)
                          {
                              echo "######################################"
                              echo "########ERROR IN PREPARE PHASE########"
                              echo "########ERROR IN PREPARE PHASE########"
                              echo "######################################"
                              RollBack(err)
                          }
                        }
                    }
                }

                stage('CleanAndUploadtoStage'){
                    agent{label "SCHAMAN-Consolas"}
                    steps{
                        script{
                          try
                          {
                            echo "##########################################################"
                            echo "###########START CLEAN AND UPLOAD TO STAGE PHASE##########"
                            echo "##########################################################"
                            echo "Start TimeStamp:  ${new Date()}"
                            stageError="CleanAndUploadtoStage"
                            if (isThereDBActions) {
                              CleanAndUploadtoStage("${pipelineConfig.typeDataBase}")
                            }
                            if (isTherePropertyActions) {
                              CleanAndUploadtoStage("${pipelineConfig.typeProperties}")
                            }
                            if (isThereWildFlyActions) {
                              CleanAndUploadtoStage("${pipelineConfig.typeWildFly}")
                            }
                            echo "End TimeStamp:  ${new Date()}"
                            echo "##########################################################"
                            echo "############END CLEAN AND UPLOAD TO STAGE PHASE###########"
                            echo "##########################################################"
                          }
                          catch (err)
                          {
                              echo "########################################################"
                              echo "########ERROR IN CLEAN AND UPLOAD TO STAGE PHASE########"
                              echo "########ERROR IN CLEAN AND UPLOAD TO STAGE PHASE########"
                              echo "########################################################"
                              RollBack(err)
                          }
                        }
                    }
                }
                stage('Backups'){
                    agent{label "SCHAMAN-Consolas"}
                    steps{
                        script{
                          try
                          {
                            echo "#######################################"
                            echo "###########START BACKUP PHASE##########"
                            echo "#######################################"
                            echo "Start TimeStamp:  ${new Date()}"
                            stageError="Backups"
                            if (isTherePropertyActions) {
                              Backups("${pipelineConfig.typeProperties}")
                            }
                            if (isThereWildFlyActions) {
                              Backups("${pipelineConfig.typeWildFly}")
                            }
                            echo "End TimeStamp:  ${new Date()}"
                            echo "#######################################"
                            echo "############END BACKUP PHASE###########"
                            echo "#######################################"
                          }
                          catch (err)
                          {
                              echo "######################################"
                              echo "########ERROR IN BACKUPS PHASE########"
                              echo "########ERROR IN BACKUPS PHASE########"
                              echo "######################################"
                              RollBack(err)
                          }
                        }
                    }
                }
                stage('DisableMicro'){
                    agent{label "SCHAMAN-Consolas"}
                    steps{
                        script{
                          try
                          {
                            echo "#####################################################"
                            echo "###########START DISABLE MICROSERVICE PHASE##########"
                            echo "#####################################################"
                            echo "Start TimeStamp:  ${new Date()}"
                            stageError="DisableMicro"
                            EnableDisableMicro("DISABLE", varMain.binaryDeployedEnv, "Environment")
                            echo "End TimeStamp:  ${new Date()}"
                            echo "#####################################################"
                            echo "############END DISABLE MICROSERVICE PHASE###########"
                            echo "#####################################################"
                          }
                          catch (err)
                          {
                              echo "############################################"
                              echo "########ERROR IN DISABLE MICRO PHASE########"
                              echo "########ERROR IN DISABLE MICRO PHASE########"
                              echo "############################################"
                              RollBack(err)
                          }
                        }
                    }
                }
                stage('Deploy') {
                    agent{label "SCHAMAN-Consolas"}
                    steps{
                        script{
                            try
                            {
                              echo "#######################################"
                              echo "###########START DEPLOY PHASE##########"
                              echo "#######################################"
                              echo "Start TimeStamp:  ${new Date()}"
                              if (isThereDBActions){
                                stageError="DeployDataBase"
                                DeployDataBase()
                              }
                              if (isTherePropertyActions){
                                stageError="DeployProperties"
                                DeployProperties()
                              }
                              if (isThereWildFlyActions){
                                stageError="DeployWildFly"
                                DeployWildFly()
                              }
                              echo "End TimeStamp:  ${new Date()}"
                              echo "#######################################"
                              echo "############END DEPLOY PHASE###########"
                              echo "#######################################"
                            }
                            catch (err)
                            {
                                echo "#####################################"
                                echo "########ERROR IN DEPLOY PHASE########"
                                echo "########ERROR IN DEPLOY PHASE########"
                                echo "#####################################"
                                RollBack(err)
                            }
                        }
                    }
                }
                stage('EnableMicro') {
                  agent{label "SCHAMAN-Consolas"}
                  steps{
                    script{
                      try
                      {
                        echo "####################################################"
                        echo "###########START ENABLE MICROSERVICE PHASE##########"
                        echo "####################################################"
                        echo "Start TimeStamp:  ${new Date()}"
                        stageError="EnableMicro"
                        if (isThereWildFlyActions){
                          EnableDisableMicro("ENABLE", varMain.binaryPackage, "Package")
                        } else {
                          EnableDisableMicro("ENABLE", varMain.binaryDeployedEnv, "Environment")
                        }
                        echo "End TimeStamp:  ${new Date()}"
                        echo "####################################################"
                        echo "############END ENABLE MICROSERVICE PHASE###########"
                        echo "####################################################"
                      }
                      catch (err)
                      {
                        echo "##################################################"
                        echo "########ERROR IN ENABLE MICROSERVICE PHASE########"
                        echo "########ERROR IN ENABLE MICROSERVICE PHASE########"
                        echo "##################################################"
                        RollBack(err)
                      }
                    }
                  }
                }
                stage('UpdateWildFly') {
                  agent {label "SCHAMAN-Consolas"}
                  steps {
                      script{
                        try
                        {
                          echo "###############################################"
                          echo "###########START UPDATE WILDFLY PHASE##########"
                          echo "###############################################"
                          echo "Start TimeStamp:  ${new Date()}"
                          stageError="UpdateWildFly"
                          if (isThereWildFlyActions && varMain.binaryPackage != varMain.binaryDeployedEnv){
                              UndeployMicro(varMain.binaryDeployedEnv)
                          }
                          else{
                            echo "It's no needed to Update WildFly"
                          }
                          echo "End TimeStamp:  ${new Date()}"
                          echo "###############################################"
                          echo "############END UPDATE WILDFLY PHASE###########"
                          echo "###############################################"
                        }
                        catch (err)
                        {
                          echo "#############################################"
                          echo "########ERROR IN UPDATE WILDFLY PHASE########"
                          echo "########ERROR IN UPDATE WILDFLY PHASE########"
                          echo "#############################################"
                          RollBack(err)
                        }
                      }
                    }
                  }
                stage('UpdateRelease') {
                    agent {label "SCHAMAN-Consolas"}
                    steps {
                        script{
                          try
                          {
                            echo "###############################################"
                            echo "###########START UPDATE RELEASE PHASE##########"
                            echo "###############################################"
                            echo "Start TimeStamp:  ${new Date()}"
                            stageError="UpdateRelease"
                            if (isThereWildFlyActions){
                                UpdateRelease()
                            }
                            else{
                              echo "It's no needed to Update Release"
                            }
                            echo "End TimeStamp:  ${new Date()}"
                            echo "###############################################"
                            echo "############END UPDATE RELEASE PHASE###########"
                            echo "###############################################"
                          }
                          catch (err)
                          {
                            echo "#############################################"
                            echo "########ERROR IN UPDATE RELEASE PHASE########"
                            echo "########ERROR IN UPDATE RELEASE PHASE########"
                            echo "#############################################"
                            RollBack(err)
                          }
                        }
                    }
                }
                stage('CleanEnvironment') {
                    agent {label "SCHAMAN-Consolas"}
                    steps {
                        script{
                          try
                          {
                            echo "##################################################"
                            echo "###########START CLEAN ENVIRONMENT PHASE##########"
                            echo "##################################################"
                            echo "Start TimeStamp:  ${new Date()}"
                            stageError="CleanEnvironment"
                            CleanEnvironment()
                            echo "End TimeStamp:  ${new Date()}"
                            echo "##################################################"
                            echo "############END CLEAN ENVIRONMENT PHASE###########"
                            echo "##################################################"
                          }
                          catch (err)
                          {
                            echo "################################################"
                            echo "########ERROR IN CLEAN ENVIRONMENT PHASE########"
                            echo "########ERROR IN CLEAN ENVIRONMENT PHASE########"
                            echo "################################################"
                            RollBack(err)
                          }
                        }
                    }
                }
            }
        }
    }
