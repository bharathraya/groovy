package vfes.utils

import groovy.json.JsonSlurper
import java.text.SimpleDateFormat

class VFESJobConfig implements Serializable {
    String jobDisplayName=""
    String jobDescription=""
    String jobTimeStamp=""
    String jobDate=""
    String jobMergeMessage=""
    String jobDelivery=""
    String jobCommitID=""
    String jobAlmsID=""
    String jobProjectId=""
    String jobDeployEnv=""
    String jobGitRepo=""
    String jobRepoProtocol="http"
    String jobRepoServer="eswltbhr:8282"
    String jobVodafoneGroup="vodafone"
    String jobEntregasGroup="entregas"
    String jobGitCommitBefore=""
    String jobGitCommitAfter=""
    String jobGitCredentials="vfjenkins-passwd"
    String jobName="vfjenkins-passwd"
    String jobGitChanges=""
    String gitFilesChanged=""
    String gitPropertiesChanged=""
    String jobWorkspace=""
    String jobProjectFolder=""
    String jobProjectWorkspaceFolder=""
    String gitTagComment=""
    String gitTagId=""
    boolean onlyProperties

    def context
    def jobEnvConfig

    VFESJobConfig(almsId,commitId,deployEnv,deliveryId,projectId,projectFolder,gitRepo,jobName,workspace,context){
        this.context=context
        this.jobName=jobName
        this.jobWorkspace=workspace
        this.jobAlmsID=almsId
        this.jobCommitID=commitId
        this.jobDelivery=deliveryId
        this.jobProjectId=projectId
        this.jobGitRepo=gitRepo
        this.jobDeployEnv=deployEnv
        this.jobProjectFolder=projectFolder
        this.jobProjectWorkspaceFolder=this.jobWorkspace+"/"+this.jobProjectFolder
        def timeFormat = new SimpleDateFormat("yyyyMMddHHmmss")
        def dateFormat = new SimpleDateFormat("yyyyMMdd")
        def date = new Date()
        this.jobTimeStamp=timeFormat.format(date)
        this.jobDate=dateFormat.format(date)
        this.jobDisplayName = "ALMS: ${almsId} Env: ${deployEnv}"
        this.jobDescription = "ALMS: ${almsId} Environment: ${deployEnv} Commit: ${commitId} Delivery: ${jobDelivery} Delivery: ${projectId}"
        this.jobMergeMessage="[${this.jobAlmsID}][${this.jobTimeStamp}][${this.jobDeployEnv}][${this.jobDelivery}][${this.jobProjectId}]"
        def t=""
        def n=""
        if (jobDelivery!=''){
            t=t+"-${jobDelivery}"
            n=n+":${jobDelivery}"
        }
        if (jobProjectId!=''){
            t=t+"-${jobProjectId}"
            n=n+":${jobProjectId}"
        }
        this.gitTagComment="${jobAlmsID}:${jobDeployEnv}:${jobTimeStamp}${n}"
        this.gitTagId="${jobAlmsID}-${jobDeployEnv}-${jobTimeStamp}${t}"
    }

    
    def jobReadConfig(jsonFile){
        def json = this.context.readJSON(file: jsonFile)
        this.jobEnvConfig=json[this.jobDeployEnv]
    }

    def mergeCommitBitBucket()
    {

        this.context.dir("${jobProjectWorkspaceFolder}"){
            this.jobGitCommitBefore = this.context.sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            this.context.echo "GitCommit Before MERGE: ${this.jobGitCommitBefore}"
            this.context.sh "git branch"
            try{
                this.context.sh "git merge --no-ff -m'${this.jobMergeMessage}' ${this.jobCommitID} "
            }
            catch(Exception){
                this.context.echo "There are following merge conflicts!"
                this.context.sh '''#!/bin/sh
                git diff --name-only --diff-filter=U | while read f
                do
                echo File: $f
                git log -3 --follow --pretty=format:"%h%x09%an%x09%ad%x09%s" $f
                echo
                done
                '''
                this.context.error('Stopping the job, has merge conflicts!!!')
            }
            this.jobGitCommitAfter = this.context.sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            this.context.echo "GitCommit AFter MERGE: ${this.jobGitCommitAfter}"
            this.context.sh """#!/bin/sh
            echo These are the changes between ${this.jobGitCommitBefore}..${this.jobGitCommitAfter}
            git diff --name-only  ${this.jobGitCommitBefore}..${this.jobGitCommitAfter}
            """
            if (this.jobGitCommitBefore==this.jobGitCommitAfter){
                context.echo "We don't publish changes because both commits are equal!"
            }
            else{
                context.echo "Publishing changes between both commits to Job" 
                this.jobGitChanges=this.context.sh(returnStdout: true, script: "git diff --name-only  ${this.jobGitCommitBefore}..${this.jobGitCommitAfter}")
                def publisher = context.LastChanges.getLastChangesPublisher "PREVIOUS_REVISION", "SIDE", "LINE", true, true, "", "${this.jobGitCommitBefore}", "", "", ""
                publisher.publishLastChanges()
                def changes = publisher.getLastChanges()
                println(changes.getEscapedDiff())
                for (commit in changes.getCommits()) {
                    println(commit)
                    def commitInfo = commit.getCommitInfo()
                    println(commitInfo)
                    println(commitInfo.getCommitMessage())
                    println(commit.getChanges())
                }
            }

        }

    }
    def mergeCommit()
    {

        this.context.dir("${jobProjectWorkspaceFolder}"){
            this.jobGitCommitBefore = this.context.sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            this.context.echo "GitCommit Before MERGE: ${this.jobGitCommitBefore}"
            this.context.sh "git branch"
            this.context.withCredentials([this.context.usernameColonPassword(credentialsId: this.jobGitCredentials, variable: 'GITUSERPASS')]) {
                def myUrl="${this.jobRepoProtocol}://"+'${GITUSERPASS}'+"@${this.jobRepoServer}/${this.jobEntregasGroup}/${this.jobGitRepo}"
                this.context.sh """
                    git remote add entregas ${myUrl}
                """
            }  
            // git merge ${CommitID} --no-commit --no-ff
            this.context.sh """
                git fetch entregas
            """
            try{
                this.context.sh "git merge --no-ff -m'${this.jobMergeMessage}' ${this.jobCommitID} "
            }
            catch(Exception){
                this.context.echo "There are following merge conflicts!"
                this.context.sh '''#!/bin/sh
                git diff --name-only --diff-filter=U | while read f
                do
                echo File: $f
                git log -3 --follow --pretty=format:"%h%x09%an%x09%ad%x09%s" $f
                echo
                done
                '''
                this.context.error('Stopping the job, has merge conflicts!!!')
            }
            this.jobGitCommitAfter = this.context.sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            this.context.echo "GitCommit AFter MERGE: ${this.jobGitCommitAfter}"
            this.context.sh """#!/bin/sh
            echo These are the changes between ${this.jobGitCommitBefore}..${this.jobGitCommitAfter}
            git diff --name-only  ${this.jobGitCommitBefore}..${this.jobGitCommitAfter}
            """
            if (this.jobGitCommitBefore==this.jobGitCommitAfter){
                context.echo "We don't publish changes because both commits are equal!"
            }
            else{
                context.echo "Publishing changes between both commits to Job" 
                this.jobGitChanges=this.context.sh(returnStdout: true, script: "git diff --name-only  ${this.jobGitCommitBefore}..${this.jobGitCommitAfter}")
                def publisher = context.LastChanges.getLastChangesPublisher "PREVIOUS_REVISION", "SIDE", "LINE", true, true, "", "${this.jobGitCommitBefore}", "", "", ""
                publisher.publishLastChanges()
                def changes = publisher.getLastChanges()
                println(changes.getEscapedDiff())
                for (commit in changes.getCommits()) {
                    println(commit)
                    def commitInfo = commit.getCommitInfo()
                    println(commitInfo)
                    println(commitInfo.getCommitMessage())
                    println(commit.getChanges())
                }
            }

        }

    }
    def buildMVOWFront(useNodeModulesCacheFolder)
    {
        context.echo "Copy cm_build_script  to project folder ... "
        context.sh "cp ${jobWorkspace}/CDM/Jenkins/${jobName}/cm_build_script ${jobProjectWorkspaceFolder}/"
        context.sh "chmod 755 ${jobProjectWorkspaceFolder}/cm_build_script"
        if (useNodeModulesCacheFolder){
            context.sh "mkdir -p /home/plataforma/jenkins/NPM_CACHE/${jobName}/${jobDeployEnv}"
        }
        context.echo "BUILD ${jobDeployEnv}"
            context.sh """
            docker run --ulimit nofile=98304:98304 \
                -v ${jobProjectWorkspaceFolder}:/home/platafor/project \
                -v /home/plataforma/jenkins/NPM_CACHE/${jobName}/${jobDeployEnv}:/home/platafor/project/node_modules \
                vfes_cdm_centos6_base:1.0 /home/platafor/project/cm_build_script
            """

    }
    def buildMVOWFB(useNodeModulesCacheFolder,projectFolder)
    {
        context.echo "Copy cm_build_script  to project folder ... "
        context.sh "cp ${jobWorkspace}/CDM/Jenkins/${jobName}/cm_build_script ${projectFolder}/"
        context.sh "chmod 755 ${projectFolder}/cm_build_script"
        def mountNPMCACHE=""
        if (useNodeModulesCacheFolder){
            context.sh "mkdir -p /home/plataforma/jenkins/NPM_CACHE/${jobName}/${jobDeployEnv}/"
            mountNPMCACHE="-v /home/plataforma/jenkins/NPM_CACHE/${jobName}/${jobDeployEnv}:/home/platafor/project/node_modules "
        }

        context.echo "BUILD ${jobDeployEnv}"
            context.sh """
            docker run --ulimit nofile=98304:98304 \
                -v ${projectFolder}:/home/platafor/project \
                ${mountNPMCACHE} \
                vfes_cdm_centos6_base:1.0 /home/platafor/project/cm_build_script
            """

    }
    def deployMVOWFront(artifactName,distFolder,distFile,deployFolder,artifactFolder){
        def unzipOper=""
        def prodFile=""
        if (distFile.endsWith('.tar.gz'))
        {
            unzipOper="tar  --directory=${artifactFolder} -xvf  ${distFile}"
            prodFile="${artifactName}-${jobAlmsID}-${jobTimeStamp}.tar.gz"
        }else if (distFile.endsWith('.zip')){
            unzipOper="unzip ${distFile} -d ${artifactFolder}"
            prodFile="${artifactName}-${jobAlmsID}-${jobTimeStamp}.zip"
        }
        if (this.jobDeployEnv != 'master' && this.jobDeployEnv != 'masterCI') 
        {
            //En el caso de entornos no PROD y Oculto hcemos deploy automatico
            this.jobEnvConfig.webservers.each { item ->

                context.echo "Deploying up on ${item.server} ..."
                
                context.sh "scp ${jobProjectWorkspaceFolder}/${distFolder}/${distFile} ${item.apacheusername}@${item.server}:${item.apachepath}/${deployFolder} 2>/dev/null"
                context.sh """
                ssh -o StrictHostKeyChecking=no -l ${item.apacheusername}  ${item.server} \
                'cd ${item.apachepath}/${deployFolder};\
                
                if [ -d ${artifactFolder} ]; then \
                    echo Borrando ${artifactFolder} 
                    rm -rf ${artifactFolder};\
                    
                fi; \
                mkdir -p ${artifactFolder} 
                ${unzipOper};\
                rm ${distFile}'
                """
            
            }
        }
        else {
            // en el caso de PROD dejamos en la maquina de oculto el zip ...
            context.sh "cp ${jobProjectWorkspaceFolder}/${distFolder}/${distFile} ${jobProjectWorkspaceFolder}/${distFolder}/${prodFile}"
            context.sh "ssh -o StrictHostKeyChecking=no vodlow01 'mkdir -p /home/plataforma/plausr/data/temporal/${jobDate}/${jobAlmsID}/PROD' "
            context.sh "scp ${jobProjectWorkspaceFolder}/${distFolder}/${prodFile} vodlow01:/home/plataforma/plausr/data/temporal/${jobDate}/${jobAlmsID}/PROD"
            this.jobEnvConfig.webservers.each { item ->

                context.echo "Deploying up on  ${item.apacheusername}@${item.server} ${item.apachepath}..."
                
                context.sh """
                ssh -o StrictHostKeyChecking=no vodlow01 '
                cd /home/plataforma/plausr/data/temporal/${jobDate}/${jobAlmsID}/PROD
                scp ${prodFile} ${item.apacheusername}@${item.server}:${item.apachepath}/${deployFolder}
                '
                """            
            }

        }

    }
    def backupMVOWFront(deployFolder,artifactFolder){
        if (this.jobDeployEnv != 'master' && this.jobDeployEnv != 'masterCI') 
        {
            //Een el caso de entornos no PROD y Oculto hcemos backup automatico
            this.jobEnvConfig.webservers.each { item ->
                context.echo "Backing up on ${item.server} ..."
                def exists=context.sh(returnStdout: true,script:"""
                   ssh -o StrictHostKeyChecking=no -l ${item.apacheusername}  ${item.server} 'if [ -d ${item.apachepath}/${deployFolder}/${artifactFolder} ] ; then echo SI; fi;' """)
                context.sh "Existe=${exists}"   
                if (exists!=null && exists=="SI"){
                def backupfile="backup-"+this.jobAlmsID+"-"+item.server+"-"+this.jobTimeStamp+".zip"
                context.sh """
                    ssh -o StrictHostKeyChecking=no -l ${item.apacheusername}  ${item.server}  \
                    'cd ${item.apachepath}/${deployFolder}/${artifactFolder}; \
                    rm -f ../backup-*.zip; \
                    zip -r ../${backupfile} * 2>/dev/null'
                """
                context.sh "scp ${item.apacheusername}@${item.server}:${item.apachepath}/${deployFolder}/${backupfile} .  2>/dev/null"
                context.archiveArtifacts artifacts: "${backupfile}", fingerprint: true
                }
            }
        }
    }
    def getJobChanges(){
        return """
---------------------------------------------------------------------------------------------------
git diff --name-only  ${this.jobGitCommitBefore}..${this.jobGitCommitAfter}
${this.jobGitChanges}
---------------------------------------------------------------------------------------------------
            """

    }
    def publishJobChanges(){

        def publisher = context.LastChanges.getLastChangesPublisher "PREVIOUS_REVISION", "SIDE", "LINE", true, true, "", "${this.jobGitCommitBefore}", "", "", ""
              publisher.publishLastChanges()
              def changes = publisher.getLastChanges()
              println(changes.getEscapedDiff())
              for (commit in changes.getCommits()) {
                  println(commit)
                  def commitInfo = commit.getCommitInfo()
                  println(commitInfo)
                  println(commitInfo.getCommitMessage())
                  println(commit.getChanges())
              }
    }

    def simpleMavenDockerBuild(dockerImage,usesMavenCacheFolder){
        if (usesMavenCacheFolder) {
            context.sh "mkdir -p /home/plataforma/jenkins/maven_repos/${jobName}/${jobDeployEnv}/.m2"
        }
        context.dir(jobProjectWorkspaceFolder){
            context.echo "We start build as there are code changes involved in current merge..."
            context.echo "Copy settings.xml  to .m2 folder ... "
            context.sh "cp ${jobWorkspace}/CDM/Jenkins/${jobName}/m2/settings.xml /home/plataforma/jenkins/maven_repos/${jobName}/${jobDeployEnv}/.m2"
            context.echo "Copy cm_build_script  to project folder ... "
            context.sh "cp ${jobWorkspace}/CDM/Jenkins/${jobName}/cm_build_script ${jobProjectWorkspaceFolder}/"
            context.sh "chmod 755 ${jobProjectWorkspaceFolder}/cm_build_script"

            context.echo "BUILD ${jobDeployEnv}"
            context.sh """
            docker run --user=\$(id -u):\$(id -g) --ulimit nofile=98304:98304 \
                -v ${jobProjectWorkspaceFolder}:/home/plataforma/project \
                -v /home/plataforma/jenkins/maven_repos/${jobName}/${jobDeployEnv}/.m2:/home/plataforma/.m2 \
                vfes_cdm_centos6_maven3_jdk8_065:latest /home/plataforma/project/cm_build_script
            """
            //error('Stopping the job before rest of steps ...')
           
        }
    }
    def mavenDockerBuild(dockerImage,propertiesRegex,usesMavenCacheFolder){
        if (usesMavenCacheFolder) {
            context.sh "mkdir -p /home/plataforma/jenkins/maven_repos/${jobName}/${jobDeployEnv}/.m2"
        }
        context.dir(jobProjectWorkspaceFolder){
            gitFilesChanged=context.sh(returnStdout: true, script: "git diff --name-only  ${jobGitCommitBefore}..${jobGitCommitAfter}").toString().trim()
            if (propertiesRegex!=""){
                gitPropertiesChanged=context.sh(returnStdout: true, script: "git diff --name-only  ${jobGitCommitBefore}..${jobGitCommitAfter} | sed -n '/${propertiesRegex}/!p'").toString().trim()
                context.echo "gitPropertiesChanged: ${gitPropertiesChanged}"
                context.echo "gitFilesChanged: ${gitFilesChanged}"
                if (gitFilesChanged != ""){
                // there are changes involved !
                    if (gitPropertiesChanged != ""){
                        onlyProperties=false
                    }else
                    {
                        onlyProperties=true
                    }
                }else{
                    //in case no changes involved , lets recompile all
                    onlyProperties=false
                }
            }
            else{
                gitPropertiesChanged=""
                onlyProperties=false
            }
            if (onlyProperties){
                echo "There are only property files modified, no need to build!!!"
            }
            else{
                context.echo "We start build as there are code changes involved in current merge..."
                context.echo "Copy settings.xml  to .m2 folder ... "
                context.sh "cp ${jobWorkspace}/CDM/Jenkins/${jobName}/m2/settings.xml /home/plataforma/jenkins/maven_repos/${jobName}/${jobDeployEnv}/.m2"
                context.echo "Copy cm_build_script  to project folder ... "
                context.sh "cp ${jobWorkspace}/CDM/Jenkins/${jobName}/cm_build_script ${jobProjectWorkspaceFolder}/"
                context.sh "chmod 755 ${jobProjectWorkspaceFolder}/cm_build_script"

                context.echo "BUILD ${jobDeployEnv}"
                context.sh """
                docker run --user=\$(id -u):\$(id -g) --ulimit nofile=98304:98304 \
                    -v ${jobProjectWorkspaceFolder}:/home/plataforma/project \
                    -v /home/plataforma/jenkins/maven_repos/${jobName}/${jobDeployEnv}/.m2:/home/plataforma/.m2 \
                    vfes_cdm_centos6_maven3_jdk8_065:latest /home/plataforma/project/cm_build_script
                """
                //error('Stopping the job before rest of steps ...')
            }
        }
    }
    def copyToRelease(artifactsFindPath,fileFilter,sourceFolder,artifactName){
        context.echo "Create zip file..."
        def jobDeployTag=this.jobAlmsID+'-'+this.jobDeployEnv+'-'+this.jobTimeStamp

        def zipFile="${jobDeployTag}.zip"
        def zipFileWorkspace=jobWorkspace+'/'+zipFile
        def remoteTmpFolder="/home/plataforma/jenkins/tmp/job-${jobDeployTag}"
        def findFilter=""
        if (sourceFolder==""){
            sourceFolder=jobWorkspace
        }
        
        if (fileFilter!=""){
            findFilter=' -name "'+fileFilter+"'"
        }
        context.dir("${sourceFolder}"){
            if (!onlyProperties){
                context.echo "Bundling WAR files in ZIP as there are code changes involved..."
                context.sh """

					find ${artifactsFindPath} -type f ${findFilter}  | zip -r ${zipFileWorkspace} -@;
						"""
            }
            context.echo "Bundling property files in ZIP ..."
            context.sh """
                if [ \"\$(find ${artifactsFindPath} -type d -name "properties")\" != \"\" ]
                then
				    find ${artifactsFindPath} -type d -name "properties" | zip -r ${zipFileWorkspace} -@
                fi
                    """
		}
        if (jobDeployEnv != 'master' && jobDeployEnv != 'HID1' && jobDeployEnv != 'HID1CI' && jobDeployEnv != 'masterCI' ) {
            
            jobEnvConfig.release.each { item ->
                context.echo "Deploying up on ${item.server} ..."
                context.sh """
                   ssh -o StrictHostKeyChecking=no  ${item.server} "mkdir -p ${remoteTmpFolder}"
                   """
                context.sh "scp ${zipFileWorkspace} ${item.server}:${remoteTmpFolder} 2>/dev/null"
                context.sh """
                   ssh -o StrictHostKeyChecking=no -l ${item.username}  ${item.server} \
                   'cd ${item.path}; \
                   rm backup-jenkins-*-${jobDeployEnv}-*.zip
                   zipinfo -1 ${remoteTmpFolder}/${zipFile} | zip backup-jenkins-${zipFile}.zip -@;\
                   unzip -o ${remoteTmpFolder}/${zipFile}; '
                   """
                context.sh """
                   ssh -o StrictHostKeyChecking=no  ${item.server} "rm ${remoteTmpFolder}/${zipFile}"
                   """
            }
        }
        else{

            
			def plataforpath="/home/plataforma/plausr/data/temporal/${this.jobDate}/anexos/${this.jobAlmsID}"
            def zipname=""
            if (this.jobDeployEnv == 'HID1CI' || this.jobDeployEnv == 'masterCI')   {
                def myenvd=""   
                switch  (this.jobDeployEnv){
                    case 'HID1CI':
                        myenvd='HID1'
                        break
                    case 'masterCI':
                        myenvd='PROD'
                        break
                    case 'HID1':
                        myenvd='HID1'
                        break
                    case 'master':
                        myenvd='PROD'
                        break

                }
                plataforpath="/home/plataforma/plausr/data/temporal/${jobDate}/anexo/${jobAlmsID}/${myenvd}"
                zipname="${jobAlmsID}-${artifactName}"
            }else{
                plataforpath="/home/plataforma/plausr/data/temporal/${jobDate}/anexos/${jobAlmsID}"
                zipname="${jobAlmsID}-${jobDeployEnv}-${jobTimeStamp}"
            }
            jobEnvConfig.release.each { item ->
                context.echo "Preparing for ${item.server} ..."
                context.echo "create .env file for deployment ..."
                context.sh "echo export REL_ROOT=${item.path} >> ${zipname}.${item.server}.env"
                context.sh "echo export USER_REL=${item.username} >> ${zipname}.${item.server}.env"
                context.echo "create path in remote server"
                context.sh "ssh platafor@${item.server} 'mkdir -p ${plataforpath}'"
                context.echo "upload .sh, .zip and .env files"
                context.sh "scp ${zipname}.${item.server}.env platafor@${item.server}:${plataforpath}/${zipname}.env"
                context.sh "scp ${jobAlmsID}-${jobDeployEnv}-${jobTimeStamp}.zip platafor@${item.server}:${plataforpath}/${zipname}.zip"
                context.sh "scp ${jobWorkspace}/CDM/CommonTools/scripts/ROLLBACK_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.bak.sh"
                context.sh "scp ${jobWorkspace}/CDM/CommonTools/scripts/DEPLOY_ZIP_PACKAGE.sh platafor@${item.server}:${plataforpath}/${zipname}.sh"
                context.sh "ssh platafor@${item.server} 'chmod 777 ${plataforpath}; chmod 755 ${plataforpath}/*.sh'"
            }
            context.echo ""
            context.echo ""
            context.echo "************************************************************************"
            context.echo "************************************************************************"
            context.echo "Execute:"
            context.currentBuild.description = context.currentBuild.description+"\n\r\n\rExecute:"
            jobEnvConfig.release.each { item ->
                context.echo "${item.username}@${item.server}:${plataforpath}/${jobAlmsID}-${jobDeployEnv}-${jobTimeStamp}.sh"
                context.currentBuild.description = context.currentBuild.description+"\n\r${item.username}@${item.server}:${plataforpath}/${jobAlmsID}-${jobDeployEnv}-${jobTimeStamp}.sh"
            }
            context.echo "************************************************************************"
            context.echo "************************************************************************"
            context.echo ""
            context.echo ""
		}
    }
    def pushAndTag(){
        context.dir(jobProjectWorkspaceFolder){
            context.sh "git tag -a ${this.gitTagId} -m '${this.gitTagComment}'"
            context.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: this.jobGitCredentials,
                        usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                def url=this.jobRepoProtocol+'://'+'${USERNAME}:${PASSWORD}@'+this.jobRepoServer+'/'+this.jobVodafoneGroup+'/'+this.jobGitRepo
                context.sh "git push ${url} ${this.jobDeployEnv}"
                context.sh "git push ${url} ${this.gitTagId}"                        
            }
        }
        
    }
    def pushAndTagBitbucket(repo){
        context.dir(jobProjectWorkspaceFolder){
            context.sh "git tag -a ${this.gitTagId} -m '${this.gitTagComment}'"
            context.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'essvc.essvc-devops-Bitbucket',
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                def url=this.jobRepoProtocol+"://"+context.USERNAME+":"+context.PASSWORD+"@"+this.jobRepoServer+"/"+this.jobVodafoneGroup+"/"+this.jobGitRepo
                context.echo "url=${url}"
                context.sh "git remote set-url origin  ${url}"
            }
            context.sh "echo '#!/bin/bash' > cm_push_bitbucket"
            context.sh "echo 'cd /home/platafor/project' >> cm_push_bitbucket"
            context.sh "echo 'unset HTTP_PROXY' >> cm_push_bitbucket"
            context.sh "echo 'unset HTTPS_PROXY' >> cm_push_bitbucket"
            context.sh "echo 'unset http_proxy' >> cm_push_bitbucket"
            context.sh "echo 'unset https_proxy' >> cm_push_bitbucket"
            context.sh "echo 'git push --tags origin ${this.jobDeployEnv}:vodafone/${this.jobDeployEnv}' >> cm_push_bitbucket"

            context.sh "chmod 750 cm_push_bitbucket"
            context.sh "docker run -v ${jobProjectWorkspaceFolder}:/home/platafor/project vfes_cdm_centos7_base /home/platafor/project/cm_push_bitbucket "
    
            //context.sh "git push --tags vodafone/${this.jobDeployEnv}"
        }
        
    }

    def wlAnsibleRedeploy(ansibleDir,artifact){
        context.dir(ansibleDir){
            context.sh "ansible-playbook -i inventories/${jobDeployEnv}/hosts redeploy.yml --extra-vars \"deployment_env=${jobDeployEnv} deployment_artifact=${artifact}\""
        }
        
    }

}
