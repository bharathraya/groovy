package vfes.utils

class nexusData implements Serializable {
    String nexusCred=""
    String nexusCredProd=""
    String nexusRepo=""
    String nexusRepoProd=""
    String nexusUrl=""

    
    nexusData(String nexusCred,String nexusCredProd,String nexusRepo, String nexusRepoProd,String nexusUrl){
        this.nexusCred=nexusCred
        this.nexusCredProd=nexusCredProd
        this.nexusRepo=nexusRepo
        this.nexusRepoProd=nexusRepoProd
        this.nexusUrl=nexusUrl
    }
}