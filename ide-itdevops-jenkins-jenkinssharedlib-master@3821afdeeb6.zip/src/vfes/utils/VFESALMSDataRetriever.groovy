package vfes.utils
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
class VFESALMSDataRetriever implements Serializable {
    String myalmsID=""
    String mydeployEnv=""
    String mydomain=""
    String myserver=""
    String myHayPvcs=""
    String myHayAnexos=""
    def mydataModules=""
    def myParametros =""
    boolean mywbCalled=false
    //cuando hay SVN donde réplicar el código para desarrollo
    String myserverSVN=""
    //Servidor de PROD
    String myserverPROD
    //Ruta windows en la que desplegar
    String myRuta=""
    String myProdDeploy=""
    String mylistapaquetes=""
    String myIsRollback=""
    
    String mynueva=""
    String myDelivery=""
    String myHayParametros=""

    
    VFESALMSDataRetriever(_ALMS_ID,_Domain,_DeployEnv,_server,_HayModulosPVCS,_dataModules,_HayAnexos,_wbCalled,_serverSVN,_serverPROD, _ruta, _prodDeploy ){
        this.myalmsID=_ALMS_ID
        this.mydomain=_Domain
        this.mydeployEnv=_DeployEnv
        this.myserver=_server
        this.myHayPvcs=_HayModulosPVCS
        this.myHayAnexos=_HayAnexos
        this.mywbCalled=_wbCalled
        this.mydataModules=_dataModules 
        this.myserverSVN=_serverSVN
        this.myserverPROD=_serverPROD
        this.myRuta=_ruta
        this.myProdDeploy=_prodDeploy
    }
        

    VFESALMSDataRetriever(_ALMS_ID,_Domain,_DeployEnv,_server,_HayModulosPVCS,_dataModules,_HayAnexos,_wbCalled,_serverSVN,_serverPROD, _listapaquetes){
        this.myalmsID=_ALMS_ID
        this.mydomain=_Domain
        this.mydeployEnv=_DeployEnv
        this.myserver=_server
        this.myHayPvcs=_HayModulosPVCS
        this.myHayAnexos=_HayAnexos
        this.mywbCalled=_wbCalled
        this.mydataModules=_dataModules 
        this.myserverSVN=_serverSVN
        this.myserverPROD=_serverPROD
        this.mylistapaquetes=_listapaquetes
        
        }
        
        
    VFESALMSDataRetriever(_ALMS_ID,_Domain,_DeployEnv,_server,_HayModulosPVCS,_dataModules,_HayAnexos,_wbCalled,_serverSVN,_serverPROD,_listapaquetes,_isRollback,_Nueva, _Delivery,_Parametros,_HayParametros){
        this.myalmsID=_ALMS_ID
        this.mydomain=_Domain
        this.mydeployEnv=_DeployEnv
        this.myserver=_server
        this.myHayPvcs=_HayModulosPVCS
        this.myHayAnexos=_HayAnexos
        this.mywbCalled=_wbCalled
        this.mydataModules=_dataModules 
        this.myserverSVN=_serverSVN
        this.myserverPROD=_serverPROD
        this.mylistapaquetes=_listapaquetes
        this.myIsRollback=_isRollback
        this.mynueva=_Nueva
        this.myDelivery=_Delivery
        this.myParametros=_Parametros
        this.myHayParametros=_HayParametros
       
        
        }        
        
    }

                       
