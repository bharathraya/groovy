package vfes.utils

import groovy.json.JsonSlurper
import java.text.SimpleDateFormat

class VFESALMSDeployment implements Serializable {
    String almsID=""
    String deployEnv=""
    String commitID=""
    String deliveryID=""
    String projectID=""
    String mergeMessage=""
    String jobTimeStamp=""
    String jobDate=""
    String appName=""
    String gitTagComment=""
    String gitTagId=""
    String jobDisplayName=""
    String jobDescription=""
    String squad=""
    String type=""
    boolean onlyProperties=false
	String branch=""
	String owner=""
	String slackAccount=""
	String email=""
	
	String commitAuthor=""
	String commitEmail=""
	String commitDate=""

    def context=[:]

    VFESALMSDeployment(String almsId,_context){
     this.almsID=almsId
     this.context=_context
    }

    VFESALMSDeployment(String almsId){
		def wbpckinfo=context.get_workbench_package_info(almsId)
		this.almsID=almsId
        this.deployEnv=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
        def commitObject=getFullCommit(wbpckinfo.Data.Model.Model.Contents.GIT,mydeploy_env)
		this.commitID=commitObject.CommitId
		this.branch=commitObject.BranchHash
		this.commitAuthor=commitObject.AuthorName
		this.commitEmail=commitObject.AuthorEmail
		this.commitDate=commitObject.CreatedAt
        this.deliveryID=wbpckinfo.Data.Model.Model.Base.Project.Delivery.Name
        this.projectID=wbpckinfo.Data.Model.Model.Base.Project.CodProject
		this.owner=wbpckinfo.Data.Model.Model.Base.Owner
		this.email=wbpckinfo.Data.Model.Model.Base.Email
		
	}

	VFESALMSDeployment(String _ALMS_ID,String _AppName,String _DeployEnv, String _CommitID,String _DeliveryID,String _ProjectID){
        VFESALMSDeployment( _ALMS_ID, _AppName, _DeployEnv,  _CommitID, _DeliveryID, _ProjectID,"BAU")
    }
    VFESALMSDeployment(String _ALMS_ID,String _AppName,String _DeployEnv, String _CommitID,String _DeliveryID,String _ProjectID,String _squad){
        this.almsID=_ALMS_ID
        this.deployEnv=_DeployEnv
        this.commitID=_CommitID
        this.deliveryID=_DeliveryID
        this.projectID=_ProjectID
        def timeFormat = new SimpleDateFormat("yyyyMMddHHmmss")
        def dateFormat = new SimpleDateFormat("yyyyMMdd")
        def date = new Date()
        this.jobTimeStamp=timeFormat.format(date)
        this.jobDate=dateFormat.format(date)
        this.appName=_AppName
        def n=""
        def t=""
        if (deliveryID!=''){
            t=t+"-${deliveryID}"
            n=n+":${deliveryID}"
        }
        if (projectID!=''){
            t=t+"-${projectID}"
            n=n+":${projectID}"
        }
        this.gitTagComment="${almsID}:${deployEnv}:${jobTimeStamp}${n}"
        this.gitTagId="${almsID}-${deployEnv}-${jobTimeStamp}${t}"
        mergeMessage="[${this.almsID}][${this.jobTimeStamp}][${this.deployEnv}][${this.deliveryID}][${this.projectID}]"
        this.jobDisplayName = "ALMS: ${almsID} Artifact: ${_AppName} Env: ${deployEnv}"
        this.jobDescription = "ALMS: ${almsID} Artifact: ${_AppName} Environment: ${deployEnv} Commit: ${commitID} Delivery: ${deliveryID} Delivery: ${projectID}"
        this.squad=_squad
    }
    VFESALMSDeployment(String _ALMS_ID,String _AppName,String _DeployEnv, String _CommitID,String _DeliveryID,String _ProjectID,String _squad, String _type){
        this.almsID=_ALMS_ID
        this.deployEnv=_DeployEnv
        this.commitID=_CommitID
        this.deliveryID=_DeliveryID
        this.projectID=_ProjectID
        def timeFormat = new SimpleDateFormat("yyyyMMddHHmmss")
        def dateFormat = new SimpleDateFormat("yyyyMMdd")
        def date = new Date()
        this.jobTimeStamp=timeFormat.format(date)
        this.jobDate=dateFormat.format(date)
        this.appName=_AppName
        def n=""
        def t=""
        if (deliveryID!=''){
            t=t+"-${deliveryID}"
            n=n+":${deliveryID}"
        }
        if (projectID!=''){
            t=t+"-${projectID}"
            n=n+":${projectID}"
        }
        this.gitTagComment="${almsID}:${deployEnv}:${jobTimeStamp}${n}"
        this.gitTagId="${almsID}-${deployEnv}-${jobTimeStamp}${t}"
        mergeMessage="[${this.almsID}][${this.jobTimeStamp}][${this.deployEnv}][${this.deliveryID}][${this.projectID}]"
        this.jobDisplayName = "ALMS: ${almsID} Artifact: ${_AppName} Env: ${deployEnv}"
        this.jobDescription = "ALMS: ${almsID} Artifact: ${_AppName} Environment: ${deployEnv} Commit: ${commitID} Delivery: ${deliveryID} Delivery: ${projectID}"
        this.squad=_squad
        this.type=_type
    }
    String getMergeMessage(){
        return "[${this.almsID}][${this.jobTimeStamp}][${this.deployEnv}][${this.deliveryID}][${this.projectID}]"
    }

     def getPackageDetailsFromWB(){
        def wbpckinfo=this.context.get_workbench_package_info(this.almsID)
        this.deployEnv=wbpckinfo.Data.Model.Model.Base.DeployEnvironment.Name
        //def commitObject=getFullCommit(wbpckinfo.Data.Model.Model.Contents.GIT,deployEnv)
        //this.commitID=commitObject.CommitId
        //this.branch=commitObject.BranchHash
        //this.commitAuthor=commitObject.AuthorName
        //this.commitEmail=commitObject.AuthorEmail
        //this.commitDate=commitObject.CreatedAt
        this.deliveryID=wbpckinfo.Data.Model.Model.Base.Project.Delivery.Name
        this.projectID=wbpckinfo.Data.Model.Model.Base.Project.CodProject
        this.owner=wbpckinfo.Data.Model.Model.Base.Owner
        this.email=wbpckinfo.Data.Model.Model.Base.Email
     }

}