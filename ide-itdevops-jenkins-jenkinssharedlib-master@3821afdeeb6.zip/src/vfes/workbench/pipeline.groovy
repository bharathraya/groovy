#!groovy
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.text.SimpleDateFormat
import vfes.workbench.Workbench

@Library('pipeline-as-code@master') _

String _package=PAQUETE
def workbench_cred="WorkBenchAdmin_PROD"
//
//node ("es036tvr") {
node ("eswltbhr") { 
      stage ("InfoPackage"){
        //Configuramos el nombre del build y su descripcion
        currentBuild.displayName = "Info WB package"
        currentBuild.description = "WB: ${_package}"
        withCredentials([usernamePassword(credentialsId: "${workbench_cred}", usernameVariable: "usuario", passwordVariable: "password")]) {
        	Workbench workbench=new Workbench(this,usuario,password)
        	def wbPackage=workbench.get_package_info(_package,usuario,password)
            def wbPackageJson=new groovy.json.JsonBuilder(wbPackage)
            println wbPackageJson.toPrettyString();
        }
     }
}
