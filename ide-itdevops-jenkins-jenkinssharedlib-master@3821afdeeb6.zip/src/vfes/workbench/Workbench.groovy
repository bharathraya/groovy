package vfes.workbench

import com.cloudbees.groovy.cps.NonCPS
import groovy.json.JsonSlurperClassic 

class Workbench implements Serializable{
    def context=null
    String token=""
  	String usuario=""
  	String password=""

    Workbench(_context,String usuario,String password){
        def capture=null
        this.context=_context
        this.usuario=usuario
        this.password=password
        this.token=""
    }

    @NonCPS
    Map manageHttpRestRequest(String uri,String httpRequestType,String bodyMessage){
        //this.context.echo(this.baseUrl+uri)
        def request = new URL(uri).openConnection()
        request.setRequestProperty("Content-Type", "application/json")
        request.setRequestProperty ('Connection', "keep-alive")
        request.setRequestProperty ('Accept-Encoding', "gzip, deflate, br")
        //request.setRequestProperty ("Authorization", this.basicAuthCredential);
        request.setRequestMethod(httpRequestType)
        request.setDoOutput(true)
        if (bodyMessage !=""){
            request.getOutputStream().write(bodyMessage.getBytes("windows-1252"))
        }
        def getRC = request.getResponseCode();

        //this.context.echo("ResponseCode:"+getRC);
        def resultJson=getRequestResult(getRC,request)
        Map resultObject=[:]
        resultObject["httpCode"]=getRC
        resultObject["resultObject"]=resultJson
        request=null
        return resultObject

    }
    @NonCPS
    Map manageHttpRestRequestToken(String uri,String httpRequestType,String bodyMessage){
        //this.context.echo(this.baseUrl+uri)
        if(this.token==""){
            getToken()
        }
        def request = new URL(uri).openConnection()
        request.setRequestProperty("Accept", "*/*")
      	request.setRequestProperty ("Authorization", "Bearer "+this.token)
        request.setRequestProperty ('Connection', "keep-alive")
        request.setRequestProperty ('Accept-Encoding', "gzip, deflate, br")
        request.setRequestMethod(httpRequestType)
        request.setDoOutput(true)
        if (bodyMessage !=""){

            request.getOutputStream().write(bodyMessage.getBytes("windows-1252"))
        }
        def getRC = request.getResponseCode();
        println getRC
        //this.context.echo("ResponseCode:"+getRC);
        def resultJson=getRequestResult(getRC,request)
        Map resultObject=[:]
        resultObject["httpCode"]=getRC
        resultObject["resultObject"]=resultJson
        request=null
        return resultObject

    }

    @NonCPS
    Map getRequestResult(responseCode,request){
        Map resultJson=[:]
        def result="{}"
        try{
            if (responseCode>=200 && responseCode<=299){
                result = request.getInputStream().getText()

            }else {
                 result = request.getErrorStream().getText()
                 println result
            }
        }
        catch(Exception e){
            this.context.echo ("Exception when trying to retrieve request body : ${e}")
        }
        //this.context.echo "result:${result}"
      	if (result!=""){
        	resultJson=this.readJson(result)
        }
        return resultJson
    }
    @NonCPS
    def getToken(){
        def uri="https://workbench-devops.es.sedc.internal.vodafone.com/WorkBench/token"
        Map resultMap=manageHttpRestRequest(uri,"POST","grant_type=password&username=${this.usuario}&password=${this.password}")
      	if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
            this.token=resultMap.resultObject.access_token
          	//this.context.echo("token:"+this.token);
        }
    }
    @NonCPS
    private static def readJson(String text){
        def jsonSlurper = new JsonSlurperClassic ()
        return jsonSlurper.parseText(text)
    }

    def get_package_info(String paquete){
        def uri="https://workbench-devops.es.sedc.internal.vodafone.com/WorkBench/api/Construction/Package/"+ paquete +"/Model?filters.base=true&filters.references=true&filters.dependences=true&filters.dataModules=true&filters.annexes=true&filters.history=false&filters.contents=true&filters.params=true"
        Map resultado=[:]
        Map resultMap=manageHttpRestRequestToken(uri,"GET","")
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
            resultado=resultMap.resultObject
        }else{
            println resultMap.httpCode
        }
        return resultado
    }

    def obtenerIdDelivery(){
        def uri="https://workbench-devops.es.sedc.internal.vodafone.com/WorkBench/api/ContentManager/Deliveries"
        Map resultado=[:]
        Map resultMap=manageHttpRestRequestToken(uri,"GET","")
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
            resultado=resultMap.resultObject
        }else{
            println resultMap.httpCode
        }
        return resultado
    }

    def obtenerProyectosAsociados(String idDelivery){
        def uri="https://workbench-devops.es.sedc.internal.vodafone.com/WorkBench/api/ContentManager/Deliveries/"+ idDelivery +"/Projects?getRelation=true" 
        Map resultado=[:]
        Map resultMap=manageHttpRestRequestToken(uri,"GET","")
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
            resultado=resultMap.resultObject
        }else{
            println resultMap.httpCode
        }
        return resultado
    }

    def obtenerEntorno(String idDelivery, String nombreProyecto){
        def uri="https://workbench-devops.es.sedc.internal.vodafone.com/WorkBench/api/ContentManager/Deliveries/"+ idDelivery +"/Project/"+ nombreProyecto +"/Environment"
        Map resultado=[:]
        Map resultMap=manageHttpRestRequestToken(uri,"GET","")
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
            resultado=resultMap.resultObject
        }else{
            println resultMap.httpCode
        }
        return resultado
    }

}
