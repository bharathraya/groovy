package vfes.stages

import vfes.stages.interfaces.EnvironmentPreparation
import vfes.stages.interfaces.SourceCodeManagement
import vfes.stages.interfaces.StageExecutor

class CIStages implements Serializable {

    EnvironmentPreparation environmentPreparation
    SourceCodeManagement sourceCodeManagement
    StageExecutor compile
    StageExecutor unitTest
    StageExecutor codeInspection
    StageExecutor generateArtifact
    StageExecutor uploadArtifact


}


