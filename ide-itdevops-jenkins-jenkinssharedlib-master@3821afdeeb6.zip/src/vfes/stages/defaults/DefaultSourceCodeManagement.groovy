package vfes.stages.defaults

import com.cloudbees.groovy.cps.NonCPS
import vfes.stages.interfaces.SourceCodeManagement
import vfes.storage.configs.ConfigStorage
import vfes.storage.secure.SecretsStorage

class DefaultSourceCodeManagement implements SourceCodeManagement {

    protected Script context
    protected SecretsStorage secretsStorage
    protected ConfigStorage configStorage


    @Override
    def initialize(Script context, SecretsStorage secretsStorage, ConfigStorage configStorage) {
        context.echo "Iniciando Default Source Code Management"
        this.context = context
        this.secretsStorage = secretsStorage
        this.configStorage = configStorage
    }

    @NonCPS
    @Override
    def exec() {
        context.echo "Ejecutando Default Source Code Management"
        checkoutStep()
        if ((!(configStorage.props.branchPolicy ==~ /SIMPLE/) || (configStorage.props.branchPolicy ==~ /SIMPLE/ &&
                configStorage.props.almsPackage.deployEnv ==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/))) {
            mergeStep()
        }
    }

    def checkoutStep() {
        if (configStorage.props.branchPolicy == "SIMPLE" && !(configStorage.props.almsPackage.deployEnv ==~ /(?i)(HID|HID1|HIDCI|HID1CI|master|masterCI)/)) {
            context.gitRepo.checkoutCommit(configStorage.props.extractFolder, configStorage.props.almsPackage.deployEnv, configStorage.props.almsPackage.commitID)
        } else if (configStorage.props.branchPolicy ==~ /(SIMPLE|envs_and_develop)/ && configStorage.props.almsPackage.deployEnv ==~ /(?i)(HID|HID1|HIDCI|HID1CI)/) {
            context.gitRepo.cloneBranchToLocalFolder(configStorage.props.extractFolder, "develop")
        } else {
            context.gitRepo.cloneBranchToLocalFolder(configStorage.props.extractFolder, configStorage.props.almsPackage.deployEnv)
        }

    }

    def mergeStep() {
        if (configStorage.props.branchPolicy ==~ /(SIMPLE|envs_and_develop)/ && configStorage.props.almsPackage.deployEnv ==~ /(?i)(master|masterCI)/) {
            echo "Merging to ${configStorage.props.almsPackage.deployEnv} we will check for the corresponding tag for ${configStorage.props.almsPackage.commitID} in develop branch..."
            context.mergeInfo = context.gitRepo.mergeCommitFromDevelop(configStorage.props.extractFolder,
                    configStorage.props.almsPackage.commitID, configStorage.props.almsPackage.mergeMessage,
                    configStorage.props.almsPackage.almsID)
        } else {
            context.mergeInfo = context.gitRepo.mergeCommit(configStorage.props.extractFolder,
                    configStorage.props.almsPackage.commitID, configStorage.props.almsPackage.mergeMessage)
        }
    }

}
