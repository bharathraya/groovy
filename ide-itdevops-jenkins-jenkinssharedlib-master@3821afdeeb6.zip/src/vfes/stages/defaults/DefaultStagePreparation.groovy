package vfes.stages.defaults

import com.cloudbees.groovy.cps.NonCPS
import vfes.git.VFESGitRepo
import vfes.stages.interfaces.EnvironmentPreparation
import vfes.storage.configs.ConfigStorage
import vfes.storage.secure.SecretsStorage
import vfes.utils.VFESALMSDeployment
import vfes.utils.WorkBenchServiceIntegration

//@CompileStatic
class DefaultStagePreparation extends Script implements Serializable, EnvironmentPreparation {

    private Script context
    private SecretsStorage secretsStorage
    private ConfigStorage configStorage

    @Override
    def initialize(Script context, SecretsStorage secretsStorage, ConfigStorage configStorage) {
        context.echo "Iniciando Default Stage Preparation"
        this.context = context
        this.secretsStorage = secretsStorage
        this.configStorage = configStorage

        if (!context.env) context.env = [:]

        String currentCredentialId

        context.echo "WorkBench UserID is $context.env.BUILD_USER_ID"
        def myBuildUser = context.env.BUILD_USER_ID

        if (myBuildUser ==~ /pprdworkbench/ || myBuildUser == null) {
            context.echo "WorkBench Package in PreProd"
            context.env.currentServerWB = "webpre-adm.es.sedc.internal.vodafone.com:42510"
            context.env.currentProtocolWB = 'https'
            currentCredentialId = "WorkBenchAdmin_PPRD"

        } else {
            context.echo "WorkBench Package in Prod"
            context.env.currentServerWB = "es1117yw"
            context.env.currentProtocolWB = 'http'
            currentCredentialId = "WorkBenchAdmin_PROD"

        }
        context.echo "WorkBench Package in PreProd"
        def creds = secretsStorage.getUsernameAndPassword(currentCredentialId)
        context.echo "Credentials User is $creds.username"
        context.env.usernameWB = creds.username
        context.env.passwordWB = creds.password

    }


    @Override
    def exec() {
        context.echo "Ejecutando Default Stage Preparation"
//        context.sh "env"

        context.env.pipelineConfigDir = "resources/${(context.env.JOB_NAME =~ /.*\/([a-zA-Z]{0,5}-[a-zA-Z]{0,5}-[a-zA-Z]{0,5}).*/)[0][1]}"
        context.env.bitbucketKey = "${(context.env.JOB_NAME =~ /.*\/([a-zA-Z]{0,5}-[a-zA-Z]{0,5}).*/)[0][1]}"
        context.env.sonarKey = "${(context.env.JOB_NAME =~ /.*\/([a-zA-Z].*)_.*/)[0][1]}"
        context.env.sonarHost = "https://webpre-adm.es.sedc.internal.vodafone.com:44099/sonar"
        context.env.slackChannel = "es-cicd-reports-${context.env.bitbucketKey.toLowerCase()}"

        configStorage.initStorage()

        context.echo "Environment vars : $context.env"
        context.echo "Creado directorio de configuracion $context.env.pipelineConfigDir/"
        context.sh "ls -la ${configStorage.directoryConfig()}/resources"


        def wbParams = completeWorkBenchParameters(context)

        configStorage.getConfigsFromYamlFile("$context.env.pipelineConfigDir/pipelineConfig.yml")

        def almsPackage = new VFESALMSDeployment(wbParams.alms_id, wbParams.artifact_id, wbParams.deploy_env, wbParams.commit_id, wbParams.delivery, wbParams.project_id, wbParams.squad)
        configStorage.props.almsPackage = almsPackage

        context.echo "Actual Global Variable CurrentBuild ${context.currentBuild.displayName}"

        context.currentBuild.displayName = "#${context.env.BUILD_NUMBER}-${almsPackage.jobDisplayName}"
        context.currentBuild.description = almsPackage.jobDescription

        configStorage.props.extractFolder = configStorage.props.extractFolder + "/" + wbParams.artifact_id

        if (configStorage.props.gitRepoPath != "") {
            def gitRepoURL = configStorage.props.gitRepoPath + wbParams.artifact_id + ".git"
            context.echo "Git Repo URL: ${gitRepoURL}"
            context.gitRepo = new VFESGitRepo("${gitRepoURL}", context)
        } else {
            context.gitRepo = new VFESGitRepo("${configStorage.props.gitRepo}", context)
        }

    }

    @NonCPS
    def completeWorkBenchParameters(context) {
        context.echo "completeWorkBenchParameters"
        WorkBenchServiceIntegration wbParams = new WorkBenchServiceIntegration(context)

        context.echo wbParams.toString()
        return wbParams

    }

    @Override
    Object run() {
        return null
    }
}

