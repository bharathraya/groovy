package vfes.stages.tool.maven

import com.cloudbees.groovy.cps.NonCPS
import vfes.stages.defaults.DefaultSourceCodeManagement
import vfes.storage.configs.ConfigStorage
import vfes.storage.secure.SecretsStorage

class MavenSourceCodeManagement extends DefaultSourceCodeManagement{

    @Override
    def initialize(Script context, SecretsStorage secretsStorage, ConfigStorage configStorage) {
        super.initialize(context, secretsStorage, configStorage)

    }

    @Override
    def exec() {
        context.echo "Ejecutando Maven Source Code Management"
        super.exec()
        def artifacts=detectChangedArtifacts(configStorage.props)
        "https://${urlNexus}/#browse/search=keyword%3D${groupId}:snapshots%3A${artifactId}%3A${groupId}%3A${version}"
        "https://${urlNexus}/#browse/search=keyword%3D${groupId}:76d7d7e4186a390fa9a368814e827842"
        https://webpre-adm.es.sedc.internal.vodafone.com:44100/nexus/service/local/artifact/maven/redirect?r=snapshots%3Da=dxl-common-ulff-logging%3Ag=es.vodafone.chatbot%3Av=0.0.1-SNAPSHOT

        "http://31.4.249.63:8080/nexus/service/local/artifact/maven/redirect?r=snapshots&g=dxl-common-ulff-logging&a=es.vodafone.chatbot&v=0.0.1-SNAPSHOT&p=pom"
        context.echo "Artifacts: ${artifacts}"
    }


    def detectMavenArtifactsWithProperties(String projectPath){
        def artifacts=[]
        context.dir("${projectPath}"){
            def poms=context.findFiles glob:"**/pom.xml"
            if(poms) {
                poms.each { pomfile ->
                    context.echo "name: ${pomfile.name} path: ${pomfile.path} directory: ${pomfile.directory}"
                    def pom = context.readMavenPom file: pomfile.path
                    context.echo "    packaging:${pom.packaging}"
                    if (pom.packaging ==~ /[jwe]ar/){
                        context.echo "    packaging:${pom.packaging}"
                        def artifact=[groupId:"${pom.groupId}",artifactId:"${pom.artifactId}",version:"${pom.version}",packaging:"${pom.packaging}",pomfile:"${pomfile.name}"]
                        context.echo "artifact:${artifact}"
                        artifacts+=artifact

                    }
                }
            }
        }
        return artifacts

    }

    def detectChangedArtifacts(Map config){
        def ret=null
        switch(config.artifactDetection) {
            case 'maven_full_compile':
                context.echo "Detecting all maven artifacts... "
                ret=detectMavenArtifactsWithProperties(config.extractFolder)
                break
        }
        return ret
    }
}
