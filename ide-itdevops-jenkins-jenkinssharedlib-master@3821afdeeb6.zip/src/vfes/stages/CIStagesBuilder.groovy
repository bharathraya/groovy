package vfes.stages

import vfes.stages.interfaces.EnvironmentPreparation
import vfes.stages.interfaces.SourceCodeManagement
import vfes.stages.interfaces.StageExecutor
import vfes.storage.configs.ConfigStorage
import vfes.storage.secure.JenkinsSecretsStorage
import vfes.storage.secure.SecretsStorage

public final class CIStagesBuilder implements Serializable {
    private CIStages cIStages;
    private Script context
    private SecretsStorage secretsStorage
    private ConfigStorage config

    private CIStagesBuilder() { cIStages = new CIStages(); }

    public static CIStagesBuilder builder() { return new CIStagesBuilder(); }

    public CIStagesBuilder jenkinsContext(Script context) {
        this.context = context
        return this
    }

    public CIStagesBuilder secretsStorage(SecretsStorage secretsStorage = new JenkinsSecretsStorage()) {
        this.secretsStorage = secretsStorage
        return this
    }

    public CIStagesBuilder configStorage(ConfigStorage configStorage) {
        this.config = configStorage
        return this
    }

    public CIStagesBuilder environmentPreparation(EnvironmentPreparation environmentPreparation) {
        environmentPreparation.initialize(context, secretsStorage, config)
        cIStages.setEnvironmentPreparation(environmentPreparation);
        return this;
    }

    public CIStagesBuilder sourceCodeManagement(SourceCodeManagement stageExecutor) {
        stageExecutor.initialize(context, secretsStorage, config)
        cIStages.setSourceCodeManagement(stageExecutor);
        return this;
    }


    public CIStagesBuilder compile(StageExecutor compile) { cIStages.setCompile(compile); return this; }

    public CIStagesBuilder unitTest(StageExecutor unitTest) { cIStages.setUnitTest(unitTest); return this; }

    public CIStagesBuilder codeInspection(StageExecutor codeInspection) {
        cIStages.setCodeInspection(codeInspection); return this;
    }

    public CIStagesBuilder generateArtifact(StageExecutor generateArtifact) {
        cIStages.setGenerateArtifact(generateArtifact); return this;
    }

    public CIStagesBuilder uploadArtifact(StageExecutor uploadArtifact) {
        cIStages.setUploadArtifact(uploadArtifact); return this;
    }

    public CIStages create() { return cIStages; }
}
