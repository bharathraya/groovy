package vfes.stages.interfaces

interface EnvironmentPreparation extends StageExecutor{

}