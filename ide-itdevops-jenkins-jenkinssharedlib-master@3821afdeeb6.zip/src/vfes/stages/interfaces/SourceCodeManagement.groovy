package vfes.stages.interfaces

interface SourceCodeManagement extends StageExecutor{

}