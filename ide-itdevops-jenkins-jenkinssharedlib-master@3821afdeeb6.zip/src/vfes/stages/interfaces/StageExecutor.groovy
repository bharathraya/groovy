package vfes.stages.interfaces

import com.cloudbees.groovy.cps.NonCPS
import vfes.storage.configs.ConfigStorage
import vfes.storage.secure.SecretsStorage

interface StageExecutor extends Serializable{

    def initialize(Script context, SecretsStorage secretsStorage, ConfigStorage configStorage)
    @NonCPS
    def exec()
}