package vfes.git

import groovy.json.JsonSlurper
import java.text.SimpleDateFormat

class VFESGitMergeInfo_aaresmi implements Serializable {
    String commitBefore=""
    String commitAfter=""
    String commitPackage=""
	String developCommitId=""
	String developTag=""

    def filesChanged=[]
	def FilesChangedDetailed=[]


}