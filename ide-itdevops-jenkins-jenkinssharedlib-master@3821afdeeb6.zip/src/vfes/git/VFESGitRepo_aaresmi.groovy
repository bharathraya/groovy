package vfes.git

import groovy.json.JsonSlurper
import java.text.SimpleDateFormat

class VFESGitRepo_aaresmi implements Serializable {
    String server=""
    String protocol=""
    String checkoutCred=""
    String pushCred=""
    String repoPath=""
    String repoName=""
    String repoType=""
	String repoProjectKey=""
	String remoteBranch=""
	String localBranch=""
    def context=null
    final String GITLAB="Gitlab"
    final String BITBUCKET="Bitbucket"
    final String INTEGRATION_BB_PREFIX="vodafone"
    final String RELEASE_BB_PREFIX="release"
    final String FEATURE_BB_PREFIX="feature"
    final String REGEX_RELEASE=  /ES[0-9]*[A-Za-z_]*/
    final String REGEX_RELEASE_RC=  /ES[0-9]*[A-Za-z_]*-RC/
    final String REGEX_RELEASE_TEAM= /[A-Za-z_0-9]*-ES[0-9]*[A-Za-z_]*/
    final String REGEX_MASTER_DEVELOP= /(master|masterCI|develop)/
    final String REGEX_ENVIRONMENTS= /(SIT1|SIT1CI|PPRD|EBU|PPRD1|PPRDCI|PPRD1CI|SIT2|SIT3|SIT2CI|HID|HID1|HIDCI|HID1CI)/
    final String NO_PROXY='eswltbhr,eswltbhr.es.sedc.internal.vodafone.com,webpre-adm.es.sedc.internal.vodafone.com,*.internal.vodafone.com,195.233.178.75,195.233.178.97'
    VFESGitRepo_aaresmi(_protocol,_server,_credential,_repoPath,_repoName){
        // For case  when only one credential is needed
        this(_protocol,_server,_credential,_credential,_repoPath,_repoName)
    }

    VFESGitRepo_aaresmi(_protocol,_server,_checkoutCredential,_pushCredential,_repoPath,_repoName){
        this.server=_server
        this.protocol=_protocol
        this.checkoutCred=_checkoutCredential
        this.pushCred=_pushCredential
        this.repoPath=_repoPath
        this.repoName=_repoName
    }
    VFESGitRepo_aaresmi(_url,_context){
        this.context=_context
        // decompose repo url
        def regex=( _url =~ /(http|https):\/\/([a-zA-Z0-9.\-_]*(:[0-9]{1,5})?)\/([a-zA-Z0-9.\-_\/]*)\/([a-zA-Z0-9.\-_]*\.git)/)
        this.protocol=regex[0][1]
        this.server=regex[0][2]
        this.repoPath=regex[0][4]
        this.repoName=regex[0][5]


        // Determine repo type
            // server ends with :8282 and repoPath starts with /entregas/ --> Gitlab
            // else --> Bitbucket
        if (this.server.endsWith(":8282") && this.repoPath.startsWith("entregas/")){
            this.repoType=GITLAB
            this.checkoutCred="vfjenkins-passwd"
            this.pushCred="vfjenkins-passwd"
        }
        else if (this.server.endsWith(":42520") && this.repoPath.startsWith("bitbucket/") ){
            this.repoType=BITBUCKET
			this.repoProjectKey=this.repoPath.tokenize('/').last()
            this.checkoutCred="workbench_write_bitbucketLocal"
            this.pushCred="workbench_write_bitbucketLocal"
        }
        else if (this.server=="bitbucket.vodafone.es" && this.repoPath.startsWith("bitbucket/") ){
            this.server="webpre-adm.es.sedc.internal.vodafone.com:42520"
            this.repoType=BITBUCKET
			this.repoProjectKey=this.repoPath.tokenize('/').last()
            this.checkoutCred="workbench_write_bitbucketLocal"
            this.pushCred="workbench_write_bitbucketLocal"
        }
        else{
            this.repoType=BITBUCKET
			this.repoProjectKey=this.repoPath.tokenize('/').last()
            this.checkoutCred="essvc.essvc-devops-Bitbucket"
            this.pushCred="essvc.essvc-devops-URLEncode"
        }
    }

    VFESGitRepo_aaresmi(_url,_context,_repotype){
        this.context=_context
        // decompose repo url
        def regex=( _url =~ /(http|https):\/\/([a-zA-Z0-9.\-_]*(:[0-9]{1,5})?)\/([a-zA-Z0-9.\-_\/]*)\/([a-zA-Z0-9.\-_]*\.git)/)
        this.protocol=regex[0][1]
        this.server=regex[0][2]
        this.repoPath=regex[0][4]
        this.repoName=regex[0][5]


        // Determine repo type
            // server ends with :8282 and repoPath starts with /entregas/ --> Gitlab
            // else --> Bitbucket
        if (_repotype=="GITLAB" ){
            this.repoType=GITLAB
            this.checkoutCred="vfjenkins-passwd"
            this.pushCred="vfjenkins-passwd"
        }
        else if (_repotype=="BITBUCKET_LOCAL"){
            this.repoType=BITBUCKET
            this.checkoutCred="workbench_write_bitbucketLocal"
            this.pushCred="workbench_write_bitbucketLocal"
        }
        else if (this.server=="bitbucket.vodafone.es" && this.repoPath.startsWith("bitbucket/") ){
            this.server="webpre-adm.es.sedc.internal.vodafone.com:42520"
            this.repoType=BITBUCKET
			this.repoProjectKey=this.repoPath.tokenize('/').last()
            this.checkoutCred="workbench_write_bitbucketLocal"
            this.pushCred="workbench_write_bitbucketLocal"
        }
        else{
            this.repoType=BITBUCKET
            this.checkoutCred="essvc.essvc-devops-Bitbucket"
            this.pushCred="essvc.essvc-devops-URLEncode"
        }
    }
    def checkoutCommit (_folder,_commitId){
        def url=protocol+"://"+server+"/"+repoPath+"/"+repoName
        def vfRepoPath=repoPath
        this.context.sh "rm -rf ${_folder}"
        if (this.repoType==GITLAB){
            vfRepoPath=(this.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
        }
        url=this.protocol+"://"+this.server+"/"+vfRepoPath+"/"+this.repoName
        def commit=_commitId

        this.context.echo """
        Doing checkout
        URL:           ${url}
        Commit:	       ${_commitId}
        Folder:        ${_folder}"""

        this.context.checkout (
                    [
                            $class: 'GitSCM',
                            branches: [[name: "${_commitId}"]],
                            doGenerateSubmoduleConfigurations: false,
                            extensions: [
                                [$class: 'RelativeTargetDirectory', relativeTargetDir: "${_folder}"]
                            ],
                            submoduleCfg: [],
                            userRemoteConfigs: [
                                [
                                    credentialsId: "${this.checkoutCred}",
                                    url: "${url}"
                                ]
                            ]
                        ])

    }
	def getBranchWithPrefix(_branch){
        if (this.repoType==BITBUCKET)
            switch (_branch){
                case ~REGEX_MASTER_DEVELOP:
                    return _branch
                case ~REGEX_RELEASE  :
                    return RELEASE_BB_PREFIX+"/"+_branch
                case ~REGEX_RELEASE_RC  :
                    return RELEASE_BB_PREFIX+"/"+_branch
                case ~REGEX_RELEASE_TEAM :
                    return RELEASE_BB_PREFIX+"/"+_branch
                case ~REGEX_ENVIRONMENTS:
                    return INTEGRATION_BB_PREFIX+"/"+_branch
                default:
                    return FEATURE_BB_PREFIX+"/"+_branch
        }
        else return _branch
    }
    def checkoutCommit(_folder,_branch,_commitId){
        def url=protocol+"://"+server+"/"+repoPath+"/"+repoName
        def vfRepoPath=repoPath
        this.context.sh "rm -rf ${_folder}"
        if (this.repoType==GITLAB){
            vfRepoPath=(this.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
        }
        url=this.protocol+"://"+this.server+"/"+vfRepoPath+"/"+this.repoName
        def branch=getBranchWithPrefix(_branch)
        this.localBranch=_branch
		this.remoteBranch=branch
        this.context.echo """
        Doing checkout
        URL:           ${url}
        Remote branch: ${branch}
        Local branch:  ${_branch}
        Folder:        ${_folder}"""

        this.context.checkout (
                    [
                            $class: 'GitSCM',
                            branches: [[name: "${_commitId}"]],
                            doGenerateSubmoduleConfigurations: false,
                            extensions: [
                                [$class: 'RelativeTargetDirectory', relativeTargetDir: "${_folder}"]
                            ],
                            submoduleCfg: [],
                            userRemoteConfigs: [
                                [
                                    credentialsId: "${this.checkoutCred}",
                                    url: "${url}"
                                ]
                            ]
                        ])
        this.context.dir("${_folder}"){
            this.context.sh "git checkout -B ${_branch}"
            this.context.sh "git branch"
        }


    }
    // merge (_folder,_commitID)
    //  _folder - Folder relative to WORKSPACE where git repo will be extracted
    //  _branch -> name of remote branch to extract
    def cloneBranchToLocalFolder (_folder,_branch){
        def url=protocol+"://"+server+"/"+repoPath+"/"+repoName
        def vfRepoPath=repoPath
        this.context.sh "rm -rf ${_folder}"
        if (this.repoType==GITLAB){
            vfRepoPath=(this.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
        }
        url=this.protocol+"://"+this.server+"/"+vfRepoPath+"/"+this.repoName
        def branch=getBranchWithPrefix(_branch)
        this.localBranch=_branch
		this.remoteBranch=branch
        this.context.echo """
        Doing checkout
        URL:           ${url}
        Remote branch: ${branch}
        Local branch:  ${_branch}
        Folder:        ${_folder}"""

        this.context.checkout (
                    [
                            $class: 'GitSCM',
                            branches: [[name: "*/${branch}"]],
                            doGenerateSubmoduleConfigurations: false,
                            extensions: [
                                [$class: 'LocalBranch', localBranch: "${_branch}"],
                                [$class: 'RelativeTargetDirectory', relativeTargetDir: "${_folder}"]
                            ],
                            submoduleCfg: [],
                            userRemoteConfigs: [
                                [
                                    credentialsId: "${this.checkoutCred}",
                                    url: "${url}"
                                ]
                            ]
                        ])
		this.context.dir (_folder){
			//this.context.sh "git checkout -B ${_branch}"
			this.context.echo "CHECKOUT -B"
		}

    }

    // mergeCommitFromDevelop (_folder,_commitID,_commitMessage)
    //  _folder - Folder relative to WORKSPACE where git repo has been extracted
    //  _commitID -> commit to merge locally
    //  _commitMessage -> Commit messsage
    def mergeCommitFromDevelop(_folder,_commitID,_commitMessage,_packageId){
        def useCommitId=_commitID
        this.context.dir("${_folder}"){
            def mergeInfo=new VFESGitMergeInfo()
            mergeInfo.commitPackage=_commitID
            mergeInfo.commitBefore = this.context.sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            this.context.echo "GitCommit Before MERGE: ${mergeInfo.commitBefore}"
            // add remote and fetch
            // en el caso Gitlab añadir el remoto entregas y hacer fetch ...
            this.context.sh """
                git config user.email DL-SP-CM-DEP@vodafone.com
                git config user.name 'C&DM team'
            """
            if (repoType==GITLAB){
                this.context.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${checkoutCred}",
                        usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                    def entregasURL=protocol+"://"+this.context.USERNAME+":"+this.context.PASSWORD+"@"+this.server+"/"+repoPath+"/"+this.repoName
                    this.context.echo "url=${entregasURL}"
                    this.context.sh """
                    unset HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
                    git remote add entregas ${entregasURL}
                    git fetch entregas
                    """
                }
            }

            // Get the tags named "PACKAGE-<>" pointed to by this commitID
            try{
                def package_tag=this.context.sh(returnStdout: true, script: "git tag --points-at ${_commitID} | grep PACKAGE-${_packageId}").toString().trim()
                this.context.echo "Found package_tag: ${package_tag}"
                def develop_tag="develop-"+package_tag
                def develop_commitID=this.context.sh(returnStdout: true, script: "git rev-list -n 1  ${develop_tag}").toString().trim()
                this.context.echo "Found Develop tag: ${develop_tag} ${develop_commitID}"
				mergeInfo.developCommitId=develop_commitID
				mergeInfo.developTag=develop_tag
                useCommitId=develop_tag
            }
            catch(Exception e){

                this.context.echo "Error while finding develop tag!!!"

                this.context.error "Error ${e} while finding develop tag for ${_commitID}!!!"

            }
            try{
                this.context.sh "git merge --no-ff -m'${_commitMessage}' ${useCommitId} "
            }
            catch(Exception){
                this.context.echo "There are following merge conflicts!"
                this.context.sh '''
                set +x
                git diff --name-only --diff-filter=U | while read f
                do
                echo $f
                git log --follow --pretty='%h %>(18,trunc)%ai %<(25,trunc)%ce %<(50,trunc)%s' -5 $f
                echo
                done
                '''
                this.context.error('Stopping the job, has merge conflicts!!!')
            }
            mergeInfo.commitAfter = this.context.sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
            this.context.echo "GitCommit AFter MERGE: ${mergeInfo.commitAfter}"
            mergeInfo.filesChanged=this.context.sh(returnStdout: true, script: "git diff --name-only ${mergeInfo.commitBefore}..${mergeInfo.commitAfter}").split()
            return mergeInfo
        }

    }


    // mergeCommit (_folder,_commitID)
    //  _folder - Folder relative to WORKSPACE where git repo has been extracted
    //  _commitID -> commit to merge locally
    //  _commitMessage -> Commit messsage
    def mergeCommit(_folder,_commitID,_commitMessage){
        this.context.dir("${_folder}"){
            def mergeInfo=new VFESGitMergeInfo_aaresmi()
            mergeInfo.commitPackage=_commitID
            mergeInfo.commitBefore = this.context.sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
			this.context.echo "GitCommit branch: "
			this.context.sh "git branch"
            this.context.echo "GitCommit Before MERGE: ${mergeInfo.commitBefore}"

            // en el caso Gitlab añadir el remoto entregas y hacer fetch ...
            this.context.sh """
                git config user.email DL-SP-CM-DEP@vodafone.com
                git config user.name 'C&DM team'
            """
            if (repoType==GITLAB){
                this.context.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${checkoutCred}",
                        usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                    def entregasURL=protocol+"://"+this.context.USERNAME+":"+this.context.PASSWORD+"@"+this.server+"/"+repoPath+"/"+this.repoName
                    this.context.echo "url=${entregasURL}"
                    this.context.sh """
                    unset HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
                    git remote add entregas ${entregasURL}
                    git fetch entregas
                    """
                }
            }

            try{
                this.context.sh "git merge --no-ff -m'${_commitMessage}' ${_commitID} "
            }
            catch(Exception){
                this.context.echo "There are following merge conflicts!"
                this.context.sh '''
                set +x
                git diff --name-only --diff-filter=U | while read f
                do
                echo $f
                git log --follow --pretty='%h %>(18,trunc)%ai %<(25,trunc)%ce %<(50,trunc)%s' -5 $f
                echo
                done
                '''
                this.context.error('Stopping the job, has merge conflicts!!!')
            }
            mergeInfo.commitAfter = this.context.sh(returnStdout: true, script: 'git rev-parse HEAD').toString().trim()
			this.context.echo "GitCommit branch: "
			this.context.sh "git branch"
            this.context.echo "GitCommit AFter MERGE: ${mergeInfo.commitAfter}"
            this.context.sh ("git diff --name-status ${mergeInfo.commitBefore}..${mergeInfo.commitAfter}")
            mergeInfo.filesChanged=this.context.sh(returnStdout: true, script: "git diff --name-only ${mergeInfo.commitBefore}..${mergeInfo.commitAfter}").split()

            def script="""git diff --name-status ${mergeInfo.commitBefore}..${mergeInfo.commitAfter} | while read f
            do
            STATUS=\${f:0:1}
            if [[ \${STATUS} != "R" ]]
            then
            FILE=\${f:2}
            echo "\${STATUS}#\${FILE}"
            else
            OLD=`echo \$f | awk '{print \$2}'`
            NEW=`echo \$f | awk '{\$1=\$2=""; print \$0}' | sed 's/^[[:space:]]*//g'`
            echo "\${STATUS}#\${OLD}#\${NEW}"
            fi
            done"""

            def tmpfilesChangedDetailed=this.context.sh(returnStdout: true, script:script).split()
            def detailed=null
            def previous=null
            try{
                //for (detailed in tmpfilesChangedDetailed)
                //{
                    //this.context.echo "Añadiendo: ${detailed}"
                    //if (detailed.split('#')[0] != "R") {
                        //mergeInfo.FilesChangedDetailed.add([detailed.split('#')[0], detailed.split('#')[1]])
                    //} else {
                        //mergeInfo.FilesChangedDetailed.add([detailed.split('#')[0], detailed.split('#')[1],detailed.split('#')[2]])
                    //}
                //}
                tmpfilesChangedDetailed.each{
                    previous=detailed
                    detailed=it
                    if (detailed.split('#')[0] != "R") {
                        mergeInfo.FilesChangedDetailed.add([detailed.split('#')[0], detailed.split('#')[1]])
                        } else {
                        mergeInfo.FilesChangedDetailed.add([detailed.split('#')[0], detailed.split('#')[1],detailed.split('#')[2]])
                        }
                }
            }
            catch(Exception) {
                this.context.echo "There are error preparing the mergeInfo.FilesChangedDetailed"
                this.context.echo "Can be a white space in one of the registers."
                this.context.echo "The last register was ${detailed}"
                this.context.echo "And the previous register was ${previous}"
                this.context.error('Stopping the job, has error with mergeInfo.FilesChangedDetailed!!!')
            }
            return mergeInfo
        }
    }
    // tagAndPush (_folder,_commitID)
    //  _folder - Folder relative to WORKSPACE where git repo has been extracted
    //  _tagName -> Tag name for -a parameter
    //  _tagMsg -> Tag message for -m parameter
    //  _branch -> Branch to push
    def simpleTagAndPush(_folder,_tagName,_tagMsg,_branch,_packageId){
        def _localBranch=_branch
        def _remoteBranch=getBranchWithPrefix(_branch)
        def vfRepoPath=repoPath
        if (this.repoType==GITLAB){
            vfRepoPath=(this.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
        }

        this.context.dir(_folder){
            this.context.sh """
                git config user.email DL-SP-CM-DEP@vodafone.com
                git config user.name 'C&DM team'
            """

            this.context.sh "git tag -a ${_tagName} -m '${_tagMsg}'"
            this.context.sh "git tag -f -a ${_branch} -m '${_tagMsg}'"
            this.context.sh "git tag -f -a PACKAGE-${_packageId} -m '${_tagMsg}'"
            // realizar un set-url con las credenciales para el origen para poder hacer un push ...
            this.context.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pushCred}",
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                def pushUrl=protocol+"://"+context.USERNAME+":"+context.PASSWORD+"@"+this.server+"/"+vfRepoPath+"/"+this.repoName
                this.context.echo "url=${pushUrl}"
                this.context.sh "git remote set-url origin ${pushUrl}"
            }
            this.context.sh """
                export NO_PROXY=${NO_PROXY}
                export no_proxy=${NO_PROXY}
                unset HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
                git push  --force  origin  ${_tagName} refs/tags/${_branch} PACKAGE-${_packageId}
            """
        }
    }
    // tagAndPushDevelop (_folder,_commitID)
    //  _folder - Folder relative to WORKSPACE where git repo has been extracted
    //  _tagName -> Tag name for -a parameter
    //  _tagMsg -> Tag message for -m parameter
    //  _branch -> Branch to push
    def tagAndPushDevelop(_folder,_tagName,_tagMsg,_branch,_packageId,_commitID){
        def _localBranch=_branch
        def _remoteBranch=getBranchWithPrefix(_branch)
        def vfRepoPath=repoPath
        if (this.repoType==GITLAB){
            vfRepoPath=(this.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
        }

        this.context.dir(_folder){
            this.context.sh "git tag -a ${_tagName} -m '${_tagMsg}'"

            this.context.sh "git tag -f -a develop-PACKAGE-${_packageId} -m '${_tagMsg}'"
            this.context.sh "git tag -f -a PACKAGE-${_packageId} -m '${_tagMsg}' ${_commitID}"

            // realizar un set-url con las credenciales para el origen para poder hacer un push ...
            this.context.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pushCred}",
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                def pushUrl=protocol+"://"+context.USERNAME+":"+context.PASSWORD+"@"+this.server+"/"+vfRepoPath+"/"+this.repoName
                this.context.echo "url=${pushUrl}"
                this.context.sh "git remote set-url origin ${pushUrl}"
            }
            this.context.sh """
                export NO_PROXY=${NO_PROXY}
                export no_proxy=${NO_PROXY}
                unset HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
                git push --tags --force origin develop-PACKAGE-${_packageId} PACKAGE-${_packageId}
                git push --tags origin ${_localBranch}:${_remoteBranch}
            """
        }
    }

    // tagAndPush (_folder,_commitID)
    //  _folder - Folder relative to WORKSPACE where git repo has been extracted
    //  _tagName -> Tag name for -a parameter
    //  _tagMsg -> Tag message for -m parameter
    //  _branch -> Branch to push
    def tagAndPush(_folder,_tagName,_tagMsg,_branch){
        def _localBranch=_branch
        def _remoteBranch=getBranchWithPrefix(_branch)
        def vfRepoPath=repoPath
        if (this.repoType==GITLAB){
            vfRepoPath=(this.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
        }

        this.context.dir(_folder){
            this.context.sh "git tag -a ${_tagName} -m '${_tagMsg}'"
            if (_branch=="develop"){

            }
            // realizar un set-url con las credenciales para el origen para poder hacer un push ...
            this.context.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pushCred}",
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                def pushUrl=protocol+"://"+context.USERNAME+":"+context.PASSWORD+"@"+this.server+"/"+vfRepoPath+"/"+this.repoName
                this.context.echo "url=${pushUrl}"
                this.context.sh "git remote set-url origin ${pushUrl}"
            }
            this.context.sh """
                export NO_PROXY=${NO_PROXY}
                export no_proxy=${NO_PROXY}
                unset HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
                git push --tags origin ${_localBranch}:${_remoteBranch}
            """
        }
    }
// tagAndPush (_folder,_commitID)
    //  _folder - Folder relative to WORKSPACE where git repo has been extracted
    //  _tagName -> Tag name for -a parameter
    //  _tagMsg -> Tag message for -m parameter
    //  _branch -> Branch to push
    def tagAndPushWithRollback(_folder,_tagName,_tagMsg,_branch,_mergeInfo){
        def _localBranch=_branch
        def _remoteBranch=getBranchWithPrefix(_branch)
        def vfRepoPath=repoPath
        if (this.repoType==GITLAB){
            vfRepoPath=(this.repoPath =~ /^entregas\//).replaceFirst('vodafone/')
        }

        this.context.dir(_folder){
            this.context.sh "git tag -a BEFORE-${_tagName} ${_mergeInfo.commitBefore} -m '[BEFORE]${_tagMsg}'"
            this.context.sh "git tag -a PACKAGE-${_tagName} ${_mergeInfo.commitPackage} -m '[PACKAGE]${_tagMsg}'"
            this.context.sh "git tag -a DEPLOYED-${_tagName} -m '[DEPLOYED]${_tagMsg}'"
            // realizar un set-url con las credenciales para el origen para poder hacer un push ...
            this.context.withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: "${pushCred}",
                    usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                def pushUrl=protocol+"://"+context.USERNAME+":"+context.PASSWORD+"@"+this.server+"/"+vfRepoPath+"/"+this.repoName
                this.context.echo "url=${pushUrl}"
                this.context.sh "git remote set-url origin ${pushUrl}"
            }
            this.context.sh """
                export NO_PROXY=${NO_PROXY}
                export no_proxy=${NO_PROXY}
                unset HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
                git push --tags origin ${_localBranch}:${_remoteBranch}
            """
            if (this.repoType==GITLAB){
                this.context.sh """
                    export NO_PROXY=${NO_PROXY}
                    export no_proxy=${NO_PROXY}
                    unset HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
                    git push entregas ALMS-${_tagName}
                """
            }
        }
    }
}
