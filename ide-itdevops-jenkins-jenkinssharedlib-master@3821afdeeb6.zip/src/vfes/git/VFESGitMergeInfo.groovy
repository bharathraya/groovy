package vfes.git

import groovy.json.JsonSlurper
import java.text.SimpleDateFormat

class VFESGitMergeInfo implements Serializable {
    String commitBefore=""
    String commitAfter=""
    String commitPackage=""
	String developCommitId=""
	String developTag=""

    def filesChanged=[]


}
