package vfes.bitbucket

import com.cloudbees.groovy.cps.NonCPS
import groovy.json.JsonSlurper

class Bitbucket implements Serializable{
    def context=null
    String baseUrl=""
    String protocol=""
    String server=""
    String projectKey=""
    String repoSlug=""
    String basicAuthCredential=""
    String repoUrl=""


    Bitbucket(_context,String _gitUrl,String _basicAuthCredential){
        def capture=null
        this.repoUrl=_gitUrl
        final String BITBUCKET_URL_REGEX=/((http|https|git):\/\/([0-9a-zA-Z._-]*)(:[0-9]{1,6})?\/(([0-9a-zA-Z\._-]*)\/)?)scm\/([a-zA-Z0-9_-]*)\/([a-zA-Z0-9_-]*)(\.git)/
        if((capture = _gitUrl =~ BITBUCKET_URL_REGEX)){
            this.baseUrl=capture.group(1)
            this.protocol=capture.group(2)
            this.projectKey=capture.group(7)
            this.repoSlug=capture.group(8)
        }
        this.context=_context
        this.basicAuthCredential=_basicAuthCredential

    }
    @NonCPS
    Map getRequestResult(responseCode,request){
        Map resultJson=[:]
        def result="{}"
        try{
            if (responseCode>=200 && responseCode<=299){
                result = request.getInputStream().getText()

            }else {
                 result = request.getErrorStream().getText()
            }
        }
        catch(Exception e){
            this.context.echo ("Exception when trying to retrieve request body : ${e}")
        }
        if(result!=""){
            resultJson=this.readJson(result)
        }
        return resultJson
    }
    @NonCPS
    Map manageHttpRestRequest(String uri,String httpRequestType,String bodyMessage){
        //this.context.echo(this.baseUrl+uri)
        def request = new URL(this.baseUrl+uri).openConnection()
        request.setRequestProperty("Content-Type", "application/json")
        request.setRequestProperty ("Authorization", this.basicAuthCredential);
        request.setRequestMethod(httpRequestType)
        request.setDoOutput(true)
        if (bodyMessage !=""){

            request.getOutputStream().write(bodyMessage.getBytes("UTF-8"))
        }
        def getRC = request.getResponseCode();

        //this.context.echo("ResponseCode:"+getRC);
        def resultJson=getRequestResult(getRC,request)
        Map resultObject=[:]
        resultObject["httpCode"]=getRC
        resultObject["resultObject"]=resultJson
        request=null
        return resultObject

    }
	@NonCPS
	String parsePullRequestMessage(message){
		def regex=/^Merge pull request \#([0-9]*) in .*/
		def m=(commitMessage =~ regex)
		def PR=m ? m[0][1] : ""
		return PR
	}
	
	def getCurrentMergedPRForBranches(String source,String target){
		return getCurrentPRForBranchesStatus(source,target,"MERGED")
	}
	def getCurrentOpenPRForBranches(String source,String target){
		return getCurrentPRForBranchesStatus(source,target,"OPEN")
	}

	def getCurrentPRForBranchesStatus(String source,String target,String  status){
		def pullRequest=new BitbucketPullRequest("","",this.projectKey,this.repoSlug,"",source,target)
		def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests?at=refs/heads/${target}&state=${status}"
		this.context.echo ("getCurrentPRForBranchesStatus: ${source} ${target} ${status}")
		Map resultMap =manageHttpRestRequest(uri,"GET","")
		if (resultMap.resultObject.size>0){
			def foundPR=null
			this.context.echo ("SIZE: "+resultMap.resultObject.size)
			for (int contadorPR=0;contadorPR<resultMap.resultObject.size;contadorPR++){
				this.context.echo (resultMap.resultObject.values[contadorPR].fromRef.id+" vs refs/heads/${source}")
				if (resultMap.resultObject.values[contadorPR].fromRef.id=="refs/heads/${source}") {
					this.context.echo ("Found!")
					foundPR=resultMap.resultObject.values[contadorPR]
					break
				}
			}
			if (foundPR!=null){
				pullRequest=new BitbucketPullRequest(foundPR.title,foundPR.description,this.projectKey,this.repoSlug,"",source,target)
				pullRequest.pullRequestId=foundPR.id
            	pullRequest.isCreated=false
				pullRequest.status=status
			}
		}
		return pullRequest		
	}
	def getLastPRForBranches(String source,String target){
		def result=["id":"","commitId":"","author":"","email":"","createdAt":0,"message":""]
		def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/commits?merges=only&until=${target}&since=${source}"
		Map resultMap =manageHttpRestRequest(uri,"GET","")
		result.id=parsePullRequestMessage(resultMap.resultObject.values[0].message)
		result.commitId=resultMap.resultObject.values[0].id
		result.author=resultMap.resultObject.values[0].committer.name
		result.email=resultMap.resultObject.values[0].committer.emailAddress
		result.message=resultMap.resultObject.values[0].message
		result.createdAt=resultMap.resultObject.values[0].committerTimestamp
	}

    String getPRDetails(String pullRequestId){
        def result=["commitId":"","author":"","email":"","createdAt":0,"message":""]
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${pullRequestId}/activities"
        Map resultMap =manageHttpRestRequest(uri,"GET","")
        def action=resultMap.resultObject.values.find{it.action=="MERGED"}
        println "action commit.id: ${action.commit.id}"
        result.commitId=action.commit.id
        result.author=action.commit.committer.name
        result.email=action.commit.committer.emailAddress
        result.message=action.commit.message
        result.createdAt=action.commit.committerTimestamp
        return result
    }
    String getPullRequestCommidId(String pullRequestId){
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${pullRequestId}/activities"
        Map resultMap =manageHttpRestRequest(uri,"GET","")
        def action=resultMap.resultObject.values.find{it.action=="MERGED"}
        println "action commit.id: ${action.commit.id}"
        return action.commit.id
    }
    Map getPullRequestChangedFiles(String pullRequestId){
        Map result=["changedFiles":[]]
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${pullRequestId}/diff"
        Map resultMap =manageHttpRestRequest(uri,"GET","")
		this.context.echo "resultMap=${resultMap}"  
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
            for (int i=0;i<resultMap.resultObject.diffs.size();i++){
              if (resultMap.resultObject.diffs[i].source != null){
                	result.changedFiles << resultMap.resultObject.diffs[i].source.toString
              }
            }
            
          return result
        }
        else{
          this.context.echo "httpCode: ${resultMap.httpCode}"
          	result.changedFiles=""
          	return result
        }
    }
    boolean deletePullRequest(String pullRequestId, String pullRequestVersion){
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${pullRequestId}"
        Map resultMap =manageHttpRestRequest(uri,"DELETE","""{ "version":${pullRequestVersion} }""")
        true
    }
    String getLastCommitOfBranch(String branchName){
        String uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/branches?filterText=${branchName}"
        Map resultMap=manageHttpRestRequest(uri,"GET","")
        def commitId=""
        if (resultMap.resultObject.size >=1){
          //println "values: ${resultMap.resultObject.values}"
        	def indexCommit=0
            for (indexCommit=0;indexCommit< resultMap.resultObject.size;indexCommit++){
              //println "values[${indexCommit}]: ${resultMap.resultObject.values[indexCommit]}"
              if(resultMap.resultObject.values[indexCommit].displayId =="$branchName"){
              	commitId= resultMap.resultObject.values[indexCommit].latestCommit
              }
            }
            if(commitId==""){
              this.context.echo "Warning No existe la rama: ${branchName}"
            }
            return commitId
        }else{
              this.context.echo "Warning No existe la rama: ${branchName}"
              return commitId
        }
    }
    boolean declinePullRequest(String pullRequestId, String pullRequestVersion,String comment){
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${pullRequestId}/decline?version=${pullRequestVersion}"
        Map resultMap=manageHttpRestRequest(uri,"POST","")
        if (comment!=""){
            addCommentToPullRequest(pullRequestId,comment)
        }
        true
    }
    boolean addCommentToPullRequest(String pullRequestId,String comment){
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${pullRequestId}/comments"
        Map resultMap=manageHttpRestRequest(uri,"POST","""{"text":"${comment}"}""")
    }
    Map getPullRequestInfo(String prId){
        Map result=[:]
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${prId}"
        Map resultMap =manageHttpRestRequest(uri,"GET","")
        result=resultMap.resultObject
        return result
    }
    boolean createTag(String commitId,String tag,String tagMessage){
        String body=""" { "name": "${tag}",
    "startPoint": "${commitId}",
    "message": "${tagMessage}" } """
        String uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/tags"
        Map resultMap =manageHttpRestRequest(uri,"POST",body)

    }
    boolean mergePullRequest(String prId,String version)
    {
        String result=""
        Map prInfo=this.getPullRequestInfo(prId)
        this.context.echo("Current PR-${prId} version: ${prInfo.version}")
        this.context.echo("prInfo: ${prInfo}")
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${prId}/merge?version=${prInfo.version}"
        Map resultMap =manageHttpRestRequest(uri,"POST","")
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
            this.context.echo "PR-${prId} merged successfully!!"
            return resultMap.resultObject.canMerge
        }
        else{
            this.context.echo "Error when merging PR-${prId}!!! : ${resultMap.httpCode} ${resultMap.resultObject}"
            return false
        }
    }
    @NonCPS
    private static def readJson(String text){
        def jsonSlurper = new JsonSlurper()
        return jsonSlurper.parseText(text)
    }
    boolean checkPullRequestCanMerge(String prId)
    {

        String result=""
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests/${prId}/merge"
        Map resultMap =manageHttpRestRequest(uri,"GET","")
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
            return resultMap.resultObject.canMerge
        }
        else{
            return false
        }
    }
    String getLatestMergedPullRequest(_sourcebranch,_targetbranch){
        String resultPR=""
        String uri="rest/api/1.0/projects/IDE-WBPRUEB/repos/ide-wbprueb-java-mavenexampleproject/commits?&merges=only&until=refs/heads/${_targetbranch}&since=refs/heads/${_sourcebranch}"
        Map resultMap=manageHttpRestRequest(uri,"GET",pullRequest.getJSON())
        if (!resultMap.containsKey("resultObject")){
            return resultPR
        }
        if (!resultMap.containsKeys("values")){
            return resultPR
        }
        def commits=resultMap.resultObject.values
        def searchPRRegex="Merge pull request #([0-9]*) in ([-a-zA-Z0-9_]*/[-a-zA-Z0-9_]*) from ${_sourcebranch} to ${_targetbranch}"
        for (indexCommit=0;idexCommit< commits.size();indexCommit++){
            if((capture = commits[indexCommit].message =~ /${searchPRRegex}/)){
                resultPR=capture.group(1)
            }
        }
        return resultPR

    }
    BitbucketPullRequest createPullRequest(_title,_description,_prType,_sourcebranch,_targetbranch){
        def pullRequest=new BitbucketPullRequest(_title,_description,this.projectKey,this.repoSlug,_prType,_sourcebranch,_targetbranch)
        String uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/pull-requests"
        Map resultMap=manageHttpRestRequest(uri,"POST",pullRequest.getJSON())
        def postRC = resultMap.httpCode
        def resultJson=null
        if (postRC>=200 && postRC<=299){
            resultJson=resultMap.resultObject
            this.context.echo "resultJson:${resultJson}"
            pullRequest.pullRequestId=resultJson.id
            pullRequest.pullRequestVersion=resultJson.version
            pullRequest.sourceCommitId=resultJson.fromRef.latestCommit
            pullRequest.isCreated=true
            pullRequest.canMerge=this.checkPullRequestCanMerge(pullRequest.pullRequestId)
            this.context.echo "Pull request created (${_sourcebranch} -> ${_targetbranch}): PR-${pullRequest.pullRequestId} sourceCommitId:${pullRequest.sourceCommitId}"
        }
        else{
            this.context.echo "Could not create pull request (${_sourcebranch} -> ${_targetbranch}), check if it is already existing "
            this.context.echo "Bitbucket API result: ${resultMap.resultObject}"
            pullRequest.pullRequestError="Could not create pull request (${_sourcebranch} -> ${_targetbranch}), check if it is already existing"
        }

        return pullRequest
    }
    boolean delGitTag(String tag){
        this.context.echo "delGitTag ($tag)"
        def uri="rest/git/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/tags/${tag}"
        Map resultMap=manageHttpRestRequest(uri,"DELETE","")
        return true
    }
    boolean addTag(String tag, String Commit, String Message){
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/tags"
        Map resultMap=manageHttpRestRequest(uri,"POST","""
          {
            "name": "${tag}",
            "startPoint": "${Commit}",
            "message": "${Message}"
          }
        """)
        return true
    }

    boolean addGitTag(String tag, String Commit, String Message){
        this.context.echo "addGitTag(${tag},${Commit},${Message})"
        def uri="rest/git/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/tags"
        Map resultMap=manageHttpRestRequest(uri,"POST","""
          {
            "force": "true",
            "message": "${Message}",
            "name": "${tag}",
            "startPoint": "${Commit}",
            "type": "LIGHTWEIGHT",
            "message": "${Message}"
          }
        """)
        return true
    }
    boolean getCommitFromTagFilter(String filter){
        String commitId=""
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/tags?${filter}"
        Map resultMap=manageHttpRestRequest(uri,"GET","")
      this.context.echo "resultMap:${resultMap}"
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
          if (resultMap.resultObject.size >=1){
                    commitId= resultMap.resultObject.values[0].latestCommit
                }
            this.context.echo "commit.id: ${commitId}"
                return commitId
        }
        else{
            this.context.echo "Error No existe el tag!!! : ${label}"
            return false
        }
    }
    boolean getCommitFromTagFilter(String delivery,String commit){
        this.context.echo "getCommitFromTagFilter ($delivery,$commit)"
        String commitId=""
        def uri="rest/api/1.0/projects/${this.projectKey}/repos/${this.repoSlug}/tags?filterText=${commit}"
        Map resultMap=manageHttpRestRequest(uri,"GET","")
      this.context.echo "resultMap:${resultMap}"
        if (resultMap.httpCode>=200 && resultMap.httpCode<=299){
          if (resultMap.resultObject.size >=1){
              commitId=""
              //println "values: ${resultMap.resultObject.values}"
            	def indexCommit=0
              for (indexCommit=0;indexCommit< resultMap.resultObject.size;indexCommit++){
                  //println "values[${indexCommit}]: ${resultMap.resultObject.values[indexCommit]}"
                  if(resultMap.resultObject.values[indexCommit].displayId =~ /(?i)${delivery}.*${commit}/){
                  	commitId= resultMap.resultObject.values[indexCommit].latestCommit
                  }
              }
              if(commitId==""){
                  this.context.echo "Warning No existe el tag!!! : ${delivery}.*${commit}"
              }
              return commitId
          }else{
              this.context.echo "Warning No existe el tag!!! : ${delivery}.*${commit}"
              return commitId
          }
        }
        else{
            this.context.echo "Warning httpCode : ${resultMap.httpCode}"
            return commitId
        }
    }

}