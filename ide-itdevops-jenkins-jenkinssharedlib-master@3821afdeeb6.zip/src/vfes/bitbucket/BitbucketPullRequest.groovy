package vfes.bitbucket
import groovy.json.JsonOutput

class BitbucketPullRequest implements Serializable {
    static final String DELIVERY_REQUEST="deliveryRequest"
    static final String INTEGRATION_REQUEST="integrationRequest"
    String sourceBranch=""
    String sourceCommitId=""
    String pullRequestVersion=""
    String targetBranch=""
    String targetCommitId=""
    String pullRequestId=""
    String [] reviewers=[]
    String status=""
    boolean canMerge=false
    boolean isCreated=false
    String projectKey=""
    String repoSlug=""
    String title=""
    String description=""
    String pullRequestWBType=""
    String pullRequestError=""


    String getJSON(){
        def body=[title: this.title,
                  description: this.description,
                  state: "OPEN",
                  open: true,
                  closed: false,
                  fromRef: [
                          id: "refs/heads/"+this.sourceBranch,
                          "repository": [
                                  "slug": this.repoSlug,
                                  "name": null,
                                  "project": [
                                          "key": this.projectKey
                                  ]
                          ]
                  ],
                  "toRef": [
                          id: "refs/heads/"+this.targetBranch,
                          "repository": [
                                  "slug": this.repoSlug,
                                  "name": null,
                                  "project": [
                                          "key": this.projectKey
                                  ]
                          ]
                  ],
                  "locked": false
                  ]

        return JsonOutput.toJson(body)
    }

    BitbucketPullRequest(_title,_description,_project,_repo,_prWbType,_sourceBranch,_targetBranch){
        this.title=_title
        this.description=_description
        this.projectKey=_project
        this.repoSlug=_repo
        this.pullRequestWBType=_prWbType
        this.sourceBranch=_sourceBranch
        this.targetBranch=_targetBranch
    }

}