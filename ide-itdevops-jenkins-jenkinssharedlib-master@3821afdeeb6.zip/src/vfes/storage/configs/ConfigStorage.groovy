package vfes.storage.configs

interface ConfigStorage extends Serializable{
        Map props=[:]
        def getConfigsFromYamlFile(String yamlFile)
        def getConfigsFromJsonFile(String jsonFile)
        def getConfigsFromProperties(String propetiesFile)
        def getConfigsFromPropertiesWithDefaultValues(String propetiesFile, Map defaultValues)
        def getContentsFile(String file)
        def getContentsFileByLines(String file)
        def initStorage()
        def directoryConfig()

}