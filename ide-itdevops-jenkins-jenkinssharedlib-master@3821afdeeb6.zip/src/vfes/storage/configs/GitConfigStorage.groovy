package vfes.storage.configs

import com.cloudbees.groovy.cps.NonCPS
import vfes.storage.secure.SecretsStorage
import hudson.model.*

//@CompileStatic
class GitConfigStorage implements ConfigStorage {
    private String url
    private String branch
    private String credentialsId
    private String directoryConfig
    private SecretsStorage secretsStorage
    def context

    GitConfigStorage(Script context, SecretsStorage secretsStorage, String url, String branch, String credentialsId, String directoryConfig = "configurations") {
        this.context = context
        this.secretsStorage = secretsStorage
        this.url = url
        this.branch = branch
        this.credentialsId = credentialsId
        this.directoryConfig = directoryConfig

    }

//    @NonCPS
    @Override
    def initStorage() {
        try {
            context.sh "env"
            context.echo "INICIANDO CONFIG STORAGE....con params ${this.toString()}"
            context.sh "echo \"$directoryConfig/\" >> .gitignore"
            secretsStorage.getUsernameAndPassword(credentialsId)
            def creds = secretsStorage.getUsernameAndPassword(credentialsId)
            context.echo "Credentials User is $creds.username"

            def strings = this.url.split("//")
            def newUrl = "${strings[0]}//${creds.username}:${creds.password}@${strings[1]}"
            def configBaseDir = context.env?.pipelineConfigDir
            def configDirProject = context.env?.pipelineConfigDirProject

            context.echo "URL inicial  ${this.url}"
            context.echo "Directorio de configuración  ${configBaseDir}"
            context.echo "Directorio de configuración del Proyecto  ${configDirProject}"

            def gitBranch = 'master'
            def existBranch = context.sh(returnStdout: true,
                    script: "git ls-remote --heads $newUrl ${context.env?.BRANCH_NAME} | wc -l").trim()

            context.echo "Exist Branch ${existBranch}"

            if(!context.env?.GIT_URL) {
                context.echo "No se encontro la variable GIT_URL se generara"
                getBBGitUrl(context)
            }


            if (existBranch == '1') {
                gitBranch = context.env?.BRANCH_NAME
            }

            context.sh """
                  rm -fr $directoryConfig
                  mkdir $directoryConfig
                  cd $directoryConfig
                  git init
                  git remote add -f configstore "$newUrl"
      
                  git config core.sparseCheckout true                    
                   
                  echo $configBaseDir > .git/info/sparse-checkout
                  
                  git pull configstore $gitBranch
                 """
            context.sh "cat $directoryConfig/.git/info/sparse-checkout"
            def defaultProperties = getConfigsFromProperties("$configBaseDir/pipelineConfig.properties")
            def projectProperties = getConfigsFromPropertiesWithDefaultValues("$configBaseDir/$configDirProject/pipelineConfig.properties",defaultProperties)

            projectProperties.each {
                context.env[it.key.replace('.','_')] = it.value
                context.echo "${it.key.replace('.','_')} -- ${it.value}"
            }
            context.echo "${projectProperties}"
            context.sh 'env'

        } catch (Exception ex) {
            context.echo "No tiene pipelineConfig.properties definido para este proyecto ${ex.getMessage()}"
        }
    }

    private getBBGitUrl(context) {
        def build = context.$build()
        context.echo "PROJECT NAME ${build?.project?.name}"
        context.env['GIT_BRANCH'] = build?.project?.name?.replace('%2F','/')
        def scm = build.parent.getSCMs()

        def repo = scm.find{ !it.getKey()?.contains('didi') }
        if(repo) {
            def gitURL = repo.getKey().replace('git ','')
            context.echo "REPOSITORY BB ${ gitURL}"
            context.env['GIT_URL'] = gitURL
        }

    }

    @NonCPS
    private getFile(String file) {
        return new File("$directoryConfig/$file")
    }

    @Override
    Map getConfigsFromYamlFile(String yamlFile) {
        context.echo "leemos fichero Yaml $directoryConfig/$yamlFile"
        def map = context.readYaml(file: "$directoryConfig/$yamlFile")
        context.echo "SHOW Params $map.gitRepoPath"
        props.putAll(map)
        return map
    }

    @Override
    Map getConfigsFromJsonFile(String jsonFile) {
        def map = context.readJSON(file: "$directoryConfig/$jsonFile")
        props.putAll(map)
        return map
    }

    @Override
    def getConfigsFromProperties(String propetiesFile) {
        def map = context.readProperties(file: "$directoryConfig/$propetiesFile")
        props.putAll(map)
        return map
    }

    @Override
    def getConfigsFromPropertiesWithDefaultValues(String propetiesFile, Map defaultValues) {
        def map = context.readProperties(defaults: defaultValues, file: "$directoryConfig/$propetiesFile")
        props.putAll(map)
        return map
    }

    @NonCPS
    @Override
    def getContentsFile(String file) {
        def text = getFile(file).text
        props.put(file, text)
    }

    @NonCPS
    @Override
    def getContentsFileByLines(String file) {
        return getFile(file).readLines()
    }

    String directoryConfig() {
        return directoryConfig
    }

    @NonCPS
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("GitConfigStorage{");
        sb.append("url='").append(url).append('\'');
        sb.append(", branch='").append(branch).append('\'');
        sb.append(", credentialsId='").append(credentialsId).append('\'');
        sb.append(", directoryConfig='").append(directoryConfig).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
