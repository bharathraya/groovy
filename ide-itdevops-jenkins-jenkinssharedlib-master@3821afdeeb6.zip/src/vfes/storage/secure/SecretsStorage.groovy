package vfes.storage.secure

import com.cloudbees.groovy.cps.NonCPS

interface SecretsStorage {
    @NonCPS
    def getSecretText(String credentialID)
    @NonCPS
    def getUsernameAndPassword(String credentialID)
    @NonCPS
    def getSecretFile(String credentialID)
    @NonCPS
    def getPrivateKey(String credentialID)
    @NonCPS
    def getCertificate(String credentialID)

}