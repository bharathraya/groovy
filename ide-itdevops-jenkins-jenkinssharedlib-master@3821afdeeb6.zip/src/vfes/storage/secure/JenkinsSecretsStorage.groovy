package vfes.storage.secure

import com.cloudbees.groovy.cps.NonCPS
import com.cloudbees.plugins.credentials.Credentials
import com.cloudbees.plugins.credentials.CredentialsProvider
import jenkins.model.Jenkins

class JenkinsSecretsStorage implements SecretsStorage {

    List<Credentials> jenkinsCredentials

    JenkinsSecretsStorage() {
        this.jenkinsCredentials = CredentialsProvider.lookupCredentials(
                com.cloudbees.plugins.credentials.Credentials.class,
                Jenkins.getInstanceOrNull(),
                null,
                null
        );
    }

    @NonCPS
    @Override
    def getSecretText(String credentialID) {
        return null
    }

    @NonCPS
    @Override
    def getUsernameAndPassword(String credentialID) {
        for (creds in jenkinsCredentials) {
            if (creds.id == credentialID) {
                println(creds.username)
                println(creds.password)
                return creds
            }
        }
        return null
    }

    @NonCPS
    @Override
    def getSecretFile(String credentialID) {
        return null
    }

    @NonCPS
    @Override
    def getPrivateKey(String credentialID) {
        return null
    }

    @NonCPS
    @Override
    def getCertificate(String credentialID) {
        return null
    }
}
