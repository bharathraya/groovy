#!/bin/ksh

DT=${timestamp}
LOG=${devopsPath}/${appName}-${alms}-${'$'}{DT}.log
(if [ ! -d ${rootPath} ]
then
	echo "${rootPath} does not exist!!!"
	exit 99
fi
cd ${rootPath}
if [ "$(echo ${zip2deploy} | grep '.zip$')" != "" ]
then
	rollback_file=${devopsPath}/rollback-backup-${appName}-${alms}-${'$'}{DT}.sh
	if [ -d ${deployPath} ]
	then
		cd ${deployPath}
		echo "Doing backup of all files under ${deployPath} in zip ${devopsPath}/backup-${appName}-${alms}-${'$'}{DT}.zip "
		zip -r ${devopsPath}/backup-${appName}-${alms}-${'$'}{DT}.zip *  | awk \'BEGIN {ORS=" "} {if(NR%10==0)print "."}\'
		cd ..
		rm -rf ${deployPath}
		cd ${rootPath}
		echo "#!/bin/ksh " >> ${'$'}{rollback_file}
		echo "cd ${rootPath}" >> ${'$'}{rollback_file}
		echo "rm -rf ${deployPath}"  >> ${'$'}{rollback_file}
		echo "mkdir -p ${deployPath}"  >> ${'$'}{rollback_file}
		echo "cd ${deployPath}"  >> ${'$'}{rollback_file}
		echo "unzip -o ${devopsPath}/backup-${appName}-${alms}-${'$'}{DT}.zip"  >> ${'$'}{rollback_file}
	else
		echo "We do not backup as folder ${deployPath} does not exist. We create folder"
		cd ${rootPath}
		echo "#!/bin/ksh " >> ${'$'}{rollback_file}
		echo "cd ${rootPath}" >> ${'$'}{rollback_file}
		echo "rm -rf ${deployPath}"  >> ${'$'}{rollback_file}
	fi
	mkdir -p ${deployPath}
	cd ${deployPath}
	echo "Deploying on /${deployPath} contents of ${devopsPath}/${zip2deploy}"
	unzip -o ${devopsPath}//${zip2deploy}  | awk \'BEGIN {ORS=" "} {if(NR%10==0)print "."}\'
	find . -type d -exec chmod a+rx {} \;
	find . -type f -exec chmod a+r {} \;
elif [ "$(echo ${zip2deploy} | grep '.tar.gz\$')" != "" -o "$(echo ${zip2deploy} | grep '.tgz\$')" != "" ]
then
	rollback_file=${devopsPath}/rollback-backup-${appName}-${alms}-${'$'}{DT}.tarbak.sh
	if [ -d ${deployPath} ]
	then
		cd ${deployPath}
		echo "Doing backup of files under ${deployPath} in file ${devopsPath}/backup-${appName}-${alms}-${'$'}{DT}.tar.gz"
		tar cvfz ${devopsPath}/backup-${appName}-${alms}-${'$'}{DT}.tar.gz *
		cd ..
		rm -rf ${deployPath}
		cd ${rootPath}
		echo "#!/bin/ksh " >> ${'$'}{rollback_file}
		echo "cd ${rootPath}" >> ${'$'}{rollback_file}
		echo "rm -rf ${deployPath}"  >> ${'$'}{rollback_file}
		echo "mkdir -p ${deployPath}"  >> ${'$'}{rollback_file}
		echo "cd ${deployPath}"  >> ${'$'}{rollback_file}
		echo "tar xvfz ${devopsPath}/backup-${appName}-${alms}-${'$'}{DT}.tar.gz"  >> ${'$'}{rollback_file}
	else
		echo "We do not backup as folder ${deployPath} does not exist. We create folder"
		cd ${rootPath}
		echo "#!/bin/ksh " >> ${'$'}{rollback_file}
		echo "cd ${rootPath}" >> ${'$'}{rollback_file}
		echo "rm -rf ${deployPath}"  >> ${'$'}{rollback_file}
	fi
	mkdir -p ${deployPath}
	cd ${deployPath}
	echo "Deploying on ${rootPath}/${deployPath} contents of ${devopsPath}/${zip2deploy}"
	tar xvfz ${devopsPath}/${zip2deploy}
	find . -type d -exec chmod a+rx {} \;
	find . -type f -exec chmod a+r {} \;
fi 2>&1) | tee -a ${'$'}{LOG}
