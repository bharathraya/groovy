#!/bin/ksh

DT=$(date +'%Y%m%d%H%M%S')
(if [ ! -d ${rootPath} ]
then
	echo "${rootPath} does not exist!!!"
	exit 99
fi
cd ${rootPath}
if [ "$(echo ${zip2deploy} | grep '.zip$')" != "" ]
then
	echo "Deleting old backups backup-${appName}-*.zip "
	num_backups=$(ls -1t backup-${appName}-*.zip 2>/dev/null | wc -l )
	del_backups=$(( ${'$'}{num_backups} - 5 ))
	
	if [ ${'$'}{del_backups} -gt 0 ]
	then
		for fil in $(ls -1t backup-${appName}-*.zip | tail -${'$'}{del_backups})
		do
			echo "Deleting old backup file ${'$'}{fil}"
			rm ${'$'}{fil}
		done
	fi

	
	if [ -d ${deployPath} ]
	then
		cd ${deployPath}
		echo "Doing backup of all files under ${deployPath} in zip ${rootPath}/backup-${appName}-${alms}-${'$'}{DT}.zip "
		zip -r ${rootPath}/backup-${appName}-${alms}-${'$'}{DT}.zip *  | awk \'BEGIN {ORS=" "} {if(NR%10==0)print "."}\'
		cd ..
		rm -rf ${deployPath}
	else
		echo "We do not backup as folder ${deployPath} does not exist. We create folder"
	fi
	mkdir -p ${deployPath}
	cd ${deployPath}
	echo "Deploying on ${deployPath} contents of ${zip2deploy}"
	unzip -o ${rootPath}/${zip2deploy}  | awk \'BEGIN {ORS=" "} {if(NR%10==0)print "."}\'
	find . -type d -exec chmod a+rx {} \;
	find . -type f -exec chmod a+r {} \;
	# Create rollback script
	cd ${rootPath}
	rollback_file=rollback-backup-${appName}-${alms}-${'$'}{DT}.sh
	echo "#!/bin/ksh " >> ${'$'}{rollback_file}
	echo "rm -rf ${deployPath}"  >> ${'$'}{rollback_file}
	echo "mkdir -p ${deployPath}"  >> ${'$'}{rollback_file}
	echo "cd ${deployPath}"  >> ${'$'}{rollback_file}
	echo "unzip -o ${rootPath}/backup-${appName}-${alms}-${'$'}{DT}.zip"  >> ${'$'}{rollback_file}

elif [ "$(echo ${zip2deploy} | grep '.tar.gz\$')" != "" -o "$(echo ${zip2deploy} | grep '.tgz\$')" != "" ]
then
	echo "Deleting old backups backup-${appName}-*.tar.gz"
	rm -f backup-${appName}-*.tar.gz
	num_backups=$(ls -1t backup-${appName}-*.tar.gz | wc -l )
	del_backups=$(( ${'$'}{num_backups} - 5 ))
	
	if [ ${'$'}{del_backups} -gt 0 ]
	then
		for fil in $(ls -1t backup-${appName}-*.tar.gz | tail -${'$'}{del_backups})
		do
			echo "Deleting old backup file ${'$'}{fil}"
			rm ${'$'}{fil}
		done
	fi

	if [ -d ${deployPath} ]
	then
		cd ${deployPath}
		echo "Doing backup of files under ${deployPath} in file ${rootPath}/backup-${appName}-${alms}-${'$'}{DT}.tar.gz"
		tar cvfz ${rootPath}/backup-${appName}-${alms}-${'$'}{DT}.tar.gz *
		cd ..
		rm -rf ${deployPath}		
	else
		echo "We do not backup as folder ${deployPath} does not exist. We create folder"
	fi
	mkdir -p ${deployPath}
	cd ${deployPath}
	echo "Deploying on ${deployPath} contents of ${zip2deploy}"
	tar xvfz ${rootPath}/${zip2deploy}
	find . -type d -exec chmod a+rx {} \;
	find . -type f -exec chmod a+r {} \;

	# Create rollback script
	cd ${rootPath}
	rollback_file=rollback-backup-${appName}-${alms}-${'$'}{DT}.tarbak.sh
	echo "#!/bin/ksh " >> ${'$'}{rollback_file}
	echo "rm -rf ${deployPath}"  >> ${'$'}{rollback_file}
	echo "mkdir -p ${deployPath}"  >> ${'$'}{rollback_file}
	echo "cd ${deployPath}"  >> ${'$'}{rollback_file}
	echo "tar xvfz ${rootPath}/backup-${appName}-${alms}-${'$'}{DT}.tar.gz"  >> ${'$'}{rollback_file}

fi 2>&1) | tee -a ${appName}-${alms}-${'$'}{DT}.log