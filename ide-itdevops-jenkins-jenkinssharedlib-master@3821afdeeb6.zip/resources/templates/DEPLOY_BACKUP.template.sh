#!/bin/ksh

if [ ! -d ${rootPath} ]
then
	echo "${rootPath} does not exist!!!"
	exit 99
fi
cd ${rootPath}
if [ "$(echo ${zip2deploy} | grep '.zip$')" != "" ]
then
	echo "Deleting old backups backup-${appName}-*.zip "
	rm -f backup-${appName}-*.zip
	if [ -d ${deployPath} ]
	then
		cd ${deployPath}
		echo "Doing backup of files under ${deployPath} in zip ${rootPath}/backup-${appName}-${alms}-$(date +'%Y%m%d%H%M%S').zip "
		zipinfo -Z1 ${rootPath}/${zip2deploy} | grep -v '/\$' | zip ${rootPath}/backup-${appName}-${alms}-$(date +'%Y%m%d%H%M%S').zip -@
	else
		echo "We do not backup as folder ${deployPath} does not exist. We create folder"
		mkdir -p ${deployPath}
		cd ${deployPath}
	fi
	echo "Deploying on ${deployPath} contents of ${zip2deploy}"
	unzip -o ${rootPath}/${zip2deploy}
elif [ "$(echo ${zip2deploy} | grep '.tar.gz\$')" != "" -o "$(echo ${zip2deploy} | grep '.tgz\$')" != "" ]
then
	echo "Deleting old backups backup-${appName}-*.tar.gz"
	rm -f backup-${appName}-*.tar.gz
	if [ -d ${deployPath} ]
	then
		cd ${deployPath}
		echo "Doing backup of files under ${deployPath} in file ${rootPath}/backup-${appName}-${alms}-$(date +'%Y%m%d%H%M%S').tar.gz"
		tar tfz ${rootPath}/${zip2deploy} | grep -v '/\$' | tar cvfz ${rootPath}/backup-${appName}-${alms}-$(date +'%Y%m%d%H%M%S').tar.gz -T -
	else
		echo "We do not backup as folder ${deployPath} does not exist. We create folder"
		mkdir -p ${deployPath}
		cd ${deployPath}
	fi
	echo "Deploying on ${deployPath} contents of ${zip2deploy}"
	tar xvfz ${rootPath}/${zip2deploy}
fi
